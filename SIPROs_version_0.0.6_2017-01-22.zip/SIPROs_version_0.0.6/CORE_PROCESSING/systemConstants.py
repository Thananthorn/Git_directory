"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

 """

import numpy as np



class LV1_2ProductionConstants:
    MS_SAMPLE_PROCESS_BOX_SIZE = 6000
    # MS band to band registration processing box size
    MS_SAMPLE_GRID_STEP = 50
    # The sample grid size for MS band t0 band registration
    LOADOFFSET = 100
    # The number of additional lines in MS Band 1, 2 and 4
    # loaded before begin_line and after begin_line + im_height
    MS_MAX_WIDTH = 6000
    # The maximum number of pixels per line in MS image
    PAN_MAX_WIDTH = 12000
    # The maximum number of pixels per line in PAN image
    MS_MAX_PRECISION = 5.0
    # The maximum acceptable registration error in meters
    MS_PRECISION = 1.0
    # The desired registration errro in meters.
    MAX_ITERATION_BAND2BAND_CORRESPONDING_POINTS = 200
    # The maximum number of iterations in the point to point
    # registration process
    REMAP_MAX_ERROR = 0.1
    # The maximum error for band to band error when using one
    # set of polynomial for the entire scene.
    MIN_DN = 1 # minimum digital number in level1 and level2 product
    MAX_DN = 255 # maximum digital number in level1 and level2 product
    PAN_PROCESS_BOX_SIZE = 1000
    # process box size for PAN deconvolutional filter.
    PAN_OVERLAP_SIZE = 100
    # the left, right, up and down margins in PAN deconvolution.
    PAN_GAUSSIAN_SIZE = (3, 3)
    # Gaussian filter filter size
    PAN_GAUSSIAN_SIGMA = 3.3
    # Gaussian filter parameter, larger -> blurrier.
    PAN_CANNY_TH1 = 4
    # First threshold for Canny edge detection
    PAN_CANNY_TH2 = 8
    # Second threshold for Canny edge detection
    PAN_EDGE_KERNEL = np.ones((7 , 7))
    # Kernel used in edge enlargement
    PAN_SUM_KERNEL = np.ones((3,3),'float32')/9.0
    # The average filter kernel.
    PAN_TH1 = 0.75
    PAN_TH2 = 1.25
    PAN_TH3 = 1.75
    PAN_TH4 = 2.25
    # Filter 3: |Value - average| < PAN_TH1
    # Filter 4: PAN_TH1 <= |Value - average| < PAN_TH2
    # Filter 5: PAN_TH2 <= |Value - average| < PAN_TH3
    # Filter 6: PAN_TH3 <= |Value - average| < PAN_TH4
    # Filter 7: |Value - average| >= PAN_TH4

    DENCONVOLUTION = True
    # True for the deconvolution
    # Must be False if the ascending mode is used
    EQUALIZATION = True
    # True for the DN equalization
    # Must be False if the ascending mode is used
    LOSS_LINE_CORRECTION = True
    # True for loss line correction
    # Must be False if the ascending mode is used
    LOSS_LINE_N_MAX = 8
    # Maximum number of lines that loss line correction will performed.
    DESCENDING = True
    # True for descending scene and False for Ascending scene
    SAVED_MS_BAND_REGISTRATION_POINTS = True
    # True for saving band to band registration sample points
    LV1ToLV2_SAMPLE_GRID_SIZE = 50
    # the Level1A to Level 2A grid size
    LV2ToLV1_SAMPLE_GRID_SIZE = 10
    # the Level2A to Level 1A grid size
    SAVED_LV1ToLV2_SAMPLE = True
    # True for saving LV1 to LV2 sample points
    LV2ToLV1_ACCURACY = 0.1
    # Level 2 to level 1 maximum accuracy in term of pixel
    LV2ToLV1_NUM_ITER = 20
    # Maximum number of iteration for pixel location