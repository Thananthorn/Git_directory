import numpy as np
import cv2
from osgeo import gdal
from skimage.feature import register_translation

def computeRMS(im1,im2,dx,dy):
    im3 = cv2.getRectSubPix(im2, (im1.shape[1], im1.shape[0]),
                            ((im1.shape[1] - 1.) / 2. + dx, (im1.shape[0] - 1.) / 2. + dy))
    #im12 = im2[:,:]
    idx, idy = np.nonzero((im1 > 0) * (im3 > 0))
    rms = im1[idx, idy].astype('float32') - im3[idx, idy].astype('float32')
    rms = rms ** 2
    rms = rms.mean()
    rms = np.sqrt(rms)
    return rms




if __name__ == "__main__":
    myf = r"D:\Data2APanSharpen\LastSceneProblemsV2\42934\THEOS_1_LEVEL0_1_111042934_42934_MS_PB_TOP_2_28_2016-12-13_14-19-33\level1a\IMAGERY.tif"
    #My file
    org = r"D:\Data2APanSharpen\LastSceneProblemsV2\TH_CAT_161214083218898_1_1M_CHILE_SCENE2_old_product\TH_CAT_161214083218898_1\IMAGERY.TIF"
    # original Image

    outf = r"D:\Data2APanSharpen\LastSceneProblemsV2\42934\THEOS_1_LEVEL0_1_111042934_42934_MS_PB_TOP_2_28_2016-12-13_14-19-33\level1a\cmpInterpolateCubic"
    # output file
    myim = gdal.Open(myf)
    orgim = gdal.Open(org)
    n_band = orgim.RasterCount
    for band in range(n_band):
        myimb1 = myim.GetRasterBand(band+1)
        orgimb1 =  orgim.GetRasterBand(band+1)
        mygeo = myim.GetGeoTransform()
        orgeo = orgim.GetGeoTransform()

        offx = (mygeo[0]-orgeo[0])/orgeo[1]
        offy = (mygeo[3]-orgeo[3])/orgeo[5]
        mywidth = myim.RasterXSize
        myheight = myim.RasterYSize
        orgwidth = orgim.RasterXSize
        orgheight = orgim.RasterYSize
        outimage = np.zeros((orgheight,orgwidth,3),'uint8')
        #original in green color
        orgdata = orgimb1.ReadAsArray()
        outimage[:,:,1] = orgdata
        orgdata = None
        mydata = myimb1.ReadAsArray()
        U,V = np.mgrid[:orgwidth,:orgheight]
        U = U.T - offx
        V = V.T - offy
        imout = cv2.getRectSubPix(mydata, (orgwidth, orgheight),((orgwidth-1.)/2. - offx, (orgheight-1.)/2. - offy)) #cv2.remap(mydata,U.astype('float32'),V.astype('float32'),interpolation=cv2.INTER_CUBIC,
                  #borderMode= cv2.BORDER_CONSTANT,borderValue= 0 )
        outimage[:, :, 2] = imout

        cv2.imwrite(outf+"%d.tif"%(band+1),outimage)
        nrw, ncl = imout.shape
        im1 = outimage[nrw/2 - 2000: nrw/2 + 2000, ncl/2 - 2000: ncl/2 + 2000, 2].astype('float32')
        im2 = outimage[nrw/2 - 2000: nrw/2 + 2000, ncl/2 - 2000: ncl/2 + 2000, 1].astype('float32')
        nrw, ncl = im1.shape
        nrw = (nrw/2) * 2
        ncl = (ncl/2) * 2
        im1 = im1[:nrw, :ncl]
        im2 = im2[:nrw, :ncl]

        dx_best = 0
        dy_best = 0
        rms_min = computeRMS(im1, im2, 0 , 0)
        print "Original Root Mean Square Error: %f for Band %d with offset (%f,%f)!" % (rms_min, band + 1, offx, offy)
        if rms_min > 0:
            shift, error, diffphase = register_translation(im1, im2, 100)
            dx = shift[1]
            dy = shift[0]
            rms = computeRMS(im1, im2, dx , dy)
            # print dx, dy, rms
            if rms < rms_min:
                rms_min = rms
                dx_best = dx
                dy_best = dy
            print "At the register location, dx = %f, dy = %f, rms = %f." % (dx_best, dy_best, rms_min)

