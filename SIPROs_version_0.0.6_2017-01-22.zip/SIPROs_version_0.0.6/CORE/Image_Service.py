# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Image_Service.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui


try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Service(object):
    def setupUi(self, Service):
        Service.setObjectName(_fromUtf8("Service"))
        Service.setWindowModality(QtCore.Qt.NonModal)
        Service.setEnabled(True)
        Service.resize(761, 572)
        Service.setMinimumSize(QtCore.QSize(761, 572))
        Service.setMaximumSize(QtCore.QSize(761, 572))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        Service.setFont(font)
        Service.setAutoFillBackground(False)
        Service.setStyleSheet(_fromUtf8("#Service {\n"
"background-color: rgb(235,234,236);\n"
"border-radius: 10px;\n"
"}"))
        self.project_name = QtGui.QLabel(Service)
        self.project_name.setGeometry(QtCore.QRect(14, 4, 736, 38))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.project_name.setFont(font)
        self.project_name.setFocusPolicy(QtCore.Qt.NoFocus)
        self.project_name.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.project_name.setAutoFillBackground(False)
        self.project_name.setStyleSheet(_fromUtf8("#project_name{\n"
"image: url(Head.png);\n"
"}"))
        self.project_name.setFrameShape(QtGui.QFrame.NoFrame)
        self.project_name.setFrameShadow(QtGui.QFrame.Plain)
        self.project_name.setText(_fromUtf8(""))
        self.project_name.setTextFormat(QtCore.Qt.AutoText)
        self.project_name.setScaledContents(True)
        self.project_name.setAlignment(QtCore.Qt.AlignCenter)
        self.project_name.setWordWrap(False)
        self.project_name.setObjectName(_fromUtf8("project_name"))
        self.clear_all = QtGui.QPushButton(Service)
        self.clear_all.setGeometry(QtCore.QRect(653, 279, 101, 28))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.clear_all.setFont(font)
        self.clear_all.setAutoFillBackground(False)
        self.clear_all.setStyleSheet(_fromUtf8("#clear_all{\n"
"border-radius: 8px;\n"
"image:url(clear_BT.png);\n"
"background-color: rgb(235,234,236);\n"
"}\n"
"\n"
"#clear_all:pressed{\n"
"border-radius: 8px;\n"
"image:url(clear_BT_push.png);\n"
"background-color: rgb(235,234,236);\n"
"}"))
        self.clear_all.setText(_fromUtf8(""))
        self.clear_all.setObjectName(_fromUtf8("clear_all"))
        self.Exit = QtGui.QPushButton(Service)
        self.Exit.setGeometry(QtCore.QRect(315, 525, 101, 28))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.Exit.setFont(font)
        self.Exit.setAutoFillBackground(False)
        self.Exit.setStyleSheet(_fromUtf8("#Exit{\n"
"border-radius: 8px;\n"
"image:url(EX_BT.png);\n"
"background-color: rgb(235,234,236);\n"
"}"))
        self.Exit.setText(_fromUtf8(""))
        self.Exit.setObjectName(_fromUtf8("Exit"))
        self.scene_info_label = QtGui.QLabel(Service)
        self.scene_info_label.setGeometry(QtCore.QRect(399, 200, 129, 31))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.scene_info_label.setFont(font)
        self.scene_info_label.setAutoFillBackground(False)
        self.scene_info_label.setStyleSheet(_fromUtf8("#scene_info_label{\n"
"image:url(scene_info_label.png);\n"
"background-color: rgb(68,123,191);\n"
"border-radius: 6px;\n"
"}"))
        self.scene_info_label.setText(_fromUtf8(""))
        self.scene_info_label.setScaledContents(True)
        self.scene_info_label.setAlignment(QtCore.Qt.AlignCenter)
        self.scene_info_label.setWordWrap(True)
        self.scene_info_label.setObjectName(_fromUtf8("scene_info_label"))
        self.Revolution_frame = QtGui.QFrame(Service)
        self.Revolution_frame.setGeometry(QtCore.QRect(10, 50, 181, 141))
        self.Revolution_frame.setAutoFillBackground(False)
        self.Revolution_frame.setStyleSheet(_fromUtf8("#Revolution_frame{\n"
"background-color: rgb(255,255,255);\n"
"border-radius: 10px;\n"
"}"))
        self.Revolution_frame.setFrameShape(QtGui.QFrame.NoFrame)
        self.Revolution_frame.setFrameShadow(QtGui.QFrame.Raised)
        self.Revolution_frame.setObjectName(_fromUtf8("Revolution_frame"))
        self.revolution_number_label = QtGui.QLabel(self.Revolution_frame)
        self.revolution_number_label.setGeometry(QtCore.QRect(1, 0, 180, 31))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.revolution_number_label.setFont(font)
        self.revolution_number_label.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.revolution_number_label.setAutoFillBackground(False)
        self.revolution_number_label.setStyleSheet(_fromUtf8("#revolution_number_label{\n"
"image: url(Head_revolution.png);\n"
"background-color: rgb(68,123,191);\n"
"border-radius: 8px;\n"
"}"))
        self.revolution_number_label.setText(_fromUtf8(""))
        self.revolution_number_label.setScaledContents(True)
        self.revolution_number_label.setAlignment(QtCore.Qt.AlignCenter)
        self.revolution_number_label.setObjectName(_fromUtf8("revolution_number_label"))
        self.revolution_number = QtGui.QLineEdit(self.Revolution_frame)
        self.revolution_number.setGeometry(QtCore.QRect(10, 36, 90, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.revolution_number.setFont(font)
        self.revolution_number.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
        self.revolution_number.setAutoFillBackground(False)
        self.revolution_number.setStyleSheet(_fromUtf8("#revolution_number{\n"
"image:url(blank_rev_num.png);\n"
"border-radius: 8px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"#revolution_number:focus {\n"
"border-radius: 8px;\n"
"image:url(blank_rev_num.png);\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.revolution_number.setText(_fromUtf8(""))
        self.revolution_number.setMaxLength(99999)
        self.revolution_number.setAlignment(QtCore.Qt.AlignCenter)
        self.revolution_number.setDragEnabled(True)
        self.revolution_number.setReadOnly(False)
        self.revolution_number.setObjectName(_fromUtf8("revolution_number"))
        self.call_rev = QtGui.QPushButton(self.Revolution_frame)
        self.call_rev.setGeometry(QtCore.QRect(116, 36, 50, 28))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.call_rev.setFont(font)
        self.call_rev.setAcceptDrops(False)
        self.call_rev.setStyleSheet(_fromUtf8("#call_rev{\n"
"border-radius: 8px;\n"
"image:url(OK.png);\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#call_rev:pressed{\n"
"border-radius: 8px;\n"
"image:url(OK_push.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.call_rev.setText(_fromUtf8(""))
        self.call_rev.setObjectName(_fromUtf8("call_rev"))
        self.total_strip_label = QtGui.QLabel(self.Revolution_frame)
        self.total_strip_label.setGeometry(QtCore.QRect(10, 70, 80, 30))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.total_strip_label.setFont(font)
        self.total_strip_label.setAutoFillBackground(False)
        self.total_strip_label.setStyleSheet(_fromUtf8("#total_strip_label{\n"
"image:url(total_strip_label.png);\n"
"}"))
        self.total_strip_label.setText(_fromUtf8(""))
        self.total_strip_label.setScaledContents(True)
        self.total_strip_label.setAlignment(QtCore.Qt.AlignCenter)
        self.total_strip_label.setObjectName(_fromUtf8("total_strip_label"))
        self.total_strip = QtGui.QLineEdit(self.Revolution_frame)
        self.total_strip.setGeometry(QtCore.QRect(92, 70, 80, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.total_strip.setFont(font)
        self.total_strip.setAutoFillBackground(False)
        self.total_strip.setStyleSheet(_fromUtf8("#total_strip{\n"
"border-radius: 8px;\n"
"image:url(blank_total.png);\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#total_strip:focus{\n"
"border-radius: 8px;\n"
"image:url(blank_total.png);\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.total_strip.setText(_fromUtf8(""))
        self.total_strip.setAlignment(QtCore.Qt.AlignCenter)
        self.total_strip.setReadOnly(True)
        self.total_strip.setObjectName(_fromUtf8("total_strip"))
        self.total_scene_label = QtGui.QLabel(self.Revolution_frame)
        self.total_scene_label.setGeometry(QtCore.QRect(10, 107, 80, 30))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.total_scene_label.setFont(font)
        self.total_scene_label.setAutoFillBackground(False)
        self.total_scene_label.setStyleSheet(_fromUtf8("#total_scene_label{\n"
"image:url(total_scene_label.png);\n"
"}"))
        self.total_scene_label.setText(_fromUtf8(""))
        self.total_scene_label.setScaledContents(True)
        self.total_scene_label.setAlignment(QtCore.Qt.AlignCenter)
        self.total_scene_label.setObjectName(_fromUtf8("total_scene_label"))
        self.total_scene = QtGui.QLineEdit(self.Revolution_frame)
        self.total_scene.setGeometry(QtCore.QRect(92, 110, 80, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.total_scene.setFont(font)
        self.total_scene.setAutoFillBackground(False)
        self.total_scene.setStyleSheet(_fromUtf8("#total_scene{\n"
"border-radius: 8px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"image:url(blank_total.png);\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"#total_scene:focus{\n"
"border-radius: 8px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"image:url(blank_total.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.total_scene.setText(_fromUtf8(""))
        self.total_scene.setAlignment(QtCore.Qt.AlignCenter)
        self.total_scene.setReadOnly(True)
        self.total_scene.setObjectName(_fromUtf8("total_scene"))
        self.Scene_frame = QtGui.QFrame(Service)
        self.Scene_frame.setGeometry(QtCore.QRect(310, 50, 441, 141))
        self.Scene_frame.setAutoFillBackground(False)
        self.Scene_frame.setStyleSheet(_fromUtf8("#Scene_frame{\n"
"background-color: rgb(255,255,255);\n"
"border-radius: 8px;\n"
"}"))
        self.Scene_frame.setFrameShape(QtGui.QFrame.NoFrame)
        self.Scene_frame.setFrameShadow(QtGui.QFrame.Raised)
        self.Scene_frame.setObjectName(_fromUtf8("Scene_frame"))
        self.order_by_time = QtGui.QCheckBox(self.Scene_frame)
        self.order_by_time.setGeometry(QtCore.QRect(2, 2, 131, 28))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.order_by_time.setFont(font)
        self.order_by_time.setAutoFillBackground(False)
        self.order_by_time.setStyleSheet(_fromUtf8("#order_by_time{\n"
"image:url(order_by_time_check.png);\n"
"background-color: rgb(68,123,191);\n"
"border-radius: 5px;\n"
"}\n"
"\n"
"#order_by_time:indicator{\n"
"width: 12px;\n"
"height: 12px;\n"
"padding-left: 5px;\n"
"background-color: rgb(68,123,191);\n"
"image:url(order_by_uncheck.png);\n"
"}\n"
"\n"
"#order_by_time:indicator:unchecked{\n"
"width: 12px;\n"
"height: 12px;\n"
"padding-left: 5px;\n"
"background-color: rgb(68,123,191);\n"
"image:url(order_by_uncheck.png);\n"
"}\n"
"\n"
"#order_by_time:indicator:checked{\n"
"width: 12px;\n"
"height:12px;\n"
"padding-left: 5px;\n"
"background-color: rgb(68,123,191);\n"
"image:url(checked_order_by_time.png)\n"
"}"))
        self.order_by_time.setText(_fromUtf8(""))
        self.order_by_time.setCheckable(True)
        self.order_by_time.setAutoRepeat(False)
        self.order_by_time.setAutoExclusive(False)
        self.order_by_time.setObjectName(_fromUtf8("order_by_time"))
        self.date_label = QtGui.QLabel(self.Scene_frame)
        self.date_label.setGeometry(QtCore.QRect(2, 30, 35, 28))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.date_label.setFont(font)
        self.date_label.setAutoFillBackground(False)
        self.date_label.setStyleSheet(_fromUtf8("#date_label{\n"
"image:url(date_label.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.date_label.setText(_fromUtf8(""))
        self.date_label.setScaledContents(True)
        self.date_label.setAlignment(QtCore.Qt.AlignCenter)
        self.date_label.setWordWrap(True)
        self.date_label.setObjectName(_fromUtf8("date_label"))
        self.date_label_2 = QtGui.QLabel(self.Scene_frame)
        self.date_label_2.setGeometry(QtCore.QRect(93, 30, 10, 25))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.date_label_2.setFont(font)
        self.date_label_2.setAutoFillBackground(False)
        self.date_label_2.setStyleSheet(_fromUtf8("#date_label_2{\n"
"image:url(sign_date.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.date_label_2.setText(_fromUtf8(""))
        self.date_label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.date_label_2.setObjectName(_fromUtf8("date_label_2"))
        self.month = QtGui.QLineEdit(self.Scene_frame)
        self.month.setGeometry(QtCore.QRect(101, 30, 50, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.month.setFont(font)
        self.month.setAutoFillBackground(False)
        self.month.setStyleSheet(_fromUtf8("#month{\n"
"image:url(month.png);\n"
"border-radius: 6px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#month:focus{\n"
"border-radius: 6px;\n"
"image:url(month.png);\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.month.setText(_fromUtf8(""))
        self.month.setMaxLength(2)
        self.month.setAlignment(QtCore.Qt.AlignCenter)
        self.month.setDragEnabled(True)
        self.month.setReadOnly(False)
        self.month.setObjectName(_fromUtf8("month"))
        self.year = QtGui.QLineEdit(self.Scene_frame)
        self.year.setEnabled(True)
        self.year.setGeometry(QtCore.QRect(44, 30, 50, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.year.setFont(font)
        self.year.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.year.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
        self.year.setAutoFillBackground(False)
        self.year.setStyleSheet(_fromUtf8("#year{\n"
"image:url(years.png);\n"
"border-radius: 6px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#year:focus{\n"
"border-radius: 6px;\n"
"image:url(years.png);\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.year.setText(_fromUtf8(""))
        self.year.setMaxLength(4)
        self.year.setAlignment(QtCore.Qt.AlignCenter)
        self.year.setDragEnabled(True)
        self.year.setReadOnly(False)
        self.year.setCursorMoveStyle(QtCore.Qt.LogicalMoveStyle)
        self.year.setObjectName(_fromUtf8("year"))
        self.date_label_3 = QtGui.QLabel(self.Scene_frame)
        self.date_label_3.setGeometry(QtCore.QRect(151, 30, 10, 25))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.date_label_3.setFont(font)
        self.date_label_3.setAutoFillBackground(False)
        self.date_label_3.setStyleSheet(_fromUtf8("#date_label_3{\n"
"image:url(sign_date.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.date_label_3.setText(_fromUtf8(""))
        self.date_label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.date_label_3.setObjectName(_fromUtf8("date_label_3"))
        self.date = QtGui.QLineEdit(self.Scene_frame)
        self.date.setGeometry(QtCore.QRect(160, 30, 50, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.date.setFont(font)
        self.date.setAutoFillBackground(False)
        self.date.setStyleSheet(_fromUtf8("#date{\n"
"image:url(date.png);\n"
"border-radius: 6px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#date:focus{\n"
"border-radius: 6px;\n"
"image:url(date.png);\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.date.setText(_fromUtf8(""))
        self.date.setMaxLength(2)
        self.date.setAlignment(QtCore.Qt.AlignCenter)
        self.date.setDragEnabled(True)
        self.date.setReadOnly(False)
        self.date.setObjectName(_fromUtf8("date"))
        self.time_label = QtGui.QLabel(self.Scene_frame)
        self.time_label.setGeometry(QtCore.QRect(214, 28, 40, 28))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.time_label.setFont(font)
        self.time_label.setAutoFillBackground(False)
        self.time_label.setStyleSheet(_fromUtf8("#time_label{\n"
"image:url(time_label.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.time_label.setText(_fromUtf8(""))
        self.time_label.setScaledContents(True)
        self.time_label.setAlignment(QtCore.Qt.AlignCenter)
        self.time_label.setWordWrap(True)
        self.time_label.setObjectName(_fromUtf8("time_label"))
        self.center_hh = QtGui.QLineEdit(self.Scene_frame)
        self.center_hh.setGeometry(QtCore.QRect(258, 30, 50, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.center_hh.setFont(font)
        self.center_hh.setAutoFillBackground(False)
        self.center_hh.setStyleSheet(_fromUtf8("#center_hh{\n"
"image:url(time_field.png);\n"
"border-radius: 6px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#center_hh:focus{\n"
"border-radius: 6px;\n"
"image:url(time_field.png);\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.center_hh.setText(_fromUtf8(""))
        self.center_hh.setMaxLength(2)
        self.center_hh.setAlignment(QtCore.Qt.AlignCenter)
        self.center_hh.setDragEnabled(True)
        self.center_hh.setReadOnly(False)
        self.center_hh.setObjectName(_fromUtf8("center_hh"))
        self.time_label_2 = QtGui.QLabel(self.Scene_frame)
        self.time_label_2.setGeometry(QtCore.QRect(308, 33, 10, 20))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.time_label_2.setFont(font)
        self.time_label_2.setStyleSheet(_fromUtf8("#time_label_2{\n"
"image:url(sign_time.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.time_label_2.setText(_fromUtf8(""))
        self.time_label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.time_label_2.setObjectName(_fromUtf8("time_label_2"))
        self.center_mm = QtGui.QLineEdit(self.Scene_frame)
        self.center_mm.setGeometry(QtCore.QRect(318, 30, 50, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.center_mm.setFont(font)
        self.center_mm.setAutoFillBackground(False)
        self.center_mm.setStyleSheet(_fromUtf8("#center_mm{\n"
"image:url(time_field.png);\n"
"border-radius: 6px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#center_mm:focus{\n"
"border-radius: 6px;\n"
"image:url(time_field.png);\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.center_mm.setText(_fromUtf8(""))
        self.center_mm.setMaxLength(2)
        self.center_mm.setAlignment(QtCore.Qt.AlignCenter)
        self.center_mm.setDragEnabled(True)
        self.center_mm.setReadOnly(False)
        self.center_mm.setObjectName(_fromUtf8("center_mm"))
        self.time_label_3 = QtGui.QLabel(self.Scene_frame)
        self.time_label_3.setGeometry(QtCore.QRect(369, 33, 10, 20))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.time_label_3.setFont(font)
        self.time_label_3.setStyleSheet(_fromUtf8("#time_label_3{\n"
"image:url(sign_time.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.time_label_3.setText(_fromUtf8(""))
        self.time_label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.time_label_3.setObjectName(_fromUtf8("time_label_3"))
        self.center_ss = QtGui.QLineEdit(self.Scene_frame)
        self.center_ss.setGeometry(QtCore.QRect(380, 30, 50, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.center_ss.setFont(font)
        self.center_ss.setAutoFillBackground(False)
        self.center_ss.setStyleSheet(_fromUtf8("#center_ss{\n"
"image:url(time_field.png);\n"
"border-radius: 6px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#center_ss:focus{\n"
"border-radius: 6px;\n"
"image:url(time_field.png);\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.center_ss.setText(_fromUtf8(""))
        self.center_ss.setMaxLength(2)
        self.center_ss.setAlignment(QtCore.Qt.AlignCenter)
        self.center_ss.setDragEnabled(True)
        self.center_ss.setReadOnly(False)
        self.center_ss.setObjectName(_fromUtf8("center_ss"))
        self.order_by_scene_rank = QtGui.QCheckBox(self.Scene_frame)
        self.order_by_scene_rank.setGeometry(QtCore.QRect(2, 57, 167, 28))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.order_by_scene_rank.setFont(font)
        self.order_by_scene_rank.setAutoFillBackground(False)
        self.order_by_scene_rank.setStyleSheet(_fromUtf8("#order_by_scene_rank{\n"
"image:url(order_by_scene_check.png);\n"
"border-radius: 4px;\n"
"background-color: rgb(68,123,191);\n"
"}\n"
"\n"
"#order_by_scene_rank:indicator{\n"
"width: 12px;\n"
"height: 12px;\n"
"padding-left: 4px;\n"
"background-color: rgb(68,123,191);\n"
"image:url(order_by_uncheck.png);\n"
"}\n"
"\n"
"#order_by_scene_rank:indicator:unchecked{\n"
"width: 12px;\n"
"height: 12px;\n"
"padding-left: 4px;\n"
"background-color: rgb(68,123,191);\n"
"image:url(order_by_uncheck.png);\n"
"}\n"
"\n"
"#order_by_scene_rank:indicator:checked{\n"
"width: 12px;\n"
"height: 12px;\n"
"padding-left: 4px;\n"
"background-color: rgb(68,123,191);\n"
"image:url(checked_order_by_scene.png)\n"
"}\n"
""))
        self.order_by_scene_rank.setText(_fromUtf8(""))
        self.order_by_scene_rank.setCheckable(True)
        self.order_by_scene_rank.setAutoRepeat(False)
        self.order_by_scene_rank.setAutoExclusive(False)
        self.order_by_scene_rank.setObjectName(_fromUtf8("order_by_scene_rank"))
        self.strip_label = QtGui.QLabel(self.Scene_frame)
        self.strip_label.setGeometry(QtCore.QRect(2, 85, 54, 28))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.strip_label.setFont(font)
        self.strip_label.setAutoFillBackground(False)
        self.strip_label.setStyleSheet(_fromUtf8("#strip_label{\n"
"image:url(strip_ID_label.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.strip_label.setText(_fromUtf8(""))
        self.strip_label.setScaledContents(True)
        self.strip_label.setAlignment(QtCore.Qt.AlignCenter)
        self.strip_label.setWordWrap(True)
        self.strip_label.setObjectName(_fromUtf8("strip_label"))
        self.strip_id = QtGui.QLineEdit(self.Scene_frame)
        self.strip_id.setGeometry(QtCore.QRect(94, 85, 50, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.strip_id.setFont(font)
        self.strip_id.setAutoFillBackground(False)
        self.strip_id.setStyleSheet(_fromUtf8("#strip_id{\n"
"image:url(blank_stript_scene.png);\n"
"border-radius: 6px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#strip_id:focus{\n"
"border-radius: 6px;\n"
"image:url(blank_stript_scene.png);\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.strip_id.setText(_fromUtf8(""))
        self.strip_id.setMaxLength(999)
        self.strip_id.setAlignment(QtCore.Qt.AlignCenter)
        self.strip_id.setDragEnabled(True)
        self.strip_id.setObjectName(_fromUtf8("strip_id"))
        self.scene_rank_label = QtGui.QLabel(self.Scene_frame)
        self.scene_rank_label.setGeometry(QtCore.QRect(2, 110, 75, 28))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.scene_rank_label.setFont(font)
        self.scene_rank_label.setAutoFillBackground(False)
        self.scene_rank_label.setStyleSheet(_fromUtf8("#scene_rank_label{\n"
"image:url(scene_rank_label.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.scene_rank_label.setText(_fromUtf8(""))
        self.scene_rank_label.setScaledContents(True)
        self.scene_rank_label.setAlignment(QtCore.Qt.AlignCenter)
        self.scene_rank_label.setWordWrap(True)
        self.scene_rank_label.setObjectName(_fromUtf8("scene_rank_label"))
        self.scene_rank = QtGui.QLineEdit(self.Scene_frame)
        self.scene_rank.setGeometry(QtCore.QRect(94, 110, 50, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.scene_rank.setFont(font)
        self.scene_rank.setAutoFillBackground(False)
        self.scene_rank.setStyleSheet(_fromUtf8("#scene_rank{\n"
"image:url(blank_stript_scene.png);\n"
"border-radius: 6px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#scene_rank:focus{\n"
"border-radius: 6px;\n"
"image:url(blank_stript_scene.png);\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.scene_rank.setText(_fromUtf8(""))
        self.scene_rank.setMaxLength(999)
        self.scene_rank.setAlignment(QtCore.Qt.AlignCenter)
        self.scene_rank.setDragEnabled(True)
        self.scene_rank.setObjectName(_fromUtf8("scene_rank"))
        self.appy_scene = QtGui.QPushButton(self.Scene_frame)
        self.appy_scene.setGeometry(QtCore.QRect(380, 85, 50, 28))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.appy_scene.setFont(font)
        self.appy_scene.setAutoFillBackground(False)
        self.appy_scene.setStyleSheet(_fromUtf8("#appy_scene{\n"
"border-radius: 6px;\n"
"image:url(apply_BT.png);\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#appy_scene:pressed{\n"
"border-radius: 6px;\n"
"image:url(apply_BT_push.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.appy_scene.setText(_fromUtf8(""))
        self.appy_scene.setObjectName(_fromUtf8("appy_scene"))
        self.order_scene = QtGui.QPushButton(self.Scene_frame)
        self.order_scene.setGeometry(QtCore.QRect(380, 110, 50, 28))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.order_scene.setFont(font)
        self.order_scene.setAutoFillBackground(False)
        self.order_scene.setStyleSheet(_fromUtf8("#order_scene{\n"
"border-radius: 8px;\n"
"image:url(order_BT.png);\n"
"}\n"
"\n"
"#order_scene:pressed{\n"
"border-radius: 8px;\n"
"image:url(order_BT_push.png);\n"
"}"))
        self.order_scene.setText(_fromUtf8(""))
        self.order_scene.setObjectName(_fromUtf8("order_scene"))
        self.order_all_frame = QtGui.QFrame(Service)
        self.order_all_frame.setGeometry(QtCore.QRect(196, 50, 111, 141))
        self.order_all_frame.setAutoFillBackground(False)
        self.order_all_frame.setStyleSheet(_fromUtf8("#order_all_frame{\n"
"image:url(order_all_frame.png);\n"
"background-color: rgb(255,255,255);\n"
"border-radius: 8px;\n"
"}"))
        self.order_all_frame.setFrameShape(QtGui.QFrame.NoFrame)
        self.order_all_frame.setFrameShadow(QtGui.QFrame.Raised)
        self.order_all_frame.setObjectName(_fromUtf8("order_all_frame"))
        self.order_all = QtGui.QPushButton(self.order_all_frame)
        self.order_all.setGeometry(QtCore.QRect(4, 35, 103, 28))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.order_all.setFont(font)
        self.order_all.setAutoFillBackground(False)
        self.order_all.setStyleSheet(_fromUtf8("#order_all{\n"
"image:url(order_all.png);\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"#order_all::pressed{\n"
"border-radius: 15px;\n"
"image:url(order_all_push.png);\n"
"}"))
        self.order_all.setText(_fromUtf8(""))
        self.order_all.setObjectName(_fromUtf8("order_all"))
        self.order_type_label = QtGui.QLabel(self.order_all_frame)
        self.order_type_label.setGeometry(QtCore.QRect(0, 64, 109, 24))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.order_type_label.setFont(font)
        self.order_type_label.setAutoFillBackground(False)
        self.order_type_label.setStyleSheet(_fromUtf8("#order_type_label{\n"
"image:url(mode_label.png);\n"
"background-color: rgb(68,123,191);\n"
"border-radius: 8px;\n"
"}"))
        self.order_type_label.setText(_fromUtf8(""))
        self.order_type_label.setScaledContents(True)
        self.order_type_label.setAlignment(QtCore.Qt.AlignCenter)
        self.order_type_label.setWordWrap(True)
        self.order_type_label.setObjectName(_fromUtf8("order_type_label"))
        self.button_ms = QtGui.QRadioButton(self.order_all_frame)
        self.button_ms.setEnabled(True)
        self.button_ms.setGeometry(QtCore.QRect(5, 92, 99, 21))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.button_ms.setFont(font)
        self.button_ms.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.button_ms.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
        self.button_ms.setAcceptDrops(False)
        self.button_ms.setAutoFillBackground(False)
        self.button_ms.setStyleSheet(_fromUtf8("#button_ms{\n"
"image:url(MS_label.png);\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#button_ms:indicator{\n"
"width:15px;\n"
"height:15px;\n"
"image:url(MS_PAN_select.png);\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#button_ms:indicator:unchecked{\n"
"width:15px;\n"
"height:15px;\n"
"image:url(MS_PAN_select.png);\n"
"}\n"
"\n"
"#button_ms:indicator:checked{\n"
"width:15px;\n"
"height:15px;\n"
"image:url(cycle_select.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.button_ms.setText(_fromUtf8(""))
        self.button_ms.setAutoExclusive(False)
        self.button_ms.setObjectName(_fromUtf8("button_ms"))
        self.button_pan = QtGui.QRadioButton(self.order_all_frame)
        self.button_pan.setGeometry(QtCore.QRect(5, 117, 99, 21))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.button_pan.setFont(font)
        self.button_pan.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.button_pan.setAutoFillBackground(False)
        self.button_pan.setStyleSheet(_fromUtf8("#button_pan{\n"
"image:url(PAN_label.png);\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#button_pan:indicator{\n"
"width: 15px;\n"
"height: 15px;\n"
"image:url(MS_PAN_select.png);\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#button_pan:indicator:unchecked{\n"
"width: 15px;\n"
"height: 15px;\n"
"image:url(MS_PAN_select.png);\n"
"}\n"
"\n"
"#button_pan:indicator:checked{\n"
"width: 15px;\n"
"height: 15px;\n"
"image:url(cycle_select.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.button_pan.setText(_fromUtf8(""))
        self.button_pan.setAutoExclusive(False)
        self.button_pan.setObjectName(_fromUtf8("button_pan"))
        self.select_level = QtGui.QComboBox(self.order_all_frame)
        self.select_level.setGeometry(QtCore.QRect(6, 3, 100, 28))
        self.select_level.setMinimumSize(QtCore.QSize(100, 28))
        self.select_level.setMaximumSize(QtCore.QSize(100, 28))
        self.select_level.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.select_level.setAutoFillBackground(False)
        self.select_level.setStyleSheet(_fromUtf8("#select_level{\n"
"border-radius: 12px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"\n"
"}\n"
"#select_level::drop-down{\n"
"image:url(bottondown.png);\n"
"background-color: rgb(255,255,255);\n"
"}\n"
""))
        self.select_level.setMaxVisibleItems(3)
        self.select_level.setMaxCount(3)
        self.select_level.setSizeAdjustPolicy(QtGui.QComboBox.AdjustToMinimumContentsLength)
        self.select_level.setObjectName(_fromUtf8("select_level"))
        self.select_level.addItem(_fromUtf8(""))
        self.select_level.addItem(_fromUtf8(""))
        self.select_level.addItem(_fromUtf8(""))
        self.gerald_frame = QtGui.QFrame(Service)
        self.gerald_frame.setGeometry(QtCore.QRect(11, 236, 741, 35))
        self.gerald_frame.setAutoFillBackground(False)
        self.gerald_frame.setStyleSheet(_fromUtf8("#gerald_frame{\n"
"background-color: rgb(255,255,255);\n"
"border-radius: 10px;\n"
"}"))
        self.gerald_frame.setFrameShape(QtGui.QFrame.StyledPanel)
        self.gerald_frame.setFrameShadow(QtGui.QFrame.Raised)
        self.gerald_frame.setObjectName(_fromUtf8("gerald_frame"))
        self.gerald_name_label = QtGui.QLabel(self.gerald_frame)
        self.gerald_name_label.setGeometry(QtCore.QRect(7, 3, 117, 28))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.gerald_name_label.setFont(font)
        self.gerald_name_label.setAutoFillBackground(False)
        self.gerald_name_label.setStyleSheet(_fromUtf8("#gerald_name_label{\n"
"image:url(gerald_name_label.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.gerald_name_label.setText(_fromUtf8(""))
        self.gerald_name_label.setScaledContents(True)
        self.gerald_name_label.setAlignment(QtCore.Qt.AlignCenter)
        self.gerald_name_label.setWordWrap(True)
        self.gerald_name_label.setObjectName(_fromUtf8("gerald_name_label"))
        self.gerald_name = QtGui.QLineEdit(self.gerald_frame)
        self.gerald_name.setGeometry(QtCore.QRect(127, 4, 611, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.gerald_name.setFont(font)
        self.gerald_name.setAutoFillBackground(False)
        self.gerald_name.setStyleSheet(_fromUtf8("#gerald_name{\n"
"image:url(blank_gerald_name.png);\n"
"border-radius: 6px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"#gerald_name:focus {\n"
"border-radius: 6px;\n"
"image:url(blank_gerald_name.png);\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.gerald_name.setText(_fromUtf8(""))
        self.gerald_name.setAlignment(QtCore.Qt.AlignCenter)
        self.gerald_name.setReadOnly(True)
        self.gerald_name.setObjectName(_fromUtf8("gerald_name"))
        self.dsr_frame = QtGui.QFrame(Service)
        self.dsr_frame.setGeometry(QtCore.QRect(11, 276, 561, 35))
        self.dsr_frame.setAutoFillBackground(False)
        self.dsr_frame.setStyleSheet(_fromUtf8("#dsr_frame{\n"
"background-color: rgb(255,255,255);\n"
"border-radius: 10px;\n"
"}"))
        self.dsr_frame.setFrameShape(QtGui.QFrame.NoFrame)
        self.dsr_frame.setFrameShadow(QtGui.QFrame.Raised)
        self.dsr_frame.setObjectName(_fromUtf8("dsr_frame"))
        self.dsr_begin_label = QtGui.QLabel(self.dsr_frame)
        self.dsr_begin_label.setGeometry(QtCore.QRect(7, 4, 85, 28))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.dsr_begin_label.setFont(font)
        self.dsr_begin_label.setAutoFillBackground(False)
        self.dsr_begin_label.setStyleSheet(_fromUtf8("#dsr_begin_label{\n"
"image:url(DSR_begin_label.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.dsr_begin_label.setText(_fromUtf8(""))
        self.dsr_begin_label.setScaledContents(True)
        self.dsr_begin_label.setAlignment(QtCore.Qt.AlignCenter)
        self.dsr_begin_label.setWordWrap(True)
        self.dsr_begin_label.setObjectName(_fromUtf8("dsr_begin_label"))
        self.dsr_begin = QtGui.QLineEdit(self.dsr_frame)
        self.dsr_begin.setGeometry(QtCore.QRect(100, 4, 186, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.dsr_begin.setFont(font)
        self.dsr_begin.setAutoFillBackground(False)
        self.dsr_begin.setStyleSheet(_fromUtf8("#dsr_begin{\n"
"image:url(blank_DSR.png);\n"
"border-radius: 6px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#dsr_begin:focus{\n"
"image:url(blank_DSR.png);\n"
"border-radius: 6px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.dsr_begin.setText(_fromUtf8(""))
        self.dsr_begin.setAlignment(QtCore.Qt.AlignCenter)
        self.dsr_begin.setReadOnly(True)
        self.dsr_begin.setObjectName(_fromUtf8("dsr_begin"))
        self.grid_referene_label = QtGui.QLabel(self.dsr_frame)
        self.grid_referene_label.setGeometry(QtCore.QRect(289, 4, 126, 28))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.grid_referene_label.setFont(font)
        self.grid_referene_label.setAutoFillBackground(False)
        self.grid_referene_label.setStyleSheet(_fromUtf8("#grid_referene_label{\n"
"image:url(grid_ref_label.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.grid_referene_label.setText(_fromUtf8(""))
        self.grid_referene_label.setScaledContents(True)
        self.grid_referene_label.setAlignment(QtCore.Qt.AlignCenter)
        self.grid_referene_label.setWordWrap(True)
        self.grid_referene_label.setObjectName(_fromUtf8("grid_referene_label"))
        self.grid_ref = QtGui.QLineEdit(self.dsr_frame)
        self.grid_ref.setGeometry(QtCore.QRect(417, 4, 141, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.grid_ref.setFont(font)
        self.grid_ref.setAutoFillBackground(False)
        self.grid_ref.setStyleSheet(_fromUtf8("#grid_ref{\n"
"image:url(blank_grid.png);\n"
"border-radius: 6px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"grid_ref:focus{\n"
"image:url(blank_grid.png);\n"
"border-radius: 6px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.grid_ref.setText(_fromUtf8(""))
        self.grid_ref.setAlignment(QtCore.Qt.AlignCenter)
        self.grid_ref.setReadOnly(True)
        self.grid_ref.setObjectName(_fromUtf8("grid_ref"))
        self.activity_log_frame = QtGui.QFrame(Service)
        self.activity_log_frame.setGeometry(QtCore.QRect(11, 315, 741, 191))
        self.activity_log_frame.setAutoFillBackground(False)
        self.activity_log_frame.setStyleSheet(_fromUtf8("#activity_log_frame{\n"
"background-color: rgb(255,255,255);\n"
"border-radius: 10px;\n"
"}"))
        self.activity_log_frame.setFrameShape(QtGui.QFrame.NoFrame)
        self.activity_log_frame.setFrameShadow(QtGui.QFrame.Raised)
        self.activity_log_frame.setObjectName(_fromUtf8("activity_log_frame"))
        self.log_data = QtGui.QTextBrowser(self.activity_log_frame)
        self.log_data.setGeometry(QtCore.QRect(5, 50, 730, 134))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.log_data.setFont(font)
        self.log_data.setAutoFillBackground(True)
        self.log_data.setStyleSheet(_fromUtf8("#log_data{\n"
"image:url(blank_Activity.png);\n"
"border-radius: 6px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"}"))
        self.log_data.setFrameShape(QtGui.QFrame.NoFrame)
        self.log_data.setFrameShadow(QtGui.QFrame.Sunken)
        self.log_data.setLineWidth(0)
        self.log_data.setMidLineWidth(0)
        self.log_data.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
        self.log_data.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
        self.log_data.setObjectName(_fromUtf8("log_data"))
        self.activity_label = QtGui.QLabel(self.activity_log_frame)
        self.activity_label.setGeometry(QtCore.QRect(3, 5, 734, 28))
        self.activity_label.setAutoFillBackground(False)
        self.activity_label.setStyleSheet(_fromUtf8("#activity_label{\n"
"image:url(imagery data-01);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.activity_label.setText(_fromUtf8(""))
        self.activity_label.setObjectName(_fromUtf8("activity_label"))
        self.gistda_logo = QtGui.QLabel(Service)
        self.gistda_logo.setGeometry(QtCore.QRect(11, 510, 291, 52))
        self.gistda_logo.setAutoFillBackground(False)
        self.gistda_logo.setStyleSheet(_fromUtf8("#gistda_logo{\n"
"image:url(gistda_logo.png);\n"
"background-color: rgb(235,234,236);\n"
"}"))
        self.gistda_logo.setText(_fromUtf8(""))
        self.gistda_logo.setObjectName(_fromUtf8("gistda_logo"))
        self.product_height_frame = QtGui.QFrame(Service)
        self.product_height_frame.setGeometry(QtCore.QRect(10, 196, 221, 35))
        self.product_height_frame.setAutoFillBackground(False)
        self.product_height_frame.setStyleSheet(_fromUtf8("#product_height_frame{\n"
"background-color: rgb(255,255,255);\n"
"border-radius: 10px;\n"
"}"))
        self.product_height_frame.setFrameShape(QtGui.QFrame.NoFrame)
        self.product_height_frame.setFrameShadow(QtGui.QFrame.Raised)
        self.product_height_frame.setObjectName(_fromUtf8("product_height_frame"))
        self.product_height_label = QtGui.QLabel(self.product_height_frame)
        self.product_height_label.setGeometry(QtCore.QRect(7, 3, 115, 28))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.product_height_label.setFont(font)
        self.product_height_label.setAutoFillBackground(False)
        self.product_height_label.setStyleSheet(_fromUtf8("#product_height_label{\n"
"image:url(product height_label.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.product_height_label.setText(_fromUtf8(""))
        self.product_height_label.setScaledContents(True)
        self.product_height_label.setAlignment(QtCore.Qt.AlignCenter)
        self.product_height_label.setWordWrap(True)
        self.product_height_label.setObjectName(_fromUtf8("product_height_label"))
        self.product_height = QtGui.QLineEdit(self.product_height_frame)
        self.product_height.setGeometry(QtCore.QRect(133, 4, 80, 28))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Calibri"))
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.product_height.setFont(font)
        self.product_height.setAutoFillBackground(False)
        self.product_height.setStyleSheet(_fromUtf8("#product_height{\n"
"border-radius: 8px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"image:url(blank_product_height.png);\n"
"background-color: rgb(255,255,255);\n"
"}\n"
"\n"
"#product_height:focus{\n"
"border-radius: 8px;\n"
"font-family: Calibri;\n"
"font-style: normal;\n"
"font-size: 12pt;\n"
"font-weight: bold;\n"
"image:url(blank_product_height.png);\n"
"background-color: rgb(255,255,255);\n"
"}"))
        self.product_height.setText(_fromUtf8(""))
        self.product_height.setAlignment(QtCore.Qt.AlignCenter)
        self.product_height.setDragEnabled(True)
        self.product_height.setObjectName(_fromUtf8("product_height"))

        self.retranslateUi(Service)
        QtCore.QObject.connect(self.Exit, QtCore.SIGNAL(_fromUtf8("clicked()")), Service.close)
        QtCore.QMetaObject.connectSlotsByName(Service)

    def retranslateUi(self, Service):
        Service.setWindowTitle(_translate("Service", "SIPPROs.", None))
        self.select_level.setItemText(0, _translate("Service", " --", None))
        self.select_level.setItemText(1, _translate("Service", "1A", None))
        self.select_level.setItemText(2, _translate("Service", "2A", None))
        self.log_data.setHtml(_translate("Service", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'Calibri\'; font-size:12pt; font-weight:600; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;\"><br /></p></body></html>", None))

