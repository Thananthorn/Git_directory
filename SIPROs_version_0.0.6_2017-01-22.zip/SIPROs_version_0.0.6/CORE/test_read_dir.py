import os , sys


path = "C:/Worker/Support-Worker/Producting_system/CPF_PROCESSING/CPF"
for root , directory , files in os.walk(path , topdown=False):
	for filepaths in files :
		filepath = os.path.abspath(os.path.join(root , filepaths))
		filename = os.path.basename(filepath)
		# print filepath
		print filename
