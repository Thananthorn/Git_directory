"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

 """

import platform

if platform.system() == "Windows":
    from osgeo import gdal
else:
    import gdal
import numpy as np
import locationutil as util
import cv2
import determine_pixel_shift as dps
import utm
from osgeo import osr, ogr

import utmLatlon
import psutil
import os
import scipy.interpolate as inplt
import digitalElevationModel as demserice
import scipy.signal as signal
from commomTools import findSamplesPoints, remapImageBandGridMethod, readDataBand, makingDEMData
from systemConstants import LV1_2ProductionConstants






def findLV2RemapFuncitionBand3WithInterpolation(in_file_name, beg_line, ger_pairs, lv2_pair_min,lv2_pair_max,
                                                lv2_geotrans, dem_ds, hmin,hmax, current_date, utc_gps, dut1,
                                                lv_width, lv_height, im_width, im_height, lv2_step_size = 10):
    band = 2

    x2_up_left, y2_up_left, dx2, dy2, zonec = lv2_geotrans
    off_set = 10


    numpairs = ger_pairs.shape[0]
    print "  Band %d....." % (band + 1)
    print "  Finding the reversed model......."
    band_map_info = []
    A = np.zeros((numpairs, 12))
    u_mean = lv_width / 2.0
    v_mean = lv_height / 2.0
    u = lv2_pair_min[:, 0] - u_mean
    v = lv2_pair_min[:, 1] - v_mean + 1

    A[:, 0] = 1.0
    A[:, 1] = u
    A[:, 2] = v
    A[:, 3] = u * v
    A[:, 4] = u ** 2
    A[:, 5] = v ** 2
    A[:, 6] = u * v * v
    A[:, 7] = v * u * u
    A[:, 8] = u ** 3
    A[:, 9] = v ** 3
    A[:, 10] = v * u ** 3
    A[:, 11] = u * v ** 3

    x_mean = ger_pairs[:, 0].mean()
    y_mean = ger_pairs[:, 1].mean()
    bx = ger_pairs[:, 0] - x_mean
    by = ger_pairs[:, 1] - y_mean
    a_x_min, errx, rnkx, s = np.linalg.lstsq(A, bx)
    # print rnk
    a_y_min, erry, rnky, s = np.linalg.lstsq(A, by)
    # print rnk
    if (rnkx == 12) and (rnky == 12):
        print "[%d] Minimun altitude average errors: %f,%f" % (band + 1, errx / numpairs, erry / numpairs)
    else:
        print "[%d]  The model for mainimum altitude is too fitted. Reduce the number of variables." % (band + 1)
        # A2 = A.copy()
        for rk in range(11, 0, -1):
            A2 = A[:, :rk]
            a_x_min2, errx, rnk, s = np.linalg.lstsq(A2, bx)
            a_y_min2, erry, rnk, s = np.linalg.lstsq(A2, by)
            if (len(a_x_min2) > 0) and (len(a_y_min2) > 0):
                a_x_min = np.zeros((12,))
                a_y_min = np.zeros((12,))
                a_x_min[:rk] = a_x_min2
                a_y_min[:rk] = a_y_min2
                break
        print ".....................The algorithm terminates with the matrix of order %d." % rk

    u = lv2_pair_max[:, 0] - u_mean
    v = lv2_pair_max[:, 1] - v_mean + 1
    # print u.min(),u.max(),v.min(),v.max()
    A[:, 0] = 1.0
    A[:, 1] = u
    A[:, 2] = v
    A[:, 3] = u * v
    A[:, 4] = u ** 2
    A[:, 5] = v ** 2
    A[:, 6] = u * v * v
    A[:, 7] = v * u * u
    A[:, 8] = u ** 3
    A[:, 9] = v ** 3
    A[:, 10] = v * u ** 3
    A[:, 11] = u * v ** 3
    x_mean = ger_pairs[:, 0].mean()
    y_mean = ger_pairs[:, 1].mean()
    bx = ger_pairs[:, 0] - x_mean
    by = ger_pairs[:, 1] - y_mean
    a_x_max, errx, rnkx, s = np.linalg.lstsq(A, bx)
    a_y_max, erry, rnky, s = np.linalg.lstsq(A, by)
    if (rnkx == 12) and (rnky == 12):
        print "[%d] Maximum altitude average errors: %f,%f" % (band + 1, errx / numpairs, erry / numpairs)
    else:
        print "[%d]    model for maximum altitude is too fitted. Reduce the number of variables." % (band + 1)
        # A2 = A.copy()
        for rk in range(11, 0, -1):
            A2 = A[:, :rk]
            a_x_max2, errx, rnk, s = np.linalg.lstsq(A2, bx)
            a_y_max2, erry, rnk, s = np.linalg.lstsq(A2, by)
            if (len(a_x_max2) > 0) and (len(a_y_max2) > 0):
                a_x_max = np.zeros((12,))
                a_y_max = np.zeros((12,))
                a_x_max[:rk] = a_x_max2
                a_y_max[:rk] = a_y_max2
                break
        print "....................The algorithm terminates with the matrix of order %d." % rk

    print "The reversed model is computed......"

    sat_pos = np.loadtxt(in_file_name + "B%d.pos" % (band + 1))
    captured_time = np.loadtxt(in_file_name + "B%d.tim" % (band + 1))
    sat_att = np.loadtxt(in_file_name + "B%d.att" % (band + 1))


    line = 0
    sample  = 0


    line_max = lv_height
    samp_max = lv_width
    print "[%d] Mapping Sample: %d to %d, and Line: %d to %d." % (band + 1, sample, sample + samp_max, line,
                                                                  line + line_max)
    Ux = np.arange(lv2_step_size/2,lv_width, lv2_step_size)
    Vx = np.arange(lv2_step_size/2,lv_height, lv2_step_size)
    U,V = np.meshgrid(Ux,Vx)


    urw, ucl = U.shape

    dem_data = dem_ds.ReadAsArray(0, 0, lv_width, lv_height)
    h = np.zeros_like(U, 'float64')
    h[:, :] = dem_data[lv2_step_size/2::lv2_step_size, lv2_step_size/2::lv2_step_size]

    # print "[%d] remapping line: %d to %d and sample: %d to %d"%(band+1,line,line+line_max,sample,sample+samp_max)

    U = U - u_mean
    V = V - v_mean

    U = U.flatten()
    V = V.flatten()
    h = h.flatten()
    try:
        X, Y = dps.findGerFileLocationPreLoadFiles(U, V, h, a_x_min, a_y_min, a_x_max, a_y_max, x_mean, y_mean,
                                                   u_mean,
                                                   v_mean, hmin, hmax, "MS", in_file_name,beg_line,
                                                   current_date,
                                                   utc_gps, dut1, (x2_up_left, y2_up_left, dx2, dy2, zonec),
                                                   im_width, im_height, sat_pos, captured_time, sat_att,
                                                   band=band + 1)
    except:
        np.save(in_file_name + "band_%d_U_%d.npy" % (band + 1, beg_line), U)
        np.save(in_file_name + "band_%d_V_%d.npy" % (band + 1, beg_line), V)
        np.save(in_file_name + "band_%d_h_%d.npy" % (band + 1, beg_line), h)
        np.save(in_file_name + "band_%d_axmin_%d.npy" % (band + 1, beg_line), a_x_min)
        np.save(in_file_name + "band_%d_aymin_%d.npy" % (band + 1, beg_line), a_y_min)
        np.save(in_file_name + "band_%d_axmax_%d.npy" % (band + 1, beg_line), a_x_max)
        np.save(in_file_name + "band_%d_aymax_%d.npy" % (band + 1, beg_line), a_y_max)
        np.save(in_file_name + "band_%d_x_mean_y_mean_%d.npy" % (band + 1, beg_line),
                np.array([x_mean, y_mean]))
        np.save(in_file_name + "band_%d_u_mean_v_mean_%d.npy" % (band + 1, beg_line),
                np.array([u_mean, v_mean]))
        np.save(in_file_name + "band_%d_hminmax_%d.npy" % (band + 1, beg_line),
                np.array([hmin, hmax]))
        print "filename", in_file_name
        print "Line:", beg_line
        print "data", current_date
        print "utc_gps", utc_gps
        print "dut1", dut1
        print "mapInfo", [x2_up_left, y2_up_left, dx2, dy2, zonec]
        np.save(in_file_name + "band_%d_cap_time_%d.npy" % (band + 1, beg_line), captured_time)
        np.save(in_file_name + "band_%d_sat_pos_%d.npy" % (band + 1, beg_line), sat_pos)
        np.save(in_file_name + "band_%d_sat_att_%d.npy" % (band + 1, beg_line), sat_att)
        exit()

    X = X.flatten()
    Y = Y.flatten()
    U2 = Ux
    V2 = Vx
    X2 = X.reshape(V2.shape[0], U2.shape[0]).T
    Y2 = Y.reshape(V2.shape[0], U2.shape[0]).T

    fx = inplt.RectBivariateSpline(U2,V2,X2,bbox=[0,lv_width, 0, lv_height])
    fy = inplt.RectBivariateSpline(U2,V2,Y2, bbox=[0,lv_width, 0, lv_height])

    mem = psutil.virtual_memory()
    mem_available = mem.available
    max_num_pixels = (mem_available - 1024 * 1024 * 1024) / ((800) * 8)  # 500 memory block per pixels and 8 for double
    num_block_lines = int(np.sqrt(max_num_pixels))
    num_block_pixels = num_block_lines
    for line in range(0, lv_height, num_block_lines):
        for sample in range(0, lv_width, num_block_pixels):
            line_max = min((lv_height - line), num_block_lines)
            samp_max = min(lv_width - sample, num_block_pixels)
            if (line == 0) & (sample == 0):
                V, U = np.mgrid[0:int(line_max), 0:int(samp_max)]
            elif (line == 0) & (sample > 0):
                V, U = np.mgrid[0:int(line_max), sample - off_set:int(samp_max + sample)]
            elif (line > 0) & (sample == 0):

                V, U = np.mgrid[line - off_set:int(line_max + line), 0:int(samp_max)]
            else:
                V, U = np.mgrid[line - off_set:int(line_max + line), sample - off_set:int(samp_max + sample)]

            U1 = U.flatten()
            V1 = V.flatten()
            X = fx.ev(U1,V1)
            Y = fy.ev(U1,V1)


            Xmin = int(X.min())
            Xmax = int(np.ceil(X.max()))
            Ymin = int(Y.min())
            Ymax = int(np.ceil(Y.max()))
            strx = int(max(Xmin, 0))
            stpx = min(Xmax + 1, im_width)

            stry = max(Ymin, 0)
            stpy = min(Ymax + 1, im_height)


            x_file_name = None
            y_file_name = None
            # print "Before:", mask_data[line:line+line_max,sample:sample+samp_max].max(), mask_data[line:line+line_max,sample:sample+samp_max].min()
            if (strx < stpx) & (stry < stpy):
                # original = databand[stry:stpy,strx:stpx]
                tr, tc = U.shape
                X = X.astype('float32')
                Y = Y.astype('float32')
                # remap_out = cv2.remap(original,X-strx,Y-stry,cv2.INTER_CUBIC,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
                # print remap_out.shape
                # print temp[(X>=X.min())*(X<=X.max())*(Y>=Y.min())*(Y<=Y.max())].shape
                X = X.reshape(tr, tc)
                Y = Y.reshape(tr, tc)
                # temp[(X>=X.min())*(X<=X.max())*(Y>=Y.min())*(Y<=Y.max())] = remap_out.flatten()
                maskxy = (X >= 0) * (Y >= 0) * (X <= im_width - 1) * (Y <= im_height - 1)
                xout = X.copy()
                yout = Y.copy()
                if (line == 0) & (sample == 0):
                    # outimage_data = temp
                    maskxy = maskxy


                elif (line == 0):
                    # outimage_data = temp[:,off_set:]
                    maskxy = maskxy[:, off_set:]
                    xout = xout[:, off_set:]
                    yout = yout[:, off_set:]


                elif (sample == 0):
                    # outimage_data = temp[off_set:,:]
                    maskxy = maskxy[off_set:, :]
                    xout = xout[off_set:, :]
                    yout = yout[off_set:, :]
                else:
                    # outimage_data = temp[off_set:,off_set:]
                    maskxy = maskxy[off_set:, off_set:]
                    xout = xout[off_set:, off_set:]
                    yout = yout[off_set:, off_set:]

                x_file_name = in_file_name + "X_Band%d_Line%d_Sample%d.npy" % (band + 1, line, sample)
                y_file_name = in_file_name + "Y_Band%d_Line%d_Sample%d.npy" % (band + 1, line, sample)
                np.save(x_file_name, xout)
                np.save(y_file_name, yout)
                # block_info_filep.writelines("%d, %d, %d, %d"%(line, sample, line_max, samp_max))
            band_map_info.append([line, sample, line_max, samp_max, x_file_name, y_file_name])

    band_map_info_array = np.array(band_map_info)


    return band_map_info_array




def utmToLatLon(x, y, zone, isnorth):
    dsc = osr.SpatialReference()
    dsc.ImportFromEPSG(4326)
    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if isnorth:
        src.SetUTM(zone, 1)
    else:
        src.SetUTM(zone, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(x, y)
    point.Transform(coordTransform)
    lon = point.GetX()
    lat = point.GetY()
    return lat, lon






def buildMS2AImageUsingCubicInterpolation(out_file_name, in_file_name, lines, current_date, utc_gps, dut1,dem,
                                          gain, dark_curr, start_sample=1,im_width = 6000,im_height = 6000,save_dem = True,
                                          dem_interpolation_method=demserice.digitalElevationModel.CUBIC, save_pixel_mapping = False):
    """

    :param out_file_name: string of Output file name
    :param in_file_name: string of input file name perfix
    :param lines: begin lines of MS
    :param current_date: [year, month, day] of the image acquisition data
    :param utc_gps: UTC-GPS time
    :param dut1: UT1- UTC time
    :param dem: DEM obect
    :param gain: Gain array
    :param dark_curr: dark current arrray
    :param start_sample: the fist pixel reference to GER file
    :param im_width: image width
    :param im_height: image height
    :param save_dem: Flag to incidate whether to save DEM
    :param dem_interpolation_method: Interpolation method
    :param save_pixel_mapping: flag to indicate whether to have pixel mapping file
    :return:
    four corners : upleft, upright, midpoint, lowleft, lowright
    Map information: map_info
    """


    end_sample =start_sample + im_width-1
    if (end_sample > LV1_2ProductionConstants.MS_MAX_WIDTH) or (start_sample<1) :
        print "The intended sample is beyond the scope of the recorded GER file."

    line = lines[2] # Get line for band #3

    # Get All 4 Tie points
    latc,lonc, heightc = dps.findInterSectionPointArrayUsingDEM("MS",in_file_name,
                                                                    np.array([(end_sample+start_sample)/2]),
                                                                    np.array([line+im_height/2]),current_date,
                                                                    utc_gps,dut1,dem, dem_interpolation_method, band= 3)

    xc,yc,zonec,zoneletterc = utm.from_latlon(latc, lonc)

    dsc = osr.SpatialReference()
    dsc.SetWellKnownGeogCS("WGS84")
    if latc >= 0:
        dsc.SetUTM(zonec, 1)
        isnorth = True
    else:
        dsc.SetUTM(zonec, 0)
        isnorth = False
    latul,lonul, heightul =  dps.findInterSectionPointArrayUsingDEM("MS",in_file_name,np.array([start_sample]),
                                                                    [line],current_date,utc_gps,dut1, dem,
                                                                    dem_interpolation_method,band=3)

    xul,yul,zoneul,zoneletter = utm.from_latlon(latul, lonul)

    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latul >= 0:
        src.SetUTM(zoneul, 1)
    else:
        src.SetUTM(zoneul, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xul, yul)
    point.Transform(coordTransform)
    xul = point.GetX()
    yul = point.GetY()
    print "original image upper left UTM:", xul, yul, "Lat, Lon", latul, lonul

    latur,lonur, heightur =  dps.findInterSectionPointArrayUsingDEM("MS",in_file_name,np.array([end_sample]),
                                                                    [line],current_date,utc_gps,dut1,dem,
                                                                    dem_interpolation_method, band=3)
    xur,yur,zoneur,zoneletter = utm.from_latlon(latur, lonur)
    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latur >= 0:
        src.SetUTM(zoneur, 1)
    else:
        src.SetUTM(zoneur, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xur, yur)
    point.Transform(coordTransform)
    xur = point.GetX()
    yur = point.GetY()

    print "original image upper right UTM:",xur, yur, "Lat, Lon", latur, lonur
    latll, lonll, heightll = dps.findInterSectionPointArrayUsingDEM("MS",in_file_name,np.array([start_sample]),
                                                                    [line+im_height],current_date,utc_gps,dut1, dem,
                                                                    dem_interpolation_method,band=3)
    xll,yll,zonell,zoneletter = utm.from_latlon(latll, lonll)

    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latll >= 0:
        src.SetUTM(zonell, 1)
    else:
        src.SetUTM(zonell, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xll, yll)
    point.Transform(coordTransform)
    xllc = point.GetX()
    yllc = point.GetY()
    print "original image lower left UTM:",xllc, yllc, "Lat, Lon", latll, lonll

    latlr,lonlr, heightlr =  dps.findInterSectionPointArrayUsingDEM("MS",in_file_name,np.array([end_sample]),
                                                                    [line+im_height],current_date,utc_gps,dut1, dem,
                                                                    dem_interpolation_method, band=3)
    xlr,ylr,zonelr,zoneletter_c = utm.from_latlon(latlr, lonlr)
    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latlr >= 0:
        src.SetUTM(zonelr, 1)
    else:
        src.SetUTM(zonelr, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xlr, ylr)
    point.Transform(coordTransform)
    xlr = point.GetX()
    ylr = point.GetY()

    print "original image lower right UTM:",xlr, ylr, "Lat, Lon", latlr, lonlr
    print "original image center UTM:", xc,yc

    # determine the mapping function.
    if LV1_2ProductionConstants.DESCENDING:
        num_lines = np.ceil((yul - ylr) / 15.0 + 1)
        num_samples = np.ceil((xur - xllc) / 15.0 + 1)
        lv_width = int(np.ceil(num_samples))
        lv_height = int(np.ceil(num_lines))
        x2_up_left = xllc
        y2_up_left = yul
        dx2 = 15.0
        dy2 = -15.0
    else:
        num_lines = np.ceil((yllc - yur) / 15.0 + 1)
        num_samples = np.ceil((xul - xlr) / 15.0 + 1)
        lv_width = int(np.ceil(num_samples))
        lv_height = int(np.ceil(num_lines))
        x2_up_left = xlr
        y2_up_left = yllc
        dx2 = 15.0
        dy2 = -15.0

    print "The level 2A image has a size of %d x %d  pixels" % (lv_width, lv_height)

    map_geo_trans =[x2_up_left, y2_up_left, dx2, dy2, zonec, zoneletter_c]

    if LV1_2ProductionConstants.DESCENDING:
        lat_topleft, lon_topleft = utmToLatLon(xllc, yul, zonec, isnorth) #utm.to_latlon(xllc,yul, zonec,zoneletterc )
        lat_botright, lon_botright = utmToLatLon(xur, ylr, zonec, isnorth) #utm.to_latlon(xur, ylr, zonec, zoneletterc )
        if zonec == 60:
            if lat_botright < 0:
                lat_botright = lat_botright + 360
        elif zonec == 1:
            if lat_topleft > 0:
                lat_botright = lat_topleft -360
        latgrid,longrid,hgrid = dem.getValuesFromRetangularArea(lat_topleft,lon_topleft, lat_botright, lon_botright)
        hmin = hgrid.min()
        hmax = hgrid.max()
    else:
        lat_topleft, lon_topleft = utmToLatLon(xlr, yllc, zonec, isnorth)  # utm.to_latlon(xllc,yul, zonec,zoneletterc )
        lat_botright, lon_botright = utmToLatLon(xul, yur, zonec,
                                                 isnorth)  # utm.to_latlon(xur, ylr, zonec, zoneletterc )
        if zonec == 60:
            if lat_botright < 0:
                lat_botright = lat_botright + 360
        elif zonec == 1:
            if lat_topleft > 0:
                lat_botright = lat_topleft - 360
        latgrid, longrid, hgrid = dem.getValuesFromRetangularArea(lat_topleft, lon_topleft, lat_botright, lon_botright)
        hmin = hgrid.min()
        hmax = hgrid.max()
    print "The Minimum and maximum altitudes of the scene are %f and %f meters, respectively."%(hmin,hmax)




    print "Load data from ger files!"

    posB1 = np.loadtxt(in_file_name + "B1.pos")
    posB2 = np.loadtxt(in_file_name + "B2.pos")
    posB3f = np.loadtxt(in_file_name + "B3.pos")
    posB4 = np.loadtxt(in_file_name + "B4.pos")
    sat_pos = [posB1, posB2, posB3f, posB4]

    timeB1 = np.loadtxt(in_file_name + "B1.tim")
    timeB2 = np.loadtxt(in_file_name + "B2.tim")
    timeB3f = np.loadtxt(in_file_name + "B3.tim")
    timeB4 = np.loadtxt(in_file_name + "B4.tim")

    sat_time = [timeB1, timeB2, timeB3f, timeB4]

    attB1 = np.loadtxt(in_file_name + "B1.att")
    attB2 = np.loadtxt(in_file_name + "B2.att")
    attB3f = np.loadtxt(in_file_name + "B3.att")
    attB4 = np.loadtxt(in_file_name + "B4.att")
    sat_att = [attB1, attB2, attB3f, attB4]

    band1 = gdal.Open(in_file_name + "B1.tif")
    band2 = gdal.Open(in_file_name + "B2.tif")
    band3 = gdal.Open(in_file_name + "B3.tif")
    band4 = gdal.Open(in_file_name + "B4.tif")
    data_height = band1.RasterYSize

    max_width = LV1_2ProductionConstants.MS_MAX_WIDTH
    offsetm = LV1_2ProductionConstants.LOADOFFSET

    offset_min1 = max(-offsetm, 1 - lines[0])
    offset_max1 = min(offsetm, data_height - lines[0] - im_height)

    offset_min2 = max(-offsetm, 1 - lines[1])
    offset_max2 = min(offsetm, data_height - lines[1] - im_height)

    offset_min3 = max(-offsetm, 1 - lines[2])
    offset_max3 = min(offsetm, data_height - lines[2] - im_height)

    offset_min4 = max(-offsetm, 1 - lines[3])
    offset_max4 = min(offsetm, data_height - lines[3] - im_height)
    gain_number = np.loadtxt(in_file_name +"B1.gain")
    databand1 = readDataBand(band1, 0, lines[0]-1 + offset_min1, max_width, offset_max1 - offset_min1 + im_height,
                             gain[0], dark_curr[0], gain_number, im_type= "MS" )

    gain_number = np.loadtxt(in_file_name + "B2.gain")
    databand2 = readDataBand(band2, 0, lines[1]-1 + offset_min2, max_width, offset_max2 - offset_min2 + im_height,
                             gain[1], dark_curr[1], gain_number, im_type= "MS" )
    gain_number = np.loadtxt(in_file_name + "B3.gain")
    databand3 = readDataBand(band3, 0, lines[2]-1 , max_width,  im_height,
                             gain[2], dark_curr[2], gain_number, im_type= "MS" )

    gain_number = np.loadtxt(in_file_name + "B4.gain")
    databand4 = readDataBand(band4, 0, lines[3]-1 + offset_min4, max_width, offset_max4 - offset_min4 + im_height,
                             gain[3], dark_curr[3], gain_number, im_type= "MS" )
    image_data = [databand1, databand2, databand3, databand4]
    offset_mins = [offset_min1, offset_min2, offset_min3, offset_min4]

    print "All data has beeen loaded."
    print "Check for existing Band1, Band2 and Band4 to Band3 tie points!"

    all_map_file_exist = True


    for band in [1,2,3,4]:
        all_map_file_exist = all_map_file_exist  and os.path.isfile(in_file_name + "x_b%d_Line%d.txt"%(band,lines[2]))

    sample_step_size = LV1_2ProductionConstants.MS_SAMPLE_GRID_STEP  # THEOS defaul value is 50 points
    process_size = LV1_2ProductionConstants.MS_SAMPLE_PROCESS_BOX_SIZE

    if (not all_map_file_exist):

        print "They do not exist. Attempts to compute them."


        x1, x2, x3, x4, y1, y2, y3, y4 = findSamplesPoints(in_file_name, sample_step_size, lines, sat_pos, sat_time,
                                                           sat_att, image_data, offset_mins, current_date, utc_gps,
                                                           dut1, dem, dem_interpolation_method, im_width, im_height,
                                                           process_box= process_size)
        print "Successful... Save them for later use."
        if LV1_2ProductionConstants.SAVED_MS_BAND_REGISTRATION_POINTS:
            np.savetxt(in_file_name + "x_b1_Line%d.txt"%lines[2], x1)
            np.savetxt(in_file_name + "x_b2_Line%d.txt"%lines[2], x2)
            np.savetxt(in_file_name + "x_b3_Line%d.txt"%lines[2], x3)
            np.savetxt(in_file_name + "x_b4_Line%d.txt"%lines[2], x4)

            np.savetxt(in_file_name + "y_b1_Line%d.txt"%lines[2], y1)
            np.savetxt(in_file_name + "y_b2_Line%d.txt"%lines[2], y2)
            np.savetxt(in_file_name + "y_b3_Line%d.txt"%lines[2], y3)
            np.savetxt(in_file_name + "y_b4_Line%d.txt"%lines[2], y4)
    else:

        x1 = np.loadtxt(in_file_name + "x_b1_Line%d.txt" % lines[2])
        x2 = np.loadtxt(in_file_name + "x_b2_Line%d.txt" % lines[2])
        x3 = np.loadtxt(in_file_name + "x_b3_Line%d.txt" % lines[2])
        x4 = np.loadtxt(in_file_name + "x_b4_Line%d.txt" % lines[2])

        y1 = np.loadtxt(in_file_name + "y_b1_Line%d.txt" % lines[2])
        y2 = np.loadtxt(in_file_name + "y_b2_Line%d.txt" % lines[2])
        y3 = np.loadtxt(in_file_name + "y_b3_Line%d.txt" % lines[2])
        y4 = np.loadtxt(in_file_name + "y_b4_Line%d.txt" % lines[2])


    print "Check for existing LV1->LV2 tie points database."
    all_map_file_exist = True
    all_map_file_exist = all_map_file_exist  and os.path.isfile(in_file_name+"ger_pair_line%d.txt"%(lines[2]))
    all_map_file_exist = all_map_file_exist and os.path.isfile(in_file_name + "B3lv2_pair_min_line%d.txt" % (lines[2]))
    all_map_file_exist = all_map_file_exist and os.path.isfile(in_file_name + "B3lv2_pair_max_line%d.txt" % ( lines[2]))
    num_samples_per_line = im_width / LV1_2ProductionConstants.LV1ToLV2_SAMPLE_GRID_SIZE
    step_sample = im_width / num_samples_per_line
    step_line = im_height / num_samples_per_line
    num_pairs = (im_height / step_line + 1) * (im_width / step_sample + 1)
    ger_pairs =[]
    lv2_pairs_min=[]
    lv2_pairs_max=[]
    if all_map_file_exist:
        print "Find them. Loadind the tie points."
        ger_pairs = np.loadtxt(in_file_name+"ger_pair_line%d.txt"%(lines[2]))
        lv2_pairs_min = np.loadtxt(in_file_name + "B3lv2_pair_min_line%d.txt" % (lines[2]))
        lv2_pairs_max = np.loadtxt(in_file_name + "B3lv2_pair_max_line%d.txt" % (lines[2]))
        if ((ger_pairs.shape[0] != num_samples) or (lv2_pairs_min.shape[0] != num_samples) or
                (lv2_pairs_max.shape[0] != num_samples)) :
            all_map_file_exist = False

    if (not all_map_file_exist) :
        print "The matching pair files LV1->LV2 have not been created."
        print "Generating the matching pair database."
        x_sampels = np.hstack((np.arange(0, im_width, step_sample),np.array([im_width-1])))
        y_sampels = np.hstack((np.arange(0, im_height, step_line),np.array([im_height-1])))
        ger_pairs = np.zeros((num_pairs,2))
        cnt = 0
        lv2_pairs_min = np.zeros((num_pairs,2))
        lv2_pairs_max = np.zeros((num_pairs,2))
        for s_line in y_sampels:
            print "find matching pairs of line %d"%s_line
            s_samples = x_sampels
            lata_min,lona_min,ha = dps.findInterSectionPointArrayGivenAltitude("MS",in_file_name,s_samples,
                                                                               [lines[2]+s_line],hmin,  current_date,
                                                                               utc_gps,dut1,band=3)
            lata_max,lona_max,ha = dps.findInterSectionPointArrayGivenAltitude("MS",in_file_name,s_samples,
                                                                               [lines[2]+s_line],hmax, current_date,
                                                                               utc_gps,dut1,band=3)
            num_s = s_samples.shape[0]
            x,y,z,zl = utmLatlon.from_latlon(lata_min,lona_min,zonec)
            cols = (x-x2_up_left)/dx2
            rows = (y-y2_up_left)/dy2
            str = cnt*num_s
            stp = str+num_s
            lv2_pairs_min[str:stp,0] = cols
            lv2_pairs_min[str:stp,1] = rows

            x,y,z,zl = utmLatlon.from_latlon(lata_max,lona_max,zonec)
            cols = (x-x2_up_left)/dx2
            rows = (y-y2_up_left)/dy2

            lv2_pairs_max[str:stp,0] = cols
            lv2_pairs_max[str:stp,1] = rows

            ger_pairs[str:stp,0] = s_samples
            ger_pairs[str:stp,1] = s_line
            cnt += 1
        if LV1_2ProductionConstants.SAVED_LV1ToLV2_SAMPLE:
            print "completed...saving to files."
            np.savetxt(in_file_name+"B3lv2_pair_min_line%d.txt"%(lines[2]),lv2_pairs_min)
            np.savetxt(in_file_name+"B3lv2_pair_max_line%d.txt"%(lines[2]),lv2_pairs_max)
            np.savetxt(in_file_name+"ger_pair_line%d.txt"%(lines[2]),ger_pairs)



    dem_file_name = in_file_name + "DEM_%d.tif" % lines[2]
    if  not os.path.isfile(dem_file_name):
        print "DEM file do not exist. Interpolate DEM for the LV2 Scene"
        makingDEMData(dem_file_name, lv_width, lv_height, map_geo_trans,dem,
                      dem_interpolation_method=dem_interpolation_method)
    else:
        print "DEM File Exist. LOAD DEM FILE."

    dem_ds_im = gdal.Open(dem_file_name)
    dem_ds = dem_ds_im.GetRasterBand(1)

    lv2_geotrans = [x2_up_left, y2_up_left, dx2, dy2, zonec]
    print "Creating the LV2->LV1 Mapping files"
    band_map_info = findLV2RemapFuncitionBand3WithInterpolation(in_file_name, lines[2], ger_pairs, lv2_pairs_min,
                                                                lv2_pairs_max, lv2_geotrans, dem_ds,  hmin, hmax,
                                                                current_date, utc_gps, dut1, lv_width, lv_height,
                                                                im_width, im_height, lv2_step_size = LV1_2ProductionConstants.LV2ToLV1_SAMPLE_GRID_SIZE)
    print "Completed!"

    print "We are ready to build LV2 Image."
    gtiffDriver = gdal.GetDriverByName("GTiff")
    dst_ds = gtiffDriver.Create(out_file_name, lv_width, lv_height, 4, gdal.GDT_Byte)

    mask_data = np.zeros((lv_height,lv_width),'uint8')

    print "We work with band 3 first!"
    band3 = dst_ds.GetRasterBand(1)
    ms_band_data = np.zeros((lv_height, lv_width), 'uint8')
    lev1_im = np.zeros((im_height, im_width,3),'uint8')
    lev1_im[:,:,2] = image_data[2]
    MIN_DN = LV1_2ProductionConstants.MIN_DN
    MAX_DN = LV1_2ProductionConstants.MAX_DN

    for line, sample, line_max, samp_max, x_file_name, y_file_name in band_map_info:
        databand = image_data[2]
        if (x_file_name is not None) and (y_file_name is not None):
            X = np.load(x_file_name)
            Y = np.load(y_file_name)
            Xmin = int(X.min())
            Xmax = int(np.ceil(X.max()))
            Ymin = int(Y.min())
            Ymax = int(np.ceil(Y.max()))
            strx = int(max(Xmin, 0))
            stpx = min(Xmax + 1, im_width)
            stry = max(Ymin, 0)
            stpy = min(Ymax + 1, im_height)
            temp = np.zeros_like(X)
            if (strx < stpx) & (stry < stpy):
                original = databand[stry:stpy, strx:stpx]
                remap_out = cv2.remap(original, X - strx, Y - stry, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                      borderValue=0)
                temp[(X >= X.min()) * (X <= X.max()) * (Y >= Y.min()) * (Y <= Y.max())] = remap_out.flatten()
                temp = MIN_DN  * (temp < MIN_DN ) + MAX_DN * (temp > MAX_DN) + temp * (temp >= MIN_DN)*(temp <= MAX_DN)
                temp = np.round(temp)
                ms_band_data[line:line + line_max, sample:sample + samp_max] = temp
                mk = (X>0)*(X<im_width)*(Y>0)*(Y<im_height)

                mask_data[line:line + line_max, sample:sample + samp_max] = mk
        else:
            mask_data[line:line + line_max, sample:sample + samp_max] *= 0
    band3.WriteArray(ms_band_data)
    block_size = im_width

    sard_time = np.loadtxt(in_file_name + "B3sadr_times.txt")
    idx = np.nonzero(timeB3f > sard_time[-1])[0]
    if len(idx) > 0:
        line3_max = min(im_height, idx[0] - lines[2])
    else:
        line3_max = im_height

    for band in [1, 2 , 4]:
        if band == 1:
            band_src = dst_ds.GetRasterBand(3)
        elif band == 3:
            band_src = dst_ds.GetRasterBand(1)
        else:
            band_src = dst_ds.GetRasterBand(band)

        databand = image_data[band-1]

        ms_band_data = np.zeros((lv_height, lv_width), 'uint8')
        mask_band = np.zeros((lv_height, lv_width), 'uint8')
        max_height = im_height

        if band == 1:
            id1 = np.nonzero(timeB1 > sard_time[-1])[0]
            b1h = databand1.shape[0] + offset_min1
            if len(id1) > 0:
                line1_max = min(b1h, id1[0] - lines[0])
            else:
                line1_max = b1h

            idok = np.nonzero((y1 < line1_max) * (y3 < line3_max))[0]
            remap_x, remap_y, mask = remapImageBandGridMethod( x1[idok], y1[idok], x3[idok], y3[idok],  0, 0,
                                                               block_size, im_width, im_height, offset_min1,
                                                               max_error= LV1_2ProductionConstants.REMAP_MAX_ERROR)

            outbb = cv2.remap(image_data[0],remap_x,remap_y,cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                          borderValue=0)
            lev1_im[:, :, 0] = outbb
        elif band == 2:
            id2 = np.nonzero(timeB2 > sard_time[-1])[0]
            b2h = databand2.shape[0] + offset_min2
            if len(id2) > 0:
                line2_max = min(b2h, id2[0] - lines[1])
            else:
                line2_max = b2h

            idok = np.nonzero((y2 < line2_max) * (y3 < line3_max))[0]
            remap_x, remap_y, mask = remapImageBandGridMethod(x2[idok], y2[idok], x3[idok], y3[idok],  0, 0,
                                                              block_size, im_width, im_height, offset_min2,
                                                              max_error = LV1_2ProductionConstants.REMAP_MAX_ERROR)

            outbb = cv2.remap(image_data[1], remap_x, remap_y, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                              borderValue=0)
            lev1_im[:, :, 1] = outbb
        elif band == 4:
            id4 = np.nonzero(timeB4 > sard_time[-1])[0]
            b4h = databand4.shape[0] + offset_min4
            if len(id4) > 0:
                line4_max = min(b4h, id4[0] - lines[3])
            else:
                line4_max = b4h

            idok = np.nonzero((y2 < line4_max) * (y3 < line3_max))[0]
            remap_x, remap_y, mask = remapImageBandGridMethod(x4[idok], y4[idok], x3[idok], y3[idok],  0, 0,
                                                              block_size, im_width, im_height, offset_min4,
                                                              max_error = LV1_2ProductionConstants.REMAP_MAX_ERROR)


        for line, sample, line_max, samp_max, x_file_name, y_file_name in band_map_info:
            if (x_file_name is not None) and (y_file_name is not None):
                U = np.load(x_file_name)
                V = np.load(y_file_name)
                U1d = U.flatten()
                V1d = V.flatten()
                X = np.zeros_like(U1d) - 1000
                Y = np.zeros_like(U1d) - 1000
                maskls = np.zeros_like(U1d, 'uint8')

                valid_pixel = np.nonzero((U1d>0) *( U1d < im_width-1) * (V1d > 0) * (V1d < max_height-1))[0]
                if len(valid_pixel) > 0:
                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    U1d_max = U1d_min + 1

                    V1d_min = np.floor(V1dvalid).astype('int')
                    V1d_max = V1d_min + 1
                    xll = remap_x[V1d_min,U1d_min]
                    xhl = remap_x[V1d_max,U1d_min]

                    xlh = remap_x[V1d_min, U1d_max]
                    xhh = remap_x[V1d_max, U1d_max]

                    yll = remap_y[V1d_min, U1d_min]
                    yhl = remap_y[V1d_max, U1d_min]

                    ylh = remap_y[V1d_min, U1d_max]
                    yhh = remap_y[V1d_max, U1d_max]
                    du = U1dvalid - U1d_min
                    dv = V1dvalid - V1d_min
                    xvalid = xll * (1 - du) * (1 - dv) + xhl*dv*(1-du) + xlh*(1-dv)*du + xhh*dv*du
                    yvalid = yll * (1 - du) * (1 - dv) + yhl * dv * (1 - du) + ylh * (1 - dv) * du + yhh * dv * du
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid

                # left_line
                valid_pixel = np.nonzero((U1d == 0) *  (V1d > 0) * (V1d < max_height - 1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')

                    V1d_min = np.floor(V1dvalid).astype('int')
                    V1d_max = V1d_min + 1  # np.ceil(V1dvalid).astype('int')
                    xll = remap_x[V1d_min, U1d_min]
                    xhl = remap_x[V1d_max, U1d_min]
                    yll = remap_y[V1d_min, U1d_min]
                    yhl = remap_y[V1d_max, U1d_min]
                    dv = V1dvalid - V1d_min
                    xvalid = xll * (1 - dv) + xhl * dv
                    yvalid = yll * (1 - dv) + yhl * dv
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid

                #top line
                valid_pixel = np.nonzero((U1d>0) *( U1d < im_width-1) * (V1d == 0))[0]
                if len(valid_pixel) > 0:
                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    U1d_max = U1d_min + 1  # np.ceil(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')

                    xll = remap_x[V1d_min, U1d_min]

                    xlh = remap_x[V1d_min, U1d_max]

                    yll = remap_y[V1d_min, U1d_min]

                    ylh = remap_y[V1d_min, U1d_max]
                    du = U1dvalid - U1d_min

                    xvalid = xll * (1 - du)  + xlh *  du
                    yvalid = yll * (1 - du) + ylh *  du
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # right line
                valid_pixel = np.nonzero((U1d == im_width - 1) * (V1d > 0) * (V1d < max_height - 1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_max = np.floor(U1dvalid).astype('int')

                    V1d_min = np.floor(V1dvalid).astype('int')
                    V1d_max = V1d_min + 1  # np.ceil(V1dvalid).astype('int')


                    xlh = remap_x[V1d_min, U1d_max]
                    xhh = remap_x[V1d_max, U1d_max]

                    ylh = remap_y[V1d_min, U1d_max]
                    yhh = remap_y[V1d_max, U1d_max]

                    dv = V1dvalid - V1d_min
                    xvalid =  xlh * (1 - dv) + xhh * dv
                    yvalid =  ylh * (1 - dv) + yhh * dv
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # buttom line
                valid_pixel = np.nonzero((U1d > 0) * (U1d < im_width - 1) * (V1d == max_height - 1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    U1d_max = U1d_min + 1  # np.ceil(U1dvalid).astype('int')


                    V1d_max = np.floor(V1dvalid).astype('int')

                    xhl = remap_x[V1d_max, U1d_min]
                    xhh = remap_x[V1d_max, U1d_max]
                    yhl = remap_y[V1d_max, U1d_min]
                    yhh = remap_y[V1d_max, U1d_max]
                    du = U1dvalid - U1d_min

                    xvalid = xhl * (1 - du) + xhh * du
                    yvalid = yhl * (1 - du) + yhh * du
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # upper left
                valid_pixel = np.nonzero((U1d == 0) * (V1d == 0))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')
                    xvalid = remap_x[V1d_min, U1d_min]
                    yvalid = remap_y[V1d_min, U1d_min]
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # upper right
                valid_pixel = np.nonzero((U1d == im_width-1) * (V1d == 0))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')
                    xvalid = remap_x[V1d_min, U1d_min]
                    yvalid = remap_y[V1d_min, U1d_min]
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # bottom left
                valid_pixel = np.nonzero((U1d == 0) * (V1d == max_height-1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')
                    xvalid = remap_x[V1d_min, U1d_min]
                    yvalid = remap_y[V1d_min, U1d_min]
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # bottom right
                valid_pixel = np.nonzero((U1d == im_width-1) * (V1d == max_height - 1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')
                    xvalid = remap_x[V1d_min, U1d_min]
                    yvalid = remap_y[V1d_min, U1d_min]
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                mask_valid = np.nonzero((X > 0) * (X < im_width - 1) * (Y > 0) * (Y < databand.shape[0] - 1))[0]
                maskls[mask_valid] = 1
                X = X.reshape(U.shape)
                Y = Y.reshape(V.shape)

                Xmin = int(X.min())
                Xmax = int(np.ceil(X.max()))
                Ymin = int(Y.min())
                Ymax = int(np.ceil(Y.max()))
                strx = int(max(Xmin, 0))
                stpx = min(Xmax + 1, im_width)
                stry = max(Ymin, 0)
                stpy = min(Ymax + 1, databand.shape[0])
                temp = np.zeros_like(X)
                maskls = maskls.reshape(U.shape)
                if (strx < stpx) & (stry < stpy):
                    original = databand[stry:stpy, strx:stpx]
                    remap_out = cv2.remap(original, X - strx, Y - stry, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                          borderValue=0)
                    temp[(X >= X.min()) * (X <= X.max()) * (Y >= Y.min()) * (Y <= Y.max())] = remap_out.flatten()
                    temp = MIN_DN * (temp < MIN_DN) + MAX_DN * (temp > MAX_DN) + temp * (temp >= MIN_DN) * (temp <= MAX_DN)
                    temp = np.round(temp)
                    ms_band_data[line:line + line_max, sample:sample + samp_max] = temp
                    mask_band[line:line + line_max, sample:sample + samp_max] =  maskls

                if band == 4:
                    os.remove(x_file_name)
                    os.remove(y_file_name)
            else:
                mask_band[line:line + line_max, sample:sample + samp_max] *= 0




        band_src.WriteArray(ms_band_data)
        mask_data *= mask_band


    print "There are %d pixels in the level 2A image with data." % (mask_data.sum())
    print "There are %d pixels in the level 2A that has been masked out." %((mask_data==0).sum())
    print "Saving Mask image."
    cv2.imwrite(in_file_name +  "_mask.tif",mask_data*255)
    print "Mask correction...."
    dst_ds = None
    dst_ds = gdal.Open(out_file_name,gdal.GA_Update)
    for band in [1, 2, 3, 4]:
        print "   correcting Band %d........."%band,
        if band == 1:
            bandk = dst_ds.GetRasterBand(3)
        elif band == 3:
            bandk = dst_ds.GetRasterBand(1)
        else:
            bandk = dst_ds.GetRasterBand(band)

        data_bandk = bandk.ReadAsArray()
        data_bandk *= mask_data
        bandk.WriteArray(data_bandk)
        print "done."
    print "Mask Correction completed!"

    print "done!"
    print "Compute the average elevation of the scene.............",
    avg_dem = 0.0
    num_nonzero_pixel = 0.0
    num_block_lines = 1000
    num_block_pixels = 1000
    for line in range(0, lv_height, num_block_lines):
        for sample in range(0, lv_width, num_block_pixels):
            line_max = min((lv_height - line), num_block_lines)
            samp_max = min(lv_width - sample, num_block_pixels)
            mask_sub = mask_data[line:(line + line_max), sample:(sample + samp_max)]
            num_nonzero_pixel += mask_sub.sum()
            h = dem_ds.ReadAsArray(sample, line, samp_max, line_max)
            avg_dem += (h * mask_sub.astype('float32')).sum()
    avg_dem /= num_nonzero_pixel
    print "done! The averaged elevation is: %f meters." % avg_dem

    print "Computing the vertices: "
    cl1 = np.round((xul-x2_up_left)/dx2)+1
    rw1 = np.round((yul-y2_up_left)/dy2)+1
    x1  = x2_up_left + dx2*cl1
    y1 = y2_up_left + dy2*rw1
    lat1, lon1 = utmLatlon.to_latlon(np.array([x1]), np.array([y1]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat1 = lat1[0]
    lon1 = lon1[0]
    if (lon1 <= -180):
        lon1 = 360 + lon1
    elif (lon1 > 180):
        lon1 = lon1 - 360

    cl2 = np.round((xur-x2_up_left)/dx2)+1
    rw2 = np.round((yur-y2_up_left)/dy2)+1
    x2  = x2_up_left + dx2*cl2
    y2 = y2_up_left + dy2*rw2
    lat2, lon2 = utmLatlon.to_latlon(np.array([x2]), np.array([y2]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat2 = lat2[0]
    lon2 = lon2[0]
    if (lon2 <= -180):
        lon2 = 360 + lon2
    elif (lon2 > 180):
        lon2 = lon2 - 360

    cl3 = np.round((xllc-x2_up_left)/dx2)+1
    rw3 = np.round((yllc-y2_up_left)/dy2)+1
    x3  = x2_up_left + dx2*cl3
    y3 = y2_up_left + dy2*rw3

    lat3,lon3 = utmLatlon.to_latlon(np.array([x3]),np.array([y3]), zonec, zoneletter_c) #utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat3 = lat3[0]
    lon3 = lon3[0]
    if (lon3 <= -180):
        lon3 = 360 + lon3
    elif (lon3 > 180):
        lon3 = lon3 - 360

    cl4 = np.round((xlr-x2_up_left)/dx2)+1
    rw4 = np.round((ylr-y2_up_left)/dy2)+1
    x4  = x2_up_left + dx2*cl4
    y4 = y2_up_left + dy2*rw4
    lat4,lon4 = utmLatlon.to_latlon(np.array([x4]), np.array([y4]), zonec, zoneletter_c)
    lat4 = lat4[0]
    lon4 = lon4[0]
    if (lon4 <= -180):
        lon4 = 360 + lon4
    elif (lon4 > 180):
        lon4 = lon4 - 360
    cl5 = np.round((xc-x2_up_left)/dx2)+1
    rw5 = np.round((yc-y2_up_left)/dy2)+1
    x5  = x2_up_left + dx2*cl5
    y5 = y2_up_left + dy2*rw5
    lat5, lon5 = utmLatlon.to_latlon(np.array([x5]), np.array([y5]), zonec, zoneletter_c)
    lat5 = lat5[0]
    lon5 = lon5[0]
    print "Upper left vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw1,cl1)
    print "FRAME_X: %e, FRAME_COL: %e"%(x1,y1)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon1,lat1)
    print ".........................................................."

    print "Upper right vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw2,cl2)
    print "FRAME_X: %e, FRAME_COL: %e"%(x2,y2)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon2,lat2)
    print ".........................................................."

    print "Lower left vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw3,cl3)
    print "FRAME_X: %e, FRAME_COL: %e"%(x3,y3)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon3,lat3)
    print ".........................................................."

    print "Lower right vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw4,cl4)
    print "FRAME_X: %e, FRAME_COL: %e"%(x4,y4)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon4,lat4)
    print ".........................................................."

    print "Scene center.............................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw5,cl5)
    print "FRAME_X: %e, FRAME_COL: %e"%(x5,y5)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon5,lat5)
    print ".........................................................."
    dst_ds.SetGeoTransform( [ x2_up_left, 15.0, 0, y2_up_left, 0, -15.0 ] )

    srs = osr.SpatialReference()
    srs.SetWellKnownGeogCS("WGS84")
    if (lat5>=0) :
        srs.SetUTM( zonec, 1 )
    else :
        srs.SetUTM( zonec, 0 )

    dst_ds.SetProjection( srs.ExportToWkt() )
    if save_dem:
        dem_ds_im.SetProjection(srs.ExportToWkt() )

    upleft =  [[cl1,rw1],[x1,y1],[lon1,lat1]]
    upright = [[cl2,rw2],[x2,y2],[lon2,lat2]]
    midpoint =[[cl5,rw5],[x5,y5],[lon5,lat5]]
    lowleft = [[cl3,rw3],[x3,y3],[lon3,lat3]]
    lowright= [[cl4,rw4],[x4,y4],[lon4,lat4]]
    map_info = [x2_up_left, y2_up_left, 15.0, 15.0, avg_dem, zonec, (lat5 >= 0)]
    return upleft, upright, midpoint, lowleft, lowright,map_info




def computeMSImageCorners(out_file_name, in_file_name, lines, current_date, utc_gps, dut1,dem, dem_interpolation_method,
                          start_sample=1,im_width = 6000,im_height = 6000):

    #im_width = 6000
    lines[0] = lines[0]
    lines[1] = lines[1]
    lines[2] = lines[2]
    lines[3] = lines[3]
    end_sample = start_sample + im_width - 1
    if (end_sample > LV1_2ProductionConstants.MS_MAX_WIDTH) or (start_sample < 1):
        print "The intended sample is beyond the scope of the recorded GER file."

    line = lines[2]  # Get line for band #3

    # Get All 4 Tie points
    latc, lonc, heightc = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name,
                                                                 np.array([(end_sample + start_sample) / 2]),
                                                                 np.array([line + im_height / 2]), current_date,
                                                                 utc_gps, dut1, dem, dem_interpolation_method, band=3)

    xc, yc, zonec, zoneletterc = utm.from_latlon(latc, lonc)

    dsc = osr.SpatialReference()
    dsc.SetWellKnownGeogCS("WGS84")
    if latc >= 0:
        dsc.SetUTM(zonec, 1)
        isnorth = True
    else:
        dsc.SetUTM(zonec, 0)
        isnorth = False
    latul, lonul, heightul = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name, np.array([start_sample]),
                                                                    [line], current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method, band=3)

    xul, yul, zoneul, zoneletter = utm.from_latlon(latul, lonul)

    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latul >= 0:
        src.SetUTM(zoneul, 1)
    else:
        src.SetUTM(zoneul, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xul, yul)
    point.Transform(coordTransform)
    xul = point.GetX()
    yul = point.GetY()
    print "original image upper left UTM:", xul, yul, "Lat, Lon", latul, lonul

    latur, lonur, heightur = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name, np.array([end_sample]),
                                                                    [line], current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method, band=3)
    xur, yur, zoneur, zoneletter = utm.from_latlon(latur, lonur)
    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latur >= 0:
        src.SetUTM(zoneur, 1)
    else:
        src.SetUTM(zoneur, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xur, yur)
    point.Transform(coordTransform)
    xur = point.GetX()
    yur = point.GetY()

    print "original image upper right UTM:", xur, yur, "Lat, Lon", latur, lonur
    latll, lonll, heightll = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name, np.array([start_sample]),
                                                                    [line + im_height], current_date, utc_gps, dut1,
                                                                    dem,
                                                                    dem_interpolation_method, band=3)
    xll, yll, zonell, zoneletter = utm.from_latlon(latll, lonll)

    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latll >= 0:
        src.SetUTM(zonell, 1)
    else:
        src.SetUTM(zonell, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xll, yll)
    point.Transform(coordTransform)
    xllc = point.GetX()
    yllc = point.GetY()
    print "original image lower left UTM:", xllc, yllc, "Lat, Lon", latll, lonll

    latlr, lonlr, heightlr = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name, np.array([end_sample]),
                                                                    [line + im_height], current_date, utc_gps, dut1,
                                                                    dem,
                                                                    dem_interpolation_method, band=3)
    xlr, ylr, zonelr, zoneletter_c = utm.from_latlon(latlr, lonlr)
    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latlr >= 0:
        src.SetUTM(zonelr, 1)
    else:
        src.SetUTM(zonelr, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xlr, ylr)
    point.Transform(coordTransform)
    xlr = point.GetX()
    ylr = point.GetY()

    print "original image lower right UTM:", xlr, ylr, "Lat, Lon", latlr, lonlr
    print "original image center UTM:", xc, yc

    # determine the mapping function.
    if LV1_2ProductionConstants.DESCENDING:
        num_lines = np.ceil((yul - ylr) / 15.0 + 1)
        num_samples = np.ceil((xur - xllc) / 15.0 + 1)
        lv_width = int(np.ceil(num_samples))
        lv_height = int(np.ceil(num_lines))
        x2_up_left = xllc
        y2_up_left = yul
        dx2 = 15.0
        dy2 = -15.0
    else:
        num_lines = np.ceil((yllc - yur) / 15.0 + 1)
        num_samples = np.ceil((xul - xlr) / 15.0 + 1)
        lv_width = int(np.ceil(num_samples))
        lv_height = int(np.ceil(num_lines))
        x2_up_left = xlr
        y2_up_left = yllc
        dx2 = 15.0
        dy2 = -15.0

    print "The level 2A image has a size of %d x %d  pixels" % (lv_width, lv_height)

    map_geo_trans = [x2_up_left, y2_up_left, dx2, dy2, zonec, zoneletter_c]

    if LV1_2ProductionConstants.DESCENDING:
        lat_topleft, lon_topleft = utmToLatLon(xllc, yul, zonec, isnorth)  # utm.to_latlon(xllc,yul, zonec,zoneletterc )
        lat_botright, lon_botright = utmToLatLon(xur, ylr, zonec,
                                                 isnorth)  # utm.to_latlon(xur, ylr, zonec, zoneletterc )
        if zonec == 60:
            if lat_botright < 0:
                lat_botright = lat_botright + 360
        elif zonec == 1:
            if lat_topleft > 0:
                lat_botright = lat_topleft - 360
        latgrid, longrid, hgrid = dem.getValuesFromRetangularArea(lat_topleft, lon_topleft, lat_botright, lon_botright)
        hmin = hgrid.min()
        hmax = hgrid.max()
    else:
        lat_topleft, lon_topleft = utmToLatLon(xlr, yllc, zonec, isnorth)  # utm.to_latlon(xllc,yul, zonec,zoneletterc )
        lat_botright, lon_botright = utmToLatLon(xul, yur, zonec,
                                                 isnorth)  # utm.to_latlon(xur, ylr, zonec, zoneletterc )
        if zonec == 60:
            if lat_botright < 0:
                lat_botright = lat_botright + 360
        elif zonec == 1:
            if lat_topleft > 0:
                lat_botright = lat_topleft - 360
        latgrid, longrid, hgrid = dem.getValuesFromRetangularArea(lat_topleft, lon_topleft, lat_botright, lon_botright)
        hmin = hgrid.min()
        hmax = hgrid.max()
    print "The Minimum and maximum altitudes of the scene are %f and %f meters, respectively." % (hmin, hmax)
    print "Computing the vertices: "
    cl1 = np.round((xul-x2_up_left)/dx2)+1
    rw1 = np.round((yul-y2_up_left)/dy2)+1
    x1  = x2_up_left + dx2*cl1
    y1 = y2_up_left + dy2*rw1
    lat1, lon1 = utmLatlon.to_latlon(np.array([x1]), np.array([y1]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat1 = lat1[0]
    lon1 = lon1[0]
    if (lon1 <= -180):
        lon1 = 360 + lon1
    elif (lon1 > 180):
        lon1 = lon1 - 360

    cl2 = np.round((xur-x2_up_left)/dx2)+1
    rw2 = np.round((yur-y2_up_left)/dy2)+1
    x2  = x2_up_left + dx2*cl2
    y2 = y2_up_left + dy2*rw2
    lat2, lon2 = utmLatlon.to_latlon(np.array([x2]), np.array([y2]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat2 = lat2[0]
    lon2 = lon2[0]
    if (lon2 <= -180):
        lon2 = 360 + lon2
    elif (lon2 > 180):
        lon2 = lon2 - 360

    cl3 = np.round((xllc-x2_up_left)/dx2)+1
    rw3 = np.round((yllc-y2_up_left)/dy2)+1
    x3  = x2_up_left + dx2*cl3
    y3 = y2_up_left + dy2*rw3
    lat3, lon3 = utmLatlon.to_latlon(np.array([x3]), np.array([y3]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat3 = lat3[0]
    lon3 = lon3[0]
    if (lon3 <= -180):
        lon3 = 360 + lon3
    elif (lon3 > 180):
        lon3 = lon3 - 360

    cl4 = np.round((xlr-x2_up_left)/dx2)+1
    rw4 = np.round((ylr-y2_up_left)/dy2)+1
    x4  = x2_up_left + dx2*cl4
    y4 = y2_up_left + dy2*rw4
    lat4, lon4 = utmLatlon.to_latlon(np.array([x4]), np.array([y4]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat4 = lat4[0]
    lon4 = lon4[0]
    if (lon4 <= -180):
        lon4 = 360 + lon4
    elif (lon4 > 180):
        lon4 = lon4 - 360

    cl5 = np.round((xc-x2_up_left)/dx2)+1
    rw5 = np.round((yc-y2_up_left)/dy2)+1
    x5  = x2_up_left + dx2*cl5
    y5 = y2_up_left + dy2*rw5
    lat5, lon5 = utmLatlon.to_latlon(np.array([x5]), np.array([y5]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat5 = lat5[0]
    lon5 = lon5[0]
    print "Upper left vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw1,cl1)
    print "FRAME_X: %e, FRAME_COL: %e"%(x1,y1)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon1,lat1)
    print ".........................................................."

    print "Upper right vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw2,cl2)
    print "FRAME_X: %e, FRAME_COL: %e"%(x2,y2)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon2,lat2)
    print ".........................................................."

    print "Lower left vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw3,cl3)
    print "FRAME_X: %e, FRAME_COL: %e"%(x3,y3)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon3,lat3)
    print ".........................................................."

    print "Lower right vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw4,cl4)
    print "FRAME_X: %e, FRAME_COL: %e"%(x4,y4)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon4,lat4)
    print ".........................................................."

    print "Scene center.............................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw5,cl5)
    print "FRAME_X: %e, FRAME_COL: %e"%(x5,y5)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon5,lat5)
    print ".........................................................."

    upleft =  [[cl1,rw1],[x1,y1],[lon1,lat1]]
    upright = [[cl2,rw2],[x2,y2],[lon2,lat2]]
    midpoint =[[cl5,rw5],[x5,y5],[lon5,lat5]]
    lowleft = [[cl3,rw3],[x3,y3],[lon3,lat3]]
    lowright= [[cl4,rw4],[x4,y4],[lon4,lat4]]
    dem_file_name = in_file_name + "DEM_%d.tif" % lines[2]
    ms_im = gdal.Open(out_file_name)
    ms_b1 = ms_im.GetRasterBand(1)
    avg_dem = 0.0
    num_nonzero_pixels = 0.0
    block_num_lines = 1000
    block_num_pixels = 1000
    lv_height = ms_im.RasterYSize
    lv_width = ms_im.RasterXSize
    dem_im = gdal.Open(dem_file_name)
    dem_ds = dem_im.GetRasterBand(1)
    for line in range(0, lv_height, block_num_lines):
        for sample in range(0, lv_width, block_num_pixels):
            line_max = min((lv_height - line), block_num_lines)
            samp_max = min(lv_width - sample, block_num_pixels)
            h = dem_ds.ReadAsArray(sample, line, samp_max, line_max)
            data = ms_b1.ReadAsArray(sample, line, samp_max, line_max)
            mask = (data != 0).astype('float32')
            avg_dem += (h * mask).sum()
            num_nonzero_pixels += mask.sum()
    avg_dem /= num_nonzero_pixels
    map_info = [x2_up_left, y2_up_left, 15.0, 15.0, avg_dem, zonec, (lat5 >= 0)]
    return upleft, upright, midpoint, lowleft, lowright, map_info

def findLV2RemapFuncitionPANWithInterpolation(in_file_name, beg_line, ger_pairs, lv2_pair_min,lv2_pair_max, lv2_geotrans,
                                              dem_ds, hmin,hmax, current_date, utc_gps, dut1, lv_width, lv_height,
                                              im_width, im_height, lv2_step_size = 10):


    x2_up_left, y2_up_left, dx2, dy2, zonec  = lv2_geotrans
    off_set = 10

    numpairs = ger_pairs.shape[0]
    print "  Band PAN....."
    print "  Finding the reversed model......."
    band_map_info = []
    A = np.zeros((numpairs, 12))
    u_mean = lv_width / 2.0
    v_mean = lv_height / 2.0
    u = lv2_pair_min[:, 0] - u_mean
    v = lv2_pair_min[:, 1] - v_mean + 1
    # print u.min(),u.max(),v.min(),v.max()
    A[:, 0] = 1.0
    A[:, 1] = u
    A[:, 2] = v
    A[:, 3] = u * v
    A[:, 4] = u ** 2
    A[:, 5] = v ** 2
    A[:, 6] = u * v * v
    A[:, 7] = v * u * u
    A[:, 8] = u ** 3
    A[:, 9] = v ** 3
    A[:, 10] = v * u ** 3
    A[:, 11] = u * v ** 3

    x_mean = ger_pairs[:, 0].mean()
    y_mean = ger_pairs[:, 1].mean()
    bx = ger_pairs[:, 0] - x_mean
    by = ger_pairs[:, 1] - y_mean
    a_x_min, errx, rnkx, s = np.linalg.lstsq(A, bx)
    # print rnk
    a_y_min, erry, rnky, s = np.linalg.lstsq(A, by)
    # print rnk
    if (rnkx == 12) and (rnky == 12):
        print "[PAN] Minimun altitude average errors: %f,%f" % ( errx / numpairs, erry / numpairs)
    else:
        print "[PAN]  The model for mainimum altitude is too fitted. Reduce the number of variables."
        # A2 = A.copy()
        for rk in range(11, 0, -1):
            A2 = A[:, :rk]
            a_x_min2, errx, rnk, s = np.linalg.lstsq(A2, bx)
            a_y_min2, erry, rnk, s = np.linalg.lstsq(A2, by)
            if (len(a_x_min2) > 0) and (len(a_y_min2) > 0):
                a_x_min = np.zeros((12,))
                a_y_min = np.zeros((12,))
                a_x_min[:rk] = a_x_min2
                a_y_min[:rk] = a_y_min2
                break
        print ".....................The algorithm terminates with the matrix of order %d." % rk

    u = lv2_pair_max[:, 0] - u_mean
    v = lv2_pair_max[:, 1] - v_mean + 1
    # print u.min(),u.max(),v.min(),v.max()
    A[:, 0] = 1.0
    A[:, 1] = u
    A[:, 2] = v
    A[:, 3] = u * v
    A[:, 4] = u ** 2
    A[:, 5] = v ** 2
    A[:, 6] = u * v * v
    A[:, 7] = v * u * u
    A[:, 8] = u ** 3
    A[:, 9] = v ** 3
    A[:, 10] = v * u ** 3
    A[:, 11] = u * v ** 3
    x_mean = ger_pairs[:, 0].mean()
    y_mean = ger_pairs[:, 1].mean()
    bx = ger_pairs[:, 0] - x_mean
    by = ger_pairs[:, 1] - y_mean
    a_x_max, errx, rnkx, s = np.linalg.lstsq(A, bx)
    a_y_max, erry, rnky, s = np.linalg.lstsq(A, by)
    if (rnkx == 12) and (rnky == 12):
        print "[PAN] Maximum altitude average errors: %f,%f" % ( errx / numpairs, erry / numpairs)
    else:
        print "[PAN]    model for maximum altitude is too fitted. Reduce the number of variables."
        # A2 = A.copy()
        for rk in range(11, 0, -1):
            A2 = A[:, :rk]
            a_x_max2, errx, rnk, s = np.linalg.lstsq(A2, bx)
            a_y_max2, erry, rnk, s = np.linalg.lstsq(A2, by)
            if (len(a_x_max2) > 0) and (len(a_y_max2) > 0):
                a_x_max = np.zeros((12,))
                a_y_max = np.zeros((12,))
                a_x_max[:rk] = a_x_max2
                a_y_max[:rk] = a_y_max2
                break
        print "....................The algorithm terminates with the matrix of order %d." % rk

    print "The reversed model is computed......"


    sat_pos = np.loadtxt(in_file_name + ".pos" )
    captured_time = np.loadtxt(in_file_name + ".tim" )
    sat_att = np.loadtxt(in_file_name + ".att" )
    # block_info_filep = open(in_file_name + "Band%d.txt"%(band+1),"w")

    line = 0
    sample  = 0


    line_max = lv_height
    samp_max = lv_width
    print "[PAN] Mapping Sample: %d to %d, and Line: %d to %d." % (sample, sample + samp_max, line,
                                                                  line + line_max)
    Ux = np.arange(lv2_step_size/2,lv_width, lv2_step_size)
    Vx = np.arange(lv2_step_size/2,lv_height, lv2_step_size)
    U,V = np.meshgrid(Ux,Vx)


    dem_data = dem_ds.ReadAsArray(0, 0, lv_width, lv_height)
    h = np.zeros_like(U, 'float64')
    h[:, :] = dem_data[lv2_step_size/2::lv2_step_size, lv2_step_size/2::lv2_step_size]

    # print "[%d] remapping line: %d to %d and sample: %d to %d"%(band+1,line,line+line_max,sample,sample+samp_max)

    U = U - u_mean
    V = V - v_mean

    U = U.flatten()
    V = V.flatten()
    h = h.flatten()
    print "Create LV2->LV1 tie points at the step of %d pixels" % lv2_step_size
    try:
        X, Y = dps.findGerFileLocationPreLoadFiles(U, V, h, a_x_min, a_y_min, a_x_max, a_y_max, x_mean, y_mean,
                                                   u_mean,
                                                   v_mean, hmin, hmax, "PAN", in_file_name,beg_line,
                                                   current_date,
                                                   utc_gps, dut1, (x2_up_left, y2_up_left, dx2, dy2, zonec),
                                                   im_width, im_height, sat_pos, captured_time, sat_att)
    except:
        np.save(in_file_name + "band_PAN_U_%d.npy" % (beg_line), U)
        np.save(in_file_name + "band_PAN_V_%d.npy" % (beg_line), V)
        np.save(in_file_name + "band_PAN_h_%d.npy" % (beg_line), h)
        np.save(in_file_name + "band_PAN_axmin_%d.npy" % (beg_line), a_x_min)
        np.save(in_file_name + "band_PAN_aymin_%d.npy" % (beg_line), a_y_min)
        np.save(in_file_name + "band_PAN_axmax_%d.npy" % (beg_line), a_x_max)
        np.save(in_file_name + "band_PAN_aymax_%d.npy" % (beg_line), a_y_max)
        np.save(in_file_name + "band_PAN_x_mean_y_mean_%d.npy" % (beg_line),
                np.array([x_mean, y_mean]))
        np.save(in_file_name + "band_PAN_u_mean_v_mean_%d.npy" % (beg_line),
                np.array([u_mean, v_mean]))
        np.save(in_file_name + "band_PAN_hminmax_%d.npy" % (beg_line),
                np.array([hmin, hmax]))
        print "filename", in_file_name
        print "Line:", beg_line
        print "data", current_date
        print "utc_gps", utc_gps
        print "dut1", dut1
        print "mapInfo", [x2_up_left, y2_up_left, dx2, dy2, zonec]
        np.save(in_file_name + "band_PAN_cap_time_%d.npy" % (beg_line), captured_time)
        np.save(in_file_name + "band_PAN_sat_pos_%d.npy" % (beg_line), sat_pos)
        np.save(in_file_name + "band_PAN_sat_att_%d.npy" % (beg_line), sat_att)
        exit()

    print "Done!"

    X =  X.flatten()
    Y =  Y.flatten()
    U2 = Ux
    V2 = Vx
    X2 = X.reshape(V2.shape[0], U2.shape[0]).T
    Y2 = Y.reshape(V2.shape[0], U2.shape[0]).T
    fx = inplt.RectBivariateSpline(U2,V2,X2,bbox=[0,lv_width, 0, lv_height])
    fy = inplt.RectBivariateSpline(U2,V2,Y2, bbox=[0,lv_width, 0, lv_height])

    mem = psutil.virtual_memory()
    mem_available = mem.available
    max_num_pixels = (mem_available - 1024 * 1024 * 1024) / ((100) * 8)  # 100 memory block per pixels and 8 for double
    num_block_lines = int(np.sqrt(max_num_pixels))
    num_block_pixels = num_block_lines
    print "Making the mapping function between LV2-LV1"
    for line in range(0, lv_height, num_block_lines):
        for sample in range(0, lv_width, num_block_pixels):
            line_max = min((lv_height - line), num_block_lines)
            samp_max = min(lv_width - sample, num_block_pixels)
            if (line == 0) & (sample == 0):
                V, U = np.mgrid[0:int(line_max), 0:int(samp_max)]
            elif (line == 0) & (sample > 0):
                V, U = np.mgrid[0:int(line_max), sample - off_set:int(samp_max + sample)]
            elif (line > 0) & (sample == 0):

                V, U = np.mgrid[line - off_set:int(line_max + line), 0:int(samp_max)]
            else:
                V, U = np.mgrid[line - off_set:int(line_max + line), sample - off_set:int(samp_max + sample)]

            U1 = U.flatten()
            V1 = V.flatten()
            X = fx.ev(U1,V1)
            Y = fy.ev(U1,V1)


            Xmin = int(X.min())
            Xmax = int(np.ceil(X.max()))
            Ymin = int(Y.min())
            Ymax = int(np.ceil(Y.max()))
            strx = int(max(Xmin, 0))
            stpx = min(Xmax + 1, im_width)

            stry = max(Ymin, 0)
            stpy = min(Ymax + 1, im_height)

            # print "[%d] Used the data from (%d,%d)->(%d,%d)"%(band+1,strx,stry,stpx,stpy)
            # maskxy = np.zero_like(U,'uint8')
            x_file_name = None
            y_file_name = None
            # print "Before:", mask_data[line:line+line_max,sample:sample+samp_max].max(), mask_data[line:line+line_max,sample:sample+samp_max].min()
            if (strx < stpx) & (stry < stpy):
                # original = databand[stry:stpy,strx:stpx]
                tr, tc = U.shape
                X = X.astype('float32')
                Y = Y.astype('float32')
                # remap_out = cv2.remap(original,X-strx,Y-stry,cv2.INTER_CUBIC,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
                # print remap_out.shape
                # print temp[(X>=X.min())*(X<=X.max())*(Y>=Y.min())*(Y<=Y.max())].shape
                X = X.reshape(tr, tc)
                Y = Y.reshape(tr, tc)
                # temp[(X>=X.min())*(X<=X.max())*(Y>=Y.min())*(Y<=Y.max())] = remap_out.flatten()
                maskxy = (X >= 0) * (Y >= 0) * (X <= im_width - 1) * (Y <= im_height - 1)
                xout = X.copy()
                yout = Y.copy()
                if (line == 0) & (sample == 0):
                    # outimage_data = temp
                    maskxy = maskxy


                elif (line == 0):
                    # outimage_data = temp[:,off_set:]
                    maskxy = maskxy[:, off_set:]
                    xout = xout[:, off_set:]
                    yout = yout[:, off_set:]


                elif (sample == 0):
                    # outimage_data = temp[off_set:,:]
                    maskxy = maskxy[off_set:, :]
                    xout = xout[off_set:, :]
                    yout = yout[off_set:, :]
                else:
                    # outimage_data = temp[off_set:,off_set:]
                    maskxy = maskxy[off_set:, off_set:]
                    xout = xout[off_set:, off_set:]
                    yout = yout[off_set:, off_set:]

                x_file_name = in_file_name + "X_BandPAN_Line%d_Sample%d.npy" % (line, sample)
                y_file_name = in_file_name + "Y_BandPAN_Line%d_Sample%d.npy" % (line, sample)
                np.save(x_file_name, xout)
                np.save(y_file_name, yout)
                # block_info_filep.writelines("%d, %d, %d, %d"%(line, sample, line_max, samp_max))
            band_map_info.append([line, sample, line_max, samp_max, x_file_name, y_file_name])

    band_map_info_array = np.array(band_map_info)
    #np.save(in_file_name + "_map_info_band_%d.npy" % (band + 1), band_map_info_array)
    print "Done."

    return band_map_info_array



def buildPAN2AImageUsingCubicInterpolation(out_file_name, in_file_name, beg_line, current_date, utc_gps, dut1, dem,
                                           filter2D, gain, dark_cur,start_sample=1, im_width=12000, im_height=12000,
                                           save_dem = True,dem_interpolation_method=demserice.digitalElevationModel.CUBIC):


    line = beg_line
    end_sample =start_sample + im_width-1
    if (end_sample > LV1_2ProductionConstants.PAN_MAX_WIDTH) or (start_sample<1) :
        print "The intended sample is beyond the scope of the recorded GER file."
    start_sample = start_sample-1
    # check number of line
    sat_times = np.loadtxt(in_file_name+".tim")
    line_max = len(sat_times)
    im_height = min(line_max-beg_line,im_height)



    # Get All 4 Tie points
    latc,lonc, heightc = dps.findInterSectionPointArrayUsingDEM("PAN",in_file_name,
                                                                    np.array([(end_sample+start_sample)/2]),
                                                                    np.array([line+im_height/2]),current_date,
                                                                    utc_gps,dut1,dem, dem_interpolation_method)

    xc,yc,zonec,zoneletterc = utm.from_latlon(latc, lonc)

    dsc = osr.SpatialReference()
    dsc.SetWellKnownGeogCS("WGS84")
    if latc >= 0:
        dsc.SetUTM(zonec, 1)
        isnorth = True
    else:
        dsc.SetUTM(zonec, 0)
        isnorth = False
    latul,lonul, heightul =  dps.findInterSectionPointArrayUsingDEM("PAN",in_file_name,np.array([start_sample]),
                                                                    [line],current_date,utc_gps,dut1, dem,
                                                                    dem_interpolation_method)

    xul,yul,zoneul,zoneletter = utm.from_latlon(latul, lonul)

    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latul >= 0:
        src.SetUTM(zoneul, 1)
    else:
        src.SetUTM(zoneul, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xul, yul)
    point.Transform(coordTransform)
    xul = point.GetX()
    yul = point.GetY()
    print "original image upper left UTM:", xul, yul, "Lat, Lon", latul, lonul

    latur,lonur, heightur =  dps.findInterSectionPointArrayUsingDEM("PAN",in_file_name,np.array([end_sample]),
                                                                    [line],current_date,utc_gps,dut1,dem,
                                                                    dem_interpolation_method)
    xur,yur,zoneur,zoneletter = utm.from_latlon(latur, lonur)
    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latur >= 0:
        src.SetUTM(zoneur, 1)
    else:
        src.SetUTM(zoneur, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xur, yur)
    point.Transform(coordTransform)
    xur = point.GetX()
    yur = point.GetY()

    print "original image upper right UTM:",xur, yur, "Lat, Lon", latur, lonur
    latll, lonll, heightll = dps.findInterSectionPointArrayUsingDEM("PAN",in_file_name,np.array([start_sample]),
                                                                    [line+im_height],current_date,utc_gps,dut1, dem,
                                                                    dem_interpolation_method)
    xll,yll,zonell,zoneletter = utm.from_latlon(latll, lonll)

    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latll >= 0:
        src.SetUTM(zonell, 1)
    else:
        src.SetUTM(zonell, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xll, yll)
    point.Transform(coordTransform)
    xll = point.GetX()
    yll = point.GetY()
    print "original image lower left UTM:",xll, yll, "Lat, Lon", latll, lonll

    latlr,lonlr, heightlr =  dps.findInterSectionPointArrayUsingDEM("PAN",in_file_name,np.array([end_sample]),
                                                                    [line+im_height],current_date,utc_gps,dut1, dem,
                                                                    dem_interpolation_method)
    xlr,ylr,zonelr,zoneletter_c = utm.from_latlon(latlr, lonlr)
    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latlr >= 0:
        src.SetUTM(zonelr, 1)
    else:
        src.SetUTM(zonelr, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xlr, ylr)
    point.Transform(coordTransform)
    xlr = point.GetX()
    ylr = point.GetY()

    print "original image lower right UTM:",xlr, ylr, "Lat, Lon", latlr, lonlr
    print "original image center UTM:", xc,yc

    # determine the mapping function.
    if LV1_2ProductionConstants.DESCENDING:
        num_lines = np.ceil((yul - ylr) / 2.0 + 1)
        num_samples = np.ceil((xur - xll) / 2.0 + 1)
        lv_width = int(np.ceil(num_samples))
        lv_height = int(np.ceil(num_lines))
        x2_up_left = xll
        y2_up_left = yul
        dx2 = 2.0
        dy2 = -2.0
    else:
        num_lines = np.ceil((yll - yur) / 2.0 + 1)
        num_samples = np.ceil((xul - xlr) / 2.0 + 1)
        lv_width = int(np.ceil(num_samples))
        lv_height = int(np.ceil(num_lines))
        x2_up_left = xlr
        y2_up_left = yll
        dx2 = 2.0
        dy2 = -2.0

    print "The level 2A image has a size of %d x %d  pixels" % (lv_width, lv_height)


    lv2_geotrans = [x2_up_left, y2_up_left, dx2, dy2, zonec]
    map_geo_trans = [x2_up_left, y2_up_left, dx2, dy2, zonec, zoneletter_c]

    if LV1_2ProductionConstants.DESCENDING:
        lat_topleft, lon_topleft = utmToLatLon(xll, yul, zonec, isnorth) #utm.to_latlon(xllc,yul, zonec,zoneletterc )
        lat_botright, lon_botright = utmToLatLon(xur, ylr, zonec, isnorth) #utm.to_latlon(xur, ylr, zonec, zoneletterc )
        if zonec == 60:
            if lat_botright < 0:
                lat_botright = lat_botright + 360
        elif zonec == 1:
            if lat_topleft > 0:
                lat_botright = lat_topleft -360
        latgrid,longrid,hgrid = dem.getValuesFromRetangularArea(lat_topleft,lon_topleft, lat_botright, lon_botright)
        hmin = hgrid.min()
        hmax = hgrid.max()
    else:
        lat_topleft, lon_topleft = utmToLatLon(xlr, yll, zonec, isnorth)  # utm.to_latlon(xllc,yul, zonec,zoneletterc )
        lat_botright, lon_botright = utmToLatLon(xul, yur, zonec,
                                                 isnorth)  # utm.to_latlon(xur, ylr, zonec, zoneletterc )
        if zonec == 60:
            if lat_botright < 0:
                lat_botright = lat_botright + 360
        elif zonec == 1:
            if lat_topleft > 0:
                lat_botright = lat_topleft - 360
        latgrid, longrid, hgrid = dem.getValuesFromRetangularArea(lat_topleft, lon_topleft, lat_botright, lon_botright)
        hmin = hgrid.min()
        hmax = hgrid.max()
    print "The Minimum and maximum altitudes of the scene are %f and %f meters, respectively."%(hmin,hmax)




    gain_numbers = np.loadtxt(in_file_name + ".gain").astype('int')

    in_im= gdal.Open(in_file_name + ".tif")
    max_width = in_im.RasterXSize
    band1 = in_im.GetRasterBand(1)
    ger_height = in_im.RasterYSize
    databand  = np.zeros((im_height,im_width), 'float32')
    print "Perform image filtering...",

    for k in range(0, im_height, LV1_2ProductionConstants.PAN_PROCESS_BOX_SIZE):
        for m in range(0, im_width, LV1_2ProductionConstants.PAN_PROCESS_BOX_SIZE):
            #print "Building block (%d,%d)......" % (k, m)
            y_min = max(0, beg_line + k - LV1_2ProductionConstants.PAN_OVERLAP_SIZE)
            x_min = max(0, m - LV1_2ProductionConstants.PAN_OVERLAP_SIZE + start_sample)
            x_off_l = start_sample + m - x_min
            y_off_l = beg_line + k - y_min
            x_max = min(max_width, m + LV1_2ProductionConstants.PAN_OVERLAP_SIZE +
                        LV1_2ProductionConstants.PAN_PROCESS_BOX_SIZE + start_sample)
            y_max = min(ger_height, min(beg_line + im_height + 20, beg_line + k +
                                        LV1_2ProductionConstants.PAN_OVERLAP_SIZE +
                                        LV1_2ProductionConstants.PAN_PROCESS_BOX_SIZE ))
            load_width = x_max - x_min
            load_height = y_max - y_min
            one_block = readDataBand(band1, x_min, y_min, load_width, load_height, gain, dark_cur,
                                     gain_numbers, im_type="PAN")


            if LV1_2ProductionConstants.DENCONVOLUTION:
                summ = cv2.GaussianBlur(one_block.astype('uint8'), LV1_2ProductionConstants.PAN_GAUSSIAN_SIZE,
                                        LV1_2ProductionConstants.PAN_GAUSSIAN_SIGMA)
                edges = cv2.Canny(summ.astype('uint8'), LV1_2ProductionConstants.PAN_CANNY_TH1,
                                  LV1_2ProductionConstants.PAN_CANNY_TH2, L2gradient=False)
                edges = cv2.filter2D(edges, cv2.CV_8U, LV1_2ProductionConstants.PAN_EDGE_KERNEL)


                kernel =  LV1_2ProductionConstants.PAN_SUM_KERNEL
                summ = signal.convolve2d(one_block, kernel, mode = 'same', fillvalue= 0.0)
                gradient = np.abs(one_block - summ) * (edges > 0)

                gradient[0, :] = 0
                gradient[1, :] = 0
                gradient[-1, :] = 0
                gradient[-2, :] = 0
                gradient[:, 0] = 0
                gradient[:, 1] = 0
                gradient[:, -1] = 0
                gradient[:, -2] = 0
                my_filter_im = np.zeros_like(one_block).astype('float32')
                idx, idy = np.nonzero(gradient < LV1_2ProductionConstants.PAN_TH1)
                my_filter_im[idx, idy] = one_block[idx, idy]
                idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH1) * (
                    gradient < LV1_2ProductionConstants.PAN_TH2))
                tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[3], borderType=cv2.BORDER_REFLECT)
                my_filter_im[idx, idy] = tem[idx, idy]
                idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH2) * (
                    gradient < LV1_2ProductionConstants.PAN_TH3))
                tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[4], borderType=cv2.BORDER_REFLECT)
                my_filter_im[idx, idy] = tem[idx, idy]
                idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH3) * (
                    gradient < LV1_2ProductionConstants.PAN_TH4))
                tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[5], borderType=cv2.BORDER_REFLECT)
                my_filter_im[idx, idy] = tem[idx, idy]
                idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH4))
                tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[6], borderType=cv2.BORDER_REFLECT)
                my_filter_im[idx, idy] = tem[idx, idy]
                filtered_im = my_filter_im.copy()
            else:
                filtered_im = one_block
            used_ar = filtered_im[y_off_l:y_off_l + LV1_2ProductionConstants.PAN_PROCESS_BOX_SIZE,
                      x_off_l:x_off_l + LV1_2ProductionConstants.PAN_PROCESS_BOX_SIZE].astype('float32')
            rw,cl = used_ar.shape
            databand[k:k+rw,m:m+cl] = used_ar
    # try to load the LV2A and GER pixel pairs for both lowest and highest altitude.
    print "Done!"
    # cv2.imwrite(in_file_name + "temp.tif", databand.astype('uint8'))
    all_file_exist = os.path.isfile(in_file_name + "ger_pair_line%d.txt" % beg_line) and \
                     os.path.isfile(in_file_name + "lv2_pair_min_altitude_line%d.txt" % beg_line ) and \
                     os.path.isfile(in_file_name + "lv2_pair_max_altitude_line%d.txt" % beg_line )

    step_sample = LV1_2ProductionConstants.LV1ToLV2_SAMPLE_GRID_SIZE
    step_line = LV1_2ProductionConstants.LV1ToLV2_SAMPLE_GRID_SIZE
    x_sampels = np.hstack((np.arange(0, im_width, step_sample), np.array([im_width - 1])))
    y_sampels = np.hstack((np.arange(0, im_height, step_line), np.array([im_height - 1])))
    num_pairs = len(x_sampels) * len(y_sampels)
    if all_file_exist:
        print "Attempt to load files containing Level 2A and GER pixel paris..."
        ger_pairs = np.loadtxt(in_file_name+"ger_pair_line%d.txt"%(beg_line))
        lv2_pairs_min = np.loadtxt(in_file_name+"lv2_pair_min_altitude_line%d.txt"%(beg_line))
        lv2_pairs_max = np.loadtxt(in_file_name+"lv2_pair_max_altitude_line%d.txt"%(beg_line))
        if (ger_pairs.shape[0] != num_pairs) or (lv2_pairs_max.shape[0] != num_pairs) or (lv2_pairs_min.shape[0] != num_pairs):
            all_file_exist =False
    else:
        ger_pairs = []
        lv2_pairs_max =[]
        lv2_pairs_min =[]
    if not all_file_exist:
        ger_pairs = np.zeros((num_pairs,2))
        lv2_pairs_min = np.zeros((num_pairs,2))
        lv2_pairs_max = np.zeros((num_pairs,2))
        print "The matching pair files have not been created."
        print "Generating the matching pair database."
        cnt = 0
        for s_line in y_sampels:
            print "find matching pairs of line %d"%s_line
            s_samples = x_sampels+start_sample
            lata_min,lona_min,ha = dps.findInterSectionPointArrayGivenAltitude("PAN",in_file_name,s_samples,[line+s_line],hmin,
                                                                       current_date,utc_gps,dut1)
            lata_max,lona_max,ha = dps.findInterSectionPointArrayGivenAltitude("PAN",in_file_name,s_samples,[line+s_line],hmax,
                                                                       current_date,utc_gps,dut1)

            num_s = s_samples.shape[0]
            x,y,z,zl = utmLatlon.from_latlon(lata_min,lona_min,zonec)
            cols = (x-x2_up_left)/dx2
            rows = (y-y2_up_left)/dy2
            str = cnt*num_s
            stp = str+num_s
            lv2_pairs_min[str:stp,0] = cols
            lv2_pairs_min[str:stp,1] = rows

            x,y,z,zl = utmLatlon.from_latlon(lata_max,lona_max,zonec)
            cols = (x-x2_up_left)/dx2
            rows = (y-y2_up_left)/dy2

            lv2_pairs_max[str:stp,0] = cols
            lv2_pairs_max[str:stp,1] = rows

            ger_pairs[str:stp,0] = s_samples-1
            ger_pairs[str:stp,1] = s_line
            cnt += 1
        if LV1_2ProductionConstants.SAVED_LV1ToLV2_SAMPLE:
            print "completed...saving to files."
            np.savetxt(in_file_name+"ger_pair_line%d.txt"%(beg_line),ger_pairs)
            np.savetxt(in_file_name+"lv2_pair_min_altitude_line%d.txt"%(beg_line),lv2_pairs_min)
            np.savetxt(in_file_name+"lv2_pair_max_altitude_line%d.txt"%(beg_line),lv2_pairs_max)

    dem_file_name = in_file_name + "DEM_%d.tif" % beg_line
    if  not os.path.isfile(dem_file_name):
        print "DEM file do not exist. Interpolate DEM for the LV2 Scene"
        makingDEMData(dem_file_name, lv_width, lv_height, map_geo_trans,dem,
                      dem_interpolation_method=dem_interpolation_method)
    else:
        print "DEM File Exist. LOAD DEM FILE."

    dem_ds_im = gdal.Open(dem_file_name)
    dem_ds = dem_ds_im.GetRasterBand(1)

    band_map_info = findLV2RemapFuncitionPANWithInterpolation(in_file_name, beg_line, ger_pairs, lv2_pairs_min, lv2_pairs_max,
                                                              lv2_geotrans, dem_ds, hmin, hmax, current_date, utc_gps,
                                                              dut1, lv_width, lv_height, im_width, im_height,
                                                              lv2_step_size = LV1_2ProductionConstants.LV2ToLV1_SAMPLE_GRID_SIZE)


    gtiffDriver = gdal.GetDriverByName('GTiff')

    dst_ds = gtiffDriver.Create(out_file_name, lv_width, lv_height , 1, gdal.GDT_Byte)
    pan_b1 = dst_ds.GetRasterBand(1)



    pan_data = np.zeros((lv_height,lv_width),'uint8')
    mask_data = np.zeros((lv_height,lv_width),'uint8')
    MIN_DN = LV1_2ProductionConstants.MIN_DN
    MAX_DN = LV1_2ProductionConstants.MAX_DN

    for line, sample, line_max, samp_max, x_file_name, y_file_name in band_map_info:

        if (x_file_name is not None) and (y_file_name is not None):

            X = np.load(x_file_name)
            Y = np.load(y_file_name)
            Xmin = int(X.min())
            Xmax = int(np.ceil(X.max()))
            Ymin = int(Y.min())
            Ymax = int(np.ceil(Y.max()))
            strx = int(max(Xmin, 0))
            stpx = min(Xmax + 1, im_width)
            stry = max(Ymin, 0)
            stpy = min(Ymax + 1, im_height)
            temp = np.zeros_like(X)
            if (strx < stpx) & (stry < stpy):
                original = databand[stry:stpy, strx:stpx]
                remap_out = cv2.remap(original, X - strx, Y - stry, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                      borderValue=0)
                temp[(X >= X.min()) * (X <= X.max()) * (Y >= Y.min()) * (Y <= Y.max())] = remap_out.flatten()

                #band3.WriteArray(sample, line, ms_band_data)
                mk = (X>0)*(X<im_width)*(Y>0)*(Y<im_height)
                temp = MIN_DN * (temp < MIN_DN) + MAX_DN * (temp > MAX_DN) + temp * (temp >= MIN_DN) * (temp <= MAX_DN)
                temp = np.round(temp).astype('uint8')
                #temp = temp * mk

                pan_data[line:line + line_max, sample:sample + samp_max] = temp*mk
                mask_data[line:line + line_max, sample:sample + samp_max] = mk
            os.remove(x_file_name)
            os.remove(y_file_name)
        else:
            mask_data[line:line + line_max, sample:sample + samp_max] *= 0
    pan_b1.WriteArray(pan_data,0,0)

    avg_dem = 0.0
    num_nonzero_pixels = 0.0
    block_num_lines = 1000
    block_num_pixels = 1000
    for line in range(0, lv_height, block_num_lines):
        for sample in range(0, lv_width, block_num_pixels):
            line_max = min((lv_height - line), block_num_lines)
            samp_max = min(lv_width - sample, block_num_pixels)
            h = dem_ds.ReadAsArray(sample, line, samp_max, line_max)
            data = pan_data[line:(line+line_max),sample:(sample+samp_max)]
            mask = (data!=0).astype('float32')
            avg_dem += (h*mask).sum()
            num_nonzero_pixels += mask.sum()
    avg_dem /= num_nonzero_pixels
    print "Computing the vertices: "
    cl1 = np.round((xul-x2_up_left)/dx2)+1
    rw1 = np.round((yul-y2_up_left)/dy2)+1
    x1  = x2_up_left + dx2*cl1
    y1 = y2_up_left + dy2*rw1
    lat1,lon1 = utm.to_latlon(x1,y1,zonec,zoneletter_c)
    if (lon1 <= -180):
        lon1 = 360 + lon1
    elif (lon1 > 180):
        lon1 = lon1 - 360

    cl2 = np.round((xur-x2_up_left)/dx2)+1
    rw2 = np.round((yur-y2_up_left)/dy2)+1
    x2  = x2_up_left + dx2*cl2
    y2 = y2_up_left + dy2*rw2
    lat2,lon2 = utm.to_latlon(x2,y2,zonec,zoneletter_c)
    if (lon2 <= -180):
        lon2 = 360 + lon2
    elif (lon2 > 180):
        lon2 = lon2 - 360

    cl3 = np.round((xll-x2_up_left)/dx2)+1
    rw3 = np.round((yll-y2_up_left)/dy2)+1
    x3  = x2_up_left + dx2*cl3
    y3 = y2_up_left + dy2*rw3
    lat3,lon3 = utm.to_latlon(x3,y3,zonec,zoneletter_c)
    if (lon3 <= -180):
        lon3 = 360 + lon3
    elif (lon3 > 180):
        lon3 = lon3 - 360

    cl4 = np.round((xlr-x2_up_left)/dx2)+1
    rw4 = np.round((ylr-y2_up_left)/dy2)+1
    x4  = x2_up_left + dx2*cl4
    y4 = y2_up_left + dy2*rw4
    lat4,lon4 = utm.to_latlon(x4,y4,zonec,zoneletter_c)
    if (lon4 <= -180):
        lon4 = 360 + lon4
    elif (lon4 > 180):
        lon4 = lon4 - 360

    cl5 = np.round((xc-x2_up_left)/dx2)+1
    rw5 = np.round((yc-y2_up_left)/dy2)+1
    x5  = x2_up_left + dx2*cl5
    y5 = y2_up_left + dy2*rw5
    lat5,lon5 = utm.to_latlon(x5,y5,zonec,zoneletter_c)
    print "Upper left vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw1,cl1)
    print "FRAME_X: %e, FRAME_COL: %e"%(x1,y1)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon1,lat1)
    print ".........................................................."

    print "Upper right vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw2,cl2)
    print "FRAME_X: %e, FRAME_COL: %e"%(x2,y2)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon2,lat2)
    print ".........................................................."

    print "Lower left vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw3,cl3)
    print "FRAME_X: %e, FRAME_COL: %e"%(x3,y3)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon3,lat3)
    print ".........................................................."

    print "Lower right vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw4,cl4)
    print "FRAME_X: %e, FRAME_COL: %e"%(x4,y4)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon4,lat4)
    print ".........................................................."

    print "Scene center.............................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw5,cl5)
    print "FRAME_X: %e, FRAME_COL: %e"%(x5,y5)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon5,lat5)
    print ".........................................................."
    dst_ds.SetGeoTransform( [ x2_up_left, 2.0, 0, y2_up_left, 0, -2.0 ] )
    srs = osr.SpatialReference()
    srs.SetWellKnownGeogCS("WGS84")
    if (lat5>=0) :
        srs.SetUTM( zonec, 1 )
    else :
        srs.SetUTM( zonec, 0 )

    dst_ds.SetProjection(srs.ExportToWkt())

    upleft =  [[cl1,rw1],[x1,y1],[lon1,lat1]]
    upright = [[cl2,rw2],[x2,y2],[lon2,lat2]]
    midpoint =[[cl5,rw5],[x5,y5],[lon5,lat5]]
    lowleft = [[cl3,rw3],[x3,y3],[lon3,lat3]]
    lowright= [[cl4,rw4],[x4,y4],[lon4,lat4]]
    map_info = [x2_up_left,y2_up_left,2.0,2.0,avg_dem,zonec,(lat5>=0)]
    return upleft, upright, midpoint, lowleft, lowright, map_info


def computePANImageCorners(out_file_name, in_file_name, beg_line, current_date, utc_gps, dut1,dem, dem_interpolation_method,
                                         filter2D,start_sample=1, im_width=12000, im_height=12000):
    line = beg_line
    end_sample = start_sample + im_width - 1
    if (end_sample > LV1_2ProductionConstants.PAN_MAX_WIDTH) or (start_sample < 1):
        print "The intended sample is beyond the scope of the recorded GER file."
    start_sample = start_sample - 1
    # check number of line
    sat_times = np.loadtxt(in_file_name + ".tim")
    line_max = len(sat_times)
    im_height = min(line_max - beg_line, im_height)

    # Get All 4 Tie points
    latc, lonc, heightc = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name,
                                                                 np.array([(end_sample + start_sample) / 2]),
                                                                 np.array([line + im_height / 2]), current_date,
                                                                 utc_gps, dut1, dem, dem_interpolation_method)

    xc, yc, zonec, zoneletterc = utm.from_latlon(latc, lonc)

    dsc = osr.SpatialReference()
    dsc.SetWellKnownGeogCS("WGS84")
    if latc >= 0:
        dsc.SetUTM(zonec, 1)
        isnorth = True
    else:
        dsc.SetUTM(zonec, 0)
        isnorth = False
    latul, lonul, heightul = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([start_sample]),
                                                                    [line], current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method)

    xul, yul, zoneul, zoneletter = utm.from_latlon(latul, lonul)

    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latul >= 0:
        src.SetUTM(zoneul, 1)
    else:
        src.SetUTM(zoneul, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xul, yul)
    point.Transform(coordTransform)
    xul = point.GetX()
    yul = point.GetY()
    print "original image upper left UTM:", xul, yul, "Lat, Lon", latul, lonul

    latur, lonur, heightur = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([end_sample]),
                                                                    [line], current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method)
    xur, yur, zoneur, zoneletter = utm.from_latlon(latur, lonur)
    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latur >= 0:
        src.SetUTM(zoneur, 1)
    else:
        src.SetUTM(zoneur, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xur, yur)
    point.Transform(coordTransform)
    xur = point.GetX()
    yur = point.GetY()

    print "original image upper right UTM:", xur, yur, "Lat, Lon", latur, lonur
    latll, lonll, heightll = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([start_sample]),
                                                                    [line + im_height], current_date, utc_gps, dut1,
                                                                    dem,
                                                                    dem_interpolation_method)
    xll, yll, zonell, zoneletter = utm.from_latlon(latll, lonll)

    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latll >= 0:
        src.SetUTM(zonell, 1)
    else:
        src.SetUTM(zonell, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xll, yll)
    point.Transform(coordTransform)
    xll = point.GetX()
    yll = point.GetY()
    print "original image lower left UTM:", xll, yll, "Lat, Lon", latll, lonll

    latlr, lonlr, heightlr = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([end_sample]),
                                                                    [line + im_height], current_date, utc_gps, dut1,
                                                                    dem,
                                                                    dem_interpolation_method)
    xlr, ylr, zonelr, zoneletter_c = utm.from_latlon(latlr, lonlr)
    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latlr >= 0:
        src.SetUTM(zonelr, 1)
    else:
        src.SetUTM(zonelr, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xlr, ylr)
    point.Transform(coordTransform)
    xlr = point.GetX()
    ylr = point.GetY()

    print "original image lower right UTM:", xlr, ylr, "Lat, Lon", latlr, lonlr
    print "original image center UTM:", xc, yc

    # determine the mapping function.
    if LV1_2ProductionConstants.DESCENDING:
        num_lines = np.ceil((yul - ylr) / 2.0 + 1)
        num_samples = np.ceil((xur - xll) / 2.0 + 1)
        lv_width = int(np.ceil(num_samples))
        lv_height = int(np.ceil(num_lines))
        x2_up_left = xll
        y2_up_left = yul
        dx2 = 2.0
        dy2 = -2.0
    else:
        num_lines = np.ceil((yll - yur) / 2.0 + 1)
        num_samples = np.ceil((xul - xlr) / 2.0 + 1)
        lv_width = int(np.ceil(num_samples))
        lv_height = int(np.ceil(num_lines))
        x2_up_left = xlr
        y2_up_left = yll
        dx2 = 2.0
        dy2 = -2.0

    print "The level 2A image has a size of %d x %d  pixels" % (lv_width, lv_height)

    lv2_geotrans = [x2_up_left, y2_up_left, dx2, dy2, zonec]
    map_geo_trans = [x2_up_left, y2_up_left, dx2, dy2, zonec, zoneletter_c]

    if LV1_2ProductionConstants.DESCENDING:
        lat_topleft, lon_topleft = utmToLatLon(xll, yul, zonec, isnorth)  # utm.to_latlon(xllc,yul, zonec,zoneletterc )
        lat_botright, lon_botright = utmToLatLon(xur, ylr, zonec,
                                                 isnorth)  # utm.to_latlon(xur, ylr, zonec, zoneletterc )
        if zonec == 60:
            if lat_botright < 0:
                lat_botright = lat_botright + 360
        elif zonec == 1:
            if lat_topleft > 0:
                lat_botright = lat_topleft - 360
        latgrid, longrid, hgrid = dem.getValuesFromRetangularArea(lat_topleft, lon_topleft, lat_botright, lon_botright)
        hmin = hgrid.min()
        hmax = hgrid.max()
    else:
        lat_topleft, lon_topleft = utmToLatLon(xlr, yll, zonec, isnorth)  # utm.to_latlon(xllc,yul, zonec,zoneletterc )
        lat_botright, lon_botright = utmToLatLon(xul, yur, zonec,
                                                 isnorth)  # utm.to_latlon(xur, ylr, zonec, zoneletterc )
        if zonec == 60:
            if lat_botright < 0:
                lat_botright = lat_botright + 360
        elif zonec == 1:
            if lat_topleft > 0:
                lat_botright = lat_topleft - 360
        latgrid, longrid, hgrid = dem.getValuesFromRetangularArea(lat_topleft, lon_topleft, lat_botright, lon_botright)
        hmin = hgrid.min()
        hmax = hgrid.max()
    print "The Minimum and maximum altitudes of the scene are %f and %f meters, respectively." % (hmin, hmax)


    cl1 = np.round((xul-x2_up_left)/dx2)+1
    rw1 = np.round((yul-y2_up_left)/dy2)+1
    x1  = x2_up_left + dx2*cl1
    y1 = y2_up_left + dy2*rw1
    lat1,lon1 = utm.to_latlon(x1,y1,zonec,zoneletter_c)
    if (lon1 <= -180):
        lon1 = 360 + lon1
    elif (lon1 > 180):
        lon1 = lon1 - 360

    cl2 = np.round((xur-x2_up_left)/dx2)+1
    rw2 = np.round((yur-y2_up_left)/dy2)+1
    x2  = x2_up_left + dx2*cl2
    y2 = y2_up_left + dy2*rw2
    lat2,lon2 = utm.to_latlon(x2,y2,zonec,zoneletter_c)
    if (lon2 <= -180):
        lon2 = 360 + lon2
    elif (lon2 > 180):
        lon2 = lon2 - 360


    cl3 = np.round((xll-x2_up_left)/dx2)+1
    rw3 = np.round((yll-y2_up_left)/dy2)+1
    x3  = x2_up_left + dx2*cl3
    y3 = y2_up_left + dy2*rw3
    lat3,lon3 = utm.to_latlon(x3,y3,zonec,zoneletter_c)
    if (lon3 <= -180):
        lon3 = 360 + lon3
    elif (lon3 > 180):
        lon3 = lon3 - 360

    cl4 = np.round((xlr-x2_up_left)/dx2)+1
    rw4 = np.round((ylr-y2_up_left)/dy2)+1
    x4  = x2_up_left + dx2*cl4
    y4 = y2_up_left + dy2*rw4
    lat4,lon4 = utm.to_latlon(x4,y4,zonec,zoneletter_c)
    if (lon4 <= -180):
        lon4 = 360 + lon4
    elif (lon4 > 180):
        lon4 = lon4 - 360

    cl5 = np.round((xc-x2_up_left)/dx2)+1
    rw5 = np.round((yc-y2_up_left)/dy2)+1
    x5  = x2_up_left + dx2*cl5
    y5 = y2_up_left + dy2*rw5
    lat5,lon5 = utm.to_latlon(x5,y5,zonec,zoneletter_c)
    print "Upper left vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw1,cl1)
    print "FRAME_X: %e, FRAME_COL: %e"%(x1,y1)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon1,lat1)
    print ".........................................................."

    print "Upper right vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw2,cl2)
    print "FRAME_X: %e, FRAME_COL: %e"%(x2,y2)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon2,lat2)
    print ".........................................................."

    print "Lower left vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw3,cl3)
    print "FRAME_X: %e, FRAME_COL: %e"%(x3,y3)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon3,lat3)
    print ".........................................................."

    print "Lower right vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw4,cl4)
    print "FRAME_X: %e, FRAME_COL: %e"%(x4,y4)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon4,lat4)
    print ".........................................................."

    print "Scene center.............................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw5,cl5)
    print "FRAME_X: %e, FRAME_COL: %e"%(x5,y5)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon5,lat5)
    print ".........................................................."

    upleft =  [[cl1,rw1],[x1,y1],[lon1,lat1]]
    upright = [[cl2,rw2],[x2,y2],[lon2,lat2]]
    midpoint =[[cl5,rw5],[x5,y5],[lon5,lat5]]
    lowleft = [[cl3,rw3],[x3,y3],[lon3,lat3]]
    lowright= [[cl4,rw4],[x4,y4],[lon4,lat4]]
    dem_file_name = in_file_name + "DEM_%d.tif" % beg_line
    pan_im = gdal.Open(out_file_name)
    pan_b1 = pan_im.GetRasterBand(1)
    avg_dem = 0.0
    num_nonzero_pixels = 0.0
    block_num_lines = 1000
    block_num_pixels = 1000
    lv_height = pan_im.RasterYSize
    lv_width = pan_im.RasterXSize
    dem_im = gdal.Open(dem_file_name)
    dem_ds = dem_im.GetRasterBand(1)
    for line in range(0, lv_height, block_num_lines):
        for sample in range(0, lv_width, block_num_pixels):
            line_max = min((lv_height - line), block_num_lines)
            samp_max = min(lv_width - sample, block_num_pixels)
            h = dem_ds.ReadAsArray(sample, line, samp_max, line_max)
            data = pan_b1.ReadAsArray(sample,line,samp_max,line_max)
            mask = (data != 0).astype('float32')
            avg_dem += (h * mask).sum()
            num_nonzero_pixels += mask.sum()
    avg_dem /= num_nonzero_pixels


    map_info = [x2_up_left, y2_up_left, 2.0, 2.0,avg_dem, zonec, (lat5 >= 0)]

    return upleft, upright, midpoint, lowleft, lowright, map_info


def buildMSForPanSharpenImageUsingCubicInterpolation(out_file_name, pan_out_file,pan_in_file_name, ms_in_file_name,
                                                     pansharpen_info_dir, beg_line_pan,
                                                     current_date, utc_gps, dut1,dem_directory,start_sample=1,
                                                     im_width=12000, im_height=12000,ms_width_max =6000, ms_height_max = 6000):


    pan_line = beg_line_pan
    #ms_lines = beg_line_ms
    end_sample =start_sample + im_width-1
    if (end_sample >12000) or (start_sample<1) :
        print "The intended sample is beyond the scope of the recorded GER file."
    #start_sample = start_sample-1
    # compute pan scene information
    latc,lonc, heightc = dps.findInterSectionPointArrayUsingKriging("PAN",pan_in_file_name,
                                                                    np.array([(end_sample+start_sample)/2]),
                                                                    np.array([pan_line+im_height/2]),current_date,
                                                                    utc_gps,dut1,dem_directory)
    xc,yc,zonec,zoneletter = utm.from_latlon(latc, lonc)

    # Upper left
    latul,lonul, heightul =  dps.findInterSectionPointArrayUsingKriging("PAN",pan_in_file_name,np.array([start_sample]),[pan_line],current_date,utc_gps,dut1,dem_directory)
    xul,yul,zoneul,zoneletter = utm.from_latlon(latul, lonul,zonec)
    print "original image upper left UTM:", xul, yul

    latur,lonur, heightur =  dps.findInterSectionPointArrayUsingKriging("PAN",pan_in_file_name,np.array([end_sample]),[pan_line],current_date,utc_gps,dut1,dem_directory)
    xur,yur,zoneur,zoneletter = utm.from_latlon(latur, lonur,zonec)
    print "original image upper right UTM:",xur, yur
    latll, lonll, heightll = dps.findInterSectionPointArrayUsingKriging("PAN",pan_in_file_name,np.array([start_sample]),[pan_line+im_height],current_date,utc_gps,dut1,dem_directory)
    xll,yll,zonell,zoneletter = utm.from_latlon(latll, lonll,zonec)
    print "original image lower left UTM:",xll, yll

    latlr,lonlr, heightlr =  dps.findInterSectionPointArrayUsingKriging("PAN",pan_in_file_name,np.array([end_sample]),[pan_line+im_height],current_date,utc_gps,dut1,dem_directory)
    xlr,ylr,zonelr,zoneletter_c = utm.from_latlon(latlr, lonlr,zonec)
    print "original image lower right UTM:",xlr, ylr

    print "original image center UTM:", xc,yc

    hmin,hmax = util.findMinMaxHeight([latul,lonul],[latlr,lonlr],dem_directory)
    print "The Minimum and maximum altitude of the scene is: %f and %f meters, respectively."%(hmin,hmax)
    num_lines = (yul-ylr)/2.0+1
    num_samples = (xur-xll)/2.0+1
    # determine the mapping function.
    x2_up_left = xll
    y2_up_left = yul
    dx2 = 2.0
    dy2 = -2.0
    dem_temp = util.load_dem_file(13,99,dem_directory)
    pixel_size =dem_temp.GetGeoTransform()[1]/3600.
    gtiffDriver = gdal.GetDriverByName('GTiff')
    lv_width = int(num_samples)
    lv_height = int(num_lines)
    #dem_ds_im = gtiffDriver.Create(pan_in_file_name+"_dem.tif", lv_width, lv_height , 1, gdal.GDT_Float32)
    #dem_ds = dem_ds_im.GetRasterBand(1)


    #find the begining and end line of MS
    ms_lines =[]
    aline = np.arange(6000)+1
    print "Find the beginning line....."
    for band in [1,2,3,4]:
        print "Band:%d"%(band)
        ms_im = gdal.Open(ms_in_file_name+"B%d.tif"%band)
        raw_height = ms_im.RasterYSize
        raw_width = ms_im.RasterXSize
        dis = []

        for line in range(0,raw_height,1000):
            latms,lonms,h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline,[line], heightul,
                                                                        current_date,utc_gps,dut1,band)
            dist1 = np.sqrt((latms-latul)**2+(lonms-lonul)**2)
            dist1 = dist1.min()
            dis.append(dist1)
        dis = np.array(dis)
        best_k =  np.nonzero(dis==dis.min())[0][0]
        dis = []
        km1 = max(0,best_k-1)*1000
        kp1 = min((best_k+1)*1000,raw_height)
        print "     The best line is between %d and %d"%(km1,kp1)
        for line in range(km1,kp1,100):
            latms, lonms, h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline,[line], heightul,
                                                                          current_date, utc_gps, dut1, band)
            dist1 = np.sqrt((latms - latul) ** 2 + (lonms - lonul) ** 2)
            dist1 = dist1.min()
            dis.append(dist1)
        dis = np.array(dis)
        best_k = np.nonzero(dis == dis.min())[0][0]
        kp1 = km1+  min((best_k + 1) * 100, raw_height)
        km1 = km1 + max(0, best_k - 1) * 100
        print "     The best line is between %d and %d" % (km1, kp1)
        dis = []
        for line in range(km1, kp1,10):
            latms, lonms, h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline, [line],
                                                                          heightul,
                                                                          current_date, utc_gps, dut1, band)
            dist1 = np.sqrt((latms - latul) ** 2 + (lonms - lonul) ** 2)
            dist1 = dist1.min()
            dis.append(dist1)
        dis = np.array(dis)
        best_k = np.nonzero(dis == dis.min())[0][0]

        kp1 = km1 + min((best_k + 1) * 10, raw_height)
        km1 = km1 + max(0, best_k - 1) * 10
        print "     The best line is between %d and %d" % (km1, kp1)
        dis = []
        for line in range(km1, kp1):
            latms, lonms, h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline, [line],
                                                                          heightul,
                                                                          current_date, utc_gps, dut1, band)
            dist1 = np.sqrt((latms - latul) ** 2 + (lonms - lonul) ** 2)
            dist1 = dist1.min()
            dis.append(dist1)
        dis = np.array(dis)
        best_k = np.nonzero(dis == dis.min())[0][0]
        best_line = best_k+km1
        latms, lonms, h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline, [best_line],
                                                                      heightul,
                                                                      current_date, utc_gps, dut1, band)
        dist1 = np.sqrt((latms - latul) ** 2 + (lonms - lonul) ** 2)
        opt_samples = np.nonzero(dist1==dist1.min())[0][0]

        print "best line:%d for band %d at sample %d"%(best_k+km1-5,band,opt_samples)
        ms_lines.append(best_k+km1-5)

    print ms_lines

    # We need to link MS to PAN
    ms_step_sample = 30 # Smaller than  is faster, but less accurate
    ms_step_line =  30

    ms_width = (min(6000,ms_width_max)/ms_step_sample)*ms_step_sample
    ms_height = (min(ms_height_max,int(im_height*1.1/7.5))/ms_step_line)*ms_step_line

    num_pairs = (ms_height/ms_step_line+1)*(ms_width/ms_step_sample+1)


    cnt = 0

    try:
        lv2_pair_min_list = []
        lv2_pair_max_list = []
        print "try to find the matching image pair file for ger file."
        ger_pairs = np.loadtxt(pansharpen_info_dir + "/ger_pairpansharp%d.txt"%beg_line_pan)
        for band in [1, 2, 3, 4]:
            print "try to load matching image pair files for MS Band %d." % band
            lv2_pairs_min = np.loadtxt(pansharpen_info_dir + "/B%dpansharp_pair_min%d.txt"%(band, beg_line_pan))
            lv2_pairs_max = np.loadtxt(pansharpen_info_dir +"/B%dpansharp_pair_max%d.txt"%(band, beg_line_pan))
            lv2_pair_min_list.append(lv2_pairs_min)
            lv2_pair_max_list.append(lv2_pairs_max)


    except:
        lv2_pair_min_list = []
        lv2_pair_max_list = []
        print "The matching pair files have not been created."
        print "Generating the matching pair database."
        x_sampels = np.hstack((np.arange(0, ms_width,  ms_step_sample), np.array([ms_width - 1])))
        y_sampels = np.hstack((np.arange(0, ms_height, ms_step_line), np.array([ms_height - 1])))

        ger_pairs = np.zeros((num_pairs, 2))

        for band in [1, 2, 3, 4]:
            cnt = 0
            lv2_pairs_min = np.zeros((num_pairs, 2))
            lv2_pairs_max = np.zeros((num_pairs, 2))
            for s_line in y_sampels:
                print "find matching pairs of line %d" % s_line
                s_samples = x_sampels

                lata_min, lona_min, ha = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, s_samples,
                                                                                     [ms_lines[band - 1] + s_line], hmin,
                                                                                     current_date, utc_gps, dut1,
                                                                                     band=band)
                lata_max, lona_max, ha = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, s_samples,
                                                                                     [ms_lines[band - 1] + s_line], hmax,
                                                                                     current_date, utc_gps, dut1,
                                                                                     band=band)

                num_s = s_samples.shape[0]
                x, y, z, zl = utmLatlon.from_latlon(lata_min, lona_min, zonec)
                cols = (x - x2_up_left) / dx2
                rows = (y - y2_up_left) / dy2
                str = cnt * num_s
                stp = str + num_s
                #print str, stp
                lv2_pairs_min[str:stp, 0] = cols
                lv2_pairs_min[str:stp, 1] = rows


                x, y, z, zl = utmLatlon.from_latlon(lata_max, lona_max, zonec)
                cols = (x - x2_up_left) / dx2
                rows = (y - y2_up_left) / dy2

                lv2_pairs_max[str:stp, 0] = cols
                lv2_pairs_max[str:stp, 1] = rows


                if band == 4:
                    ger_pairs[str:stp, 0] = s_samples
                    ger_pairs[str:stp, 1] = s_line
                cnt += 1
            lv2_pair_min_list.append(lv2_pairs_min)
            lv2_pair_max_list.append(lv2_pairs_max)
            np.savetxt(pansharpen_info_dir +"/B%dpansharp_pair_min%d.txt"%(band,beg_line_pan), lv2_pairs_min)
            np.savetxt(pansharpen_info_dir +"/B%dpansharp_pair_max%d.txt"%(band,beg_line_pan), lv2_pairs_max)

        print "completed...saving to files."
        np.savetxt(pansharpen_info_dir +"/ger_pairpansharp%d.txt"%beg_line_pan, ger_pairs)


    # Remove all pairs with out of the PAN scene

    numpairs = ger_pairs.shape[0]

    offsetlows = [0, 0, 0, 0]
    offsethighs = [0, 0, 0, 0]  # [offset1,offset2,0,offset4]

    lv2_pairs_min = lv2_pair_min_list
    lv2_pairs_max = lv2_pair_max_list  # [lv2_pairs1_max,lv2_pairs2_max,lv2_pairs3_max,lv2_pairs4_max]

    gtiffDriver = gdal.GetDriverByName('GTiff')
    lv_width = int(num_samples)
    lv_height = int(num_lines)
    dst_ds = gtiffDriver.Create(out_file_name, lv_width, lv_height, 4, gdal.GDT_Byte)
    gtiffDriver = gdal.GetDriverByName('GTiff')
    lv_width = int(num_samples)
    lv_height = int(num_lines)
    u_mean = num_samples / 2.0
    v_mean = num_lines / 2.0
    pan_file = gdal.Open(pan_out_file)
    band1_pan = pan_file.GetRasterBand(1)
    #dem_ds_im = gtiffDriver.Create(pan_in_file_name + "_dem%d.tif"%beg_line_pan, lv_width, lv_height, 1, gdal.GDT_Float32)
    dem_ds_im = gdal.Open(pan_in_file_name + "DEM_%d.tif" % beg_line_pan)
    dem_ds = dem_ds_im.GetRasterBand(1)

    for band in [0,1,2,3]:
        u = lv2_pairs_min[band][:, 0]
        v = lv2_pairs_min[band][:, 1]
        # remove negative coordinate and larger than output image size
        idx = np.nonzero((u>=0)*(v>=0)*(u<=lv_width)*(v<=lv_height))
        idx = idx[0].flatten()
        u = u[idx]
        v = v[idx]
        gx = ger_pairs[idx, 0]
        gy = ger_pairs[idx, 1]
        num_pairs = len(idx)
        A = np.zeros((num_pairs, 12))

        u = u - u_mean
        v = v - v_mean + 1
        # print u.min(),u.max(),v.min(),v.max()
        A[:, 0] = 1.0
        A[:, 1] = u
        A[:, 2] = v
        A[:, 3] = u * v
        A[:, 4] = u ** 2
        A[:, 5] = v ** 2
        A[:, 6] = u * v * v
        A[:, 7] = v * u * u
        A[:, 8] = u ** 3
        A[:, 9] = v ** 3
        A[:, 10] = v * u ** 3
        A[:, 11] = u * v ** 3

        x_mean = 3000
        y_mean = 3000
        bx = gx - x_mean
        by = gy - y_mean
        a_x_min, errx, rnk, s = np.linalg.lstsq(A, bx)
        a_y_min, erry, rnk, s = np.linalg.lstsq(A, by)
        print errx, erry
        print A.shape
        print bx.shape
        print by.shape
        print "[%d] Minimun altitude average errors: %f,%f" % (band + 1, errx / numpairs, erry / num_pairs)

        u = lv2_pairs_max[band][:, 0]
        v = lv2_pairs_max[band][:, 1]

        # remove negative coordinate and larger than output image size
        idx = np.nonzero((u >= 0) * (v >= 0) * (u <= lv_width) * (v <= lv_height))
        idx = idx[0].flatten()
        print idx.shape
        u = u[idx]
        v = v[idx]
        gx = ger_pairs[idx, 0]
        gy = ger_pairs[idx, 1]
        num_pairs = len(idx)
        A = np.zeros((num_pairs, 12))

        u = u - u_mean
        v = v - v_mean + 1
        # print u.min(),u.max(),v.min(),v.max()
        A[:, 0] = 1.0
        A[:, 1] = u
        A[:, 2] = v
        A[:, 3] = u * v
        A[:, 4] = u ** 2
        A[:, 5] = v ** 2
        A[:, 6] = u * v * v
        A[:, 7] = v * u * u
        A[:, 8] = u ** 3
        A[:, 9] = v ** 3
        A[:, 10] = v * u ** 3
        A[:, 11] = u * v ** 3


        bx = gx - x_mean
        by = gy - y_mean
        a_x_max, errx, rnk, s = np.linalg.lstsq(A, bx)
        a_y_max, erry, rnk, s = np.linalg.lstsq(A, by)
        print "[%d] Maximum altitude average errors: %f,%f" % (band + 1, errx / numpairs, erry / num_pairs)

        if band == 0:
            bandk = dst_ds.GetRasterBand(3)
        elif band == 2:
            bandk = dst_ds.GetRasterBand(1)
        else:
            bandk = dst_ds.GetRasterBand(band + 1)



        # compute remap coordinate
        # We will remap for a 1000 lines at at time
        src_image = None
        src_image = gdal.Open(ms_in_file_name + "B%d.tif" % (band + 1))
        band_src = src_image.GetRasterBand(1)
        print src_image, band_src, (ms_in_file_name + "B%d.tif" % (band + 1))
        print  (0, offsetlows[band] + ms_lines[band], ms_width,
                                        ms_height + 200+ offsethighs[band] - offsetlows[band])
        databand = band_src.ReadAsArray(0, int(ms_lines[band]), ms_width, ms_height + 200)

        mem = psutil.virtual_memory()
        mem_available = mem.available
        max_num_pixels = (mem_available-(1024*1024*1024)) / ((400) * 8)  # 400 memory block per pixels and 8 for double
        num_lines = int(np.sqrt(max_num_pixels))
        num_pixels = num_lines
        print "[%d] The maximum number of lines and pixels are: %d,%d. " % (band + 1, num_lines, num_pixels)
        # num_lines = 1000
        # num_pixels = 1000
        off_set = 0
        num_lines2 = num_lines + off_set
        num_pixels2 = num_pixels  +off_set
        print "num_line:%d, num_pixel:%d"%(num_lines2,num_pixels2)
        outimage = np.zeros((lv_height, lv_width), 'uint8')
        sat_pos = np.loadtxt(ms_in_file_name + "B%d.pos" % (band + 1))
        captured_time = np.loadtxt(ms_in_file_name + "B%d.tim" % (band + 1))
        sat_att = np.loadtxt(ms_in_file_name + "B%d.att" % (band + 1))

        for line in range(0, lv_height, num_lines):
            for sample in range(0, lv_width, num_pixels):
                #line = 9700
                #sample = 700

                line_max = min((lv_height - line), num_lines2)
                samp_max = min(lv_width - sample, num_pixels2)
                if (line == 0) & (sample == 0):
                    V, U = np.mgrid[0:int(line_max), 0:int(samp_max)]
                elif (line == 0) & (sample > 0):
                    V, U = np.mgrid[0:int(line_max), sample - off_set:int(samp_max + sample)]
                elif (line > 0) & (sample == 0):

                    V, U = np.mgrid[line - off_set:int(line_max + line), 0:int(samp_max)]
                else:
                    V, U = np.mgrid[line - off_set:int(line_max + line), sample - off_set:int(samp_max + sample)]

                temp = np.zeros_like(U, 'uint8')
                u_earth = U * dx2 + x2_up_left
                v_earth = V * dy2 + y2_up_left
                late, lone = utmLatlon.to_latlon(u_earth, v_earth, zonec, zoneletter_c)

                # h = util.determineHeight(late,lone,dem_directory)
                print "[%d]  coord:" % (band + 1), late.min(), late.max(), lone.min(), lone.max()
                latgrid, longrid, hgrid = util.load_dem_data(
                    [late.max() + 30 * pixel_size, lone.min() - 30. * pixel_size],
                    [late.min() - 30 * pixel_size, lone.max() + 30. * pixel_size], dem_directory)

                # if band == 0:
                #     h = util.interpolateDemGrid(late, lone, latgrid, longrid, hgrid, pixel_size)
                #
                #     #dem_data = np.zeros_like(U, "float64")
                #     ofx = off_set * (sample != 0)
                #     ofy = off_set * (line != 0)
                #     dem_out = h[ofy:, ofx:].astype('float64')
                #     print "sample:%d, line:%d" % (sample, line), h.shape
                #     dem_ds.WriteArray(dem_out, sample, line)
                # else:
                urw,ucl = U.shape
                dem_data = dem_ds.ReadAsArray(sample,line,ucl,urw)
                ofx = off_set * (sample != 0)
                ofy = off_set * (line != 0)
                h = np.zeros_like(U,'float64')

                h[ofy:, ofx:] = dem_data[:urw-ofy,:ucl-ofx]
                print "[%d] remapping line: %d to %d and sample: %d to %d" % (
                band + 1, line, line + line_max, sample, sample + samp_max)


                U = U - u_mean
                V = V - v_mean

                U = U.flatten()
                V = V.flatten()
                h = h.flatten()
                X, Y = dps.findGerFileLocationPreLoadFiles(U, V, h, a_x_min, a_y_min, a_x_max, a_y_max, x_mean, y_mean,
                                                           u_mean,
                                                           v_mean, hmin, hmax, "MS", ms_in_file_name, ms_lines[band],
                                                           current_date,
                                                           utc_gps, dut1, (x2_up_left, y2_up_left, dx2, dy2, zonec),
                                                           ms_width, ms_height, sat_pos, captured_time, sat_att,
                                                           band=band + 1)

                Xmin = int(X.min())
                Xmax = int(np.ceil(X.max()))
                Ymin = int(Y.min())
                Ymax = int(np.ceil(Y.max()))
                strx = int(max(Xmin, 0))
                stpx = min(Xmax + 1, im_width)

                stry = max(Ymin, 0)
                stpy = min(Ymax + 1, im_height)

                print "[%d] Used the data from (%d,%d)->(%d,%d)" % (band + 1, strx, stry, stpx, stpy)
                if (strx < stpx) & (stry < stpy):
                    original = databand[stry:stpy, strx:stpx]
                    tr, tc = temp.shape
                    X = X.astype('float32')
                    Y = Y.astype('float32')
                    remap_out = cv2.remap(original, X - strx, Y - stry, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                          borderValue=0)
                    # print remap_out.shape
                    # print temp[(X>=X.min())*(X<=X.max())*(Y>=Y.min())*(Y<=Y.max())].shape
                    X = X.reshape(tr, tc)
                    Y = Y.reshape(tr, tc)
                    print "Load PAN image from (%d,%d) to (%d,%d)"%(sample,line,sample + samp_max,line +line_max)
                    pan_data = band1_pan.ReadAsArray(sample, line, samp_max , line_max)
                    print "Successfully load PAN image of size",pan_data.shape
                    temp[(X >= X.min()) * (X <= X.max()) * (Y >= Y.min()) * (Y <= Y.max())] = remap_out.flatten()
                    if (line == 0) & (sample == 0):
                        outimage[line:line + line_max, sample:sample + samp_max] = temp*(pan_data>0)
                    elif (line == 0):
                        outimage[line:line + line_max, sample:sample + samp_max] = temp[:, off_set:]*(pan_data>0)
                    elif (sample == 0):
                        outimage[line:line + line_max, sample:sample + samp_max] = temp[off_set:, :]*(pan_data>0)
                    else:
                        outimage[line:line + line_max, sample:sample + samp_max] = temp[off_set:, off_set:]*(pan_data>0)
        bandk.WriteArray(outimage, 0, 0)



    cl1 = np.round((xul-x2_up_left)/dx2)+1
    rw1 = np.round((yul-y2_up_left)/dy2)+1
    x1  = x2_up_left + dx2*cl1
    y1 = y2_up_left + dy2*rw1
    lat1 , lon1 = utm.to_latlon(x1,y1,zonec,zoneletter_c)

    cl2 = np.round((xur-x2_up_left)/dx2)+1
    rw2 = np.round((yur-y2_up_left)/dy2)+1
    x2  = x2_up_left + dx2*cl2
    y2 = y2_up_left + dy2*rw2
    lat2,lon2 = utm.to_latlon(x2,y2,zonec,zoneletter_c)

    cl3 = np.round((xll-x2_up_left)/dx2)+1
    rw3 = np.round((yll-y2_up_left)/dy2)+1
    x3  = x2_up_left + dx2*cl3
    y3 = y2_up_left + dy2*rw3
    lat3,lon3 = utm.to_latlon(x3,y3,zonec,zoneletter_c)

    cl4 = np.round((xlr-x2_up_left)/dx2)+1
    rw4 = np.round((ylr-y2_up_left)/dy2)+1
    x4  = x2_up_left + dx2*cl4
    y4 = y2_up_left + dy2*rw4
    lat4,lon4 = utm.to_latlon(x4,y4,zonec,zoneletter_c)

    cl5 = np.round((xc-x2_up_left)/dx2)+1
    rw5 = np.round((yc-y2_up_left)/dy2)+1
    x5  = x2_up_left + dx2*cl5
    y5 = y2_up_left + dy2*rw5
    lat5,lon5 = utm.to_latlon(x5,y5,zonec,zoneletter_c)
    print "Upper left vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw1,cl1)
    print "FRAME_X: %e, FRAME_COL: %e"%(x1,y1)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon1,lat1)
    print ".........................................................."

    print "Upper right vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw2,cl2)
    print "FRAME_X: %e, FRAME_COL: %e"%(x2,y2)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon2,lat2)
    print ".........................................................."

    print "Lower left vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw3,cl3)
    print "FRAME_X: %e, FRAME_COL: %e"%(x3,y3)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon3,lat3)
    print ".........................................................."

    print "Lower right vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw4,cl4)
    print "FRAME_X: %e, FRAME_COL: %e"%(x4,y4)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon4,lat4)
    print ".........................................................."

    print "Scene center.............................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw5,cl5)
    print "FRAME_X: %e, FRAME_COL: %e"%(x5,y5)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon5,lat5)
    print ".........................................................."
    dst_ds.SetGeoTransform( [ x2_up_left, 2.0, 0, y2_up_left, 0, -2.0 ] )
    srs = osr.SpatialReference()
    srs.SetWellKnownGeogCS("WGS84")
    if (lat5>=0) :
        srs.SetUTM( zonec, 1 )
    else :
        srs.SetUTM( zonec, 0 )


    dst_ds.SetProjection(srs.ExportToWkt())
    upleft =  [[cl1,rw1],[x1,y1],[lon1,lat1]]
    upright = [[cl2,rw2],[x2,y2],[lon2,lat2]]
    midpoint =[[cl5,rw5],[x5,y5],[lon5,lat5]]
    lowleft = [[cl3,rw3],[x3,y3],[lon3,lat3]]
    lowright= [[cl4,rw4],[x4,y4],[lon4,lat4]]
    return upleft, upright, midpoint, lowleft, lowright



