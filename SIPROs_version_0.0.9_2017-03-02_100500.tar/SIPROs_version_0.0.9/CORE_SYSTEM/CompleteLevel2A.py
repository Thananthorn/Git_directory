"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

 """

import generalFileReader as gr
import createImage2A as createImage
import os
import locationutil
import determine_pixel_shift as dps
import numpy as np
from xml.dom import minidom
from osgeo import gdal
from osgeo import osr
import cv2
import DIMAPLV2 as DIMAP1
import time
import digitalElevationModel as demservice

dem_directories = dict()





def MSDataExtraction(ms_ger_file_names, output_file_names, cpf_file_name, force_run=False):
    year, month, day,  band_bad_lines, band_degraded_lines = gr.readGerMSFiles(ms_ger_file_names, output_file_names, cpf_file_name, force_run)
    return year, month, day,  band_bad_lines, band_degraded_lines


def PANDataExtraction(pan_ger_file_names, output_file_names, cpf_file_name, force_run=False):
    year, month, day,  band_bad_lines, band_degraded_lines = gr.readGerPANFiles(pan_ger_file_names, output_file_names, cpf_file_name, force_run)
    return year, month, day,  band_bad_lines, band_degraded_lines


def find_ger_files(ger_dir):
    ger_file_list = []
    for filename in os.listdir(ger_dir):
        base, ext = os.path.splitext(filename)
        # print base, ext
        if ext.lower() == ".ger":
            ger_file = base + ext
            ger_file_list.append(ger_file)
    return ger_file_list


def createPreview(file_name, preview_file, icon_file, width, height):
    im = gdal.Open(file_name)
    imw = im.RasterXSize
    imh = im.RasterYSize
    scalex = float(imw)/float(width)
    scaley = float(imh)/float(height)
    scale = max(scalex , scaley)
    #steph = int(imh / height)
    #stepw = int(imw / width)
    scale_int = int(np.ceil(scale))

    realheight = int(np.ceil(float(imh) / scale_int))
    realwidht = int(np.ceil(float(imw) / scale_int))
    strx = width / 2 - realwidht / 2
    stpx = strx + realwidht
    stry = height / 2 - realheight / 2
    stpy = stry + realheight
    if im.RasterCount == 4:  # ms Images
        outim = np.zeros((realheight, realwidht, 3), 'uint8')
        preview_im = np.zeros((width, height,3),'uint8')

        b1 = im.GetRasterBand(3)
        b2 = im.GetRasterBand(2)
        b3 = im.GetRasterBand(1)
        for line in range(realheight):
            line_im = line * scale_int
            d1 = b1.ReadAsArray(0, line_im, imw, 1)
            d2 = b2.ReadAsArray(0, line_im, imw, 1)
            d3 = b3.ReadAsArray(0, line_im, imw, 1)
            outim[line, :, 0] = d1[0, ::scale_int]
            outim[line, :, 1] = d2[0, ::scale_int]
            outim[line, :, 2] = d3[0, ::scale_int]

        preview_im[stry:stpy,strx:stpx,:] = outim
    else:
        outim = np.zeros((realheight, realwidht), 'uint8')
        preview_im = np.zeros((width, height), 'uint8')
        b1 = im.GetRasterBand(1)
        for line in range(realheight):
            line_im = line * scale_int
            d1 = b1.ReadAsArray(0, line_im, imw, 1)
            outim[line, :] = d1[0, ::scale_int]
        preview_im[stry:stpy, strx:stpx] = outim
    cv2.imwrite(preview_file, preview_im)
    scale = min(width / 128, height / 128)
    icon = cv2.resize(preview_im, (width / scale, height / scale))
    cv2.imwrite(icon_file, icon)





def createLevel2A_MSImage(out_dir, ger_info_dir, ger_dir, cpf_file, band_lines, dem, start_sample=1, im_width=6000,
                          im_height=6000, dem_interp= "kriging", force_run=False):

    """"

    :param out_dir: output file directory
    :param ger_info_dir: the extracted files will be put in ger_info_dir
    :param ger_dir: director contraining .ger files
    :param cpf_file: absolute location of a .cpf file
    :param dem: dem services
    :param band_lines: begining line for level 2A image [band1, band2, band3, band4]
    :param start_sample: staring samples default 1
    :param im_width: ger_file_image width default 12,0000
    :param im_height:ger_file_image heeight default 12,0000
    :param dem_interp: interpolation method for dem {"kriging", "linear", "cubic","nearest", "rbf"} defualt "kriging"
    :param force_run: force to extract all the files default is false
    :return:
        date: [year, month, day] when image was captured
        utc_gps: UTC-GPS obtained from .cpf file
        ut1_utc: UT1-UTC obtained from .cpf file
        file:_name=prefix of name of the files containing information extracted from the .ger file
        upleft: upper left corner of the scene in [row-col,utm lat-lon]
        upright: upper right corner of the scene in [row-col,utm lat-lon]
        midpoint: scene center in [row-col,utm lat-lon]
        lowleft: lower left corner of the scene in [row-col,utm lat-lon]
        lowright: lower right corner of the scene in [row-col,utm lat-lon]
        map_info: [x coordinate upper left corner in level 2A, y coordinate upper left corner in level 2A,
                  pixel resolution in x-direction,pixel resolution in y-direction, average elevation of the scene,
                  utm zone number, True if northern hemisphere]
    """
    ms_ger_files = []
    ger_file_names = find_ger_files(ger_dir)
    for file_name in ger_file_names:
        ms_ger_files.append(ger_dir + "/" + file_name)
        ms_ger_files.sort()
    ms_ger_output_files = []
    for ger_file in ger_file_names:
        base, ext = os.path.splitext(ger_file)
        ms_ger_output_files.append(ger_info_dir + "/" + base)
        ms_ger_output_files.sort()

    year, month, day, band_bad_lines, band_degraded_lines = MSDataExtraction(ms_ger_files, ms_ger_output_files, cpf_file, force_run)
    date =[year,month,day]
    file_name = ms_ger_output_files[0][:-2]
    utc_gps, ut1_utc = locationutil.readGainsAndDarkCurrent(cpf_file)
    out_file = out_dir + "/IMAGERY.tif"
    if (os.path.isfile(out_file) == False) or force_run:
        g1 = []
        g2 = []
        g3 = []
        g4 = []
        d1 = []
        d2 = []
        d3 = []
        d4 = []

        for gnumber in range(1, 11):
            g, d = gr.readGainsAndDarkCurrent(cpf_file, 1, gnumber)
            g1.append(g)
            d1.append(d)

            g, d = gr.readGainsAndDarkCurrent(cpf_file, 2, gnumber)
            g2.append(g)
            d2.append(d)

            g, d = gr.readGainsAndDarkCurrent(cpf_file, 3, gnumber)
            g3.append(g)
            d3.append(d)

            g, d = gr.readGainsAndDarkCurrent(cpf_file, 4, gnumber)
            g4.append(g)
            d4.append(d)
        gain = [g1, g2, g3, g4]
        darkcurrent = [d1, d2, d3, d4]
        upleft, upright, midpoint, lowleft, lowright, map_info = \
            createImage.buildMS2AImageUsingCubicInterpolation(out_file, file_name, band_lines, date, utc_gps, ut1_utc,
                                                              dem, gain, darkcurrent, start_sample, im_width, im_height,
                                                              dem_interpolation_method=dem_interp)
    elif (os.path.isfile(out_file) == True):  # image file has been created.
        upleft, upright, midpoint, lowleft, lowright, map_info  = \
            createImage.computeMSImageCorners(out_file, file_name, band_lines, date, utc_gps, ut1_utc,
                                              dem, dem_interp,start_sample, im_width, im_height)
    scale = min(im_width / 1000, im_height / 1000)
    createPreview(out_file, out_dir + "/PREVIEW.JPG", out_dir + "/ICON.JPG", im_width / scale, im_height / scale)
    im = gdal.Open(out_file)
    proj = im.GetProjection()
    src = osr.SpatialReference()
    src.ImportFromWkt(proj)
    epsg = src.GetAttrValue("AUTHORITY", 1)
    map_info.append(epsg)
    width = im.RasterXSize
    height = im.RasterYSize
    map_info.append([width, height])

    return date, utc_gps, ut1_utc, file_name, upleft, upright, midpoint, lowleft, lowright,map_info,band_bad_lines,\
           band_degraded_lines



def loadFilter(apf_file, band="PAN", id=9):
    """

    :param apf_file: The .apf file containing filter parameters
    :param band: spectral band. Default is "PAN"
    :param id: filter id. The defualt id is 9.
    :return: a 5x5 filter
    """
    doc = minidom.parse(apf_file)
    resplist = doc.getElementsByTagName("RestorationParametersList")[0]
    resparms = resplist.getElementsByTagName("RestorationParameters")
    for resp in resparms:
        apf_band = resp.getAttribute("band")
        if apf_band == band:
            filter_list = resp.getElementsByTagName("filter")
            for filter in filter_list:
                filter_id = int(filter.getAttribute("id"))
                if filter_id == id:
                    filterout = np.fromstring(filter.childNodes[0].data, dtype="float32", sep=",")
    filter2D = filterout.reshape((5, 5))

    return filter2D


def createLevel2A_PANImage(out_dir, ger_info_dir, ger_dir, cpf_file, apf_file, dem, band_line, start_sample=1,
                           im_width=12000,
                           im_height=12000, dem_interp = "kriging", force_run="False"):
    """

    :param out_dir: output file directory
    :param ger_info_dir: the extracted files will be put in ger_info_dir
    :param ger_dir: director contraining .ger file
    :param cpf_file: absolute location of a .cpf file
    :param apf_file: absolute location of a .apf file
    :param dem: dem services
    :param band_line: begining line for level 2A image
    :param start_sample: staring samples default 1
    :param im_width: ger_file_image width default 12,0000
    :param im_height:ger_file_image heeight default 12,0000
    :param dem_interp: interpolation method for dem {"kriging", "linear", "cubic","nearest", "rbf"} defualt "kriging"
    :param force_run: force to extract all the files default is false
    :return:
        date: [year, month, day] when image was captured
        utc_gps: UTC-GPS obtained from .cpf file
        ut1_utc: UT1-UTC obtained from .cpf file
        file:_name=prefix of name of the files containing information extracted from the .ger file
        upleft: upper left corner of the scene in [row-col,utm lat-lon]
        upright: upper right corner of the scene in [row-col,utm lat-lon]
        midpoint: scene center in [row-col,utm lat-lon]
        lowleft: lower left corner of the scene in [row-col,utm lat-lon]
        lowright: lower right corner of the scene in [row-col,utm lat-lon]
        map_info: [x coordinate upper left corner in level 2A, y coordinate upper left corner in level 2A,
                  pixel resolution in x-direction,pixel resolution in y-direction, average elevation of the scene,
                  utm zone number, True if northern hemisphere]
    """



    pan_ger_files = []
    ger_file_names = find_ger_files(ger_dir)
    for file_name in ger_file_names:
        pan_ger_files.append(ger_dir + "/" + file_name)
        pan_ger_files.sort()
    pan_ger_output_files = []
    for ger_file in ger_file_names:
        base, ext = os.path.splitext(ger_file)
        pan_ger_output_files.append(ger_info_dir + "/" + base)
        pan_ger_output_files.sort()

    year, month, day, band_bad_lines, band_degraded_linees = PANDataExtraction(pan_ger_files, pan_ger_output_files, cpf_file, force_run)
    date = [year, month, day]
    file_name = pan_ger_output_files[0]
    utc_gps, ut1_utc = locationutil.readGainsAndDarkCurrent(cpf_file)
    out_file = out_dir + "/IMAGERY.tif"
    filter2D = []
    for id in range(1,10):
        filter = loadFilter(apf_file, "PAN", id)
        filter2D.append(filter)


    if (force_run == True) or (os.path.isfile(out_file) == False):
        gain = []
        dark_cur = []
        for gnumber in range(1, 11):
            g, d = gr.readGainsAndDarkCurrent(cpf_file, "PAN", gnumber)
            gain.append(g)
            dark_cur.append(d)
        upleft, upright, midpoint, lowleft, lowright, map_info  = \
            createImage.buildPAN2AImageUsingCubicInterpolation(out_file, file_name, band_line, date, utc_gps, ut1_utc,
                                                               dem, filter2D, gain, dark_cur, start_sample, im_width,
                                                               im_height,dem_interpolation_method=dem_interp )
    elif (os.path.isfile(out_file) == True):  # image file has been created.



        upleft, upright, midpoint, lowleft, lowright, map_info = \
            createImage.computePANImageCorners(out_file, file_name, band_line, date, utc_gps, ut1_utc, dem,
                                               dem_interp, filter2D, start_sample, im_width, im_height)
    im = gdal.Open(out_file)
    proj = im.GetProjection()
    src = osr.SpatialReference()
    src.ImportFromWkt(proj)
    epsg = src.GetAttrValue("AUTHORITY", 1)
    map_info.append(epsg)
    width = im.RasterXSize
    height = im.RasterYSize
    map_info.append([width, height])

    scale = min(im_width / 1000, im_height / 1000)
    createPreview(out_file, out_dir + "/PREVIEW.JPG", out_dir + "/ICON.JPG", im_width / scale, im_height / scale)

    return date, utc_gps, ut1_utc, file_name, upleft, upright, midpoint, lowleft, lowright, map_info,  \
           band_bad_lines, band_degraded_linees


def computeDIMAPParametersLevel2A(ger_info_prefix, dem, dem_interpolation_method, image_type, line1, date, utc_gps, ut1_utc, start_sample,
                                  im_width, im_height, midpoint):
    """

    :param ger_info_prefix: text containing all prefix to files extracted from .ger
    :param dem: dem service
    :param dem_interpolation_method: string indicate dem tyoe
    :param image_type: "MS" for multispectral, "PAN" for panchromatic images
    :param line1: first line of Band 3 for multispectral image, and first line of panchromatic image
    :param date: [year, month, day] of capturing image
    :param utc_gps: UTC-GPS time
    :param ut1_utc: UT1-UTC time
    :param midpoint = latitude and longitude of the center of the image
    :return:
    upleft: latitude and longitude of pixel 1,1 in the image
    upright: latitude and longitude of pixel 1,width in the image
    lowleft = latitude and longitude of pixel height,1 in the image
    lowright = latitude and longitude of pixel height,width in the image
    midpoint = latitude and longitude of the center of the image
    view_angles = viewing angles along and across track.
    sat_angles = satellite incidence and azimuth angles
    sun_angles = sun azimuth and elevation angles
    orientation: orientation of the scene.

    """

    mid_s = start_sample + im_width / 2 - 1
    mid_l = line1 + im_height / 2 - 1
    lat_mid = midpoint[2][1]
    lon_mid = midpoint[2][0]

    al, al_along, al_across, sat_incidence, sat_azimuth, sat_altitude = dps.findViewingAngles(image_type,
                                                                                              ger_info_prefix,
                                                                                              mid_l, mid_s, date,
                                                                                              utc_gps, ut1_utc,
                                                                                              lat_mid, lon_mid)

    print "VIEWING_ANGLE_ALONG_TRACK: %f, VIEWING_ANGLE_ACROSS_TRACK: %f" % (al_along, al_across)
    print "SATELLITE_INCIDENCE_ANGLE: %f, SATELLITE_AZIMUTH_ANGLE: %f, SATELLITE_ALTITUDE: %f" % (
        sat_incidence, sat_azimuth, sat_altitude)
    orientation = dps.findOrientationAngle(image_type, ger_info_prefix, mid_l, date, utc_gps, ut1_utc, dem,
                                           dem_interpolation_method)
    print "SCENE_ORIENTATION: %f" % orientation
    sun_ev, sun_az = dps.findSunAngles(image_type, ger_info_prefix, mid_l, date, utc_gps, ut1_utc, lat_mid,
                                       lon_mid)
    print "SUN_AZIMUTH: %f,SUN_ELEVATION: %f" % (sun_az, sun_ev)

    view_angles = [al_along, al_across]
    sat_angles = [sat_incidence, sat_azimuth]
    sun_angles = [sun_az, sun_ev]
    return view_angles, sat_angles, sat_altitude, sun_angles, orientation





def buildLevel2A_MS(ger_dir, cpf_file, band_lines, ger_info_dir, out_dir, dem_type, dem_interp="kriging",
                    start_sample=1, im_width=6000,im_height=6000, force_run=False):
    """

    :param ger_dir: sting  of the absolute Directory containing GER file
    :param cpf_file: string of the absolute cpf file name
    :param band_lines  the scan lines corresponding to the first line of the ourput image in
                format [band1,band2,band3,band4]
    :param ger_info_dir: string of the absolute path to the directory containing all extracted information
    :param out_dir: string of the absolute path to the directory containing all extracted tiff image and previews
    :param dem_type  string of digital elevation model database
    :param dem_interp: dem interpolation method {"kriging","nearest","linear","cubic","rbf"} [defualt: "kriging"]
    :param start_sample: starting sample in ger file [defualt: 1]
    :param im_width: the used area in width [default: 12,0000]
    :param im_height: the used area in height [default: 12,0000]
    :param force_run: True to force the system to re-extracting every files
    :return:
        upright: upper right corner of the scene in [row-col,utm lat-lon]
        midpoint: scene center in [row-col,utm lat-lon]
        lowleft: lower left corner of the scene in [row-col,utm lat-lon]
        lowright: lower right corner of the scene in [row-col,utm lat-lon]
        map_info: [x coordinate upper left corner in level 2A, y coordinate upper left corner in level 2A,
                  pixel resolution in x-direction,pixel resolution in y-direction, average elevation of the scene,
                  utm zone number, True if northern hemisphere]
        view_angles: viewing angles along and across track
        sat_angles: satellite incidence and azimuth angles
        sat_altitude: satellite altitude in meters
        sun_angles: sun elevation and azimuth angles
        orientation: scene orientation
    """
    ts = time.time()
    print "Extracting GER file....."
    if dem_type == demservice.SRTM90_DEM:
        dem = demservice.srtm90(dem_directories[dem_type])
    elif dem_type == demservice.GLOBE_DEM:
        dem = demservice.globedem(dem_directories[dem_type])
    elif dem_type == demservice.THEOS_DEM:
        dem = demservice.theosDEM(dem_directories[dem_type])
    elif dem_type == demservice.SRTM30_DEM :
        dem = demservice.srtm30(dem_directories[dem_type])


    date, utc_gps, ut1_utc, ger_prefix, upleft, upright, midpoint, lowleft, lowright, map_info, band_band_lines,\
    band_degraded_lines =\
        createLevel2A_MSImage(out_dir, ger_info_dir, ger_dir, cpf_file, band_lines, dem, dem_interp=dem_interp,
                              start_sample=start_sample, im_width=im_width, im_height=im_height,force_run=force_run)
    print "file extraction completed."
    print "computing TILE points."
    view_angles, sat_angles, sat_altitude, sun_angles, orientation = computeDIMAPParametersLevel2A(ger_prefix, dem, dem_interp,
                                                                                                   "MS",
                                                                                                   band_lines[2], date,
                                                                                                   utc_gps,
                                                                                                   ut1_utc,
                                                                                                   start_sample,
                                                                                                   im_width, im_height,
                                                                                                   midpoint)
    print "completed."
    print "Embedding TILE points into theimage file.."
    ms = gdal.Open(out_dir + "/IMAGERY.tif", gdal.GA_Update)
    t = time.gmtime()
    metadata = {'TIFFTAG_DATETIME': '%s  ' % time.strftime("%Y%m%d %H:%M:%S", t), 'TIFFTAG_IMAGEDESCRIPTION': 'PAN',
                'AREA_OR_POINT': 'Point'}
    ms.SetMetadata(metadata)
    ms = None
    print "completed."
    tp = time.time()
    print "Total processing time: %fs." % (tp - ts)
    return upleft, upright, midpoint, lowleft, lowright, map_info, view_angles, sat_angles, sat_altitude, sun_angles, \
           orientation, band_band_lines, band_degraded_lines


def buildLevel2A_PAN(ger_dir, cpf_file, apf_file, band_line, ger_info_dir, out_dir, dem_type,
                     dem_interp=demservice.digitalElevationModel.CUBIC, start_sample=1,
                     im_width=12000, im_height=12000, force_run=False):
    """

    :param ger_dir: sting  of the absolute Directory containing GER file
    :param cpf_file: string of the absolute cpf file name
    :param apf_file: string of the absolute apf file name
    :param band_line:  the scan lines corresponding to the first line of the ourput image
    :param ger_info_dir: string of the absolute path to the directory containing all extracted information
    :param out_dir: string of the absolute path to the directory containing all extracted tiff image and previews
    :param dem_type:  string of the digital elevation model database
    :param dem_interp: dem interpolation method {"kriging","nearest","linear","cubic","rbf"} [defualt: "kriging"]
    :param start_sample: starting sample in ger file [defualt: 1]
    :param im_width: the used area in width [default: 12,0000]
    :param im_height: the used area in height [default: 12,0000]
    :param force_run: True to force the system to re-extracting every files
    :return:
        upright: upper right corner of the scene in [row-col,utm lat-lon]
        midpoint: scene center in [row-col,utm lat-lon]
        lowleft: lower left corner of the scene in [row-col,utm lat-lon]
        lowright: lower right corner of the scene in [row-col,utm lat-lon]
        map_info: [x coordinate upper left corner in level 2A, y coordinate upper left corner in level 2A,
                  pixel resolution in x-direction,pixel resolution in y-direction, average elevation of the scene,
                  utm zone number, True if northern hemisphere]
        view_angles: viewing angles along and across track
        sat_angles: satellite incidence and azimuth angles
        sat_altitude: satellite altitude in meters
        sun_angles: sun elevation and azimuth angles
        orientation: scene orientation
    """

    if dem_type == demservice.SRTM90_DEM:
        dem = demservice.srtm90(dem_directories[dem_type])
    elif dem_type == demservice.GLOBE_DEM:
        dem = demservice.globedem(dem_directories[dem_type])
    elif dem_type == demservice.THEOS_DEM:
        dem = demservice.theosDEM(dem_directories[dem_type])
    elif dem_type == demservice.SRTM30_DEM :
        dem = demservice.srtm30(dem_directories[dem_type])

    ts = time.time()
    print "GER file extracing......."
    date, utc_gps, ut1_utc, ger_prefix, upleft, upright, midpoint, lowleft, lowright, map_info, \
    band_band_lines, band_degraded_lines = createLevel2A_PANImage(out_dir, ger_info_dir, ger_dir, cpf_file, apf_file,
                                                                    dem, band_line,  dem_interp=dem_interp,
                                                                    start_sample=start_sample,im_width= im_width,
                                                                    im_height=im_height, force_run=force_run)
    print "Extraction completed."
    print "computing the TILE points"
    print "file extraction completed."
    print "computing TILE points."
    view_angles, sat_angles, sat_altitude, sun_angles, orientation = computeDIMAPParametersLevel2A(ger_prefix, dem,
                                                                                                   dem_interp,
                                                                                                   "PAN",
                                                                                                   band_line, date,
                                                                                                   utc_gps,
                                                                                                   ut1_utc,
                                                                                                   start_sample,
                                                                                                   im_width, im_height,
                                                                                                   midpoint)
    print "completed."
    print "Embedding TILE points into theimage file.."
    ms = gdal.Open(out_dir + "/IMAGERY.tif", gdal.GA_Update)
    t = time.gmtime()
    metadata = {'TIFFTAG_DATETIME': '%s  ' % time.strftime("%Y%m%d %H:%M:%S", t), 'TIFFTAG_IMAGEDESCRIPTION': 'PAN',
                'AREA_OR_POINT': 'Point'}
    ms.SetMetadata(metadata)
    ms = None
    print "completed."
    tp = time.time()
    print "Total processing time: %fs." % (tp - ts)
    return upleft, upright, midpoint, lowleft, lowright, map_info, view_angles, sat_angles,\
           sat_altitude, sun_angles, orientation,band_band_lines, band_degraded_lines


def buildLevel2AImage(image_type,ger_directory,cpf_file, apf_file,begin_line,dem_type,info_directory,destination_directory,
                      rev_num, grid_ref,dem_dirs, dem_interpolation=demservice.digitalElevationModel.CUBIC,line_shift=0,start_sample = 1,
                      im_width=None,im_height = None,force_run= False):
    """
    The main code for building Level2A MS and PAN IMAGE
    :param image_type: "PAN" or "MS"
    :param ger_directory: directory containing ger files
    :param cpf_file: the cpf file associated with GER file
    :param apf_file: the advanced parameter files
    :param begin_line: the first line of the image
    :param dem_type: type of DEM used in the creation of LEVEL 2A product.
    :param info_directory: The directory that is used to stored all extracted data
    :param destination_directory: The output directory
    :param rev_num: revolution number
    :param grid_ref: the grid reference
    :param dem_dirs: dem directory object
    :param dem_interpolation: the interpolation method NEAREST, LINEAR, CUBIC, RBF, KRIGING
    :param line_shift: "The number of line shifted from the grid
    :param start_sample: The start sample. The default values i one
    :param im_width: Image width 6000 for MS and  12000 for PAN
    :param im_height: Image height6000 for MS and  12000 for PAN
    :param force_run: True to force the system to re-extracting all files.
    :return: None
    """
    job_time = time.time()
    dem_directories[demservice.SRTM90_DEM] = dem_dirs.SRTM90
    dem_directories[demservice.GLOBE_DEM] = dem_dirs.GLOBE
    dem_directories[demservice.THEOS_DEM] = dem_dirs.THEOS
    dem_directories[demservice.SRTM30_DEM] = dem_dirs.SRTM30
    if image_type =="PAN": # PAN IMAGE
        if (im_width is None):
            im_width = 12000
        if (im_height is None):
            im_height = 12000

        if isinstance(begin_line, list):
            if len(begin_line) > 1:
                raise ("begin_line must be one dimension list or an integer!!")
            else:
                begin_line = begin_line[0]
        elif not isinstance(begin_line, int):
            raise ("begin_line must be one dimension list or an integer!!")

        upleft, upright, midpoint, lowleft, lowright, map_info, view_angles, sat_angles, sat_altitude, sun_angles,\
        orientation, band_band_lines, band_degraded_lines = \
            buildLevel2A_PAN(
                ger_directory, cpf_file, apf_file, begin_line, info_directory, destination_directory, dem_type,
                dem_interp= dem_interpolation, start_sample=start_sample, im_width=im_width, im_height=im_height,
                force_run=force_run)
        angle_list = [upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles,
                      orientation, map_info]
        print "Create DIMAP file."
        DIMAP1.dimap_create(destination_directory, rev_num, "PAN", grid_ref, [begin_line], info_directory, cpf_file,
                            angle_list, start_sample, im_width, im_height, band_band_lines,
                            band_degraded_lines, line_shift, job_time)
        print "completed."
    elif image_type == "MS": # MS IMAGE
        if (im_width is None):
            im_width = 6000
        if (im_height is None):
            im_height = 6000
        upleft, upright, midpoint, lowleft, lowright, map_info, view_angles, sat_angles, sat_altitude, sun_angles, \
        orientation, band_band_lines, band_degraded_lines\
            = buildLevel2A_MS(ger_directory, cpf_file, begin_line, info_directory, destination_directory,
                                      dem_type, dem_interp= dem_interpolation, start_sample=start_sample,
                                      im_width=im_width, im_height=im_height, force_run=force_run)
        angle_list = [upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles,
                      orientation, map_info]
        print "creating DIMAP"
        DIMAP1.dimap_create(destination_directory, rev_num, "MS", grid_ref, begin_line, info_directory,
                            cpf_file, angle_list,  start_sample, im_width, im_height, band_band_lines,
                            band_degraded_lines,line_shift, job_time)

        print "completed."
    else:
        print "Invalid image type"
        exit(1)
    job_time2 = time.time()
    print "Total Prpcessing time is %f s." % (job_time2 - job_time)
