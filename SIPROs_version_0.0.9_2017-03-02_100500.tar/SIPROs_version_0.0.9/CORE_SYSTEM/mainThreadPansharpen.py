"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""


import CompletePanSharpen as pansharpenSystem
import digitalElevationModel as demservice
from systemConstants import pansharpenMethods

# SYSTEM CONSTANTS
class demDirectory:
    SRTM30 = ""
    SRTM90 ="/home/sipros/Application_1A_2A/Sipros_System/dem/SRTM_90"
    GLOBE = "/home/sipros/Application_1A_2A/Sipros_System/dem/globe"
    THEOS = "/home/sipros/Application_1A_2A/Sipros_System/dem/THEOS_DEM"


class processingLevel:
    LEVEL1A = "1A"
    LEVEL2A = "2A"



class sensorType:
    PAN ="PAN"
    MS = "MS"



class pansharpenSceneInfo:
    pan_ger_dir = r"C:\Worker\Support-Worker\Sipros_system\GERALD\THEOS_1_LEVEL0_1_111027827_27827_PAN_PB_TOP_1_11_2014-01-14_03-19-06"
    # GERALD Directory for the PAN Image
    ms_ger_dir = r"C:\Worker\Support-Worker\Sipros_system\GERALD\THEOS_1_LEVEL0_1_111027827_27827_MS_PB_TOP_2_12_2014-01-14_03-19-07"
    # GERALD Directory for the MS Image
    cpf_file = r"C:\Worker\Support-Worker\Sipros_system\CPF_PROCESSING\CPF_file\THEOS_1_20131230_000000_20131231_000000.CPF"
    pan_sharpen_info = r"C:\Worker\Support-Worker\Sipros_system\Extraction_files\THEOS_1_LEVEL0_1_111027827_27827_PANSHARPEN_PB_TOP_1_11_2014-01-14_03-19-06"
    ger_pan_info = r"C:\Worker\Support-Worker\Sipros_system\Extraction_files\THEOS_1_LEVEL0_1_111027827_27827_PAN_PB_TOP_1_11_2014-01-14_03-19-06"
    ger_ms_info = r"C:\Worker\Support-Worker\Sipros_system\Extraction_files\THEOS_1_LEVEL0_1_111027827_27827_MS_PB_TOP_2_12_2014-01-14_03-19-07"
    pansharp_out = r"C:\Worker\Support-Worker\Sipros_system\Product_files\THEOS_1_LEVEL0_1_111027827_27827_PANSHARPEN_PB_TOP_1_11_2014-01-14_03-19-06"
    revolution = "27827"
    line_shift = 0
    grid_id = "262-323"

class pansharpenProcessSetup:
    processing_level = processingLevel.LEVEL2A
    dem_interpolation = demservice.digitalElevationModel.CUBIC
    dem_type = demservice.THEOS_DEM
    apf_file =r"C:\Worker\Support-Worker\Sipros_system\APF\THEOS_nominal.APF"
    pansharpen_algorithm = pansharpenMethods.HIGHPASS_MODULATION
    pan_begin_line = 31622

def callPansharpenProcessingSystem():
    processing_level = pansharpenProcessSetup.processing_level
    pansharpen_algorithm = pansharpenProcessSetup.pansharpen_algorithm
    ms_dir = pansharpenSceneInfo.ms_ger_dir
    pan_dir = pansharpenSceneInfo.pan_ger_dir
    cpf_file = pansharpenSceneInfo.cpf_file
    begin_line = pansharpenProcessSetup.pan_begin_line
    pan_sharpen_info = pansharpenSceneInfo.pan_sharpen_info
    ger_pan_info = pansharpenSceneInfo.ger_pan_info
    ger_ms_info = pansharpenSceneInfo.ger_ms_info
    pansharp_out = pansharpenSceneInfo.pansharp_out
    apf_file = pansharpenProcessSetup.apf_file
    dem_dir = demDirectory
    dem_type = pansharpenProcessSetup.dem_type
    dem_interpolation_method = pansharpenProcessSetup.dem_interpolation
    rev_num = pansharpenSceneInfo.revolution
    grid_ref = pansharpenSceneInfo.grid_id
    line_shift = pansharpenSceneInfo.line_shift
    pansharpenSystem.build_PANSHARPEN(processing_level, pansharpen_algorithm, ms_dir, pan_dir,
                                      cpf_file,begin_line,  pan_sharpen_info, ger_pan_info, ger_ms_info,
                                      pansharp_out, apf_file,rev_num, grid_ref, line_shift,
                                      dem_dir, dem_type, dem_interpolation_method)



if __name__ == "__main__":
    callPansharpenProcessingSystem()
