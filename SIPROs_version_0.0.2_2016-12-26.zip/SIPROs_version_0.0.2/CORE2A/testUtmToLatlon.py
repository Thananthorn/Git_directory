# ////////////////////////////////////////////////////////////////////////////////////////////
# //
# // ToLL - function to compute Latitude and Longitude given UTM Northing and Easting in meters
# //
# //  Description:
# //    This member function converts input north and east coordinates
# //    to the corresponding Northing and Easting values relative to the defined
# //    UTM zone.  Refer to the reference in this file's header.
# //
# //  Parameters:
# //    north   - (i) Northing (meters)
# //    east    - (i) Easting (meters)
# //    utmZone - (i) UTM Zone of the North and East parameters
# //    lat     - (o) Latitude in degrees
# //    lon     - (o) Longitude in degrees
# //

from osgeo import osr

import numpy as np
import utmLatlon


def DegToRad(x):
    return x * np.pi / 180.0

def RadToDeg(x) :
    return x * 180.0 / np.pi

def ToLL(north, east, utmZone):
    # This is the lambda knot value in the reference
    LngOrigin = DegToRad(utmZone * 6 - 183)

    # The following set of class constants define characteristics of the
    # ellipsoid, as defined my the WGS84 datum.  These values need to be
    # changed if a different dataum is used.

    FalseNorth = 0.  # South or North?
    # if ( lat < 0.):
    #     FalseNorth = 10000000.  # South or North?
    # else:
    #     FalseNorth = 0.

    Ecc = 0.081819190842622  # Eccentricity
    EccSq = Ecc * Ecc
    Ecc2Sq = EccSq / (1. - EccSq)
    Ecc2 = np.sqrt(Ecc2Sq)  # Secondary eccentricity
    E1 = (1 - np.sqrt(1 - EccSq)) / (1 + np.sqrt(1 - EccSq))
    E12 = E1 * E1
    E13 = E12 * E1
    E14 = E13 * E1

    SemiMajor = 6378137.0  # Ellipsoidal semi-major axis (Meters)
    FalseEast = 500000.0  # UTM East bias (Meters)
    ScaleFactor = 0.9996  # Scale at natural origin

    # Calculate the Cassini projection parameters

    M1 = (north - FalseNorth) / ScaleFactor
    Mu1 = M1 / (SemiMajor * (1 - EccSq / 4.0 - 3.0 * EccSq * EccSq / 64.0 - 
                              5.0 * EccSq * EccSq * EccSq / 256.0))

    Phi1 = Mu1 + (3.0 * E1 / 2.0 - 27.0 * E13 / 32.0) * np.sin(2.0 * Mu1)\
           + (21.0 * E12 / 16.0 - 55.0 * E14 / 32.0) * np.sin(4.0 * Mu1)\
           + (151.0 * E13 / 96.0) * np.sin(6.0 * Mu1) + (1097.0 * E14 / 512.0) * np.sin(8.0 * Mu1)

    sin2phi1 = np.sin(Phi1) * np.sin(Phi1)
    Rho1 = (SemiMajor * (1.0 - EccSq)) / ((1.0 - EccSq * sin2phi1) ** 1.5)
    Nu1 = SemiMajor / np.sqrt(1.0 - EccSq * sin2phi1)

    # Compute parameters as defined in the POSC specification.  T, C and D

    T1 = np.tan(Phi1) * np.tan(Phi1)
    T12 = T1 * T1
    C1 = Ecc2Sq * np.cos(Phi1) * np.cos(Phi1)
    C12 = C1 * C1
    D = (east - FalseEast) / (ScaleFactor * Nu1)
    D2 = D * D
    D3 = D2 * D
    D4 = D3 * D
    D5 = D4 * D
    D6 = D5 * D

    # Compute the Latitude and Longitude and convert to degrees
    lat = Phi1 - Nu1 * np.tan(Phi1) / Rho1 * (D2 / 2.0 - (5.0 + 3.0 * T1 + 10.0 * C1 - 4.0 * C12 - 9.0 * Ecc2Sq) * D4 / 24.0
                                           + (61.0 + 90.0 * T1 + 298.0 * C1 + 45.0 * T12 - 252.0 * Ecc2Sq - 3.0 * C12) * D6 / 720.0)

    lat = RadToDeg(lat)

    lon = LngOrigin + (D - (1.0 + 2.0 * T1 + C1) * D3 / 6.0 + (5.0 - 2.0 * C1 + 28.0 * T1
                                                          - 3.0 * C12 + 8.0 * Ecc2Sq + 24.0 * T12) * D5 / 120.0) / np.cos(Phi1)

    lon = RadToDeg(lon)

    # Create a object to store the calculated Latitude and Longitude values
    sendLatLon = [lat, lon]

    # Returns a PC_LatLon object
    return sendLatLon



print utmLatlon.from_latlon(np.array(47.9941214), np.array(7.8509671))




def get_utm_zone(longitude):
    return (int(1 + (longitude + 180.0) / 6.0))


def is_northern(latitude):
    """
    Determines if given latitude is a northern for UTM
    """
    if (latitude < 0.0):
        return 0
    else:
        return 1

utm_coordinate_system = osr.SpatialReference()
utm_coordinate_system.SetWellKnownGeogCS("WGS84")  # Set geographic coordinate system to handle lat/lon
utm_coordinate_system.SetUTM(get_utm_zone(7.8509671), is_northern(47.9941214))
wgs84_coordinate_system = utm_coordinate_system.CloneGeogCS()
wgs84_to_utm_transform = osr.CoordinateTransformation(wgs84_coordinate_system, utm_coordinate_system)
print wgs84_to_utm_transform.TransformPoint(7.8509671, 47.9941214, 0)
