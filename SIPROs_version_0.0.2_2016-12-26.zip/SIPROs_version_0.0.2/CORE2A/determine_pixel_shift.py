__author__ = 'professor'
# import gdal
import datetime
import platform
import time

import digitalElevationModel as demservice
import dutil
import locationutil as util
import matplotlib.pyplot as plt
import multiprocessing as mlp
import numpy as np
import utmLatlon


if platform.system() == "Windows":
    from osgeo import gdal
else:
    import gdal

def computeJDtime(date, time, utc_gps) :
    t1 = time
    hour1 = int(np.floor(t1 / 3600.0))
    t1 -= hour1 * 3600.0
    minute1 = int(np.floor(t1) / 60.0)
    second1 = t1 - minute1 * 60.0
    micsec1 = second1 - int(np.floor(second1))
    micsec1 = int(micsec1 * 1e6)
    second1 = int(second1)
    tt1 = dutil.datetime(date[0], date[1], date[2], hour1, minute1, second1, micsec1)
    JD1 = tt1.to_jd() + utc_gps / (24 * 60.*60.)
    return JD1

def w(x):
    a = -0.5
    a3 = a + 2.0
    a2 = -a - 3.0
    b3 = a
    b2 = -5.0 * a
    b1 = 8 * a
    b0 = -4 * a
    absx = np.abs(x)
    absx3 = absx ** 3
    absx2 = absx ** 2
    y1 = a3 * absx3 ** 3 + a2 * absx2 + 1.0
    y2 = b3 * absx3 + b2 * absx2 + b1 * absx + b0
    y = y1 * (absx <= 1.0) + y2 * (absx > 1) * (absx < 2.0)
    return y

def find_pixel_shift(in_file_name, lines, current_date, utc_gps) :
    im_height = 6000
    im_width = 6000
    samples = np.arange(1, im_width + 1, 100)
    samples2 = np.arange(1, im_width + 1, 100).reshape((60, 1))
    samples_full = np.arange(1, im_width + 1)
    posB1 = np.loadtxt(in_file_name + "B1.pos")
    posB2 = np.loadtxt(in_file_name + "B2.pos")
    posB3 = np.loadtxt(in_file_name + "B3.pos")
    posB4 = np.loadtxt(in_file_name + "B4.pos")

    timeB1 = np.loadtxt(in_file_name + "B1.tim")
    timeB2 = np.loadtxt(in_file_name + "B2.tim")
    timeB3 = np.loadtxt(in_file_name + "B3.tim")
    timeB4 = np.loadtxt(in_file_name + "B4.tim")

    attB1 = np.loadtxt(in_file_name + "B1.att")
    attB2 = np.loadtxt(in_file_name + "B2.att")
    attB3 = np.loadtxt(in_file_name + "B3.att")
    attB4 = np.loadtxt(in_file_name + "B4.att")

    band1 = gdal.Open(in_file_name + "B1.tif")
    band2 = gdal.Open(in_file_name + "B2.tif")
    band3 = gdal.Open(in_file_name + "B3.tif")
    band4 = gdal.Open(in_file_name + "B4.tif")


    # out_im = np.zeros((im_height,im_height,4),'uint8')
    out_line0 = np.zeros((1, im_width), 'uint8')
    posB1 = posB1[lines[0]:lines[0] + im_height]
    posB2 = posB2[lines[1]:lines[1] + im_height]
    posB3 = posB3[lines[2]:lines[2] + im_height]
    posB4 = posB4[lines[3]:lines[3] + im_height]

    timeB1 = timeB1[lines[0]:lines[0] + im_height]
    timeB2 = timeB2[lines[1]:lines[1] + im_height]
    timeB3 = timeB3[lines[2]:lines[2] + im_height]
    timeB4 = timeB4[lines[3]:lines[3] + im_height]

    attB1 = attB1[lines[0]:lines[0] + im_height]
    attB2 = attB2[lines[1]:lines[1] + im_height]
    attB3 = attB3[lines[2]:lines[2] + im_height]
    attB4 = attB4[lines[3]:lines[3] + im_height]
    band1 = gdal.Open(in_file_name + "B1.tif")
    band2 = gdal.Open(in_file_name + "B2.tif")
    band3 = gdal.Open(in_file_name + "B3.tif")
    band4 = gdal.Open(in_file_name + "B4.tif")
    t1 = 0
    t2 = 0
    t3 = 0
    t4 = 0
    t5 = 0
    a_offset = []
    steps = 100
    n_samples = 6000 / 100
    for k in range(0, 6000, 5000):
        tst = time.clock()
        jd1 = computeJDtime(current_date, timeB1[k], utc_gps)
        jd2 = computeJDtime(current_date, timeB2[k], utc_gps)
        jd3 = computeJDtime(current_date, timeB3[k], utc_gps)
        jd4 = computeJDtime(current_date, timeB4[k], utc_gps)
        tsp = time.clock()
        t1 += tsp - tst
        # print t1
        tst = time.clock()
        uecef1 = util.computeUECEF(jd1, samples, attB1[k], 1)
        uecef2 = util.computeUECEF(jd2, samples, attB2[k], 2)
        uecef3 = util.computeUECEF(jd3, samples, attB3[k], 3)
        uecef4 = util.computeUECEF(jd4, samples, attB4[k], 4)
        tsp = time.clock()
        t2 += tsp - tst
        tst = time.clock()
        earth_post1 = util.findEarthSurfacePosition(uecef1, posB1[k])
        earth_post2 = util.findEarthSurfacePosition(uecef2, posB2[k])
        earth_post3 = util.findEarthSurfacePosition(uecef3, posB3[k])
        earth_post4 = util.findEarthSurfacePosition(uecef4, posB4[k])
        tsp = time.clock()
        t3 += tsp - tst
        tst = time.clock()
        lat1, lon1, height1 = util.itrf2latlon(earth_post1)
        lat2, lon2, height2 = util.itrf2latlon(earth_post2)
        lat3, lon3, height3 = util.itrf2latlon(earth_post3)
        lat4, lon4, height4 = util.itrf2latlon(earth_post4)
        # lat1_samp = lat1[::100]
        # lon1_samp = lon1[::100]
        # samp = samples[::100]
        # samp = samples[::100].reshape((im_width/100,1))
        onesam = np.ones((n_samples, 1))
        AA = np.hstack((onesam, samples2 , samples2 ** 2, samples2 ** 3))  # ,samples.reshape(im_width,1)**3))
        bb = lon1
        par = np.linalg.lstsq(AA, bb)[0]
        lon1 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)
        bb = lat1
        par = np.linalg.lstsq(AA, bb)[0]
        lat1 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)

        bb = lon2
        par = np.linalg.lstsq(AA, bb)[0]
        lon2 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)
        bb = lat2
        par = np.linalg.lstsq(AA, bb)[0]
        lat2 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)

        bb = lon3
        par = np.linalg.lstsq(AA, bb)[0]
        lon3 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)
        bb = lat3
        par = np.linalg.lstsq(AA, bb)[0]
        lat3 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)

        bb = lon4
        par = np.linalg.lstsq(AA, bb)[0]
        lon4 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)
        bb = lat4
        par = np.linalg.lstsq(AA, bb)[0]
        lat4 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)
        # plt.show()

        # lat3_samp = lat3[::100]
        # lon3_samp = lon3[::100]
        tsp = time.clock()
        t4 += tsp - tst
        tst = time.clock()
        distances13 = (lat1.reshape((im_width, 1)) - lat3.reshape((1, im_width))) ** 2
        distances13 += (lon1.reshape((im_width, 1)) - lon3.reshape((1, im_width))) ** 2
        distances13 = np.sqrt(distances13)
        distances13_min = distances13.min(0).reshape((1, im_width))
        distances13_min = np.repeat(distances13_min, im_width, 0)
        tsp = time.clock()
        t5 += tsp - tst
        tst = time.clock()
        # print t1,t2,t3,t4,t5
        [a, b] = np.nonzero(distances13 == distances13_min)
        idx = 0
        bsub = []
        B = np.array([[-1., 1, -1, 1], [0, 0, 0, 1], [1, 1, 1, 1], [8, 4, 2, 1]])
        Bin = np.linalg.inv(B)
        for a0 in a:

            an2 = max(0, a0 - 2)
            an1 = max(0, a0 - 1)
            ap1 = min(im_width - 1, a0 + 1)
            ap2 = min(im_width - 1, a0 + 2)
            distances13x = distances13[:, idx].flatten()
            A = np.array([[an2 ** 2, an2, 1], [an1 ** 2, an1, 1], [a0 ** 2, a0, 1], [ap1 ** 2, ap1, 1], [ap2 ** 2, ap2, 1]]).astype('float64')
            bv = np.array([distances13x[an2], distances13x[an1], distances13x[a0], distances13x[ap1], distances13x[ap2]])
            par = np.linalg.lstsq(A, bv)[0]
            b_best = -par[1] / (2.0 * par[0])
            bsub.append(b_best)
            idx += 1
        # b_sub = np.array(bsub)-2.0*int(bsub[0])
        a_sub = np.array(bsub)
        a_sub = a_sub * (a_sub <= im_width - 1) * (a_sub >= 0) + (im_width - 1) * (a_sub > im_width)
        # print a_sub
        a_offset.append(a_sub)
        print a_sub[1000]
        # print a_sub[0:50]
        one_lineB1 = band1.ReadAsArray(0, lines[0] + k - 1, im_width, 1).astype('float32')[0]
        # f = interpol.interp1d(samples,one_lineB1[0],kind='cubic')
        # inter_line = f(b_sub)
        # b_int =b_sub
        b0 = np.floor(a_sub).astype('int32')
        bp1 = b0 + 1
        bp1 = bp1 * (bp1 < im_width) + (im_width - 1) * (bp1 >= im_width)
        bp2 = b0 + 2
        bp2 = bp2 * (bp2 < im_width) + (im_width - 1) * (bp2 >= im_width)
        bn1 = b0 - 1
        bn1 = bn1 * (bn1 >= 0)
        p0 = one_lineB1[b0]
        p1 = one_lineB1[bp1]
        p2 = one_lineB1[bp2]
        m1 = one_lineB1[bn1]
        y = np.vstack((m1, p0, p1, p2))
        err = a_sub - b0
        By = np.dot(Bin, y)
        xv = np.vstack((err ** 3, err ** 2, err, err ** 0))
        # print err.shape
        lnB1 = (xv * By).sum(0)
        # print "line:%d"%k, lnB1[:50]
        # print one_lineB1[:50]
    a_offset = np.array(a_offset)



    # std = a_offset.std(0)
    data = a_offset[:, 1000]
    ln = np.arange(0, 6000, steps)
    num = ln.shape[0]
    one = np.ones((num, 1))
    ln = ln.reshape(num, 1)


    A = np.hstack((one, ln))
    print A.shape, data.shape
    par = np.linalg.lstsq(A, data)[0]
    ln = ln.flatten()
    plt.plot(ln, a_offset[:, 1000], ln, par[0] + par[1] * ln)
    plt.show()
    err = a_offset[:, 1000] - par[0] - par[1] * ln
    print np.abs(err).mean(), np.abs(err).max()

    # print inter_line
def determineHeight(in_file_name, pix, curr_line, target_location, currdate, utc_gps) :
    im_height = 6000
    im_width = 6000
    samples = np.arange(im_width)

    sat_pos = np.loadtxt(in_file_name + "B3.pos")
    captured_time = np.loadtxt(in_file_name + "B3.tim")
    sat_att = np.loadtxt(in_file_name + "B3.att")
    k = curr_line - 1
    jd = computeJDtime(currdate, captured_time[k], utc_gps)
    uecef1 = util.computeUECEF(jd, pix, sat_att[k], 3)
    # uecef6000 = util.computeUECEF(jd,1,sat_att[k],3)
    xt, yt, zt = util.latlon2itrf(target_location[0], target_location[1], 0)
    pos = sat_pos[k]
    u = uecef1.flatten()
    v = np.array([xt, yt, zt])
    w0 = pos
    a = np.inner(u, u)
    b = np.inner(u, v)
    c = np.inner(v, v)
    d = np.inner(u, w0)
    e = np.inner(v, w0)
    sc = (b * e - c * d) / (a * c - b ** 2)
    tc = (a * e - b * d) / (a * c - b ** 2)
    # print sc, tc
    h = (tc - 1.0) * np.sqrt(xt ** 2 + yt ** 2 + zt ** 2)
    # print h
    est_loc = pos + sc * u
    lat, lon, height = util.itrf2latlon(est_loc)
    err_vec = pos + sc * u - tc * v
    err = np.linalg.norm(err_vec)
    print "target:", target_location, "estimated: %f,%f" % (lat, lon)
    print "err: %f,%f at hight = %f" % (target_location[0] - lat, target_location[1] - lon, h)


def findInterSectionPoint(im_type, in_file_name, pix, curr_line, currdate, utc_gps, dut1, dem, dem_interpolation_method):

    if im_type == "MS":
        sat_pos = np.loadtxt(in_file_name + "B3.pos")
        captured_time = np.loadtxt(in_file_name + "B3.tim")
        sat_att = np.loadtxt(in_file_name + "B3.att")
    elif im_type == "PAN":
        sat_pos = np.loadtxt(in_file_name + ".pos")
        captured_time = np.loadtxt(in_file_name + ".tim")
        sat_att = np.loadtxt(in_file_name + ".att")

    k = curr_line - 1
    # jd = computeJDtime(currdate,captured_time[k],utc_gps)
    year = currdate[0]
    month = currdate[1]
    day = currdate[2]
    hour = int(captured_time[k] / 3600.)
    minute = int((captured_time[k] - hour * 3600.0) / 60.0)
    seconds = captured_time[k] % 60.0
    sec = int(seconds)
    microsec = int(1e6 * (seconds - sec))

    if im_type == "PAN" :
        lat, lon, h = util.computeViewLatLongArrayUsingDEM("PAN", np.array([pix]), sat_pos[k], sat_att[k],
                                                           year, month, day, hour, minute, sec, microsec, utc_gps, dut1, dem,
                                                           dem_interpolation_method)
    else:
        lat, lon, h = util.computeViewLatLongArrayUsingDEM(3, np.array([pix]), sat_pos[k], sat_att[k], year, month, day,
                                                               hour, minute, sec, microsec, utc_gps, dut1, dem,
                                                               dem_interpolation_method)
    print "elevation = %f" % h
    return lat, lon, h

def findInterSectionPointArray(im_type, in_file_name, pix_array, line_array, currdate, utc_gps, dut1, dem_directory, band=3):

    if im_type == "MS":
        sat_pos = np.loadtxt(in_file_name + "B%d.pos" % band)
        captured_time = np.loadtxt(in_file_name + "B%d.tim" % band)
        sat_att = np.loadtxt(in_file_name + "B%d.att" % band)
    elif im_type == "PAN":
        sat_pos = np.loadtxt(in_file_name + ".pos")
        captured_time = np.loadtxt(in_file_name + ".tim")
        sat_att = np.loadtxt(in_file_name + ".att")
    year = currdate[0]
    month = currdate[1]
    day = currdate[2]
    for curr_line in line_array:
        k = curr_line - 1
        # jd = computeJDtime(currdate,captured_time[k],utc_gps)

        hour = int(captured_time[k] / 3600.)
        minute = int((captured_time[k] - hour * 3600.0) / 60.0)
        seconds = captured_time[k] % 60.0
        sec = int(seconds)
        microsec = int(1e6 * (seconds - sec))
        if im_type == "PAN" :
            lat, lon, h = util.computeViewLatLongArray("PAN", pix_array, sat_pos[k], sat_att[k], year, month, day, hour, minute, sec, microsec, utc_gps, dut1, dem_directory)
        else:
            lat, lon, h = util.computeViewLatLongArray(band, pix_array, sat_pos[k], sat_att[k], year, month, day, hour, minute, sec, microsec, utc_gps, dut1, dem_directory)
        # print "elevation = %f"%h
    return lat, lon, h

def findInterSectionPointArrayGivenAltitude(im_type, in_file_name, pix_array, line_array, altitude, currdate, utc_gps, dut1, band=3):

    if im_type == "MS":
        sat_pos = np.loadtxt(in_file_name + "B%d.pos" % band)
        captured_time = np.loadtxt(in_file_name + "B%d.tim" % band)
        sat_att = np.loadtxt(in_file_name + "B%d.att" % band)
    elif im_type == "PAN":
        sat_pos = np.loadtxt(in_file_name + ".pos")
        captured_time = np.loadtxt(in_file_name + ".tim")
        sat_att = np.loadtxt(in_file_name + ".att")
    year = currdate[0]
    month = currdate[1]
    day = currdate[2]
    for curr_line in line_array:
        k = curr_line - 1
        # jd = computeJDtime(currdate,captured_time[k],utc_gps)

        hour = int(captured_time[k] / 3600.)
        minute = int((captured_time[k] - hour * 3600.0) / 60.0)
        seconds = captured_time[k] % 60.0
        sec = int(seconds)
        microsec = int(1e6 * (seconds - sec))
        if im_type == "PAN" :
            lat, lon, h = util.computeViewLatLongArrayGivenAltitude("PAN", pix_array, sat_pos[k], sat_att[k], altitude,
                                                                    year, month, day, hour, minute, sec, microsec, utc_gps, dut1)
        else:
            lat, lon, h = util.computeViewLatLongArrayGivenAltitude(band, pix_array, sat_pos[k], sat_att[k], altitude,
                                                                    year, month, day, hour, minute, sec, microsec, utc_gps, dut1)
        # print "elevation = %f"%h
    return lat, lon, h


def findInterSectionPointArrayUsingDEM(im_type, in_file_name, pix_array, line_array, currdate, utc_gps, dut1,
                                       dem, dem_interpolation, band=3):
    if im_type == "MS":
        sat_pos = np.loadtxt(in_file_name + "B%d.pos" % band)
        captured_time = np.loadtxt(in_file_name + "B%d.tim" % band)
        sat_att = np.loadtxt(in_file_name + "B%d.att" % band)
    elif im_type == "PAN":
        sat_pos = np.loadtxt(in_file_name + ".pos")
        captured_time = np.loadtxt(in_file_name + ".tim")
        sat_att = np.loadtxt(in_file_name + ".att")
    year = currdate[0]
    month = currdate[1]
    day = currdate[2]
    for curr_line in line_array:
        k = curr_line - 1
        # jd = computeJDtime(currdate,captured_time[k],utc_gps)

        hour = int(captured_time[k] / 3600.)
        minute = int((captured_time[k] - hour * 3600.0) / 60.0)
        seconds = captured_time[k] % 60.0
        sec = int(seconds)
        microsec = int(1e6 * (seconds - sec))
        if im_type == "PAN" :
            lat, lon, h = util.computeViewLatLongArrayUsingDEM("PAN", pix_array, sat_pos[k], sat_att[k], year, month, day, hour, minute, sec, microsec, utc_gps, dut1, dem, dem_interpolation)
        else:
            lat, lon, h = util.computeViewLatLongArrayUsingDEM(band, pix_array, sat_pos[k], sat_att[k], year, month, day, hour, minute, sec, microsec, utc_gps, dut1, dem, dem_interpolation)
        # print "elevation = %f"%h
    return lat, lon, h



def findInterSectionPointArrayUsingKriging(im_type, in_file_name, pix_array, line_array, currdate, utc_gps, dut1, dem_directory, band=3):

    if im_type == "MS":
        sat_pos = np.loadtxt(in_file_name + "B%d.pos" % band)
        captured_time = np.loadtxt(in_file_name + "B%d.tim" % band)
        sat_att = np.loadtxt(in_file_name + "B%d.att" % band)
    elif im_type == "PAN":
        sat_pos = np.loadtxt(in_file_name + ".pos")
        captured_time = np.loadtxt(in_file_name + ".tim")
        sat_att = np.loadtxt(in_file_name + ".att")
    year = currdate[0]
    month = currdate[1]
    day = currdate[2]
    for curr_line in line_array:
        k = curr_line - 1
        # jd = computeJDtime(currdate,captured_time[k],utc_gps)

        hour = int(captured_time[k] / 3600.)
        minute = int((captured_time[k] - hour * 3600.0) / 60.0)
        seconds = captured_time[k] % 60.0
        sec = int(seconds)
        microsec = int(1e6 * (seconds - sec))
        if im_type == "PAN" :
            lat, lon, h = util.computeViewLatLongArrayUsingKriging("PAN", pix_array, sat_pos[k], sat_att[k], year, month, day, hour, minute, sec, microsec, utc_gps, dut1, dem_directory)
        else:
            lat, lon, h = util.computeViewLatLongArrayUsingKriging(band, pix_array, sat_pos[k], sat_att[k], year, month, day, hour, minute, sec, microsec, utc_gps, dut1, dem_directory)
        # print "elevation = %f"%h
    return lat, lon, h

def findInterSectionPointArrayUsingDEMPreloaded(im_type, in_file_name, pix_array, line_array, sat_pos, captured_time,
                                                sat_att, currdate, utc_gps, dut1, dem, dem_interpolation_method, band=3):

    # if im_type == "MS":
    #     sat_pos = np.loadtxt(in_file_name+"B%d.pos"%band)
    #     captured_time = np.loadtxt(in_file_name+"B%d.tim"%band)
    #     sat_att = np.loadtxt(in_file_name+"B%d.att"%band)
    # elif im_type == "PAN":
    #     sat_pos = np.loadtxt(in_file_name+".pos")
    #     captured_time = np.loadtxt(in_file_name+".tim")
    #     sat_att = np.loadtxt(in_file_name+".att")
    year = currdate[0]
    month = currdate[1]
    day = currdate[2]
    for curr_line in line_array:
        k = curr_line - 1
        # jd = computeJDtime(currdate,captured_time[k],utc_gps)

        hour = int(captured_time[k] / 3600.)
        minute = int((captured_time[k] - hour * 3600.0) / 60.0)
        seconds = captured_time[k] % 60.0
        sec = int(seconds)
        microsec = int(1e6 * (seconds - sec))
        if im_type == "PAN" :
            lat, lon, h = util.computeViewLatLongArrayUsingDEM("PAN", pix_array, sat_pos[k], sat_att[k], year, month, day,
                                                               hour, minute, sec, microsec, utc_gps, dut1, dem,
                                                               dem_interpolation_method)
        else:
            lat, lon, h = util.computeViewLatLongArrayUsingDEM(band, pix_array, sat_pos[k], sat_att[k], year, month, day,
                                                               hour, minute, sec, microsec, utc_gps, dut1, dem,
                                                               dem_interpolation_method)
        # print "elevation = %f"%h
    return lat, lon, h


def findInterSectionPointArrayUsingKrigingPreloaded(im_type, in_file_name, pix_array, line_array, sat_pos, captured_time, sat_att, currdate, utc_gps, dut1, dem_directory, band=3):

    # if im_type == "MS":
    #     sat_pos = np.loadtxt(in_file_name+"B%d.pos"%band)
    #     captured_time = np.loadtxt(in_file_name+"B%d.tim"%band)
    #     sat_att = np.loadtxt(in_file_name+"B%d.att"%band)
    # elif im_type == "PAN":
    #     sat_pos = np.loadtxt(in_file_name+".pos")
    #     captured_time = np.loadtxt(in_file_name+".tim")
    #     sat_att = np.loadtxt(in_file_name+".att")
    year = currdate[0]
    month = currdate[1]
    day = currdate[2]
    for curr_line in line_array:
        k = curr_line - 1
        # jd = computeJDtime(currdate,captured_time[k],utc_gps)

        hour = int(captured_time[k] / 3600.)
        minute = int((captured_time[k] - hour * 3600.0) / 60.0)
        seconds = captured_time[k] % 60.0
        sec = int(seconds)
        microsec = int(1e6 * (seconds - sec))
        if im_type == "PAN" :
            lat, lon, h = util.computeViewLatLongArrayUsingKriging("PAN", pix_array, sat_pos[k], sat_att[k], year, month, day, hour, minute, sec, microsec, utc_gps, dut1, dem_directory)
        else:
            lat, lon, h = util.computeViewLatLongArrayUsingKriging(band, pix_array, sat_pos[k], sat_att[k], year, month, day, hour, minute, sec, microsec, utc_gps, dut1, dem_directory)
        # print "elevation = %f"%h
    return lat, lon, h
def reverseModel(u, v, height, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, h_min, h_max):
    u = u.flatten()
    v = v.flatten()
    num_pix = len(u)
    A = np.zeros((num_pix, 12))
    A[:, 0] = 1.0
    A[:, 1] = u
    A[:, 2] = v
    A[:, 3] = u * v
    A[:, 4] = u ** 2
    A[:, 5] = v ** 2
    A[:, 6] = u * v * v
    A[:, 7] = v * u * u
    A[:, 8] = u ** 3
    A[:, 9] = v ** 3
    A[:, 10] = v * u ** 3
    A[:, 11] = u * v ** 3
    ymin = np.dot(A, ay_min) + y_mean
    xmin = np.dot(A, ax_min) + x_mean

    ymax = np.dot(A, ay_max) + y_mean
    xmax = np.dot(A, ax_max) + x_mean

    k = (height - h_min) / (h_max - h_min)
    y = k * ymax + (1. - k) * ymin
    x = k * xmax + (1. - k) * xmin
    return x, y

def forwardModel(xadj, yadj, hadj, u_mean, v_mean, line0, sat_pos, sat_att, captured_time, year, month, day, utc_gps, dut1,
                 im_type, upperleft, band=3):
    xl = upperleft[0]
    yl = upperleft[1]
    dx = upperleft[2]
    dy = upperleft[3]
    zn = upperleft[4]
    if im_type == "PAN" :
        lat, lon, h = util.computeViewLatLongArrayWithHeight("PAN", xadj, yadj, hadj, line0, sat_pos, sat_att, captured_time, year, month, day, utc_gps, dut1)
    else:
         lat, lon, h = util.computeViewLatLongArrayWithHeight(band, xadj, yadj, hadj, line0, sat_pos, sat_att, captured_time, year, month, day, utc_gps, dut1)
    utmx, utmy, tt1, tt2 = utmLatlon.from_latlon(lat, lon, zn)
    un = (utmx - xl) / dx - u_mean
    vn = (utmy - yl) / dy - v_mean
    return un, vn



def findGerLocationGivenHeight(u, v, height, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, u_mean, v_mean, h_min, h_max, im_type, sat_pos, sat_att, cap_time,
                               line0, currdate, utc_gps, dut1, upleft, im_width, im_height, err_max=1.0, iter_max=10, band=3):

    iter = 0
    year = currdate[0]
    month = currdate[1]
    day = currdate[2]
    x, y = reverseModel(u, v, height, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, h_min, h_max)  # corrdinate on Ger Files
    idx = np.nonzero((x >= -70) * (x < im_width + 70) * (y >= -70) * (y < im_height + 200))
    idx = idx[0]
    xout = x.copy()
    yout = y.copy()
    # return xout, yout
    if len(idx) > 0:
        xadj = x[idx]
        yadj = y[idx]
        hadj = height[idx]
        u0 = u[idx]
        v0 = v[idx]
        ui = u[idx]
        vi = v[idx]
        while (iter < iter_max):
            ub, vb = forwardModel(xadj, yadj, hadj, u_mean, v_mean, line0, sat_pos, sat_att, cap_time, year, month, day, utc_gps,
                                 dut1, im_type, upleft, band)
            erru = u0 - ub
            errv = v0 - vb
            err_sum = np.sqrt(erru ** 2 + errv ** 2)
            id_err = np.nonzero(err_sum > err_max)
            id_ok = np.nonzero(err_sum <= err_max)
            id_err = id_err[0]
            id_ok = id_ok[0]
            # print "Not Pass:%d\nPass:%d"%(len(id_err),len(id_ok))

            xout[idx[id_ok]] = xadj[id_ok]
            yout[idx[id_ok]] = yadj[id_ok]
            if len(id_err) > 0:
                idx = idx[id_err]
                u0 = u[idx]
                v0 = v[idx]
                uim1 = ui[id_err]
                vim1 = vi[id_err]
                ui = uim1 + erru[id_err]
                vi = vim1 + errv[id_err]
                hadj = height[idx]
                xadj, yadj = reverseModel(ui, vi, hadj, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, h_min, h_max)
            else:
                # print "The algorithm is terminated successfully at the iteration %d"%iter
                break
            iter += 1


        if iter == iter_max:
            # pass
            print "The algorithm terminated before the desired error is obtained."
            # print "error max:%f" % (err_sum.max())
            print "There are %d pixels with positioning error more than %f." % (len(id_err), (err_sum.max()))
    else:
        pass
        # print "There are no pixel that is needed to adjust its position."
    erxout = np.abs(xout - x)
    eryout = np.abs(yout - y)
    # print "maximum error out:", erxout.max(),eryout.max()

    return xout, yout


def findGerLocationGivenHeightAndDem(u, v, height, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, u_mean, v_mean, h_min, h_max, im_type,
                                     sat_pos, sat_att, cap_time, line0, currdate, utc_gps, dut1, upleft, im_width, im_height,
                                     err_max=1.0, iter_max=10, band=3):

    iter = 0
    year = currdate[0]
    month = currdate[1]
    day = currdate[2]
    x, y = reverseModel(u, v, height, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, h_min, h_max)  # corrdinate on Ger Files
    idx = np.nonzero((x >= -5) * (x < im_width + 5) * (y >= -5) * (y < im_height + 5))
    idx = idx[0]
    xout = x.copy()
    yout = y.copy()
    if len(idx) > 0:
        xadj = x[idx]
        yadj = y[idx]
        hadj = height[idx]
        u0 = u[idx]
        v0 = v[idx]
        ui = u[idx]
        vi = v[idx]
        while (iter < iter_max):
            ub, vb = forwardModel(xadj, yadj, hadj, u_mean, v_mean, line0, sat_pos, sat_att, cap_time, year, month, day, utc_gps,
                                 dut1, None, im_type, upleft, band)
            erru = u0 - ub
            errv = v0 - vb
            err_sum = np.sqrt(erru ** 2 + errv ** 2)
            id_err = np.nonzero(err_sum > err_max)
            id_ok = np.nonzero(err_sum <= err_max)
            id_err = id_err[0]
            id_ok = id_ok[0]
            # print "Not Pass:%d\nPass:%d"%(len(id_err),len(id_ok))
            # print "error max:%f"%(err_sum.max())
            xout[idx[id_ok]] = xadj[id_ok]
            yout[idx[id_ok]] = yadj[id_ok]
            if len(id_err) > 0:
                idx = idx[id_err]
                u0 = u[idx]
                v0 = v[idx]
                uim1 = ui[id_err]
                vim1 = vi[id_err]
                ui = uim1 + erru[id_err]
                vi = vim1 + errv[id_err]
                hadj = height[idx]
                xadj, yadj = reverseModel(ui, vi, hadj, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, h_min, h_max)
            else:
                print "The algorithm is terminated successfully at the iteration %d" % iter
                break
            iter += 1


        if iter == iter_max:
            print "The algorithm terminated before the desired error is obtained."
            # "There are %d pixels with positioning error more than %f."%(len(id_err),err_max)
    else:
        print "There are no pixel that is needed to adjust its position."
    erxout = np.abs(xout - x)
    eryout = np.abs(yout - y)
    print "maximum error out:", erxout.max(), eryout.max()

    return xout, yout

# def findGerLocationGivenHeightSingleInput(args):
#
#
#     u,v,height,ax_min,ay_min,ax_max,ay_max,x_mean,y_mean,u_mean,v_mean,h_min,h_max,im_type, sat_pos,sat_att,cap_time,\
#     line0,currdate,utc_gps,dut1,upleft,im_width,im_height,dem_directory, err_max,iter_max, band =args
#     xout,yout = findGerLocationGivenHeight(u,v,height,ax_min,ay_min,ax_max,ay_max,x_mean,y_mean,u_mean,v_mean,h_min,h_max,im_type, sat_pos,sat_att,cap_time,
#                                            line0,currdate,utc_gps,dut1,upleft,im_width,im_height,dem_directory, err_max = err_max,iter_max = iter_max, band=band)
#
#     return xout,yout

def findGerLocationGivenHeightSingleInput(args):


    u, v, height, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, u_mean, v_mean, h_min, h_max, im_type, sat_pos, sat_att, cap_time, \
    line0, currdate, utc_gps, dut1, upleft, im_width, im_height, err_max, iter_max, band = args
    xout, yout = findGerLocationGivenHeight(u, v, height, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, u_mean, v_mean, h_min,
                                                 h_max, im_type, sat_pos, sat_att, cap_time, line0, currdate, utc_gps, dut1,
                                                 upleft, im_width, im_height, err_max=err_max, iter_max=iter_max, band=band)

    return xout, yout

def findGerFileLocation(u, v, height, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, u_mean, v_mean, h_min, h_max, im_type, in_file_name,
                        line0, currdate, utc_gps, dut1, dem_directory, upleft, im_width, im_height, pix0=0, band=3):

    # xl = upleft[0]
    # yl  = upleft[1]
    # dx = upleft[2]
    # dy  = upleft[3]
    # zn = upleft[4]
    if im_type == "MS":
        sat_pos = np.loadtxt(in_file_name + "B%d.pos" % band)
        captured_time = np.loadtxt(in_file_name + "B%d.tim" % band)
        sat_att = np.loadtxt(in_file_name + "B%d.att" % band)
    elif im_type == "PAN":
        sat_pos = np.loadtxt(in_file_name + ".pos")
        captured_time = np.loadtxt(in_file_name + ".tim")
        sat_att = np.loadtxt(in_file_name + ".att")
    # year = currdate[0]
    # month = currdate[1]
    # day = currdate[2]
    x, y = findGerLocationGivenHeight(u, v, height, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, u_mean, v_mean, h_min, h_max, im_type, sat_pos, sat_att, captured_time,
                               line0, currdate, utc_gps, dut1, upleft, im_width, im_height, dem_directory, err_max=1.0, iter_max=5, band=band)
    # iter = 0
    # while iter < 1:
    #     iter+= 1
    #     #backword model.
    #     u = u.flatten()
    #     v = v.flatten()
    #     num_pix = len(u)
    #     A = np.zeros((num_pix,12))
    #     A[:,0] = 1.0
    #     A[:,1] = u
    #     A[:,2] = v
    #     A[:,3] = u*v
    #     A[:,4] = u**2
    #     A[:,5] = v**2
    #     A[:,6] = u*v*v
    #     A[:,7] = v*u*u
    #     A[:,8] = u**3
    #     A[:,9] = v**3
    #     A[:,10] = v*u**3
    #     A[:,11] = u*v**3
    #     ymin = np.dot(A,ay_min) +y_mean
    #     xmin = np.dot(A,ax_min) +x_mean
    #
    #     ymax = np.dot(A,ay_max) +y_mean
    #     xmax = np.dot(A,ax_max) +x_mean
    #
    #     k = (height-h_min)/(h_max-h_min)
    #     y = k*ymax +(1.-k)*ymin
    #     x = k*xmax +(1.-k)*xmin
    #     idx = np.nonzero((x>=0)*(x<im_width)*(y>=0)*(y<im_height))
    #     idx = idx[0]
    #     xadj = x[idx]
    #     yadj = y[idx]
    #     hadj = height[idx]
    #
    #     #forward model.
    #     if len(idx) > 0:
    #         if im_type == "PAN" :
    #             lat, lon, h = util.computeViewLatLongArrayWithHeight("PAN",xadj,yadj,hadj,line0,sat_pos,sat_att,captured_time,year,month,day,utc_gps,dut1,dem_directory)
    #         else:
    #             lat, lon, h = util.computeViewLatLongArrayWithHeight(band,xadj,yadj,hadj,line0,sat_pos,sat_att,captured_time,year,month,day,utc_gps,dut1,dem_directory)
    #         utmx,utmy,tt1,tt2 = utmLatlon.from_latlon(lat,lon,zn)
    #         un = (utmx-xl)/dx - u_mean
    #         vn = (utmy-yl)/dy - v_mean
    #         erx = ((un-u[idx])**2)
    #         idd = np.nonzero(erx==erx.max())
    #         idd = idd[0]
    #         id2 = idx[idd]
    #         liney = line0+int(y[id2])
    #         timy = captured_time[liney]
    #         hour = int(timy/3600.)
    #         minute = int((timy-hour*3600.0)/60.)
    #         seconds = timy%60.0
    #         sec = int(seconds)
    #         microsec = int(1e6*(seconds -sec))
    #         laty,lony,hy = util.computeViewLatLongArrayUsingKriging(band,x[id2],sat_pos[liney],sat_att[liney],year,month,day,
    #                                                              hour,minute,sec,microsec,utc_gps,dut1,dem_directory)
    #         print "erx:%f\nlat_old: %f\nlat_new: %f\nlon_old: %f\nlon_new%f"%(erx[idd],laty,lat[idd],lony,lon[idd])
    #         x2,y2,tt1,tt2 = utm.from_latlon(laty,lony,zn)
    #         u2 = (x2-xl)/dx - u_mean
    #         v2 = (y2-yl)/dy - v_mean
    #         print "u old:%f\nu_new:%f\nv_old:%f\nv_new:%f\nu_org:%f\nv_org:%f"%(un[idd],u2,vn[idd],v2,u[id2],v[id2])
    #         A = np.zeros((1,12))
    #         uu = u[id2]
    #         vv = v[id2]
    #         A[:,0] = 1.0
    #         A[:,1] = uu
    #         A[:,2] = vv
    #         A[:,3] = uu*vv
    #         A[:,4] = uu**2
    #         A[:,5] = vv**2
    #         A[:,6] = uu*vv*vv
    #         A[:,7] = vv*uu*uu
    #         A[:,8] = uu**3
    #         A[:,9] = vv**3
    #         A[:,10] = vv*uu**3
    #         A[:,11] = uu*vv**3
    #         ymin = np.dot(A,ay_min) +y_mean
    #         xmin = np.dot(A,ax_min) +x_mean
    #         ymax = np.dot(A,ay_max) +y_mean
    #         xmax = np.dot(A,ax_max) +x_mean
    #         k = (height[id2]-h_min)/(h_max-h_min)
    #         y3 = k*ymax +(1.-k)*ymin
    #         x3 = k*xmax +(1.-k)*xmin
    #         print "x old%f\nx new:%f\ny old:%f\ny_new:%f"%(x[id2],x3,y[id2],y3)
    #         exit()
    #         print "eru:", ((un-u[idx])**2).mean()
    #         print "erv:", ((vn-v[idx])**2).mean()

    return x, y

class findGerLocationThread(mlp.Process):
    def __init__(self, u, v, height, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, u_mean, v_mean, h_min, h_max, im_type, sat_pos, sat_att, captured_time,
                               line0, currdate, utc_gps, dut1, upleft, im_width, im_height, dem_directory, err_max=1.0, iter_max=5, band=3):
        mlp.Process.__init__(self)
        self.u = u
        self.v = v
        self.height = height
        self.ax_min = ax_min
        self.ay_min = ay_min
        self.ax_max = ax_max
        self.ay_max = ay_max
        self.x_mean = x_mean
        self.y_mean = y_mean
        self.u_mean = u_mean
        self.v_mean = v_mean
        self.h_min = h_min
        self.h_max = h_max
        self.im_type = im_type
        self.sat_pos = sat_pos
        self.sat_att = sat_att
        self.captured_time = captured_time
        self.line0 = line0
        self.currdate = currdate
        self.utc_gps = utc_gps
        self.dut1 = dut1
        self.upleft = upleft
        self.im_width = im_width
        self.im_height = im_height
        self.dem_directory = dem_directory
        self.err_max = err_max
        self.iter_max = iter_max
        self.band = band
        self.completed = False
    def run(self):
        x, y = findGerLocationGivenHeight(self.u, self.v, self.height, self.ax_min, self.ay_min, self.ax_max, self.ay_max,
                                         self.x_mean, self.y_mean, self.u_mean, self.v_mean, self.h_min, self.h_max, self.im_type,
                                         self.sat_pos, self.sat_att, self.captured_time, self.line0, self.currdate, self.utc_gps,
                                         self.dut1, self.upleft, self.im_width, self.im_height, self.dem_directory,
                                         err_max=self.err_max, iter_max=self.iter_max, band=self.band)
        self.x = x
        self.y = y
        self.completed = True

    def getXY(self):
        return self.x, self.y

    def isCompleted(self):
        return self.completed

def findGerFileLocationPreLoadAllFiles(u, v, height, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, u_mean, v_mean, h_min, h_max, im_type, in_file_name,
                                       line0, currdate, utc_gps, dut1, upleft, im_width, im_height, sat_pos, captured_time, sat_att,
                                       lat_grid, lon_grid, h_grid, pixel_size,
                                       pix0=0, band=3):

    num_cpu = mlp.cpu_count()
#     num_cpu_used = max(1, num_cpu / 2)
    num_cpu_used = max(1, num_cpu - 2)
    num_data = captured_time.shape[0]
    line0_new = min(100, line0)  # try to minimize memory used by removing data that we do not need
    line_min = line0 - line0_new
    line_max = min(num_data, line_min + im_width + 1000)
    sat_pos_used = sat_pos[line_min:line_max, :]
    sat_att_used = sat_att[line_min:line_max, :]
    cap_time = captured_time[line_min:line_max]
    num_pixel = u.shape[0]
    str = 0
    args = []
    x = np.zeros_like(u)
    y = np.zeros_like(v)
    for thread_id in range(num_cpu_used):
        if thread_id < num_cpu_used - 1:
            stp = str + num_pixel / num_cpu_used
        else:
            stp = num_pixel
        uw = u[str:stp]
        vw = v[str:stp]
        hw = height[str:stp]

        # worker = findGerLocationThread(uw,vw,hw,ax_min,ay_min,ax_max,ay_max,x_mean,y_mean,u_mean,v_mean,h_min,h_max,
        #                               im_type, sat_pos_used,sat_att_used,cap_time,line0_new,currdate,utc_gps,dut1,
        #                               upleft,im_width,im_height,dem_directory, err_max = 1.0,iter_max = 5, band=band)
        # args.append((uw,vw,hw,ax_min,ay_min,ax_max,ay_max,x_mean,y_mean,u_mean,v_mean,h_min,h_max,im_type, sat_pos_used,
        #             sat_att_used,cap_time,line0_new,currdate,utc_gps,dut1, upleft,im_width,im_height,lat_grid,lon_grid,
        #             h_grid,pixel_size, 0.25,5, band))
        # str = stp
    # pool = mlp.Pool(processes=num_cpu_used)
    # results = pool.map(findGerLocationGivenHeightSingleInput,args)
    str = 0

    # for thread_id in range(num_cpu_used):
    #    if thread_id < num_cpu_used-1:
    #        stp = str+num_pixel/num_cpu_used
    #    else:
    #        stp = num_pixel
    #    xw,yw = results[thread_id]
    #    x[str:stp] = xw
    #    y[str:stp] = yw
    #    str = stp
    #
    #
    #
    #
    #
    #
    x, y = findGerLocationGivenHeight(u, v, height, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, u_mean, v_mean, h_min, h_max, im_type,
                                     sat_pos_used, sat_att_used, cap_time, line0_new, currdate, utc_gps, dut1, upleft, im_width,
                                     im_height, lat_grid, lon_grid, h_grid, pixel_size, 0.25, 25, band=band)
    # pool.close()
    args = None
    results = None

    return x, y


def findGerFileLocationPreLoadFiles(u, v, height, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, u_mean, v_mean, h_min, h_max, im_type, in_file_name,
                                    line0, currdate, utc_gps, dut1, upleft, im_width, im_height, sat_pos, captured_time, sat_att,
                                    pix0=0, band=3):

    num_cpu = mlp.cpu_count()
    num_cpu_used = max(1, num_cpu - 2)
    num_data = captured_time.shape[0]
    line0_new = line0  # min(100,line0) # try to minimize memory used by removing data that we do not need
    line_min = 0  # line0 -line0_new
    line_max = num_data  # ,line_min+im_height+10000)
    sat_pos_used = sat_pos[line_min:line_max, :]
    sat_att_used = sat_att[line_min:line_max, :]
    cap_time = captured_time[line_min:line_max]
    num_pixel = u.shape[0]
    str = 0
    args = []
    x = np.zeros_like(u)
    y = np.zeros_like(v)
    for thread_id in range(num_cpu_used):
        if thread_id < num_cpu_used - 1:
            stp = str + num_pixel / num_cpu_used
        else:
            stp = num_pixel
        uw = u[str:stp]
        vw = v[str:stp]
        hw = height[str:stp]

        # worker = findGerLocationThread(uw,vw,hw,ax_min,ay_min,ax_max,ay_max,x_mean,y_mean,u_mean,v_mean,h_min,h_max,
        #                               im_type, sat_pos_used,sat_att_used,cap_time,line0_new,currdate,utc_gps,dut1,
        #                               upleft,im_width,im_height,dem_directory, err_max = 1.0,iter_max = 5, band=band)
        args.append((uw, vw, hw, ax_min, ay_min, ax_max, ay_max, x_mean, y_mean, u_mean, v_mean, h_min, h_max, im_type, sat_pos_used,
                     sat_att_used, cap_time, line0_new, currdate, utc_gps, dut1, upleft, im_width, im_height, 0.1,
                     20, band))
        str = stp
    pool = mlp.Pool(processes=num_cpu_used)
    results = pool.map(findGerLocationGivenHeightSingleInput, args)
    # result = findGerLocationGivenHeight(uw,vw,hw,ax_min,ay_min,ax_max,ay_max,x_mean,y_mean,u_mean,v_mean,h_min,h_max,im_type, sat_pos_used,
    #               sat_att_used,cap_time,line0_new,currdate,utc_gps,dut1, upleft,im_width,im_height,
    #                                  err_max = 0.1,iter_max = 100, band=band)
    #
    # results = [result]
    str = 0

    for thread_id in range(num_cpu_used):
        if thread_id < num_cpu_used - 1:
            stp = str + num_pixel / num_cpu_used
        else:
            stp = num_pixel
        xw, yw = results[thread_id]
        x[str:stp] = xw
        y[str:stp] = yw
        str = stp
    #
    #
    #
    #
    #
    #
    # x,y = findGerLocationGivenHeight(u,v,height,ax_min,ay_min,ax_max,ay_max,x_mean,y_mean,u_mean,v_mean,h_min,h_max,im_type, sat_pos,sat_att,captured_time,
    #                            line0,currdate,utc_gps,dut1,upleft,im_width,im_height,dem_directory, err_max = 1.0,iter_max = 5, band=band)
    pool.close()
    args = None
    results = None

    return x, y



def findViewingAngles(im_type, in_file_name, curr_line, mid_s, currdate, utc_gps, dut1, mid_lat, mid_lon):
    if im_type == "MS":
        sat_pos = np.loadtxt(in_file_name + "B3.pos")
        captured_time = np.loadtxt(in_file_name + "B3.tim")
        sat_att = np.loadtxt(in_file_name + "B3.att")
        sat_vel = np.loadtxt(in_file_name + "B3.vel")
    elif im_type == "PAN":
        sat_pos = np.loadtxt(in_file_name + ".pos")
        captured_time = np.loadtxt(in_file_name + ".tim")
        sat_att = np.loadtxt(in_file_name + ".att")
        sat_vel = np.loadtxt(in_file_name + ".vel")

    k = curr_line - 1
    # jd = computeJDtime(currdate,captured_time[k],utc_gps)
    year = currdate[0]
    month = currdate[1]
    day = currdate[2]
    hour = int(captured_time[k] / 3600.)
    minute = int((captured_time[k] - hour * 3600.0) / 60.0)
    seconds = captured_time[k] % 60.0
    sec = int(seconds)
    microsec = int(1e6 * (seconds - sec))
    pos = sat_pos[curr_line]
    att = sat_att[curr_line]
    vel = sat_vel[curr_line]

    if im_type == "PAN" :
        alpha, alpha_along, alpha_accross = util.computeSceneViewingAngles(mid_s, "PAN", pos, att, vel, year, month, day, \
                                                                                      hour, minute, sec, microsec, utc_gps, dut1)
       # util.computeSatAngles(pos,alpha,mid_lat,mid_lon)
    else:
        alpha, alpha_along, alpha_accross = util.computeSceneViewingAngles(mid_s, 3, pos, att, vel, year, month, day, \
                                                                      hour, minute, sec, microsec, utc_gps, dut1)
    sat_incidence, sat_azimuth, sat_altitude = util.computeSatAngles(pos, alpha, mid_lat, mid_lon)
    return alpha, alpha_along, alpha_accross, sat_incidence, sat_azimuth, sat_altitude



def findOrientationAngle(im_type, file_name, mid_line, date, utc_gps, dut1, dem, dem_interpolation_method):
    if im_type == "PAN":
        width = 12000
        height = 12000
    elif im_type == "MS":
        width = 6000
        height = 6000
    # compute mid points
    latmid, lonmid, hmid = findInterSectionPoint(im_type, file_name, width / 2 , mid_line, date, utc_gps, dut1, dem,
                                                dem_interpolation_method)
    latmidn1, lonmidn1, hmidn1 = findInterSectionPoint(im_type, file_name, 1 , mid_line, date, utc_gps, dut1, dem,
                                                      dem_interpolation_method)
    latmidp1, lonmidp1, hmidp1 = findInterSectionPoint(im_type, file_name, width, mid_line, date, utc_gps, dut1, dem,
                                                      dem_interpolation_method)



    d2r = np.pi / 180.0
    mid_lat = latmid
    mid_lon = lonmid
    nadir_lat = latmidp1
    nadir_lon = lonmidp1

    x = np.cos(mid_lat * d2r) * np.sin(nadir_lat * d2r) - np.sin(mid_lat * d2r) * np.cos(nadir_lat * d2r) * np.cos((nadir_lon - mid_lon) * d2r)
    y = np.sin((nadir_lon - mid_lon) * d2r) * np.cos(nadir_lat * d2r)
    or_1 = np.arctan2(y, x) / d2r

    mid_lat = latmidn1
    mid_lon = lonmidn1
    nadir_lat = latmid
    nadir_lon = lonmid

    x = np.cos(mid_lat * d2r) * np.sin(nadir_lat * d2r) - np.sin(mid_lat * d2r) * np.cos(nadir_lat * d2r) * np.cos((nadir_lon - mid_lon) * d2r)
    y = np.sin((nadir_lon - mid_lon) * d2r) * np.cos(nadir_lat * d2r)
    or_2 = np.arctan2(y, x) / d2r
    theta2 = (or_1 + or_2) / 2.0 - 90.0

    # print "theta2:",theta2
    return theta2

def findSunAngles(im_type, in_file_name, center_line, date, utc_gps, dut1, lat, lon) :
    def sind(x):
        y = np.sin((x) * np.pi / 180.)
        return y
    def cosd(x):
        y = np.cos((x) * np.pi / 180.)
        return y
    if im_type == "MS":

        captured_time = np.loadtxt(in_file_name + "B3.tim")

    elif im_type == "PAN":

        captured_time = np.loadtxt(in_file_name + ".tim")

    dt = datetime.datetime(date[0], date[1], date[2])
    d = dt.timetuple().tm_yday
    t = captured_time[center_line - 1]
    tutc = (t + utc_gps) / (60.*60.)
    tmst = tutc + (lon / 15.)
    x1 = 1.00554 * d - 6.28306
    x2 = 1.93946 * d + 23.35089
    et = -7.67825 * sind(x1) - 10.09176 * sind(x2)
    ttst = tmst + et / 60.
    ttst = ttst - 12.
    ah = ttst * 15.
    a3 = 0.9683 * d - 78.00878
    delta = 23.4856 * sind(a3)
    # theta = 360*ttst/(24.*60.*60.)
    delta = 23.4856 * sind(0.9683 * d - 78.00878)
    amuzero = sind(lat) * sind(delta) + cosd(lat) * cosd(delta) * cosd(ah)
    sun_ev = np.arcsin(amuzero) * 180.0 / np.pi
    az = cosd(delta) * sind(ah) / cosd(sun_ev)
    caz = (-cosd(lat) * sind(delta) + sind(lat) * cosd(delta) * cosd(ah)) / cosd(sun_ev)
    sun_azimuth = np.arcsin(az) * 180.0 / np.pi
    if caz <= 0 :
        sun_azimuth = sun_azimuth - 180.0
    elif (caz > 0) and (az <= 0) :
        sun_azimuth = 360. + sun_azimuth
    sun_azimuth = sun_azimuth + 180.
    if sun_azimuth > 360. :
        sun_azimuth = sun_azimuth - 360.

    # sun_ev = np.arcsin(sind(lat)*sind(delta)+cosd(lat)*cosd(delta)*cosd(theta))*180./np.pi
    # sun_azimuth = np.arcsin((cosd(delta)*sind(theta))/cosd(sun_ev))*180.0/np.pi
    return sun_ev, sun_azimuth


if __name__ == "__main__" :
    file_name = "/media/professor/Data and Backup/LEVEL0/2013-12-03_REV27231/THEOS_1_LEVEL0_1_111027231_27231_MS_PB_TOP_2_22_2013-12-03_03-24-32/TS1_2013337_27231_022_B3"
    # find_pixel_shift(file_name,[26741,26813,26885,26957],[2015,1,2],-16.0)
    # file_name =r"C:\LEVEL0\THEOS_1_LEVEL0_1_111032837_32837_MS_PB_TOP_2_8_2015-01-02_03-26-33\TS1_2015002_32837_008_"
    # dem_file = r"C:\Users\professor\Dropbox\THEOS_LEVEL1ADEVELOPMENT\n17e099.bil"
    dem_dir = r"D:\dem\gls"
    im_file = r"D:\THEOS_1_LEVEL0_1_111037541_37541_PAN_PB_TOP_1_13_2015-11-29_07-39-24\info\TS1_2015333_37541_013_PAN"
    dut1 = 0.1
    utc_gps = -17.0
    pix = np.arange(0, 12000, 100)
    curr_line = 10946
    curdate = [2015, 11, 29 ]
    str = time.clock()
    lat, lon, h = findInterSectionPointArray("PAN", im_file, pix, [curr_line], curdate, utc_gps, dut1, dem_dir)
    stp = time.clock()
    print "total time is %f" % (stp - str)


