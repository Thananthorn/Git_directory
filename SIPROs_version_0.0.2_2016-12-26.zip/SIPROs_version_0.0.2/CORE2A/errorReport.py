import cv2

from osgeo import gdal
from osgeo import osr
import utm

import numpy as np


class clickDisplay:
    def __init__(self, gdal_fp, utmx, utmy, win_name, scale=1, N=401):
        self.rm_fp = gdal_fp
        self.utmx = utmx
        self.utmy = utmy
        self.win_name = win_name
        self.find_point = False
        self.x = 0
        self.y = 0
        self.scale = scale
        self.N = N
        self.makeDisplayImage()

    def makeDisplayImage(self):
        self.rmgeo = self.rm_fp.GetGeoTransform()
        self.rmwidth = myimage.RasterXSize
        self.rmheight = myimage.RasterYSize
        self.midrow = (self.utmy - self.rmgeo[3]) / self.rmgeo[5]
        self.midcol = (self.utmx - self.rmgeo[0]) / self.rmgeo[1]
        win_width = (self.N - 1) / 2
        str_row = int(self.midrow - win_width)
        stp_row = int(self.midrow + win_width)
        str_col = int(self.midcol - win_width)
        stp_col = int(self.midcol + win_width)
        x_low = max(str_col, 0)
        x_high = min(stp_col, self.rmwidth - 1)
        loadwdth = x_high - x_low + 1

        y_low = max(str_row, 0)
        y_high = min(stp_row, self.rmheight - 1)
        loadheight = y_high - y_low + 1
        # print x_low,y_low,mywidth,myheight
        if self.rm_fp.RasterCount == 1:
            loadData = self.rm_fp.ReadAsArray(x_low, y_low, loadwdth, loadheight)
        else:
            loadData = np.zeros((loadheight, loadwdth, 3), "uint8")
            cnt = 0
            for band in [3, 2, 1]:
                data = self.rm_fp.GetRasterBand(band)
                loadData[:, :, cnt] = data.ReadAsArray(x_low, y_low, loadwdth, loadheight)
                cnt += 1

        kk = self.midcol + np.arange(-win_width, win_width + 1) - x_low
        mm = self.midrow + np.arange(-win_width, win_width + 1) - y_low
        k, m = np.meshgrid(kk, mm)
        k = k.astype("float32")
        m = m.astype("float32")
        imdat = cv2.remap(loadData, k, m, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        self.imdata = imdat


    def waitForClick(self, event, x, y, flag, param):
        if event == cv2.EVENT_MOUSEMOVE:
            self.x = x
            self.y = y
        elif event == cv2.EVENT_LBUTTONUP:
            self.x = x
            self.y = y
            self.find_point = True
    def findLocation(self):
        cv2.namedWindow(self.win_name)
        cv2.setMouseCallback(self.win_name, self.waitForClick)
        key = 0
        while (not self.find_point):
            scale = self.scale
            if key == "+":
                scale += 1
                scale = min(scale, 4)
                self.scale = scale
            elif key == "-":
                scale -= 1
                scale = max(scale, 1)
                self.scale = scale
            if self.imdata.ndim == 2:
                rw, cl = self.imdata.shape
                show_image = np.zeros((rw, cl, 3), 'uint8')
                for b in [0, 1, 2]:
                    show_image[:, :, b] = self.imdata
            else:
                rw, cl, bd = self.imdata.shape
                show_image = self.imdata.copy()
            x = self.x
            y = self.y
            show_image = cv2.resize(show_image, (cl * scale, rw * scale))
            if (x < cl * scale) & (y < rw * scale) & (x > 0) & (y > 0):
                show_image[:, x, 2] = 255
                show_image[y, :, 2] = 255
            cv2.imshow(self.win_name, show_image)
            key = cv2.waitKey(10)
            if (key >= 0) & (key < 256):
                key = chr(key)
            elif (key >= 256):
                print "%x" % key

        cv2.destroyWindow(self.win_name)
        self.point_row = y
        self.point_col = x
    def getClickPoint(self):
        win_width = (self.N - 1) / 2
        clck_x = float(self.point_col)
        clck_y = float(self.point_row)
        clck_x = clck_x + (self.midcol - win_width) * self.scale
        clck_y = clck_y + (self.midrow - win_width) * self.scale
        map_x = self.rmgeo[1] * clck_x / (float(self.scale)) + self.rmgeo[0] + self.rmgeo[1] / 2.0
        map_y = self.rmgeo[5] * clck_y / (float(self.scale)) + self.rmgeo[3] + self.rmgeo[5] / 2.0
        return map_x, map_y


if __name__ == "__main__":

    myf = r"D:\Data2APanSharpen\2016-05-27\bridge error\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\GERALD\output\IMAGERY.tif"
    org = r"D:\Data2APanSharpen\2016-05-27\Tested Images\revolution_39848_new\old_product\TH_CAT_160511081330552_1\IMAGERY.tif"

    lat, lon = 8.997443, 99.550554

    lat_lon = [[lat, lon]]
    myimage = gdal.Open(myf)
    orgimage = gdal.Open(org)
    mysrc = osr.SpatialReference(myimage.GetProjection())
    orgsrc = osr.SpatialReference(orgimage.GetProjection())
    # srs.SetProjection(myimage.GetProjection())
    myutm = np.abs(mysrc.GetUTMZone())
    orgutm = np.abs(mysrc.GetUTMZone())
    if myutm != orgutm:
        print "error"
        exit()
    else:
        my_errx = []
        my_erry = []
        my_overall_err = []
        org_errx = []
        org_erry = []
        org_overall_err = []
        for lat, lon in lat_lon:
            x, y, t1, t2 = utm.from_latlon(lat, lon, myutm)
            print x, y
            shw = clickDisplay(myimage, x, y, "my file", scale=2)
            shw.findLocation()
            my_map_x, my_map_y = shw.getClickPoint()
            geot = myimage.GetGeoTransform()
            row = (my_map_y - geot[3]) / geot[5]
            col = (my_map_x - geot[0]) / geot[1]
            print "Click at: %f,%f" % (row, col)

            errx = my_map_x - x
            erry = my_map_y - y
            err_sum = np.sqrt(errx ** 2 + erry ** 2)
            print "My Image Errors report are:", errx, erry, err_sum
            my_errx.append(errx)
            my_erry.append(erry)
            my_overall_err.append(err_sum)

            shw = clickDisplay(orgimage, x, y, "org file", scale=2)
            shw.findLocation()
            org_map_x, org_map_y = shw.getClickPoint()
            geot = orgimage.GetGeoTransform()
            row = (org_map_y - geot[3]) / geot[5]
            col = (org_map_x - geot[0]) / geot[1]
            print "Click at: %f,%f" % (row, col)

            errx = org_map_x - x
            erry = org_map_y - y
            err_sum = np.sqrt(errx ** 2 + erry ** 2)
            print "Original Image Errors report are:", errx, erry, err_sum
            org_errx.append(errx)
            org_erry.append(erry)
            org_overall_err.append(err_sum)
