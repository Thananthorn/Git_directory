"""This script have 6 library
1. sys or know as System-specific parameters and function. This module provides access to some variables used or maintained by 
   the interpreter and to functions that interact strongly with the interpreter.
2. numpy it is library about calculate and numerical methods for engineering or science methods it import bypass in script as [np] .
3. os or know as Miscellaneous operating system interfaces. This module provides a portable way of using operating system dependent functionality.
4. traceback is module provides a standard interface to extract. I use this for check error of function or script.\
"""

import os
import sys
import traceback 

import numpy as np


def comparecufandcpf(cuf_date , cpf_file_keep_directory , cpf_result_directory):
	""" This function is methods to read all CPF files from CPF directory and create index file for keep CPF file path.
		+ valiable [cpf_test_directory] is directory path you keep all CPF files.
		+ valiable [cpf_test_result_directory] is directory path to keep your index files when it was create by this function.
		+ valiable [validity_name] is a list of valiable it use when you want to create valiable to get some value in for loop.
		+ valiable [validity_name_list] is list of all CPF path in CPF directory.
		+ valiable [cpf_path] is cpf path.
		+ valiable [validity_start] is cpf filename.
		+ 
	 """

	cpf_test_directory = cpf_file_keep_directory
	cpf_test_result_directory = cpf_result_directory

	validity_name = globals()
	validity_name_list = []

	for cpf_root , cpf_directory , cpf_filename in os.walk(cpf_test_directory , topdown=False):
		for filename in cpf_filename :
			cpf_path = os.path.abspath(os.path.join(cpf_root , filename))
			validity_start = os.path.basename(cpf_path)
			validity_name["validity_%s" % filename] = cpf_test_result_directory + "/" + validity_start[24:-11] + ".txt"
			validity_file = open(validity_name["validity_%s" % filename] , "w")
			validity_file.write(str(cpf_path))
			validity_file.write("\n" + str(validity_start))
			validity_file.close()
			validity_name_list.append(validity_start[24:-11])
			validity_name_list.sort()

	cpf_file_count = len(validity_name_list)
	date_value = int(cuf_date)

	for i in range(0, cpf_file_count):
		if i != (cpf_file_count - 1) :
			if (date_value >= int(validity_name_list[i])) and (date_value < int(validity_name_list[(i + 1)])):
				index_filename = cpf_test_result_directory + "/" + validity_name_list[i] + ".txt"
				index_file = open(index_filename , "r")
				read_value_list = []
				for j in range (2):
					pre_read_value = index_file.readline()
					read_value = pre_read_value.strip("\n")
					read_value_list.append(read_value)
				index_file.close()
				Pre_calibration_parameter_file = read_value_list[0]
				calibration_parameter_filename = read_value_list[1]
 				print "date_value : %s" % date_value , " use cpf : %s" % Pre_calibration_parameter_file, "cpf name : %s" % calibration_parameter_filename

		elif i == (cpf_file_count - 1) :
			if (date_value >= int(validity_name_list[i])) :
				index_filename = cpf_test_result_directory + "/" + validity_name_list[i] + ".txt"
				index_file = open(index_filename , "r")
				read_value_list = []
				for j in range (2):
					pre_read_value = index_file.readline()
					read_value = pre_read_value.strip("\n")
					read_value_list.append(read_value)
				index_file.close()
				Pre_calibration_parameter_file = read_value_list[0]
				calibration_parameter_filename = read_value_list[1]
 				print "date_value : %s" % date_value , " use cpf : %s" % Pre_calibration_parameter_file, "cpf name : %s" % calibration_parameter_filename

	return Pre_calibration_parameter_file , calibration_parameter_filename

if __name__ == '__main__':
	cuf_date = "20161003"
	cpf_file_keep_directory = r"C:\Worker\Support-Worker\Producting_system\CPF_PROCESSING\CPF"
	cpf_result_directory = r"C:\Worker\Support-Worker\Producting_system\CPF_PROCESSING\index_CPF"
	try:
		comparecufandcpf(cuf_date , cpf_file_keep_directory , cpf_result_directory)
	except:
		print traceback.format_exc()
