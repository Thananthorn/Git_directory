import cv2

from osgeo import gdal

import numpy as np


def makeRGBFrom2Scenes(scene1, scene2, outfile):
    im1 = gdal.Open(scene1)
    im2 = gdal.Open(scene2)
    geot1 = im1.GetGeoTransform()
    geot2 = im2.GetGeoTransform()
    width1 = im1.RasterXSize
    height1 = im1.RasterYSize
    width2 = im2.RasterXSize
    height2 = im2.RasterYSize
    x1 = geot1[0]
    y1 = geot1[3]
    x2 = geot2[0]
    y2 = geot2[3]
    dx = geot1[1]
    dy = geot2[5]
    x_left = max(x1, x2)
    x_right = min(x1 + width1 * dx, x2 + width2 * dx)
    y_left = min(y1, y2)
    y_right = max (y1 + height1 * dy, y2 + height2 * dy)
    out_width = int((x_right - x_left) / dx) + 1
    out_height = int((y_right - y_left) / dy) + 1
    drv = gdal.GetDriverByName("GTiff")
    dsn = drv.Create(outfile, out_width, out_height, 3, gdal.GDT_Byte)
    rw, cl = np.mgrid[:out_height, :out_width]
    y = rw * dy + y_left
    x = cl * dx + x_left
    x = x.flatten().astype('float32')
    y = y.flatten().astype('float32')
    for band in [1, 2, 3]:
        band_im1 = im1.GetRasterBand(band)
        band_im2 = im2.GetRasterBand(band)
        bandout = dsn.GetRasterBand(band)
        data1 = band_im1.ReadAsArray()
        data2 = band_im2.ReadAsArray()
        xout1 = (x - x1) / dx
        yout1 = (y - y1) / dy
        out1 = cv2.remap(data1, xout1, yout1, cv2.INTER_CUBIC, borderValue=0, borderMode=cv2.BORDER_CONSTANT)
        out1[(xout1 < 0)] = 0
        out1[(yout1 < 0)] = 0
        out1[(xout1 >= 6000)] = 0
        out1[(yout1 >= 6000)] = 0
        xout2 = (x - x2) / dx
        yout2 = (y - y2) / dy
        out2 = cv2.remap(data2, xout2, yout2, cv2.INTER_CUBIC, borderValue=0, borderMode=cv2.BORDER_CONSTANT)
        out2[(xout2 < 0)] = 0
        out2[(yout2 < 0)] = 0
        out2[(xout2 >= 6000)] = 0
        out2[(yout2 >= 6000)] = 0
        out = out1 + out2 * (out1 == 0)
        out = out.reshape(out_height, out_width)
        bandout.WriteArray(out)





if __name__ == "__main__":
    scene1 = r"D:\Data2APanSharpen\scene_discont\THEOS_1_LEVEL0_1_111042210_42210_MS_PB_TOP_2_42_2016-10-23_13-59-25\scene3\IMAGERY.tif"
    scene2 = r"D:\Data2APanSharpen\scene_discont\THEOS_1_LEVEL0_1_111042210_42210_MS_PB_TOP_2_42_2016-10-23_13-59-25\scene4\IMAGERY.tif"
    out_name = r"D:\Data2APanSharpen\scene_discont\THEOS_1_LEVEL0_1_111042210_42210_MS_PB_TOP_2_42_2016-10-23_13-59-25\scene34.tif"
    makeRGBFrom2Scenes(scene1, scene2, out_name)
