import cv2

from osgeo import gdal

import numpy as np


if __name__ == "__main__":
    dem_file = r"D:\Data2APanSharpen\StrechImage\GERALD\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\info\TS1_2016131_39848_022_DEM_2541.tif"
    dem_rgb_file = r"D:\Data2APanSharpen\StrechImage\GERALD\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\info\TS1_2016131_39848_022_DEM_rgb_kriging_2541.tif"
    crop_im = gdal.Open(r"D:\Data2APanSharpen\StrechImage\GERALD\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\output\IMAGERY.tif")
    crob_band = crop_im.GetRasterBand(3)
    step = 1500
    dem_im = gdal.Open(dem_file)
    dem_band = dem_im.GetRasterBand(1)
    dem_data = dem_band.ReadAsArray()

    width = dem_im.RasterXSize
    height = dem_im.RasterYSize
    h_min = dem_data.min()
    h_max = dem_data.max()
    print "maximum altitude: %f, minimum altitude: %f" % (h_max, h_min)
    drv = gdal.GetDriverByName("GTiff")
    dem_rgb = drv.Create(dem_rgb_file, width, height, 3, gdal.GDT_Byte)
    demred = dem_rgb.GetRasterBand(1)
    demgreen = dem_rgb.GetRasterBand(2)
    demblue = dem_rgb.GetRasterBand(3)
    for sample  in range(0, width, step):
        for line in range(0, height, step):
            size_x = min(step, width - sample)
            size_y = min(step, height - line)
            dem_data = dem_band.ReadAsArray(sample, line, size_x, size_y)
            crop_data = crob_band.ReadAsArray(sample, line, size_x, size_y)
            hsv = np.zeros((size_y, size_x, 3), 'uint8') + 255
            hsv[:, :, 0] = 170 - 170 * (dem_data - h_min) / h_max
            rgb = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
            demred.WriteArray(rgb[:, :, 0] * (crop_data > 0) , sample, line)
            demgreen.WriteArray(rgb[:, :, 1] * (crop_data > 0), sample, line)
            demblue.WriteArray(rgb[:, :, 2] * (crop_data > 0), sample, line)
