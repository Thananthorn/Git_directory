__author__ = 'professor'
import cv2
import os
import platform

from osgeo import osr
import psutil
import utm

import determine_pixel_shift as dps
import digitalElevationModel as demserice
import dutil
import locationutil as util
import matplotlib.pyplot as plt
import numpy as np
import scipy.interpolate as inplt
import scipy.signal as signal
import utmLatlon
import xml.etree.ElementTree as ET


if platform.system() == "Windows":
    from osgeo import gdal
else:
    import gdal
# import osr



def readGainsAndDarkCurrent(cpf_file, band, gain_number):
    tree = ET.parse(cpf_file)
    root = tree.getroot()
    if band == "PAN":
        gains_txt = root.findall("./RadiometricParameters/PAN/G%d/DetectorRelativeGains" % (gain_number))[0].text
        darkCurrent_txt = root.findall("./RadiometricParameters/PAN/G%d/DarkCurrents" % (gain_number))[0].text
    else:
        gains_txt = root.findall("./RadiometricParameters/B%d/G%d/DetectorRelativeGains" % (band, gain_number))[0].text
        darkCurrent_txt = root.findall("./RadiometricParameters/B%d/G%d/DarkCurrents" % (band, gain_number))[0].text
    # print gains_txt
    gains_txt = gains_txt.split(",")

    darkCurrent_txt = darkCurrent_txt.split(",")
    gains = []
    darkCurrents = []
    for it in range(len(gains_txt)):
        gains.append(float(gains_txt[it]))
        darkCurrents.append(float(darkCurrent_txt[it]))
    gains = np.array(gains)
    darkCurrents = np.array(darkCurrents)
    return gains, darkCurrents


def buildRMImage(file_name, line1B1, line1B2, line1B3, line1B4, g1, g2, g3, g4, d1, d2, d3, d4):
    file_band1 = file_name + "B1.tif"
    band1 = gdal.Open(file_band1)
    file_band2 = file_name + "B2.tif"
    band2 = gdal.Open(file_band2)
    file_band3 = file_name + "B3.tif"
    band3 = gdal.Open(file_band3)
    file_band4 = file_name + "B4.tif"
    band4 = gdal.Open(file_band4)
    out_file_name = file_name + "_ms.tif"
    gtiffDriver = gdal.GetDriverByName('GTiff')
    dst_ds = gtiffDriver.Create(out_file_name, 6000, 6000, 4, gdal.GDT_Byte)
    ms_b1 = dst_ds.GetRasterBand(1)
    ms_b2 = dst_ds.GetRasterBand(2)
    ms_b3 = dst_ds.GetRasterBand(3)
    ms_b4 = dst_ds.GetRasterBand(4)
    print "Saving Image"
    for line in range(6000):
        print "save line %d" % line
        lb1 = band1.ReadAsArray(0, line1B1 + line, 6000, 1).astype('float32')
        lb2 = band2.ReadAsArray(0, line1B2 + line, 6000, 1).astype('float32')
        lb3 = band3.ReadAsArray(0, line1B3 + line, 6000, 1).astype('float32')
        lb4 = band4.ReadAsArray(0, line1B4 + line, 6000, 1).astype('float32')
        lb1 = np.round((lb1 - d1) / g1)
        if lb1.min() < 0:
            print "find b1 less than zero"
        if lb1.max() > 255:
            print "find b1 greater than 255= %f" % lb1.max()
        lb1 = lb1 * (lb1 < 255.0) + 255.0 * (lb1 >= 255)
        lb1 = lb1.astype('uint8').reshape((1, 6000))
        lb1[0, 6:] = lb1[0, :-6]
        lb2 = np.round((lb2 - d2) / g2)
        if lb2.min() < 0:
            print "find b2 less than zero"
        if lb2.max() > 255:
            print "find b2 greater than 255= %f" % lb2.max()
        lb2 = lb2 * (lb2 < 255.0) + 255.0 * (lb2 >= 255)
        lb2 = lb2.astype('uint8').reshape((1, 6000))
        lb2[0, 4:] = lb2[0, :-4]
        lb3 = np.round((lb3 - d3) / g3)
        if lb3.min() < 0:
            print "find b3 less than zero"
        if lb3.max() > 255:
            print "find b3 greater than 255= %f" % lb3.max()
        lb3 = lb3 * (lb3 < 255.0) + 255.0 * (lb3 >= 255)
        lb3 = lb3.astype('uint8').reshape((1, 6000))
        lb4 = np.round((lb4 - d4) / g4)
        if lb4.min() < 0:
            print "find b4 less than zero"
        if lb4.max() > 255:
            print "find b4 greater than 255= %f" % lb4.max()
        lb4 = lb4 * (lb4 < 255.0) + 255.0 * (lb4 >= 255)
        lb4 = lb4.astype('uint8').reshape((1, 6000))
        lb4[0, :-5] = lb1[0, 5:]
        ms_b1.WriteArrayWriteArray(lb1, 0, line)
        ms_b2.WriteArray(lb2, 0, line)
        ms_b3.WriteArray(lb3, 0, line)
        ms_b4.WriteArray(lb4, 0, line)
    dst_ds = None


def computeJDtime(date, time, utc_gps):
    t1 = time
    hour1 = int(np.floor(t1 / 3600.0))
    t1 -= hour1 * 3600.0
    minute1 = int(np.floor(t1) / 60.0)
    second1 = t1 - minute1 * 60.0
    micsec1 = second1 - int(np.floor(second1))
    micsec1 = int(micsec1 * 1e6)
    second1 = int(second1)
    tt1 = dutil.datetime(date[0], date[1], date[2], hour1, minute1, second1, micsec1)
    JD1 = tt1.to_jd() + utc_gps / (24 * 60. * 60.)
    return JD1


def determine_shift(lat1, lon1, lat3, lon3, im_width):
    distances13 = (lat1.reshape((im_width, 1)) - lat3.reshape((1, im_width))) ** 2
    distances13 += (lon1.reshape((im_width, 1)) - lon3.reshape((1, im_width))) ** 2
    distances13 = np.sqrt(distances13)
    distances13_min = distances13.min(1).reshape((im_width, 1))
    distances13_min = np.repeat(distances13_min, im_width, 1)
    [a, b] = np.nonzero(distances13 == distances13_min)
    return b


def determine_shift_subpixel(lat1, lon1, lat3, lon3, im_width):
    distances13 = (lat1.reshape((im_width, 1)) - lat3.reshape((1, im_width))) ** 2
    distances13 += (lon1.reshape((im_width, 1)) - lon3.reshape((1, im_width))) ** 2
    distances13 = np.sqrt(distances13)
    distances13_min = distances13.min(1).reshape((im_width, 1))
    distances13_min = np.repeat(distances13_min, im_width, 1)
    [a, b] = np.nonzero(distances13 == distances13_min)
    idx = 0
    bout = []
    for b0 in b:
        if (b0 > 0) and (b0 < im_width - 1):
            bn2 = max(0, b0 - 2)
            bn1 = max(0, b0 - 1)
            bp1 = min(im_width - 1, b0 + 1)
            bp2 = min(im_width - 1, b0 + 2)
            distances13x = distances13[idx, :]
            A = np.array([[bn2 ** 2, bn2, 1], [bn1 ** 2, bn1, 1], [b0 ** 2, b0, 1], [bp1 ** 2, bp1, 1],
                          [bp2 ** 2, bp2, 1]]).astype('float64')
            bv = np.array(
                [distances13x[bn2], distances13x[bn1], distances13x[b0], distances13x[bp1], distances13x[bp2]])
            par = np.linalg.lstsq(A, bv)[0]
            b_best = -par[1] / (2.0 * par[0])
        else:
            b_best = None
        bout.append(b_best)
        idx += 1
    bout = np.array(bout)
    return bout


def buildMSImageFromGerFile(out_file_name, in_file_name, lines, gains, dark_currents, current_date, utc_gps):
    im_height = 6000
    im_width = 6000
    samples = np.arange(im_width)
    posB1 = np.loadtxt(in_file_name + "B1.pos")
    posB2 = np.loadtxt(in_file_name + "B2.pos")
    posB3 = np.loadtxt(in_file_name + "B3.pos")
    posB4 = np.loadtxt(in_file_name + "B4.pos")

    timeB1 = np.loadtxt(in_file_name + "B1.tim")
    timeB2 = np.loadtxt(in_file_name + "B2.tim")
    timeB3 = np.loadtxt(in_file_name + "B3.tim")
    timeB4 = np.loadtxt(in_file_name + "B4.tim")

    attB1 = np.loadtxt(in_file_name + "B1.att")
    attB2 = np.loadtxt(in_file_name + "B2.att")
    attB3 = np.loadtxt(in_file_name + "B3.att")
    attB4 = np.loadtxt(in_file_name + "B4.att")

    band1 = gdal.Open(in_file_name + "B1.tif")
    band2 = gdal.Open(in_file_name + "B2.tif")
    band3 = gdal.Open(in_file_name + "B3.tif")
    band4 = gdal.Open(in_file_name + "B4.tif")


    # out_im = np.zeros((im_height,im_height,4),'uint8')
    out_line0 = np.zeros((1, im_width), 'uint8')
    posB1 = posB1[lines[0]:lines[0] + im_height]
    posB2 = posB2[lines[1]:lines[1] + im_height]
    posB3 = posB3[lines[2]:lines[2] + im_height]
    posB4 = posB4[lines[3]:lines[3] + im_height]

    timeB1 = timeB1[lines[0]:lines[0] + im_height]
    timeB2 = timeB2[lines[1]:lines[1] + im_height]
    timeB3 = timeB3[lines[2]:lines[2] + im_height]
    timeB4 = timeB4[lines[3]:lines[3] + im_height]

    attB1 = attB1[lines[0]:lines[0] + im_height]
    attB2 = attB2[lines[1]:lines[1] + im_height]
    attB3 = attB3[lines[2]:lines[2] + im_height]
    attB4 = attB4[lines[3]:lines[3] + im_height]
    gtiffDriver = gdal.GetDriverByName('GTiff')
    dst_ds = gtiffDriver.Create(out_file_name, 6000, 6000, 4, gdal.GDT_Byte)
    ms_b1 = dst_ds.GetRasterBand(1)
    ms_b2 = dst_ds.GetRasterBand(2)
    ms_b3 = dst_ds.GetRasterBand(3)
    ms_b4 = dst_ds.GetRasterBand(4)

    for k in range(im_height):
        out_line0 = np.zeros((1, im_width), 'uint8')
        out_line1 = np.zeros((1, im_width), 'uint8')
        out_line2 = np.zeros((1, im_width), 'uint8')
        out_line3 = np.zeros((1, im_width), 'uint8')
        jd1 = computeJDtime(current_date, timeB1[k], utc_gps)
        jd2 = computeJDtime(current_date, timeB2[k], utc_gps)
        jd3 = computeJDtime(current_date, timeB3[k], utc_gps)
        jd4 = computeJDtime(current_date, timeB4[k], utc_gps)
        uecef1 = util.computeUECEF(jd1, samples, attB1[k], 1)
        uecef2 = util.computeUECEF(jd2, samples, attB2[k], 2)
        uecef3 = util.computeUECEF(jd3, samples, attB3[k], 3)
        uecef4 = util.computeUECEF(jd4, samples, attB4[k], 4)
        earth_post1 = util.findEarthSurfacePosition(uecef1, posB1[k])
        earth_post2 = util.findEarthSurfacePosition(uecef2, posB2[k])
        earth_post3 = util.findEarthSurfacePosition(uecef3, posB3[k])
        earth_post4 = util.findEarthSurfacePosition(uecef4, posB4[k])
        lat1, lon1, height1 = util.itrf2latlon(earth_post1)
        lat2, lon2, height2 = util.itrf2latlon(earth_post2)
        lat3, lon3, height3 = util.itrf2latlon(earth_post3)
        lat4, lon4, height4 = util.itrf2latlon(earth_post4)
        one_lineB3 = band3.ReadAsArray(0, lines[2] + k - 1, im_width, 1)
        one_lineB3 = np.round((one_lineB3 - dark_currents[2]) / gains[2])
        one_lineB3 = one_lineB3 * (one_lineB3 < 255.0) + 255.0 * (one_lineB3 >= 255)

        out_line2[0, :] = one_lineB3[0]
        print "===========================\n creating Line %d:" % k

        b = determine_shift(lat1, lon1, lat3, lon3, im_width)
        one_lineB1 = band1.ReadAsArray(0, lines[0] + k - 1, im_width, 1)
        one_lineB1 = np.round((one_lineB1 - dark_currents[0]) / gains[0])
        one_lineB1 = one_lineB1 * (one_lineB1 < 255.0) + 255.0 * (one_lineB1 >= 255)


        # out_im[k,b,0] = one_lineB1
        out_line0[0, b] = one_lineB1
        print "   shift band1 pixel 1:%d" % b[0]
        print "   shift band1 pixel 3000:%d" % (b[3000] - 3000)

        b = determine_shift(lat2, lon2, lat3, lon3, im_width)
        one_lineB2 = band2.ReadAsArray(0, lines[1] + k - 1, im_width, 1)
        one_lineB2 = np.round((one_lineB2 - dark_currents[1]) / gains[1])
        one_lineB2 = one_lineB2 * (one_lineB2 < 255.0) + 255.0 * (one_lineB2 >= 255)
        # out_im[k,b,1] = one_lineB2
        out_line1[0, b] = one_lineB2
        print "   shift band2 :%d" % b[0]
        print "   shift band2 pixel 3000:%d" % (b[3000] - 3000)

        b = determine_shift(lat4, lon4, lat3, lon3, im_width)
        one_lineB4 = band4.ReadAsArray(0, lines[3] + k - 1, im_width, 1)
        one_lineB4 = np.round((one_lineB4 - dark_currents[3]) / gains[3])
        one_lineB4 = one_lineB4 * (one_lineB4 < 255.0) + 255.0 * (one_lineB4 >= 255)
        # out_im[k,b,3] = one_lineB4
        out_line3[0, b] = one_lineB4
        print "   shift band4 :%d" % (-im_width + b[-1])
        print "   shift band1 pixel 3000:%d" % (b[3000] - 3000)
        ms_b1.WriteArray(out_line0, 0, k)
        ms_b2.WriteArray(out_line1, 0, k)
        ms_b3.WriteArray(out_line2, 0, k)
        ms_b4.WriteArray(out_line3, 0, k)
    dst_ds = None




    # distances1 = np.zeros((im_width,im_width))
    # distances2 = np.zeros((im_width,im_width))
    # distances3 = np.zeros((im_width,im_width))
    # distances4 = np.zeros((im_width,im_width))
    # x31 = earth_post3[0].reshape(im_width,1)
    # x32 = earth_post3[1].reshape(im_width,1)
    # x33 = earth_post3[2].reshape(im_width,1)
    #
    # x11 = earth_post1[0].reshape(1,im_width)
    # x12 = earth_post1[1].reshape(1,im_width)
    # x13 = earth_post1[2].reshape(1,im_width)
    # distances1 = np.sqrt((x11-x31)**2+(x12-x32)**2 +(x13-x33)**2)
    # min_d1 = distances1.min(1)
    #
    # x21 = earth_post2[0].reshape(1,im_width)
    # x22 = earth_post2[1].reshape(1,im_width)
    # x23 = earth_post2[2].reshape(1,im_width)
    # distances2 = np.sqrt((x21-x31)**2+(x22-x32)**2 +(x23-x33)**2)
    #
    # x41 = earth_post4[0].reshape(1,im_width)
    # x42 = earth_post4[1].reshape(1,im_width)
    # x43 = earth_post4[2].reshape(1,im_width)
    # distances4 = np.sqrt((x41-x31)**2+(x42-x32)**2 +(x43-x33)**2)



    # use band3 for positioning'


def findPixelShifting(lat, lon, lat_ref, lon_ref, im_width):
    distances = (lat.reshape((im_width, 1)) - lat_ref.reshape((1, im_width))) ** 2
    distances += (lon.reshape((im_width, 1)) - lon_ref.reshape((1, im_width))) ** 2
    distances = np.sqrt(distances)
    distances_min = distances.min(0).reshape((1, im_width))
    distances_min = np.repeat(distances_min, im_width, 0)
    [a, b] = np.nonzero(distances == distances_min)
    idx = 0
    asub = []

    for a0 in a:
        an2 = max(0, a0 - 2)
        an1 = max(0, a0 - 1)
        ap1 = min(im_width - 1, a0 + 1)
        ap2 = min(im_width - 1, a0 + 2)
        distancesx = distances[:, idx].flatten()
        A = np.array(
            [[an2 ** 2, an2, 1], [an1 ** 2, an1, 1], [a0 ** 2, a0, 1], [ap1 ** 2, ap1, 1], [ap2 ** 2, ap2, 1]]).astype(
            'float64')
        bv = np.array([distancesx[an2], distancesx[an1], distancesx[a0], distancesx[ap1], distancesx[ap2]])
        par = np.linalg.lstsq(A, bv)[0]
        b_best = -par[1] / (2.0 * par[0])
        asub.append(b_best)
        idx += 1
    a_sub = np.array(asub)
    a_sub = a_sub * (a_sub <= im_width - 1) * (a_sub >= 0) + (im_width - 1) * (a_sub > im_width)
    return a_sub


def w(x):
    a = -0.5
    a3 = a + 2.0
    a2 = -a - 3.0
    b3 = a
    b2 = -5.0 * a
    b1 = 8 * a
    b0 = -4 * a
    absx = np.abs(x)
    absx3 = absx ** 3
    absx2 = absx ** 2
    y1 = a3 * absx3 ** 3 + a2 * absx2 + 1.0
    y2 = b3 * absx3 + b2 * absx2 + b1 * absx + b0
    y = y1 * (absx <= 1.0) + y2 * (absx > 1) * (absx < 2.0)
    return y


def cubicInterpolationV1(data, pixel_map, im_width):
    data = data.astype('float32')
    a = np.floor(pixel_map).astype('int32')
    ap1 = a + 1
    ap1 = ap1 * (ap1 < im_width) + (a - (ap1 - im_width) - 1) * (ap1 >= im_width)
    ap1 = ap1 * (ap1 >= 0) + (-ap1) * (ap1 < 0)
    ap2 = a + 2
    ap2 = ap2 * (ap2 < im_width) + (a - (ap2 - im_width) - 1) * (ap2 >= im_width)
    ap2 = ap2 * (ap2 >= 0) + (-ap2) * (ap2 < 0)
    an1 = a - 1
    an1 = an1 * (an1 >= 0) + (-an1) * (an1 < 0)
    an1 = an1 * (an1 < im_width) + (a - (an1 - im_width) - 1) * (an1 >= im_width)
    w0 = w(pixel_map - a)
    wp1 = w(a + 1 - pixel_map)
    wp2 = w(a + 2 - pixel_map)
    wn1 = w(pixel_map - a + 1)
    imout = w0 * data[0, a] + wp1 * data[0, ap1] + wp2 * data[0, ap2] + wn1 * data[0, an1]
    imout = imout * (imout > 0) * (imout <= 255) + 255 * (imout > 255)
    imout = imout.astype('uint8')
    imout = imout.reshape((1, im_width))
    return imout


def cubicInterpolation(data, pixel_map, im_width):
    data = data.astype('float32')
    pixel_map2 = pixel_map.copy()

    pixel_map = pixel_map * (pixel_map > 0) * (pixel_map <= im_width - 1) + (im_width - 1) * (pixel_map > im_width)


    a = np.floor(pixel_map).astype('int32')
    ap1 = a + 1
    ap1 = ap1 * (ap1 < im_width) + (a - (ap1 - im_width) - 1) * (ap1 >= im_width)
    ap1 = ap1 * (ap1 >= 0) + (-ap1) * (ap1 < 0)
    ap2 = a + 2
    ap2 = ap2 * (ap2 < im_width) + (a - (ap2 - im_width) - 1) * (ap2 >= im_width)
    ap2 = ap2 * (ap2 >= 0) + (-ap2) * (ap2 < 0)
    an1 = a - 1
    an1 = an1 * (an1 >= 0) + (-an1) * (an1 < 0)
    an1 = an1 * (an1 < im_width) + (a - (an1 - im_width) - 1) * (an1 >= im_width)
    # print a.shape
    # print a.max()
    # print a.min()


    term1 = 2.0 * data[a]
    term2 = -1 * data[an1] + data[ap1]
    term3 = 2.0 * data[an1] - 5.0 * data[a] + 4.0 * data[ap1] - 1.0 * data[ap2]
    term4 = -1.0 * data[an1] + 3.0 * data[a] - 3.0 * data[ap1] + 1.0 * data[ap2]
    t = pixel_map - a
    imout = term1 + t * term2 + t * t * term3 + t * t * t * term4
    imout = imout / 2.0
    imout = imout * (imout > 0) * (imout <= 255) + 255 * (imout > 255)
    imout = imout.astype('uint8') * (pixel_map2 > 0) * (pixel_map2 <= im_width - 1)
    # imout = imout.reshape((1,im_width))
    return imout


def buildMSImageUsingCubicInterpolation(out_file_name, in_file_name, lines, current_date, utc_gps, dut1, dem_directory, start_sample=1, im_width=6000, im_height=6000):

    # im_width = 6000
    lines[0] = lines[0] - 1
    lines[1] = lines[1] - 1
    lines[2] = lines[2] - 1
    lines[3] = lines[3] - 1
    end_sample = start_sample + im_width - 1
    if (end_sample > 6000) or (start_sample < 1) :
        print "The intended sample is beyond the scope of the recorded GER file."
    samples = np.arange(start_sample, start_sample + im_width)

    posB1 = np.loadtxt(in_file_name + "B1.pos")
    posB2 = np.loadtxt(in_file_name + "B2.pos")
    posB3 = np.loadtxt(in_file_name + "B3.pos")
    posB4 = np.loadtxt(in_file_name + "B4.pos")

    timeB1 = np.loadtxt(in_file_name + "B1.tim")
    timeB2 = np.loadtxt(in_file_name + "B2.tim")
    timeB3 = np.loadtxt(in_file_name + "B3.tim")
    timeB4 = np.loadtxt(in_file_name + "B4.tim")

    attB1 = np.loadtxt(in_file_name + "B1.att")
    attB2 = np.loadtxt(in_file_name + "B2.att")
    attB3 = np.loadtxt(in_file_name + "B3.att")
    attB4 = np.loadtxt(in_file_name + "B4.att")

    band1 = gdal.Open(in_file_name + "B1.tif")
    band2 = gdal.Open(in_file_name + "B2.tif")
    band3 = gdal.Open(in_file_name + "B3.tif")
    band4 = gdal.Open(in_file_name + "B4.tif")


    # out_im = np.zeros((im_height,im_height,4),'uint8')

    posB3 = posB3[lines[2]:lines[2] + im_height]
    timeB3 = timeB3[lines[2]:lines[2] + im_height]
    attB3 = attB3[lines[2]:lines[2] + im_height]
    jd3 = computeJDtime(current_date, timeB3[0], utc_gps)
    uecef3_1 = util.computeUECEF(jd3, dut1, 3000, attB3[0], 3)
    earth_post3_1 = util.findEarthSurfacePosition(uecef3_1, posB3[0])
    lat3, lon3, height3 = util.itrf2latlon(earth_post3_1)
    errmin1_1 = 1e100
    errmin1_2 = 1e100
    errmin1_4 = 1e100
    print "Finding the actual line offset........."
    for off_set in range(-500, 500):
        jd1 = computeJDtime(current_date, timeB1[off_set + lines[0]], utc_gps)
        jd2 = computeJDtime(current_date, timeB2[off_set + lines[1]], utc_gps)
        jd4 = computeJDtime(current_date, timeB4[off_set + lines[3]], utc_gps)
        uecef1 = util.computeUECEF(jd1, dut1, 3000, attB1[off_set + lines[0]], 1)
        uecef2 = util.computeUECEF(jd2, dut1, 3000, attB2[off_set + lines[1]], 2)
        uecef4 = util.computeUECEF(jd4, dut1, 3000, attB4[off_set + lines[3]], 4)
        earth_post1 = util.findEarthSurfacePosition(uecef1, posB1[off_set + lines[0]])
        earth_post2 = util.findEarthSurfacePosition(uecef2, posB2[off_set + lines[1]])
        earth_post4 = util.findEarthSurfacePosition(uecef4, posB4[off_set + lines[3]])
        lat1, lon1, height1 = util.itrf2latlon(earth_post1)
        lat2, lon2, height2 = util.itrf2latlon(earth_post2)
        lat4, lon4, height4 = util.itrf2latlon(earth_post4)
        er1_b1 = (lat3 - lat1) ** 2 + (lon3 - lon1) ** 2
        er1_b2 = (lat3 - lat2) ** 2 + (lon3 - lon2) ** 2
        er1_b4 = (lat3 - lat4) ** 2 + (lon3 - lon4) ** 2

        if er1_b1 < errmin1_1:
            errmin1_1 = er1_b1
            offset1 = off_set
        if er1_b2 < errmin1_2:
            errmin1_2 = er1_b2
            offset2 = off_set
        if er1_b4 < errmin1_4:
            errmin1_4 = er1_b4
            offset4 = off_set


    lines[0] += offset1
    lines[1] += offset2
    lines[3] += offset4
    print "Corrected First Lines are: ", lines

    posB1 = posB1[lines[0]:lines[0] + im_height]
    posB2 = posB2[lines[1]:lines[1] + im_height]
    posB4 = posB4[lines[3]:lines[3] + im_height]

    timeB1 = timeB1[lines[0]:lines[0] + im_height]
    timeB2 = timeB2[lines[1]:lines[1] + im_height]
    timeB4 = timeB4[lines[3]:lines[3] + im_height]

    attB1 = attB1[lines[0]:lines[0] + im_height]
    attB2 = attB2[lines[1]:lines[1] + im_height]
    attB4 = attB4[lines[3]:lines[3] + im_height]

    gtiffDriver = gdal.GetDriverByName('GTiff')
    dst_ds = gtiffDriver.Create(out_file_name, im_width, im_height, 4, gdal.GDT_Byte)
    ms_b1 = dst_ds.GetRasterBand(3)
    ms_b2 = dst_ds.GetRasterBand(2)
    ms_b3 = dst_ds.GetRasterBand(1)
    ms_b4 = dst_ds.GetRasterBand(4)
    # Find the shift function using the middle line
    mid_line = im_height / 2
    mid_sample = start_sample + im_width / 2
    # Building the transformation polynomial
    step = 50
    samples2 = samples[step:-step:step]
    x1 = []
    y1 = []
    x2 = []
    y2 = []
    x4 = []
    y4 = []
    v = np.arange(step, im_height - step, step)
    u = samples2.copy()
    num_u = u.shape[0]
    num_v = v.shape[0]
    AA = np.zeros((num_u * num_v, 6))
    idx = 0
    # find approprite line offset
    # consider only the first and last lines.
    sub_line_ranges = 10
    print "finding the corresponding pixels among image bands"
    for line in range(step, im_height - step, step):
        jd3 = computeJDtime(current_date, timeB3[line], utc_gps)
        uecef3 = util.computeUECEF(jd3, dut1, samples2, attB3[line], 3)
        earth_post3 = util.findEarthSurfacePosition(uecef3, posB3[line])
        lat3, lon3, height3 = util.itrf2latlon(earth_post3)
        err1 = 1e100 * np.ones_like(samples2).astype('float32')
        best_line1 = np.ones_like(samples2)
        best_sample1 = np.ones_like(samples2)
        err2 = 1e100 * np.ones_like(samples2).astype('float32')
        best_line2 = np.ones_like(samples2)
        best_sample2 = np.ones_like(samples2)
        err4 = 1e100 * np.ones_like(samples2).astype('float32')
        best_line4 = np.ones_like(samples2)
        best_sample4 = np.ones_like(samples2)
        AA[idx * num_u:(idx + 1) * num_u, 0] = 1.0
        AA[idx * num_u:(idx + 1) * num_u, 1] = samples2 - mid_sample
        AA[idx * num_u:(idx + 1) * num_u, 2] = line - mid_line
        AA[idx * num_u:(idx + 1) * num_u, 3] = (samples2 - mid_sample) * (line - mid_line)
        AA[idx * num_u:(idx + 1) * num_u, 4] = (samples2 - mid_sample) ** 2
        AA[idx * num_u:(idx + 1) * num_u, 5] = (line - mid_line) ** 2
        idx += 1

        for sub_line in range(line - sub_line_ranges, line + sub_line_ranges):
            jd1 = computeJDtime(current_date, timeB1[sub_line], utc_gps)
            jd2 = computeJDtime(current_date, timeB2[sub_line], utc_gps)
            jd4 = computeJDtime(current_date, timeB4[sub_line], utc_gps)
            uecef1 = util.computeUECEF(jd1, dut1, samples, attB1[sub_line], 1)
            uecef2 = util.computeUECEF(jd2, dut1, samples, attB2[sub_line], 2)
            uecef4 = util.computeUECEF(jd4, dut1, samples, attB4[sub_line], 4)
            earth_post1 = util.findEarthSurfacePosition(uecef1, posB1[sub_line])
            earth_post2 = util.findEarthSurfacePosition(uecef2, posB2[sub_line])
            earth_post4 = util.findEarthSurfacePosition(uecef4, posB4[sub_line])
            lat1, lon1, height1 = util.itrf2latlon(earth_post1)
            lat2, lon2, height2 = util.itrf2latlon(earth_post2)
            lat4, lon4, height4 = util.itrf2latlon(earth_post4)



            for k in range(samples2.shape[0]):
                err = (lat1 - lat3[k]) ** 2 + (lon1 - lon3[k]) ** 2
                err_min = err.min()
                if err_min < err1[k]:
                    err1[k] = err_min
                    best_line1[k] = sub_line - mid_line
                    id = np.nonzero(err == err_min)
                    best_sample1[k] = samples[id[0][0]] - mid_sample
                err = (lat2 - lat3[k]) ** 2 + (lon2 - lon3[k]) ** 2
                err_min = err.min()
                if err_min < err2[k]:
                    err2[k] = err_min
                    best_line2[k] = sub_line - mid_line
                    id = np.nonzero(err == err_min)
                    best_sample2[k] = samples[id[0][0]] - mid_sample

                err = (lat4 - lat3[k]) ** 2 + (lon4 - lon3[k]) ** 2
                err_min = err.min()
                if err_min < err4[k]:
                    err4[k] = err_min
                    best_line4[k] = sub_line - mid_line
                    id = np.nonzero(err == err_min)
                    best_sample4[k] = samples[id[0][0]] - mid_sample

        x1.append(best_sample1)
        y1.append(best_line1)
        x2.append(best_sample2)
        y2.append(best_line2)
        x4.append(best_sample4)
        y4.append(best_line4)

        # print "Band1, line:%d,  err_min_max: %f" % (line, err1.max())
        # print "Band2, line:%d,  err_min_max: %f" % (line, err2.max())
        # print "Band4, line:%d,  err_min_max: %f" % (line, err4.max())


    x1 = np.array(x1)
    y1 = np.array(y1)
    # find tune the location
    print "Total of %d pixels pairs between Band1 and Band3" % len(x1)

    b = np.array(x1).flatten()
    par_x1 = np.linalg.lstsq(AA, b)[0]
    print "max error column band 1: %f" % (np.abs(np.dot(AA, par_x1) - b).max())

    b = np.array(y1).flatten()
    par_y1 = np.linalg.lstsq(AA, b)[0]
    print "max error row band 1: %f" % (np.abs(np.dot(AA, par_y1) - b).max())
    x2 = np.array(x2)
    y2 = np.array(y2)
    print "Total of %d pixels pairs between Band2 and Band3" % len(x2)
    b = np.array(x2).flatten()
    par_x2 = np.linalg.lstsq(AA, b)[0]
    print "max error column band 2: %f" % (np.abs(np.dot(AA, par_x2) - b).max())

    b = np.array(y2).flatten()
    par_y2 = np.linalg.lstsq(AA, b)[0]
    print "max error row band 2: %f" % (np.abs(np.dot(AA, par_y2) - b).max())

    x4 = np.array(x4)
    y4 = np.array(y4)
    b = np.array(x4).flatten()
    print "Total of %d pixels pairs between Band4 and Band3" % len(x4)
    par_x4 = np.linalg.lstsq(AA, b)[0]
    print "max error column band 4: %f" % (np.abs(np.dot(AA, par_x4) - b).max())

    b = np.array(y4).flatten()
    par_y4 = np.linalg.lstsq(AA, b)[0]
    print "max error row band 4: %f" % (np.abs(np.dot(AA, par_y4) - b).max())

    # print par_x1,par_x2, par_x4
    # print par_y1,par_y2, par_y4

    # check for line offset
    line_off_set1_min = 0
    line_off_set1_max = im_height
    line_off_set2_min = 0
    line_off_set2_max = im_height
    line_off_set4_min = 0
    line_off_set4_max = im_height

    for cl in [0, im_width - 1]:
        for rw in [0, im_height - 1]:
            k = cl - mid_sample + 1
            m = rw - mid_line
            line_off_set1 = par_y1[0] + par_y1[1] * k + par_y1[2] * m + par_y1[3] * k * m + par_y1[4] * k * k \
                            + par_y1[5] * m * m + mid_line
            line_off_set1_min = int(np.floor(min(line_off_set1 - 3.0, line_off_set1_min)))
            line_off_set1_max = int(np.ceil(max(line_off_set1 + 3.0, line_off_set1_max)))

            line_off_set2 = par_y2[0] + par_y2[1] * k + par_y2[2] * m + par_y2[3] * k * m + par_y2[4] * k * k \
                            + par_y2[5] * m * m + mid_line
            line_off_set2_min = int(np.floor(min(line_off_set2 - 3.0, line_off_set2_min)))
            line_off_set2_max = int(np.ceil(max(line_off_set2 + 3.0, line_off_set2_max)))

            line_off_set4 = par_y4[0] + par_y4[1] * k + par_y4[2] * m + par_y4[3] * k * m + par_y4[4] * k * k\
                            + par_y4[5] * m * m + mid_line
            line_off_set4_min = int(np.floor(min(line_off_set4 - 3.0, line_off_set4_min)))
            line_off_set4_max = int(np.ceil(max(line_off_set4 + 3.0, line_off_set4_max)))
    print line_off_set1_min, line_off_set1_max
    print line_off_set2_min, line_off_set2_max
    print line_off_set4_min, line_off_set4_max
    max_width = 6000
    databand1 = band1.ReadAsArray(0, lines[0] + line_off_set1_min, max_width, line_off_set1_max - line_off_set1_min)
    databand2 = band2.ReadAsArray(0, lines[1] + line_off_set2_min, max_width, line_off_set2_max - line_off_set2_min)
    databand3 = band3.ReadAsArray(0, lines[2], max_width, im_height)
    databand4 = band4.ReadAsArray(0, lines[3] + line_off_set4_min, max_width, line_off_set4_max - line_off_set4_min)

    # print databand1.shape
    # print databand2.shape
    # print databand3.shape
    # print databand4.shape
    # par_y1[0] -= line_off_set1_min
    # par_y2[0] -= line_off_set2_min
    # par_y4[0] -= line_off_set4_min


    outband_fullwidth1 = np.zeros_like(databand3)
    outband_fullwidth2 = np.zeros_like(databand3)
    # outband3 = np.zeros_like(databand3)
    outband_fullwidth4 = np.zeros_like(databand3)

    # resampling in y-direction
    im_lines1 = np.arange(im_height).astype('float32') - mid_line
    im_lines2 = np.arange(im_height).astype('float32') - mid_line
    im_lines4 = np.arange(im_height).astype('float32') - mid_line
    print "Resampling image in height direction......"
    for s in range(max_width):
        s1 = float(s + 1 - mid_sample)
        one_sampleB1 = databand1[:, s].astype('float32')
        b1sub = par_y1[0] + par_y1[1] * s1 + par_y1[2] * im_lines1 + par_y1[3] * s1 * im_lines1 + par_y1[4] * s1 * s1 + \
                par_y1[5] * (im_lines1 ** 2) - line_off_set1_min
        b1sub += mid_line
        outband_fullwidth1[:, s] = cubicInterpolation(one_sampleB1, b1sub, im_lines1.shape[0])

        one_sampleB2 = databand2[:, s].astype('float32')
        b2sub = par_y2[0] + par_y2[1] * s1 + par_y2[2] * im_lines2 + par_y2[3] * s1 * im_lines2 + par_y2[4] * s1 * s1 + \
                par_y2[5] * (im_lines2 ** 2) - line_off_set2_min
        b2sub += mid_line
        outband_fullwidth2[:, s] = cubicInterpolation(one_sampleB2, b2sub, im_lines2.shape[0])

        one_sampleB4 = databand4[:, s].astype('float32')
        b4sub = par_y4[0] + par_y4[1] * s1 + par_y4[2] * im_lines4 + par_y4[3] * s1 * im_lines4 + par_y4[4] * s1 * s1 + \
                par_y4[5] * (im_lines4 ** 2) - line_off_set4_min
        b4sub += mid_line
        outband_fullwidth4[:, s] = cubicInterpolation(one_sampleB4, b4sub, im_lines4.shape[0])

    # resampling in x-direction
    # outband1 = databand1[-line_off_set1_max:im_height-line_off_set1_max,:]
    # outband2 = databand2[-line_off_set2_max:im_height-line_off_set2_max,:]
    # outband4 = databand4[-line_off_set4_max:im_height-line_off_set4_max,:]
    s = samples.copy() - 1
    samples = samples.astype('float32') - mid_sample
    outband3 = np.zeros((im_height, im_width), 'uint8')
    outband1 = np.zeros_like(outband3)
    outband2 = np.zeros_like(outband3)
    outband4 = np.zeros_like(outband3)

    print "Resampling image in width direction......"
    for k in range(im_height):
        # print "Building line %d......" % k
        one_lineB3 = databand3[k, :].astype('float32')
        # one_lineB3 = np.round((one_lineB3_t-dark_currents[2])/gains[2])
        # out_lineB3 = one_lineB3*(one_lineB3 <255.0) + 255.0*(one_lineB3>=255)

        # out_lineB3 = one_lineB3*(one_lineB3_t <255.0) + 255.0*(one_lineB3_t>=255)
        outband3[k, :] = one_lineB3[s].astype('uint8')

        k1 = float(k - mid_line)  # + line_off_set1_min
        one_lineB1 = outband_fullwidth1[k, :].astype('float32')
        # one_lineB1 = np.round((one_lineB1_t-dark_currents[0])/gains[0])
        # one_lineB1 = one_lineB1*(one_lineB1 <255.0) + 255.0*(one_lineB1>=255)
        # one_lineB1 =  one_lineB1*(one_lineB1_t <255.0) + 255.0*(one_lineB1_t>=255)
        a1sub = par_x1[0] + par_x1[1] * samples + par_x1[2] * k1 + par_x1[3] * samples * k1 + \
                par_y1[4] * samples * samples + \
                par_y1[5] * k1 * k1
        a1sub += mid_sample
        outband1[k, :] = cubicInterpolation(one_lineB1, a1sub, max_width)

        k2 = float(k - mid_line)  # + line_off_set2_min
        one_lineB2 = outband_fullwidth2[k, :].astype('float32')
        # one_lineB2 = np.round((one_lineB2_t-dark_currents[1])/gains[1])
        # one_lineB2 = one_lineB2*(one_lineB2 <255.0) + 255.0*(one_lineB2>=255)
        # one_lineB2 = one_lineB2*(one_lineB2_t <255.0) + 255.0*(one_lineB2_t>=255)
        a2sub = par_x2[0] + par_x2[1] * samples + par_x2[2] * k2 + par_x2[3] * samples * k2 + \
                par_y2[4] * samples * samples + \
                par_y2[5] * k2 * k2
        a2sub += mid_sample
        outband2[k, :] = cubicInterpolation(one_lineB2, a2sub, max_width)

        k4 = float(k - mid_line)  # + line_off_set4_min
        one_lineB4 = outband_fullwidth4[k, :].astype('float32')
        # one_lineB4 = np.round((one_lineB4_t-dark_currents[3])/gains[3])
        # one_lineB4 = one_lineB4*(one_lineB4 <255.0) + 255.0*(one_lineB4>=255)
        # one_lineB4 = one_lineB4*(one_lineB4_t <255.0) + 255.0*(one_lineB4_t >=255)
        a4sub = par_x4[0] + par_x4[1] * samples + par_x4[2] * k4 + par_x4[3] * samples * k4 + \
                par_y4[4] * samples * samples + \
                par_y4[5] * k4 * k4
        a4sub += mid_sample
        outband4[k, :] = cubicInterpolation(one_lineB4, a4sub, max_width)

    ms_b1.WriteArray(outband1, 0, 0)
    ms_b2.WriteArray(outband2, 0, 0)
    ms_b3.WriteArray(outband3, 0, 0)
    ms_b4.WriteArray(outband4, 0, 0)


def findSamplesPoints(in_file_name, step, lines, sat_pos, sat_time, sat_att, image_data, offset_mins, current_date,
                      utc_gps, dut1, dem, dem_interpolation_method, im_width, im_height, precision_error=1.0,
                      max_percision_error=5.0, process_box=1000):

    process_box = 500
    pos1, pos2, pos3, pos4 = sat_pos
    time1, time2, time3, time4 = sat_time
    att1, att2, att3, att4 = sat_att

    x1 = []
    y1 = []
    x2 = []
    y2 = []
    x3 = []
    y3 = []
    x4 = []
    y4 = []

    for block_line in range(0, im_height, process_box) :
        for block_sample in range(0, im_width, process_box):
            mid_sample = block_sample + process_box / 2
            mid_line = block_line + process_box / 2

            print "Find the initial shift at the middle of an image (%d,%d)" % (mid_sample, mid_line)
            lat3a, lon3a, h3a = dps.findInterSectionPointArrayUsingDEMPreloaded("MS", in_file_name, np.array([mid_sample]),
                                                                                [mid_line + lines[2]], pos3, time3, att3,
                                                                                current_date, utc_gps, dut1, dem,
                                                                                dem_interpolation_method, band=3)
            x3a, y3a, zn3, zt3 = utmLatlon.from_latlon(lat3a, lon3a)
            dx_init = np.zeros((4,))  # [45, 22, 0, -23]
            dy_init = np.zeros((4,))  # [29, 28, 0, -29]
            for band in [1, 2, 4]:
                err_min = 1e100
                best_solution_found = False
                dx = 0
                dy = 0
                while not best_solution_found:
                    err_min = 1e100

                    for tx in [-1, 0, 1]:
                        for ty in [-1, 0, 1]:
                            latb, lonb, hb = util.computeViewLatLongArrayWithHeight(band, np.array([dx]) + tx + mid_sample,
                                                                                    np.array([dy]) + ty + mid_line, h3a,
                                                                                    lines[band - 1],
                                                                                    sat_pos[band - 1],
                                                                                    sat_att[band - 1],
                                                                                    sat_time[band - 1],
                                                                                    current_date[0], current_date[1],
                                                                                    current_date[2], utc_gps, dut1)
                            xb, yb, zn, zt = utmLatlon.from_latlon(latb, lonb, zn3)
                            error = np.sqrt((xb - x3a) ** 2 + (yb - y3a) ** 2)[0]
                            if error < err_min:
                                err_min = error
                                dx_temp = tx
                                dy_temp = ty

                    if (dx_temp == 0) and (dy_temp == 0):
                        best_solution_found = True

                        dx_init[band - 1] = dx
                        dy_init[band - 1] = dy
                    else:
                        dx += dx_temp
                        dy += dy_temp


                print "The initial dislacement for Band %d is (%d,%d)" % (band, dx_init[band - 1], dy_init[band - 1])
            bline = block_line
            bsample = block_sample
            # block_width = im_width
            max_block_height = process_box
            max_block_width = process_box
            block_height = min((im_height - bline), max_block_height)
            block_width = min(im_width - bsample, max_block_width)
            line_str = block_line
            line_stp = line_str + block_height
            sample_str = block_sample
            sample_stp = sample_str + block_width
            samples2 = np.arange(sample_str + step / 2, sample_stp, step)



            for line in range(line_str + step / 2 , line_stp, step):
                # print "working on Sample:%d and Line: %d" % (line
                # print "Estimating locations."
                lat3a, lon3a, h3a = dps.findInterSectionPointArrayUsingDEMPreloaded("MS", in_file_name, samples2,
                                                                                    [line + lines[2]], pos3, time3,
                                                                                    att3, current_date,
                                                                                    utc_gps, dut1, dem,
                                                                                    dem_interpolation_method, band=3)
                x3a, y3a, zn3, zt3 = utmLatlon.from_latlon(lat3a, lon3a, zn3)
                # x3.append(samples2)
                # y3.append(line*np.ones_like(samples2))
                sard_times = np.loadtxt(in_file_name + "B%dsadr_times.txt" % 3)
                sard_last_time = sard_times[-1]
                valid_pixels = np.ones_like(samples2)
                for band in [1, 2, 4]:
                    sx_in = (samples2 + dx_init[band - 1]).astype('float64')
                    sy_in = (np.array(line + dy_init[band - 1]) * np.ones_like(samples2)).astype('float64')
                    err_sx = np.ones_like(sx_in) * 2.0
                    err_sy = np.ones_like(sx_in) * 2.0
                    num_fail = 0

                    for it in range(200):
                        idx = np.nonzero((err_sx > precision_error) + (err_sy > precision_error))[0]
                        if len(idx) == 0 :  # and (not brute_force):
                            brute_force = False
                            # print "Save best location!!"
                            if band == 1:
                                sx1 = sx_in.copy()  # x1.append(sx)
                                sy1 = sy_in.copy()  # y1.append(sy)
                            elif band == 2:
                                sx2 = sx_in.copy()  # x2.append(sx)
                                sy2 = sy_in.copy()  # y2.append(sy)
                            elif band == 4:
                                sx4 = sx_in.copy()  # x4.append(sx)
                                sy4 = sy_in.copy()  # sy4.append(sy)
                            break

                        sx = sx_in[idx]
                        sy = sy_in[idx]
                        hb = h3a[idx]
                        lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy,
                                                                              hb, lines[band - 1], sat_pos[band - 1],
                                                                              sat_att[band - 1], sat_time[band - 1],
                                                                              current_date[0], current_date[1],
                                                                              current_date[2], utc_gps, dut1)
                        xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon, zn3)
                        errx = xb - x3a[idx]
                        erry = yb - y3a[idx]

                        errx_max = np.abs(errx).max()
                        erry_max = np.abs(erry).max()


                        lat1, lon1, ht = util.computeViewLatLongArrayWithHeight(band, sx + 1.0, sy,
                                                                                hb, lines[band - 1], sat_pos[band - 1],
                                                                                sat_att[band - 1], sat_time[band - 1],
                                                                                current_date[0], current_date[1],
                                                                                current_date[2], utc_gps, dut1)
                        lat2, lon2, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy + 1.0,
                                                                                hb, lines[band - 1], sat_pos[band - 1],
                                                                                sat_att[band - 1], sat_time[band - 1],
                                                                                current_date[0], current_date[1],
                                                                                current_date[2], utc_gps, dut1)
                        xb1, yb1, zn, zt = utmLatlon.from_latlon(lat1, lon1)
                        xb2, yb2, zn, zt = utmLatlon.from_latlon(lat2, lon2)
                        # errlat = xb - x3a
                        # errlon = yb - y3a
                        total_errors = np.sqrt(errx ** 2 + erry ** 2)
                        gx = 2.0 * errx * (xb1 - xb) + 2.0 * (erry) * (yb1 - yb)
                        gy = 2.0 * errx * (xb2 - xb) + 2.0 * (erry) * (yb2 - yb)
                        lamb = (0.1 / total_errors)
                        lamb = (lamb > 0.001) * 0.001 + (lamb <= 0.001) * lamb

                        lamb = (lamb < 1e-7) * 1e-7 + (lamb >= 1e-7) * lamb

                        errxm = errx_max
                        errym = erry_max
                        itx = 0
                        it_max = 100
                        new_total_error = total_errors.copy()
                        while np.any(new_total_error >= total_errors) and (itx < it_max):
                            sxt = sx - lamb * gx
                            syt = sy - lamb * gy

                            lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sxt, syt,
                                                                                  hb, lines[band - 1], sat_pos[band - 1],
                                                                                  sat_att[band - 1], sat_time[band - 1],
                                                                                  current_date[0], current_date[1],
                                                                                  current_date[2], utc_gps, dut1)

                            try:
                                xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon, zn3)
                                errold_x = errx.copy()
                                errold_y = erry.copy()
                                errx = xb - x3a[idx]
                                erry = yb - y3a[idx]
                                errxm = np.abs(errx).max()
                                errym = np.abs(erry).max()
                                # print "lambda:%f, %f, %f"%(lamb,errxm,errym)
                                old_total_error = new_total_error.copy()
                                new_total_error = np.sqrt(errx ** 2 + erry ** 2)
                                lamb = (lamb / 2.0) * (new_total_error >= total_errors) + \
                                       (lamb / 2.0) * (new_total_error < total_errors) * (
                                       new_total_error < old_total_error) + \
                                       (lamb) * (new_total_error < total_errors) * (new_total_error >= old_total_error)

                                errx = errx * (new_total_error >= total_errors) + \
                                       errx * (new_total_error < total_errors) * (new_total_error < old_total_error) + \
                                       errold_x * (new_total_error < total_errors) * (
                                       new_total_error >= old_total_error)

                                erry = erry * (new_total_error >= total_errors) + \
                                       erry * (new_total_error < total_errors) * (new_total_error < old_total_error) + \
                                       errold_y * (new_total_error < total_errors) * (
                                       new_total_error >= old_total_error)

                                itx += 1
                            except :
                                lamb = lamb / 10.0
                                sxt = sx - lamb * gx
                                syt = sy - lamb * gy
                                itx += 1

                        sx = sx - (lamb * 2) * gx
                        sy = sy - (lamb * 2) * gy
                        sx_in[idx] = sx
                        sy_in[idx] = sy
                        err_sx[idx] = errx
                        err_sy[idx] = erry


                        if itx == it_max:
                            # print "[%d] cannot improve the performance any future!" % (band),
                            # print "..... error x: %f, error y: %f." % ( errxm, errym)
                            # print "Exiting the solution searching"
                            # print "Try to randomly move around. "
                            sx_bestold = sx.copy()
                            sy_bestold = sy.copy()
                            if num_fail < 5:
                                sx = sx_bestold + 2.0 * (np.random.rand(sx.shape[0]) - 0.5)  # samples2 + dx_init[band - 1]
                                sy = sy_bestold + 2.0 * (np.random.rand(sx.shape[0]) - 0.5)  # np.array(line + dy_init[band - 1]) * np.ones_like(samples2)
                                num_fail += 1
                            else:
                                print "Warning: There are saving %d pixels from Band %d with positioning error more than " \
                                      "%f meters." % (sx.shape[0], band, precision_error)

                                id_max = np.nonzero((err_sx > max_percision_error) + (err_sy > max_percision_error))[0]
                                # print "The maximum errors is ( %f, %f)." % (errxm, errym)

                                valid_pixels[id_max] = 0
                                if band == 1:
                                    sx1 = sx_in.copy()  # x1.append(sx)
                                    sy1 = sy_in.copy()  # y1.append(sy)
                                elif band == 2:
                                    sx2 = sx_in.copy()  # x2.append(sx)
                                    sy2 = sy_in.copy()  # y2.append(sy)
                                elif band == 4:
                                    sx4 = sx_in.copy()  # x4.append(sx)
                                    sy4 = sy_in.copy()  # sy4.append(sy)



                                break



                if (sat_time[band - 1][line + lines[band - 1]] > sard_last_time) or (sat_time[2][line + lines[2]] > sard_last_time):
                    print "perform image to image registration"
                    num_sample_points = len(sx)
                    bandheight = image_data[band - 1].shape[0]
                    lineb = lines[band - 1]
                    max_lineb = bandheight + offset_mins[band - 1]
                    for k in range(num_sample_points):
                        sx3 = samples2[k]
                        sy3 = line
                        sxb = sx[k]
                        syb = sy[k]
                        if (sx3 > 20) & (sx3 < im_width - 20) & (sy3 > 20) & (sy3 < im_height - 20):
                            if  (sxb > 25) & (sxb < im_width - 25) & (syb > 25) & (syb < max_lineb - 25):
                                im3 = image_data[2][sy3 - 20:sy3 + 21, sx3 - 20:sx3 + 21]
                                xg, yg = np.meshgrid(sxb + np.arange(-20, 21), syb + np.arange(-20, 21) - offset_mins[band - 1])
                                xg = xg.astype('float32')
                                yg = yg.astype('float32')
                                itc_max = 10
                                itc = 0
                                c_done = False
                                dx = 0
                                dy = 0
                                grad_old = 1e300
                                while (itc < itc_max) & (not c_done):
                                    imb = cv2.remap(image_data[band - 1], xg + dx + 1, yg + dy, cv2.INTER_CUBIC)
                                    coor0 = np.corrcoef([im3.flatten(), imb.flatten()])[0, 1]
                                    imb = cv2.remap(image_data[band - 1], xg + dx + 2, yg + dy , cv2.INTER_CUBIC)
                                    coorr = np.corrcoef([im3.flatten(), imb.flatten()])[0, 1]
                                    imb = cv2.remap(image_data[band - 1], xg + dx + 1, yg + dy + 1, cv2.INTER_CUBIC)
                                    coord = np.corrcoef([im3.flatten(), imb.flatten()])[0, 1]
                                    gr = coorr - coor0
                                    gd = coord - coor0
                                    grad = np.sqrt(gr ** 2 + gd ** 2)
                                    if grad < grad_old:
                                        grad_old = grad
                                        itc += 1
                                        itg = 0
                                        itgmax = 10
                                        lamb = 1.0
                                        while (itg < itgmax):
                                            dxp = dx + lamb * gr
                                            dyp = dy + lamb * gd
                                            imb = cv2.remap(image_data[band - 1], xg + dxp + 1, yg + dyp, cv2.INTER_CUBIC)
                                            coorp = np.corrcoef([im3.flatten(), imb.flatten()])[0, 1]
                                            if coorp > coor0:
                                                dx = dxp
                                                dy = dyp
                                                itg = itgmax
                                            else:
                                                lamb /= 2.0
                                                itg += 1
                                    else:
                                        c_done = True
                                sx[k] += dx
                                sy[k] += dy




                if (sx1 is not None) & (sy1 is not None) & (sx2 is not None) & (sy2 is not None) & (sx4 is not None) & (sy4 is not None):

                    id_ready = np.nonzero(valid_pixels)[0]
                    id_max = np.nonzero(valid_pixels == 0)[0]
                    if np.any(sx1) is None:
                        print sx1
                    if len(id_max) > 0 :
                        print "Warning: We need to remove %d pixels due to the maximum error is more than the " \
                              "maximum limit of %f meters" % (id_max.shape[0], max_percision_error)
                        if valid_pixels.sum() > 0 :
                            x1.append(sx1[id_ready])
                            x2.append(sx2[id_ready])
                            x3.append(samples2[id_ready])
                            x4.append(sx4[id_ready])

                            y1.append(sy1[id_ready])
                            y2.append(sy2[id_ready])
                            y3.append(line * np.ones_like(samples2[id_ready]))
                            y4.append(sy4[id_ready])
                    else:
                        x1.append(sx1)
                        x2.append(sx2)
                        x3.append(samples2)
                        x4.append(sx4)

                        y1.append(sy1)
                        y2.append(sy2)
                        y3.append(line * np.ones_like(samples2))
                        y4.append(sy4)
    num_items = 0
    for item in x1:
        num_items += len(item)
    x1out = np.zeros((num_items,))
    x2out = np.zeros((num_items,))
    x3out = np.zeros((num_items,))
    x4out = np.zeros((num_items,))

    y1out = np.zeros((num_items,))
    y2out = np.zeros((num_items,))
    y3out = np.zeros((num_items,))
    y4out = np.zeros((num_items,))

    num_list = len(x1)
    str = 0
    for list_id in range(num_list):
        stp = str + len(x1[list_id])
        x1out[str:stp] = x1[list_id]
        x2out[str:stp] = x2[list_id]
        x3out[str:stp] = x3[list_id]
        x4out[str:stp] = x4[list_id]

        y1out[str:stp] = y1[list_id]
        y2out[str:stp] = y2[list_id]
        y3out[str:stp] = y3[list_id]
        y4out[str:stp] = y4[list_id]
        str = stp


    return x1out, x2out, x3out, x4out, y1out, y2out, y3out, y4out

def remapImageBand(U, V, xb, yb, x3, y3, im_width, im_height, max_error=0.1):

    if (V.max() < y3.min()) or (U.max() < x3.min()):
        mask = np.ones_like(U, "uint8")
        out_x = -100 * np.ones_like(U, "float32")
        out_y = -100 * np.ones_like(U, "float32")
    elif (V.min() > y3.max()) or (V.min() > y3.max()):
        mask = np.ones_like(U, "uint8")
        out_x = im_width + 100 * np.ones_like(U, "float32")
        out_y = im_height + 100 * np.ones_like(U, "float32")
    else:

        end_line = min(int(V.max() + 1), im_height)
        end_sample = min(int(U.max() + 1), im_width)
        line_str = max(int(V.min()), 0)
        sample_str = max(int(U.min()), 0)
        print "working on line:%d to %d and sample: %d to %d" % (line_str, end_line, sample_str, end_sample)
        block_height = end_line - line_str
        block_width = end_sample - sample_str
        out_x = np.zeros_like(U, 'float32')  # (block_width, block_height), 'float32')
        out_y = np.zeros_like(U, 'float32')  # ((block_width, block_height), 'float32')
        mask = np.ones_like(U, 'uint8')  # ((block_width,block_height),'uint8')
        idx = np.nonzero((x3 >= sample_str) & (x3 < end_sample) & (y3 >= line_str) & (y3 < end_line))[0]
        u = x3[idx]
        v = y3[idx]
        num_samples = u.size
        mid_sample = np.median(u)
        mid_line = np.median(v)
        ut = (u - mid_sample).astype('float64')
        vt = (v - mid_line).astype('float64')
        AA = np.zeros((num_samples, 12), 'float64')
        AA[:, 0] = 1.0
        AA[:, 1] = ut
        AA[:, 2] = vt
        AA[:, 3] = ut * vt
        AA[:, 4] = ut ** 2
        AA[:, 5] = vt ** 2
        AA[:, 6] = ut * vt * vt
        AA[:, 7] = vt * ut * ut
        AA[:, 8] = ut ** 3
        AA[:, 9] = vt ** 3
        AA[:, 10] = vt * ut ** 3
        AA[:, 11] = ut * vt ** 3
        x1 = xb[idx]
        y1 = yb[idx]
        b = x1 - mid_sample
        try:
            par_x1 = np.linalg.lstsq(AA, b)[0]
        except:
            print V.min(), V.max()
        errx1 = (np.abs(np.dot(AA, par_x1) - b).max())
        print "max error column: %f" % errx1

        b = y1 - mid_line
        par_y1 = np.linalg.lstsq(AA, b)[0]
        erry1 = (np.abs(np.dot(AA, par_y1) - b).max())
        print "max error row: %f" % erry1
        block_size = min(block_width, block_height)
        if ((errx1 > max_error) or (erry1 > max_error)) and (block_size > 200):
            new_block_size = max(block_size / 2, 200)

            for sub_line in range(line_str, end_line, new_block_size):
                for sub_sample in range(sample_str, end_sample, new_block_size):
                    regions = (V >= sub_line) * (V < sub_line + new_block_size) * (
                        U >= sub_sample) * (U < sub_sample + new_block_size)
                    if regions.sum() > 0:
                        index_block = np.nonzero(regions)[0]
                        Unew = U[index_block]
                        Vnew = V[index_block]
                        sub_out_x, sub_out_y, sub_mask = remapImageBand(Unew, Vnew, xb, yb, x3, y3, im_width, im_height,
                                                                       max_error=max_error)

                        out_x[index_block] = sub_out_x
                        out_y[index_block] = sub_out_y
                        mask[index_block] = sub_mask
        else:
            # U,V #bline = line_str

            sub_mask = np.ones_like(U, "uint8")
            # mskh, mskw = sub_mask.shape
            u1d = U.flatten()
            v1d = V.flatten()
            num_pairs = u1d.size
            A = np.zeros((num_pairs, 12))
            ut = (u1d - mid_sample).astype('float64')
            vt = (v1d - mid_line).astype('float64')
            A[:, 0] = 1.0
            A[:, 1] = ut
            A[:, 2] = vt
            A[:, 3] = ut * vt
            A[:, 4] = ut ** 2
            A[:, 5] = vt ** 2
            A[:, 6] = ut * vt * vt
            A[:, 7] = vt * ut * ut
            A[:, 8] = ut ** 3
            A[:, 9] = vt ** 3
            A[:, 10] = vt * ut ** 3
            A[:, 11] = ut * vt ** 3
            sub_mask = sub_mask.flatten()

            x = np.dot(A, par_x1) + mid_sample + 1
            y = np.dot(A, par_y1) + mid_line  # - offset_mins
            x = x.astype('float32')
            y = y.astype('float32')
            remap_x = x.reshape(U.shape)  # remap_im = cv2.remap(data, x, y, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                 # borderValue=0)
            remap_y = y.reshape(U.shape)
            idx = np.nonzero((x < 0))[0]
            sub_mask[idx] = 0
            idx = np.nonzero((x > im_width - 1))[0]
            sub_mask[idx] = 0
            # mask[y > im_height-1, x > im_width-1] = 0
            # remap_im = remap_im.reshape(U.shape)


            out_x = remap_x
            out_y = remap_y

    return out_x, out_y, mask



def findLV2RemapFuncitionBand3WithInterpolation(in_file_name, beg_line, ger_pairs, lv2_pair_min, lv2_pair_max, lv2_geotrans, dem_ds,
                            hmin, hmax, current_date, utc_gps, dut1, lv_width, lv_height, im_width, im_height, lv2_step_size=10):
    band = 2

    x2_up_left, y2_up_left, dx2, dy2, zonec = lv2_geotrans
    off_set = 10

    # num_block_lines = 885
    # num_block_pixels =885


    numpairs = ger_pairs.shape[0]
    print "  Band %d....." % (band + 1)
    print "  Finding the reversed model......."
    band_map_info = []
    A = np.zeros((numpairs, 12))
    u_mean = lv_width / 2.0
    v_mean = lv_height / 2.0
    u = lv2_pair_min[:, 0] - u_mean
    v = lv2_pair_min[:, 1] - v_mean + 1
    # print u.min(),u.max(),v.min(),v.max()
    A[:, 0] = 1.0
    A[:, 1] = u
    A[:, 2] = v
    A[:, 3] = u * v
    A[:, 4] = u ** 2
    A[:, 5] = v ** 2
    A[:, 6] = u * v * v
    A[:, 7] = v * u * u
    A[:, 8] = u ** 3
    A[:, 9] = v ** 3
    A[:, 10] = v * u ** 3
    A[:, 11] = u * v ** 3

    x_mean = ger_pairs[:, 0].mean()
    y_mean = ger_pairs[:, 1].mean()
    bx = ger_pairs[:, 0] - x_mean
    by = ger_pairs[:, 1] - y_mean
    a_x_min, errx, rnkx, s = np.linalg.lstsq(A, bx)
    # print rnk
    a_y_min, erry, rnky, s = np.linalg.lstsq(A, by)
    # print rnk
    if (rnkx == 12) and (rnky == 12):
        print "[%d] Minimun altitude average errors: %f,%f" % (band + 1, errx / numpairs, erry / numpairs)
    else:
        print "[%d]  The model for mainimum altitude is too fitted. Reduce the number of variables." % (band + 1)
        # A2 = A.copy()
        for rk in range(11, 0, -1):
            A2 = A[:, :rk]
            a_x_min2, errx, rnk, s = np.linalg.lstsq(A2, bx)
            a_y_min2, erry, rnk, s = np.linalg.lstsq(A2, by)
            if (len(a_x_min2) > 0) and (len(a_y_min2) > 0):
                a_x_min = np.zeros((12,))
                a_y_min = np.zeros((12,))
                a_x_min[:rk] = a_x_min2
                a_y_min[:rk] = a_y_min2
                break
        print ".....................The algorithm terminates with the matrix of order %d." % rk

    u = lv2_pair_max[:, 0] - u_mean
    v = lv2_pair_max[:, 1] - v_mean + 1
    # print u.min(),u.max(),v.min(),v.max()
    A[:, 0] = 1.0
    A[:, 1] = u
    A[:, 2] = v
    A[:, 3] = u * v
    A[:, 4] = u ** 2
    A[:, 5] = v ** 2
    A[:, 6] = u * v * v
    A[:, 7] = v * u * u
    A[:, 8] = u ** 3
    A[:, 9] = v ** 3
    A[:, 10] = v * u ** 3
    A[:, 11] = u * v ** 3
    x_mean = ger_pairs[:, 0].mean()
    y_mean = ger_pairs[:, 1].mean()
    bx = ger_pairs[:, 0] - x_mean
    by = ger_pairs[:, 1] - y_mean
    a_x_max, errx, rnkx, s = np.linalg.lstsq(A, bx)
    a_y_max, erry, rnky, s = np.linalg.lstsq(A, by)
    if (rnkx == 12) and (rnky == 12):
        print "[%d] Maximum altitude average errors: %f,%f" % (band + 1, errx / numpairs, erry / numpairs)
    else:
        print "[%d]    model for maximum altitude is too fitted. Reduce the number of variables." % (band + 1)
        # A2 = A.copy()
        for rk in range(11, 0, -1):
            A2 = A[:, :rk]
            a_x_max2, errx, rnk, s = np.linalg.lstsq(A2, bx)
            a_y_max2, erry, rnk, s = np.linalg.lstsq(A2, by)
            if (len(a_x_max2) > 0) and (len(a_y_max2) > 0):
                a_x_max = np.zeros((12,))
                a_y_max = np.zeros((12,))
                a_x_max[:rk] = a_x_max2
                a_y_max[:rk] = a_y_max2
                break
        print "....................The algorithm terminates with the matrix of order %d." % rk

    print "The reversed model is computed......"

    # num_lines = 1000
    # num_pixels = 1000
    num_lines2 = lv_height  # num_block_lines + off_set
    num_pixels2 = lv_width  # num_block_pixels + off_set
    # outimage = np.zeros((lv_height,lv_width),'uint8')
    sat_pos = np.loadtxt(in_file_name + "B%d.pos" % (band + 1))
    captured_time = np.loadtxt(in_file_name + "B%d.tim" % (band + 1))
    sat_att = np.loadtxt(in_file_name + "B%d.att" % (band + 1))
    # block_info_filep = open(in_file_name + "Band%d.txt"%(band+1),"w")

    line = 0
    sample = 0


    line_max = lv_height
    samp_max = lv_width
    print "[%d] Mapping Sample: %d to %d, and Line: %d to %d." % (band + 1, sample, sample + samp_max, line,
                                                                  line + line_max)
    Ux = np.arange(lv2_step_size / 2, lv_width, lv2_step_size)
    Vx = np.arange(lv2_step_size / 2, lv_height, lv2_step_size)
    U, V = np.meshgrid(Ux, Vx)


    urw, ucl = U.shape

    dem_data = dem_ds.ReadAsArray(0, 0, lv_width, lv_height)
    h = np.zeros_like(U, 'float64')
    h[:, :] = dem_data[lv2_step_size / 2::lv2_step_size, lv2_step_size / 2::lv2_step_size]

    # print "[%d] remapping line: %d to %d and sample: %d to %d"%(band+1,line,line+line_max,sample,sample+samp_max)

    U = U - u_mean
    V = V - v_mean

    U = U.flatten()
    V = V.flatten()
    h = h.flatten()
    try:
        X, Y = dps.findGerFileLocationPreLoadFiles(U, V, h, a_x_min, a_y_min, a_x_max, a_y_max, x_mean, y_mean,
                                                   u_mean,
                                                   v_mean, hmin, hmax, "MS", in_file_name, beg_line,
                                                   current_date,
                                                   utc_gps, dut1, (x2_up_left, y2_up_left, dx2, dy2, zonec),
                                                   im_width, im_height, sat_pos, captured_time, sat_att,
                                                   band=band + 1)
    except:
        np.save(in_file_name + "band_%d_U_%d.npy" % (band + 1, beg_line), U)
        np.save(in_file_name + "band_%d_V_%d.npy" % (band + 1, beg_line), V)
        np.save(in_file_name + "band_%d_h_%d.npy" % (band + 1, beg_line), h)
        np.save(in_file_name + "band_%d_axmin_%d.npy" % (band + 1, beg_line), a_x_min)
        np.save(in_file_name + "band_%d_aymin_%d.npy" % (band + 1, beg_line), a_y_min)
        np.save(in_file_name + "band_%d_axmax_%d.npy" % (band + 1, beg_line), a_x_max)
        np.save(in_file_name + "band_%d_aymax_%d.npy" % (band + 1, beg_line), a_y_max)
        np.save(in_file_name + "band_%d_x_mean_y_mean_%d.npy" % (band + 1, beg_line),
                np.array([x_mean, y_mean]))
        np.save(in_file_name + "band_%d_u_mean_v_mean_%d.npy" % (band + 1, beg_line),
                np.array([u_mean, v_mean]))
        np.save(in_file_name + "band_%d_hminmax_%d.npy" % (band + 1, beg_line),
                np.array([hmin, hmax]))
        print "filename", in_file_name
        print "Line:", beg_line
        print "data", current_date
        print "utc_gps", utc_gps
        print "dut1", dut1
        print "mapInfo", [x2_up_left, y2_up_left, dx2, dy2, zonec]
        np.save(in_file_name + "band_%d_cap_time_%d.npy" % (band + 1, beg_line), captured_time)
        np.save(in_file_name + "band_%d_sat_pos_%d.npy" % (band + 1, beg_line), sat_pos)
        np.save(in_file_name + "band_%d_sat_att_%d.npy" % (band + 1, beg_line), sat_att)
        exit()
    U = U + u_mean
    V = V + v_mean
    X = X.flatten()
    Y = Y.flatten()
    U2 = Ux
    V2 = Vx
    X2 = X.reshape(V2.shape[0], U2.shape[0]).T
    Y2 = Y.reshape(V2.shape[0], U2.shape[0]).T
    # np.save(in_file_name + "U.npy", U)
    # np.save(in_file_name + "V.npy", V)
    # np.save(in_file_name + "X.npy", X2)
    # np.save(in_file_name + "Y.npy", Y2)
    fx = inplt.RectBivariateSpline(U2, V2, X2, bbox=[0, lv_width, 0, lv_height])
    fy = inplt.RectBivariateSpline(U2, V2, Y2, bbox=[0, lv_width, 0, lv_height])

    mem = psutil.virtual_memory()
    mem_available = mem.available
    max_num_pixels = (mem_available - 1024 * 1024 * 1024) / ((800) * 8)  # 500 memory block per pixels and 8 for double
    num_block_lines = int(np.sqrt(max_num_pixels))
    num_block_pixels = num_block_lines
    for line in range(0, lv_height, num_block_lines):
        for sample in range(0, lv_width, num_block_pixels):
            line_max = min((lv_height - line), num_block_lines)
            samp_max = min(lv_width - sample, num_block_pixels)
            if (line == 0) & (sample == 0):
                V, U = np.mgrid[0:int(line_max), 0:int(samp_max)]
            elif (line == 0) & (sample > 0):
                V, U = np.mgrid[0:int(line_max), sample - off_set:int(samp_max + sample)]
            elif (line > 0) & (sample == 0):

                V, U = np.mgrid[line - off_set:int(line_max + line), 0:int(samp_max)]
            else:
                V, U = np.mgrid[line - off_set:int(line_max + line), sample - off_set:int(samp_max + sample)]

            U1 = U.flatten()
            V1 = V.flatten()
            X = fx.ev(U1, V1)
            Y = fy.ev(U1, V1)


            Xmin = int(X.min())
            Xmax = int(np.ceil(X.max()))
            Ymin = int(Y.min())
            Ymax = int(np.ceil(Y.max()))
            strx = int(max(Xmin, 0))
            stpx = min(Xmax + 1, im_width)

            stry = max(Ymin, 0)
            stpy = min(Ymax + 1, im_height)

            # print "[%d] Used the data from (%d,%d)->(%d,%d)"%(band+1,strx,stry,stpx,stpy)
            # maskxy = np.zero_like(U,'uint8')
            x_file_name = None
            y_file_name = None
            # print "Before:", mask_data[line:line+line_max,sample:sample+samp_max].max(), mask_data[line:line+line_max,sample:sample+samp_max].min()
            if (strx < stpx) & (stry < stpy):
                # original = databand[stry:stpy,strx:stpx]
                tr, tc = U.shape
                X = X.astype('float32')
                Y = Y.astype('float32')
                # remap_out = cv2.remap(original,X-strx,Y-stry,cv2.INTER_CUBIC,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
                # print remap_out.shape
                # print temp[(X>=X.min())*(X<=X.max())*(Y>=Y.min())*(Y<=Y.max())].shape
                X = X.reshape(tr, tc)
                Y = Y.reshape(tr, tc)
                # temp[(X>=X.min())*(X<=X.max())*(Y>=Y.min())*(Y<=Y.max())] = remap_out.flatten()
                maskxy = (X >= 0) * (Y >= 0) * (X <= im_width - 1) * (Y <= im_height - 1)
                xout = X.copy()
                yout = Y.copy()
                if (line == 0) & (sample == 0):
                    # outimage_data = temp
                    maskxy = maskxy


                elif (line == 0):
                    # outimage_data = temp[:,off_set:]
                    maskxy = maskxy[:, off_set:]
                    xout = xout[:, off_set:]
                    yout = yout[:, off_set:]


                elif (sample == 0):
                    # outimage_data = temp[off_set:,:]
                    maskxy = maskxy[off_set:, :]
                    xout = xout[off_set:, :]
                    yout = yout[off_set:, :]
                else:
                    # outimage_data = temp[off_set:,off_set:]
                    maskxy = maskxy[off_set:, off_set:]
                    xout = xout[off_set:, off_set:]
                    yout = yout[off_set:, off_set:]

                x_file_name = in_file_name + "X_Band%d_Line%d_Sample%d.npy" % (band + 1, line, sample)
                y_file_name = in_file_name + "Y_Band%d_Line%d_Sample%d.npy" % (band + 1, line, sample)
                np.save(x_file_name, xout)
                np.save(y_file_name, yout)
                # block_info_filep.writelines("%d, %d, %d, %d"%(line, sample, line_max, samp_max))
            band_map_info.append([line, sample, line_max, samp_max, x_file_name, y_file_name])

    band_map_info_array = np.array(band_map_info)
    # np.save(in_file_name + "_map_info_band_%d.npy" % (band + 1), band_map_info_array)

    return band_map_info_array




def findLV2RemapFuncitionBand3(in_file_name, beg_line, ger_pairs, lv2_pair_min, lv2_pair_max, lv2_geotrans, dem_ds,
                            hmin, hmax, current_date, utc_gps, dut1, lv_width, lv_height, im_width, im_height):
    band = 2

    x2_up_left, y2_up_left, dx2, dy2, zonec = lv2_geotrans
    off_set = 10
    mem = psutil.virtual_memory()
    mem_available = mem.available
    max_num_pixels = (mem_available - 1024 * 1024 * 1024) / ((800) * 8)  # 500 memory block per pixels and 8 for double
    num_block_lines = int(np.sqrt(max_num_pixels))
    num_block_pixels = num_block_lines
    # num_block_lines = 885
    # num_block_pixels =885


    numpairs = ger_pairs.shape[0]
    print "  Band %d....." % (band + 1)
    print "  Finding the reversed model......."
    band_map_info = []
    A = np.zeros((numpairs, 12))
    u_mean = lv_width / 2.0
    v_mean = lv_height / 2.0
    u = lv2_pair_min[:, 0] - u_mean
    v = lv2_pair_min[:, 1] - v_mean + 1
    # print u.min(),u.max(),v.min(),v.max()
    A[:, 0] = 1.0
    A[:, 1] = u
    A[:, 2] = v
    A[:, 3] = u * v
    A[:, 4] = u ** 2
    A[:, 5] = v ** 2
    A[:, 6] = u * v * v
    A[:, 7] = v * u * u
    A[:, 8] = u ** 3
    A[:, 9] = v ** 3
    A[:, 10] = v * u ** 3
    A[:, 11] = u * v ** 3

    x_mean = ger_pairs[:, 0].mean()
    y_mean = ger_pairs[:, 1].mean()
    bx = ger_pairs[:, 0] - x_mean
    by = ger_pairs[:, 1] - y_mean
    a_x_min, errx, rnkx, s = np.linalg.lstsq(A, bx)
    # print rnk
    a_y_min, erry, rnky, s = np.linalg.lstsq(A, by)
    # print rnk
    if (rnkx == 12) and (rnky == 12):
        print "[%d] Minimun altitude average errors: %f,%f" % (band + 1, errx / numpairs, erry / numpairs)
    else:
        print "[%d]  The model for mainimum altitude is too fitted. Reduce the number of variables." % (band + 1)
        # A2 = A.copy()
        for rk in range(11, 0, -1):
            A2 = A[:, :rk]
            a_x_min2, errx, rnk, s = np.linalg.lstsq(A2, bx)
            a_y_min2, erry, rnk, s = np.linalg.lstsq(A2, by)
            if (len(a_x_min2) > 0) and (len(a_y_min2) > 0):
                a_x_min = np.zeros((12,))
                a_y_min = np.zeros((12,))
                a_x_min[:rk] = a_x_min2
                a_y_min[:rk] = a_y_min2
                break
        print ".....................The algorithm terminates with the matrix of order %d." % rk

    u = lv2_pair_max[:, 0] - u_mean
    v = lv2_pair_max[:, 1] - v_mean + 1
    # print u.min(),u.max(),v.min(),v.max()
    A[:, 0] = 1.0
    A[:, 1] = u
    A[:, 2] = v
    A[:, 3] = u * v
    A[:, 4] = u ** 2
    A[:, 5] = v ** 2
    A[:, 6] = u * v * v
    A[:, 7] = v * u * u
    A[:, 8] = u ** 3
    A[:, 9] = v ** 3
    A[:, 10] = v * u ** 3
    A[:, 11] = u * v ** 3
    x_mean = ger_pairs[:, 0].mean()
    y_mean = ger_pairs[:, 1].mean()
    bx = ger_pairs[:, 0] - x_mean
    by = ger_pairs[:, 1] - y_mean
    a_x_max, errx, rnkx, s = np.linalg.lstsq(A, bx)
    a_y_max, erry, rnky, s = np.linalg.lstsq(A, by)
    if (rnkx == 12) and (rnky == 12):
        print "[%d] Maximum altitude average errors: %f,%f" % (band + 1, errx / numpairs, erry / numpairs)
    else:
        print "[%d]    model for maximum altitude is too fitted. Reduce the number of variables." % (band + 1)
        # A2 = A.copy()
        for rk in range(11, 0, -1):
            A2 = A[:, :rk]
            a_x_max2, errx, rnk, s = np.linalg.lstsq(A2, bx)
            a_y_max2, erry, rnk, s = np.linalg.lstsq(A2, by)
            if (len(a_x_max2) > 0) and (len(a_y_max2) > 0):
                a_x_max = np.zeros((12,))
                a_y_max = np.zeros((12,))
                a_x_max[:rk] = a_x_max2
                a_y_max[:rk] = a_y_max2
                break
        print "....................The algorithm terminates with the matrix of order %d." % rk

    print "The reversed model is computed......"

    # num_lines = 1000
    # num_pixels = 1000
    num_lines2 = num_block_lines + off_set
    num_pixels2 = num_block_pixels + off_set
    # outimage = np.zeros((lv_height,lv_width),'uint8')
    sat_pos = np.loadtxt(in_file_name + "B%d.pos" % (band + 1))
    captured_time = np.loadtxt(in_file_name + "B%d.tim" % (band + 1))
    sat_att = np.loadtxt(in_file_name + "B%d.att" % (band + 1))
    # block_info_filep = open(in_file_name + "Band%d.txt"%(band+1),"w")

    for line in range(0, lv_height, num_block_lines):
        for sample in range(0, lv_width, num_block_pixels):
            # line = 5915
            # sample= 5070

            line_max = min((lv_height - line), num_lines2)
            samp_max = min(lv_width - sample, num_pixels2)
            print "[%d] Mapping Sample: %d to %d, and Line: %d to %d." % (band + 1, sample, sample + samp_max, line,
                                                                          line + line_max),
            if (line == 0) & (sample == 0):
                V, U = np.mgrid[0:int(line_max), 0:int(samp_max)]
            elif (line == 0) & (sample > 0):
                V, U = np.mgrid[0:int(line_max), sample - off_set:int(samp_max + sample)]
            elif (line > 0) & (sample == 0):

                V, U = np.mgrid[line - off_set:int(line_max + line), 0:int(samp_max)]
            else:
                V, U = np.mgrid[line - off_set:int(line_max + line), sample - off_set:int(samp_max + sample)]
            temp = np.zeros_like(U, 'uint8')
            u_earth = U * dx2 + x2_up_left
            v_earth = V * dy2 + y2_up_left
            # late,lone = utmLatlon.to_latlon(u_earth,v_earth,zonec,zoneletter_c)

            # h = util.determineHeight(late,lone,dem_directory)
            # print "[%d]  coord:"%(band+1), late.min(),late.max(), lone.min(),lone.max()

            urw, ucl = U.shape
            ofx = off_set * (sample != 0)
            ofy = off_set * (line != 0)
            dem_data = dem_ds.ReadAsArray(sample - ofx, line - ofy, ucl, urw)
            h = np.zeros_like(U, 'float64')
            h[:, :] = dem_data[:, :]

            # print "[%d] remapping line: %d to %d and sample: %d to %d"%(band+1,line,line+line_max,sample,sample+samp_max)

            U = U - u_mean
            V = V - v_mean

            U = U.flatten()
            V = V.flatten()
            h = h.flatten()
            try:
                X, Y = dps.findGerFileLocationPreLoadFiles(U, V, h, a_x_min, a_y_min, a_x_max, a_y_max, x_mean, y_mean,
                                                           u_mean,
                                                           v_mean, hmin, hmax, "MS", in_file_name, beg_line,
                                                           current_date,
                                                           utc_gps, dut1, (x2_up_left, y2_up_left, dx2, dy2, zonec),
                                                           im_width, im_height, sat_pos, captured_time, sat_att,
                                                           band=band + 1)
            except:
                np.save(in_file_name + "band_%d_U_%d.npy" % (band + 1, beg_line), U)
                np.save(in_file_name + "band_%d_V_%d.npy" % (band + 1, beg_line), V)
                np.save(in_file_name + "band_%d_h_%d.npy" % (band + 1, beg_line), h)
                np.save(in_file_name + "band_%d_axmin_%d.npy" % (band + 1, beg_line), a_x_min)
                np.save(in_file_name + "band_%d_aymin_%d.npy" % (band + 1, beg_line), a_y_min)
                np.save(in_file_name + "band_%d_axmax_%d.npy" % (band + 1, beg_line), a_x_max)
                np.save(in_file_name + "band_%d_aymax_%d.npy" % (band + 1, beg_line), a_y_max)
                np.save(in_file_name + "band_%d_x_mean_y_mean_%d.npy" % (band + 1, beg_line),
                        np.array([x_mean, y_mean]))
                np.save(in_file_name + "band_%d_u_mean_v_mean_%d.npy" % (band + 1, beg_line),
                        np.array([u_mean, v_mean]))
                np.save(in_file_name + "band_%d_hminmax_%d.npy" % (band + 1, beg_line),
                        np.array([hmin, hmax]))
                print "filename", in_file_name
                print "Line:", beg_line
                print "data", current_date
                print "utc_gps", utc_gps
                print "dut1", dut1
                print "mapInfo", [x2_up_left, y2_up_left, dx2, dy2, zonec]
                np.save(in_file_name + "band_%d_cap_time_%d.npy" % (band + 1, beg_line), captured_time)
                np.save(in_file_name + "band_%d_sat_pos_%d.npy" % (band + 1, beg_line), sat_pos)
                np.save(in_file_name + "band_%d_sat_att_%d.npy" % (band + 1, beg_line), sat_att)
                exit()

            Xmin = int(X.min())
            Xmax = int(np.ceil(X.max()))
            Ymin = int(Y.min())
            Ymax = int(np.ceil(Y.max()))
            strx = int(max(Xmin, 0))
            stpx = min(Xmax + 1, im_width)

            stry = max(Ymin, 0)
            stpy = min(Ymax + 1, im_height)

            # print "[%d] Used the data from (%d,%d)->(%d,%d)"%(band+1,strx,stry,stpx,stpy)
            # maskxy = np.zero_like(U,'uint8')
            x_file_name = None
            y_file_name = None
            # print "Before:", mask_data[line:line+line_max,sample:sample+samp_max].max(), mask_data[line:line+line_max,sample:sample+samp_max].min()
            if (strx < stpx) & (stry < stpy):
                # original = databand[stry:stpy,strx:stpx]
                tr, tc = temp.shape
                X = X.astype('float32')
                Y = Y.astype('float32')
                # remap_out = cv2.remap(original,X-strx,Y-stry,cv2.INTER_CUBIC,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
                # print remap_out.shape
                # print temp[(X>=X.min())*(X<=X.max())*(Y>=Y.min())*(Y<=Y.max())].shape
                X = X.reshape(tr, tc)
                Y = Y.reshape(tr, tc)
                # temp[(X>=X.min())*(X<=X.max())*(Y>=Y.min())*(Y<=Y.max())] = remap_out.flatten()
                maskxy = (X >= 0) * (Y >= 0) * (X <= im_width - 1) * (Y <= im_height - 1)
                xout = X.copy()
                yout = Y.copy()
                if (line == 0) & (sample == 0):
                    # outimage_data = temp
                    maskxy = maskxy


                elif (line == 0):
                    # outimage_data = temp[:,off_set:]
                    maskxy = maskxy[:, off_set:]
                    xout = xout[:, off_set:]
                    yout = yout[:, off_set:]


                elif (sample == 0):
                    # outimage_data = temp[off_set:,:]
                    maskxy = maskxy[off_set:, :]
                    xout = xout[off_set:, :]
                    yout = yout[off_set:, :]
                else:
                    # outimage_data = temp[off_set:,off_set:]
                    maskxy = maskxy[off_set:, off_set:]
                    xout = xout[off_set:, off_set:]
                    yout = yout[off_set:, off_set:]

                x_file_name = in_file_name + "X_Band%d_Line%d_Sample%d.npy" % (band + 1, line, sample)
                y_file_name = in_file_name + "Y_Band%d_Line%d_Sample%d.npy" % (band + 1, line, sample)
                np.save(x_file_name, xout)
                np.save(y_file_name, yout)
                # block_info_filep.writelines("%d, %d, %d, %d"%(line, sample, line_max, samp_max))
            band_map_info.append([line, sample, line_max, samp_max, x_file_name, y_file_name])

            print ".....done!"
    first_band = False
    band_map_info_array = np.array(band_map_info)
    np.save(in_file_name + "_map_info_band_%d.npy" % (band + 1), band_map_info_array)
    # image_map_info.append(band_map_info)
    return band_map_info_array


def remapImageBandGridMethod(xb, yb, x3, y3, line_str, sample_str, block_size, im_width, im_height, offset_min,
                             max_error=0.1):

    end_line = min(line_str + block_size, im_height)
    end_sample = min(sample_str + block_size, im_width)
    print "working on line:%d to %d and sample: %d to %d" % (line_str, end_line, sample_str, end_sample)
    block_height = end_line - line_str
    block_width = end_sample - sample_str
    out_x = np.zeros((block_height, block_width), 'float32')
    out_y = np.zeros((block_height, block_width), 'float32')
    mask = np.ones((block_height, block_width), 'uint8')
    idx = np.nonzero((x3 >= sample_str) * (x3 < end_sample) * (y3 >= line_str) * (y3 < end_line))[0]
    u = x3[idx]
    v = y3[idx]
    num_samples = u.size
    mid_sample = np.median(u)
    mid_line = np.median(v)
    ut = (u - mid_sample).astype('float64')
    vt = (v - mid_line).astype('float64')
    AA = np.zeros((num_samples, 12), 'float64')
    AA[:, 0] = 1.0
    AA[:, 1] = ut
    AA[:, 2] = vt
    AA[:, 3] = ut * vt
    AA[:, 4] = ut ** 2
    AA[:, 5] = vt ** 2
    AA[:, 6] = ut * vt * vt
    AA[:, 7] = vt * ut * ut
    AA[:, 8] = ut ** 3
    AA[:, 9] = vt ** 3
    AA[:, 10] = vt * ut ** 3
    AA[:, 11] = ut * vt ** 3
    x1 = xb[idx]
    y1 = yb[idx]
    b = x1 - mid_sample
    par_x1 = np.linalg.lstsq(AA, b)[0]
    errx1 = (np.abs(np.dot(AA, par_x1) - b).max())
    print "max error column: %f" % errx1

    b = y1 - mid_line
    par_y1 = np.linalg.lstsq(AA, b)[0]
    erry1 = (np.abs(np.dot(AA, par_y1) - b).max())
    print "max error row: %f" % erry1
    if ((errx1 > max_error) or (erry1 > max_error)) and (block_size > 500):
        new_block_size = max(block_size / 2, 500)
        for sub_line in range(line_str, end_line, new_block_size):
            for sub_sample in range(sample_str, end_sample, new_block_size):

                lstr = sub_line - line_str
                sstr = sub_sample - sample_str
                sub_block_line_end = min(sub_line + new_block_size, end_line)
                sub_block_sample_end = min(sub_sample + new_block_size, end_sample)
                sub_out_x, sub_out_y, sub_mask = remapImageBandGridMethod(xb, yb, x3, y3, sub_line, sub_sample,
                                                                 new_block_size, im_width, im_height, offset_min,
                                                                 max_error)

                # sub_out_x, sub_out_y, sub_mask = remapImageBandGridMethod( xb, yb, x3, y3, sub_line, sub_sample,
                #                                                  new_block_size, im_width,im_height, offset_min,
                #                                                  block_offset, max_error)
                sub_block_line_end -= line_str
                sub_block_sample_end -= sample_str
                print lstr, sstr, sub_block_line_end, sub_block_sample_end
                w = sub_block_sample_end - sstr
                h = sub_block_line_end - lstr
                out_x[lstr:sub_block_line_end, sstr: sub_block_sample_end] = sub_out_x[:h, :w]
                out_y[lstr:sub_block_line_end, sstr: sub_block_sample_end] = sub_out_y[:h, :w]
                mask[lstr:sub_block_line_end, sstr: sub_block_sample_end] = sub_mask[:h, :w]
    else:
        bline = line_str
        bsample = sample_str
        V, U = np.mgrid[bline:bline + block_height, bsample:bsample + block_width]

        # if (bline == 0) & (bsample == 0):
        #     V, U = np.mgrid[0:block_height, 0:block_width]
        #     #sub_mask = mask[0:block_height, 0:block_width]
        # elif (bline == 0) & (bsample > 0):
        #     V, U = np.mgrid[0:block_height, bsample - block_offset:bsample + block_width]
        #     #sub_mask = mask[0:block_height, bsample - block_offset:bsample + block_width]
        # elif (bline > 0) & (bsample == 0):
        #     V, U = np.mgrid[bline - block_offset:bline + block_height, 0:block_width]
        #     #sub_mask = mask[bline - block_offset:bline + block_height, 0:block_width]
        # else:
        #     V, U = np.mgrid[bline - block_offset:bline + block_height,
        #            bsample - block_offset:bsample + block_width]
            # sub_mask = mask[bline - block_offset:bline + block_height,
            #           bsample - block_offset:bsample + block_width]
        sub_mask = np.ones_like(U, "uint8")
        mskh, mskw = sub_mask.shape
        u1d = U.flatten()
        v1d = V.flatten()
        num_pairs = u1d.size
        A = np.zeros((num_pairs, 12))
        ut = (u1d - mid_sample).astype('float64')
        vt = (v1d - mid_line).astype('float64')
        A[:, 0] = 1.0
        A[:, 1] = ut
        A[:, 2] = vt
        A[:, 3] = ut * vt
        A[:, 4] = ut ** 2
        A[:, 5] = vt ** 2
        A[:, 6] = ut * vt * vt
        A[:, 7] = vt * ut * ut
        A[:, 8] = ut ** 3
        A[:, 9] = vt ** 3
        A[:, 10] = vt * ut ** 3
        A[:, 11] = ut * vt ** 3
        sub_mask = sub_mask.flatten()

        x = np.dot(A, par_x1) + mid_sample + 1
        y = np.dot(A, par_y1) + mid_line - offset_min
        x = x.astype('float32')
        y = y.astype('float32')
        out_x = x.reshape(U.shape)
        out_y = y.reshape(U.shape)
        idx = np.nonzero((x < 0))[0]
        sub_mask[idx] = 0
        idx = np.nonzero((x > im_width - 1))[0]
        sub_mask[idx] = 0
        # mask[y > im_height-1, x > im_width-1] = 0

        sub_mask = sub_mask.reshape(U.shape)
        out_x = out_x
        out_y = out_y
        mask = sub_mask
        # if (bline == 0) & (bsample == 0):
        #     out_x = out_x
        #     out_y = out_y
        #     mask = sub_mask
        # elif (bline == 0):
        #     out_x = out_x[:, block_offset:]
        #     out_y = out_y[:, block_offset:]
        #     mask = sub_mask[:, block_offset:]
        # elif (bsample == 0):
        #     out_x = out_x[block_offset:, :]
        #     out_y = out_y[block_offset:, :]
        #     mask = sub_mask[block_offset:, :]
        # else:
        #     out_x = out_x[block_offset:, block_offset:]
        #     out_y = out_y[block_offset:, block_offset:]
        #     #outimage = remap_im[block_offset:, block_offset:]
        #     mask = sub_mask[block_offset:, block_offset:]

        # mask = sub_mask.reshape((mskh, mskw))



    return out_x, out_y, mask

def makingDEMData(dem_file_name, lv_width, lv_height, map_geotransform, dem,
                   dem_interpolation_method):

    gtiffDriver = gdal.GetDriverByName('GTiff')


    dem_ds_im = gtiffDriver.Create(dem_file_name, lv_width, lv_height, 1, gdal.GDT_Float32)
    dem_ds = dem_ds_im.GetRasterBand(1)
    mem = psutil.virtual_memory()
    mem_available = mem.available
    if dem_interpolation_method != "rbf":
        max_num_pixels_dem = (mem_available - 1024 * 1024 * 1024) / (
        (200) * 8)  # 400 memory block per pixels and 8 for double
    else:
        max_num_pixels_dem = 100 ** 2
    block_num_lines = int(np.sqrt(max_num_pixels_dem))
    block_num_pixels = block_num_lines
    off_set = 10
    block_num_lines2 = block_num_lines + off_set
    block_num_pixels2 = block_num_pixels + off_set
    for line in range(0, lv_height, block_num_lines):
        for sample in range(0, lv_width, block_num_pixels):
            line_max = min((lv_height - line), block_num_lines2)
            samp_max = min(lv_width - sample, block_num_pixels2)
            if (line == 0) & (sample == 0):
                V, U = np.mgrid[0:int(line_max), 0:int(samp_max)]
            elif (line == 0) & (sample > 0):
                V, U = np.mgrid[0:int(line_max), sample - off_set:int(samp_max + sample)]
            elif (line > 0) & (sample == 0):

                V, U = np.mgrid[line - off_set:int(line_max + line), 0:int(samp_max)]
            else:
                V, U = np.mgrid[line - off_set:int(line_max + line), sample - off_set:int(samp_max + sample)]
            x2_up_left, y2_up_left, dx2, dy2, zonec, zoneletter_c = map_geotransform
            u_earth = U * dx2 + x2_up_left
            v_earth = V * dy2 + y2_up_left
            late, lone = utmLatlon.to_latlon(u_earth, v_earth, zonec, zoneletter_c)

            # h = util.determineHeight(late,lone,dem_directory)
            latem = int(np.round(late.mean()))
            lonem = int(np.round(lone.mean()))
            dem_temp = None
            print "[DEM]  coord:", late.min(), late.max(), lone.min(), lone.max()
            h = dem.interpolate(late, lone, interpolation_method=dem_interpolation_method)
            ofx = off_set * (sample != 0)
            ofy = off_set * (line != 0)
            dem_out = h[ofy:, ofx:].astype('float64')
            print "sample:%d, line:%d" % (sample, line), h.shape
            dem_ds.WriteArray(dem_out, sample, line)
    dem_ds_im = None

def readDataBand(gdalband , sample, line, width, height, gain, dark_curr, gain_numbers, im_type):

    pixels = np.arange(sample, sample + width).reshape((1, width))
    y_min = line
    im_data = gdalband.ReadAsArray(sample, line, width, height)

    if im_type == "PAN":
        nlines = gain_numbers.shape[0]
        glo = gain_numbers[:, 0].reshape((nlines, 1))
        gle = gain_numbers[:, 1].reshape((nlines, 1))
        gro = gain_numbers[:, 2].reshape((nlines, 1))
        gre = gain_numbers[:, 3].reshape((nlines, 1))
        gns = glo[y_min:(y_min + height), :] * (pixels < 6000) * (pixels % 2 == 0) + \
              gle[y_min:(y_min + height), :] * (pixels < 6000) * (pixels % 2 == 1) + \
              gro[y_min:(y_min + height), :] * (pixels >= 6000) * (pixels % 2 == 0) + \
              gre[y_min:(y_min + height), :] * (pixels >= 6000) * (pixels % 2 == 1)
    elif im_type == "MS":
        nlines = gain_numbers.shape[0]
        g = gain_numbers.reshape((nlines, 1))
        gns = np.repeat(g[y_min:(y_min + height), :], width, 1)
    pix_gain = np.zeros_like(im_data, 'float32')
    pix_drk = np.zeros_like(im_data, 'float32')
    for idg in range(len(gain)):
        pix_gain = pix_gain + (gns == (idg)) * gain[idg][pixels]
        pix_drk = pix_drk + (gns == (idg)) * dark_curr[idg][pixels]
    # print gain[2][pixels], pix_gain, pix_gain.min(), pix_gain.max()
    # print np.nonzero(pix_gain == 0.0)
    # pix_gain = gain[gns]
    # pix_drk = dark_cur[gns]
    im_data = im_data.astype('float32')
    im_data = (im_data - pix_drk) / pix_gain
    im_data = im_data.astype('float32')
    return im_data

def buildMS2AImageUsingCubicInterpolation(out_file_name, in_file_name, lines, current_date, utc_gps, dut1, dem,
                                          gain, dark_curr, start_sample=1, im_width=6000, im_height=6000, save_dem=True,
                                          dem_interpolation_method=demserice.digitalElevationModel.CUBIC, save_pixel_mapping=False):

    # im_width = 6000

    end_sample = start_sample + im_width - 1
    if (end_sample > 6000) or (start_sample < 1) :
        print "The intended sample is beyond the scope of the recorded GER file."

    line = lines[2]  # Get line for band #3

    # Get All 4 Tie points
    latc, lonc, heightc = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name,
                                                                    np.array([(end_sample + start_sample) / 2]),
                                                                    np.array([line + im_height / 2]), current_date,
                                                                    utc_gps, dut1, dem, dem_interpolation_method, band=3)
    # = dps.findInterSectionPoint("MS",in_file_name,end_sample/2,line+im_height/2,current_date,utc_gps,dut1,dem_directory)
    xc, yc, zonec, zoneletter = utm.from_latlon(latc, lonc)
    latul, lonul, heightul = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name, np.array([start_sample]),
                                                                    [line], current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method, band=3)

    xul, yul, zoneul, zoneletter = utm.from_latlon(latul, lonul, zonec)
    print "original image upper left UTM:", xul, yul

    latur, lonur, heightur = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name, np.array([end_sample]),
                                                                    [line], current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method, band=3)
    xur, yur, zoneur, zoneletter = utm.from_latlon(latur, lonur, zonec)
    print "original image upper right UTM:", xur, yur
    latll, lonll, heightll = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name, np.array([start_sample]),
                                                                    [line + im_height], current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method, band=3)
    xllc, yllc, zonell, zoneletter = utm.from_latlon(latll, lonll, zonec)
    print "original image lower left UTM:", xllc, yllc

    latlr, lonlr, heightlr = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name, np.array([end_sample]),
                                                                    [line + im_height], current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method, band=3)
    xlr, ylr, zonelr, zoneletter_c = utm.from_latlon(latlr, lonlr, zonec)
    print "original image lower right UTM:", xlr, ylr
    print "original image center UTM:", xc, yc




    num_lines = np.ceil((yul - ylr) / 15.0 + 1)
    num_samples = np.ceil((xur - xllc) / 15.0 + 1)
    lv_width = int(np.ceil(num_samples))
    lv_height = int(np.ceil(num_lines))


    print "The level 2A image has a size of %d x %d  pixels" % (lv_width, lv_height)
    # determine the mapping function.
    x2_up_left = xllc
    y2_up_left = yul
    dx2 = 15.0
    dy2 = -15.0
    map_geo_trans = [x2_up_left, y2_up_left, dx2, dy2, zonec, zoneletter_c]

    upleft_lat_lon = [latul + 30. / 3600., lonll - 30 / 3600.]
    lowright_lat_lon = [latlr - 30 / 3600., lonur + 30 / 3600.]
    latgrid, longrid, hgrid = dem.getValuesFromRetangularArea(latul, lonll, latlr, lonur)  # util.load_dem_data(upleft_lat_lon,lowright_lat_lon,dem_directory)
    # dem_temp = util.load_dem_file(13,100,dem_directory)
    # pixel_size = dem_temp.GetGeoTransform()[1]/3600.
    hmin = hgrid.min()
    hmax = hgrid.max()
    print "The Minimum and maximum altitudes of the scene are %f and %f meters, respectively." % (hmin, hmax)

    num_samples_per_line = im_width / 50  # Defualt is 50 sample grids # Smaller is faster, but less accurate
    step_sample = im_width / num_samples_per_line
    step_line = im_height / num_samples_per_line
    num_pairs = (im_height / step_line + 1) * (im_width / step_sample + 1)


    print "Load data from ger files!"

    posB1 = np.loadtxt(in_file_name + "B1.pos")
    posB2 = np.loadtxt(in_file_name + "B2.pos")
    posB3f = np.loadtxt(in_file_name + "B3.pos")
    posB4 = np.loadtxt(in_file_name + "B4.pos")
    sat_pos = [posB1, posB2, posB3f, posB4]

    timeB1 = np.loadtxt(in_file_name + "B1.tim")
    timeB2 = np.loadtxt(in_file_name + "B2.tim")
    timeB3f = np.loadtxt(in_file_name + "B3.tim")
    timeB4 = np.loadtxt(in_file_name + "B4.tim")

    sat_time = [timeB1, timeB2, timeB3f, timeB4]

    attB1 = np.loadtxt(in_file_name + "B1.att")
    attB2 = np.loadtxt(in_file_name + "B2.att")
    attB3f = np.loadtxt(in_file_name + "B3.att")
    attB4 = np.loadtxt(in_file_name + "B4.att")
    sat_att = [attB1, attB2, attB3f, attB4]

    band1 = gdal.Open(in_file_name + "B1.tif")
    band2 = gdal.Open(in_file_name + "B2.tif")
    band3 = gdal.Open(in_file_name + "B3.tif")
    band4 = gdal.Open(in_file_name + "B4.tif")
    data_height = band1.RasterYSize
    sample_step_size = 50
    max_width = 6000
    offsetm = 100
    offset_min1 = max(-offsetm, 1 - lines[0])
    offset_max1 = min(offsetm, data_height - lines[0] - im_height)

    offset_min2 = max(-offsetm, 1 - lines[1])
    offset_max2 = min(offsetm, data_height - lines[1] - im_height)

    offset_min3 = max(-offsetm, 1 - lines[2])
    offset_max3 = min(offsetm, data_height - lines[2] - im_height)

    offset_min4 = max(-offsetm, 1 - lines[3])
    offset_max4 = min(offsetm, data_height - lines[3] - im_height)
    gain_number = np.loadtxt(in_file_name + "B1.gain")
    databand1 = readDataBand(band1, 0, lines[0] - 1 + offset_min1, max_width, offset_max1 - offset_min1 + im_height,
                             gain[0], dark_curr[0], gain_number, im_type="MS")
    # band1.ReadAsArray(0, lines[0] -1 + offset_min1, max_width, offset_max1 - offset_min1 + im_height)
    gain_number = np.loadtxt(in_file_name + "B2.gain")
    databand2 = readDataBand(band2, 0, lines[1] - 1 + offset_min2, max_width, offset_max2 - offset_min2 + im_height,
                             gain[1], dark_curr[1], gain_number, im_type="MS")  # band2.ReadAsArray(0, lines[1] -1 + offset_min2, max_width, offset_max2 - offset_min2 + im_height)
    gain_number = np.loadtxt(in_file_name + "B3.gain")
    databand3 = readDataBand(band3, 0, lines[2] - 1 , max_width, im_height,
                             gain[2], dark_curr[2], gain_number, im_type="MS")  # band3.ReadAsArray(0, lines[2] -1, max_width, im_height)

    gain_number = np.loadtxt(in_file_name + "B4.gain")
    databand4 = readDataBand(band4, 0, lines[3] - 1 + offset_min4, max_width, offset_max4 - offset_min4 + im_height,
                             gain[3], dark_curr[3], gain_number, im_type="MS")  # band4.ReadAsArray(0, lines[3] -1 + offset_min4, max_width, offset_max4 - offset_min4 + im_height)
    image_data = [databand1, databand2, databand3, databand4]
    offset_mins = [offset_min1, offset_min2, offset_min3, offset_min4]

    print "All data has beeen loaded."
    print "Check for existing Band1, Band2 and Band4 to Band3 tie points!"

    all_map_file_exist = True


    for band in [1, 2, 3, 4]:
        all_map_file_exist = all_map_file_exist  and os.path.isfile(in_file_name + "x_b%d_Line%d.txt" % (band, lines[2]))


    sample_step_size = 50  # THEOS defaul value is 50 points

    if (not all_map_file_exist):

        print "They do not exist. Attempts to compute them."


        x1, x2, x3, x4, y1, y2, y3, y4 = findSamplesPoints(in_file_name, sample_step_size, lines, sat_pos, sat_time,
                                                              sat_att, image_data, offset_mins, current_date, utc_gps,
                                                              dut1, dem, dem_interpolation_method, im_width, im_height)
        print "Successful... Save them for later use."

        np.save(in_file_name + "x_b1_Line%d.npy" % lines[2], x1)
        np.save(in_file_name + "x_b2_Line%d.npy" % lines[2], x2)
        np.save(in_file_name + "x_b3_Line%d.npy" % lines[2], x3)
        np.save(in_file_name + "x_b4_Line%d.npy" % lines[2], x4)

        np.save(in_file_name + "y_b1_Line%d.npy" % lines[2], y1)
        np.save(in_file_name + "y_b2_Line%d.npy" % lines[2], y2)
        np.save(in_file_name + "y_b3_Line%d.npy" % lines[2], y3)
        np.save(in_file_name + "y_b4_Line%d.npy" % lines[2], y4)

        np.savetxt(in_file_name + "x_b1_Line%d.txt" % lines[2], x1)
        np.savetxt(in_file_name + "x_b2_Line%d.txt" % lines[2], x2)
        np.savetxt(in_file_name + "x_b3_Line%d.txt" % lines[2], x3)
        np.savetxt(in_file_name + "x_b4_Line%d.txt" % lines[2], x4)

        np.savetxt(in_file_name + "y_b1_Line%d.txt" % lines[2], y1)
        np.savetxt(in_file_name + "y_b2_Line%d.txt" % lines[2], y2)
        np.savetxt(in_file_name + "y_b3_Line%d.txt" % lines[2], y3)
        np.savetxt(in_file_name + "y_b4_Line%d.txt" % lines[2], y4)
    else:

        x1 = np.loadtxt(in_file_name + "x_b1_Line%d.txt" % lines[2])
        x2 = np.loadtxt(in_file_name + "x_b2_Line%d.txt" % lines[2])
        x3 = np.loadtxt(in_file_name + "x_b3_Line%d.txt" % lines[2])
        x4 = np.loadtxt(in_file_name + "x_b4_Line%d.txt" % lines[2])

        y1 = np.loadtxt(in_file_name + "y_b1_Line%d.txt" % lines[2])
        y2 = np.loadtxt(in_file_name + "y_b2_Line%d.txt" % lines[2])
        y3 = np.loadtxt(in_file_name + "y_b3_Line%d.txt" % lines[2])
        y4 = np.loadtxt(in_file_name + "y_b4_Line%d.txt" % lines[2])


    print "Check for existing LV1->LV2 tie points database."
    all_map_file_exist = True
    all_map_file_exist = all_map_file_exist  and os.path.isfile(in_file_name + "ger_pair_line%d.txt" % (lines[2]))
    all_map_file_exist = all_map_file_exist and os.path.isfile(in_file_name + "B3lv2_pair_min_line%d.txt" % (lines[2]))
    all_map_file_exist = all_map_file_exist and os.path.isfile(in_file_name + "B3lv2_pair_max_line%d.txt" % (lines[2]))

    if all_map_file_exist:
        print "Find them. Loadind the tie points."
        ger_pairs = np.loadtxt(in_file_name + "ger_pair_line%d.txt" % (lines[2]))
        lv2_pairs_min = np.loadtxt(in_file_name + "B3lv2_pair_min_line%d.txt" % (lines[2]))
        lv2_pairs_max = np.loadtxt(in_file_name + "B3lv2_pair_max_line%d.txt" % (lines[2]))
    else:
        print "The matching pair files LV1->LV2 have not been created."
        print "Generating the matching pair database."
        x_sampels = np.hstack((np.arange(0, im_width, step_sample), np.array([im_width - 1])))
        y_sampels = np.hstack((np.arange(0, im_height, step_line), np.array([im_height - 1])))
        ger_pairs = np.zeros((num_pairs, 2))
        cnt = 0
        lv2_pairs_min = np.zeros((num_pairs, 2))
        lv2_pairs_max = np.zeros((num_pairs, 2))
        for s_line in y_sampels:
            print "find matching pairs of line %d" % s_line
            s_samples = x_sampels
            lata_min, lona_min, ha = dps.findInterSectionPointArrayGivenAltitude("MS", in_file_name, s_samples,
                                                                               [lines[2] + s_line], hmin, current_date,
                                                                               utc_gps, dut1, band=3)
            lata_max, lona_max, ha = dps.findInterSectionPointArrayGivenAltitude("MS", in_file_name, s_samples,
                                                                               [lines[2] + s_line], hmax, current_date,
                                                                               utc_gps, dut1, band=3)
            num_s = s_samples.shape[0]
            x, y, z, zl = utmLatlon.from_latlon(lata_min, lona_min, zonec)
            cols = (x - x2_up_left) / dx2
            rows = (y - y2_up_left) / dy2
            str = cnt * num_s
            stp = str + num_s
            lv2_pairs_min[str:stp, 0] = cols
            lv2_pairs_min[str:stp, 1] = rows

            x, y, z, zl = utmLatlon.from_latlon(lata_max, lona_max, zonec)
            cols = (x - x2_up_left) / dx2
            rows = (y - y2_up_left) / dy2

            lv2_pairs_max[str:stp, 0] = cols
            lv2_pairs_max[str:stp, 1] = rows

            ger_pairs[str:stp, 0] = s_samples
            ger_pairs[str:stp, 1] = s_line
            cnt += 1
            # lv2_pair_min_list.append(lv2_pairs_min)
            # lv2_pair_max_list.append(lv2_pairs_max)
        print "completed...saving to files."
        np.savetxt(in_file_name + "B3lv2_pair_min_line%d.txt" % (lines[2]), lv2_pairs_min)
        np.savetxt(in_file_name + "B3lv2_pair_max_line%d.txt" % (lines[2]), lv2_pairs_max)
        np.savetxt(in_file_name + "ger_pair_line%d.txt" % (lines[2]), ger_pairs)






    dem_file_name = in_file_name + "DEM_%d.tif" % lines[2]
    if  not os.path.isfile(dem_file_name):
        print "DEM file do not exist. Interpolate DEM for the LV2 Scene"
        makingDEMData(dem_file_name, lv_width, lv_height, map_geo_trans, dem,
                      dem_interpolation_method=dem_interpolation_method)
    else:
        print "DEM File Exist. LOAD DEM FILE."

    dem_ds_im = gdal.Open(dem_file_name)
    dem_ds = dem_ds_im.GetRasterBand(1)



    lv2_geotrans = [x2_up_left, y2_up_left, dx2, dy2, zonec]
    print "Creating the LV2->LV1 Mapping files"
    band_map_info = findLV2RemapFuncitionBand3WithInterpolation(in_file_name, lines[2], ger_pairs, lv2_pairs_min, lv2_pairs_max,
                                              lv2_geotrans, dem_ds, hmin, hmax, current_date, utc_gps, dut1,
                                              lv_width, lv_height, im_width, im_height)
    print "Completed!"

    print "We are ready to build LV2 Image."
    gtiffDriver = gdal.GetDriverByName("GTiff")
    dst_ds = gtiffDriver.Create(out_file_name, lv_width, lv_height, 4, gdal.GDT_Byte)

    mask_data = np.zeros((lv_height, lv_width), 'uint8')

    print "We work with band 3 first!"
    band3 = dst_ds.GetRasterBand(1)
    ms_band_data = np.zeros((lv_height, lv_width), 'uint8')
    lev1_im = np.zeros((im_height, im_width, 3), 'uint8')
    lev1_im[:, :, 2] = image_data[2]

    for line, sample, line_max, samp_max, x_file_name, y_file_name in band_map_info:
        databand = image_data[2]
        if (x_file_name is not None) and (y_file_name is not None):
            X = np.load(x_file_name)
            Y = np.load(y_file_name)
            Xmin = int(X.min())
            Xmax = int(np.ceil(X.max()))
            Ymin = int(Y.min())
            Ymax = int(np.ceil(Y.max()))
            strx = int(max(Xmin, 0))
            stpx = min(Xmax + 1, im_width)
            stry = max(Ymin, 0)
            stpy = min(Ymax + 1, im_height)
            temp = np.zeros_like(X)
            if (strx < stpx) & (stry < stpy):
                original = databand[stry:stpy, strx:stpx]
                remap_out = cv2.remap(original, X - strx, Y - stry, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                      borderValue=0)
                temp[(X >= X.min()) * (X <= X.max()) * (Y >= Y.min()) * (Y <= Y.max())] = remap_out.flatten()
                temp = 1 * (temp < 1) + 255 * (temp > 254.8) + temp * (temp >= 1) * (temp <= 254.8)
                temp = np.round(temp)
                ms_band_data[line:line + line_max, sample:sample + samp_max] = temp
                # band3.WriteArray(sample, line, ms_band_data)
                mk = (X > 0) * (X < im_width) * (Y > 0) * (Y < im_height)

                mask_data[line:line + line_max, sample:sample + samp_max] = mk
        else:
            mask_data[line:line + line_max, sample:sample + samp_max] *= 0
    band3.WriteArray(ms_band_data)
    block_size = im_width
    for band in [1, 2 , 4]:
        if band == 1:
            band_src = dst_ds.GetRasterBand(3)
        elif band == 3:
            band_src = dst_ds.GetRasterBand(1)
        else:
            band_src = dst_ds.GetRasterBand(band)

        databand = image_data[band - 1]  # band_src.ReadAsArray(0,offset_mins[band-1]+lines[band-1],
        #                        #        im_width,im_height+offmax[band-1]-offsetlows[band-1])
        ms_band_data = np.zeros((lv_height, lv_width), 'uint8')
        mask_band = np.zeros((lv_height, lv_width), 'uint8')
        max_height = im_height

        # tempf = np.load(in_file_name+"_map_info_band_%d.npy"%band)
        if band == 1:
            remap_x, remap_y, mask = remapImageBandGridMethod(x1, y1, x3, y3, 0, 0, block_size, im_width, im_height, offset_min1, max_error=0.1)
                             # block_offset, max_error=0.1)
            outbb = cv2.remap(image_data[0], remap_x, remap_y, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                          borderValue=0)
            lev1_im[:, :, 0] = outbb
        elif band == 2:
            remap_x, remap_y, mask = remapImageBandGridMethod(x2, y2, x3, y3, 0, 0, block_size, im_width, im_height, offset_min2, max_error=0.1)
                                                  # block_offset, max_error=0.1)
            outbb = cv2.remap(image_data[1], remap_x, remap_y, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                              borderValue=0)
            lev1_im[:, :, 1] = outbb
        elif band == 4:
            remap_x, remap_y, mask = remapImageBandGridMethod(x4, y4, x3, y3, 0, 0, block_size, im_width, im_height, offset_min4, max_error=0.1)
                                                  # block_offset, max_error=0.1)

        for line, sample, line_max, samp_max, x_file_name, y_file_name in band_map_info:
            if (x_file_name is not None) and (y_file_name is not None):
                U = np.load(x_file_name)
                V = np.load(y_file_name)
                U1d = U.flatten()
                V1d = V.flatten()
                X = np.zeros_like(U1d) - 1000
                Y = np.zeros_like(U1d) - 1000
                maskls = np.zeros_like(U1d, 'uint8')
                # Inside
                valid_pixel = np.nonzero((U1d > 0) * (U1d < im_width - 1) * (V1d > 0) * (V1d < max_height - 1))[0]
                if len(valid_pixel) > 0:
                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    U1d_max = U1d_min + 1  # np.ceil(U1dvalid).astype('int')

                    V1d_min = np.floor(V1dvalid).astype('int')
                    V1d_max = V1d_min + 1  # np.ceil(V1dvalid).astype('int')
                    xll = remap_x[V1d_min, U1d_min]
                    xhl = remap_x[V1d_max, U1d_min]

                    xlh = remap_x[V1d_min, U1d_max]
                    xhh = remap_x[V1d_max, U1d_max]

                    yll = remap_y[V1d_min, U1d_min]
                    yhl = remap_y[V1d_max, U1d_min]

                    ylh = remap_y[V1d_min, U1d_max]
                    yhh = remap_y[V1d_max, U1d_max]
                    du = U1dvalid - U1d_min
                    dv = V1dvalid - V1d_min
                    xvalid = xll * (1 - du) * (1 - dv) + xhl * dv * (1 - du) + xlh * (1 - dv) * du + xhh * dv * du
                    yvalid = yll * (1 - du) * (1 - dv) + yhl * dv * (1 - du) + ylh * (1 - dv) * du + yhh * dv * du
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid

                # left_line
                valid_pixel = np.nonzero((U1d == 0) * (V1d > 0) * (V1d < max_height - 1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')

                    V1d_min = np.floor(V1dvalid).astype('int')
                    V1d_max = V1d_min + 1  # np.ceil(V1dvalid).astype('int')
                    xll = remap_x[V1d_min, U1d_min]
                    xhl = remap_x[V1d_max, U1d_min]
                    yll = remap_y[V1d_min, U1d_min]
                    yhl = remap_y[V1d_max, U1d_min]
                    dv = V1dvalid - V1d_min
                    xvalid = xll * (1 - dv) + xhl * dv
                    yvalid = yll * (1 - dv) + yhl * dv
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid

                # top line
                valid_pixel = np.nonzero((U1d > 0) * (U1d < im_width - 1) * (V1d == 0))[0]
                if len(valid_pixel) > 0:
                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    U1d_max = U1d_min + 1  # np.ceil(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')

                    xll = remap_x[V1d_min, U1d_min]

                    xlh = remap_x[V1d_min, U1d_max]

                    yll = remap_y[V1d_min, U1d_min]

                    ylh = remap_y[V1d_min, U1d_max]
                    du = U1dvalid - U1d_min

                    xvalid = xll * (1 - du) + xlh * du
                    yvalid = yll * (1 - du) + ylh * du
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # right line
                valid_pixel = np.nonzero((U1d == im_width - 1) * (V1d > 0) * (V1d < max_height - 1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_max = np.floor(U1dvalid).astype('int')

                    V1d_min = np.floor(V1dvalid).astype('int')
                    V1d_max = V1d_min + 1  # np.ceil(V1dvalid).astype('int')


                    xlh = remap_x[V1d_min, U1d_max]
                    xhh = remap_x[V1d_max, U1d_max]

                    ylh = remap_y[V1d_min, U1d_max]
                    yhh = remap_y[V1d_max, U1d_max]

                    dv = V1dvalid - V1d_min
                    xvalid = xlh * (1 - dv) + xhh * dv
                    yvalid = ylh * (1 - dv) + yhh * dv
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # buttom line
                valid_pixel = np.nonzero((U1d > 0) * (U1d < im_width - 1) * (V1d == max_height - 1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    U1d_max = U1d_min + 1  # np.ceil(U1dvalid).astype('int')


                    V1d_max = np.floor(V1dvalid).astype('int')

                    xhl = remap_x[V1d_max, U1d_min]
                    xhh = remap_x[V1d_max, U1d_max]
                    yhl = remap_y[V1d_max, U1d_min]
                    yhh = remap_y[V1d_max, U1d_max]
                    du = U1dvalid - U1d_min

                    xvalid = xhl * (1 - du) + xhh * du
                    yvalid = yhl * (1 - du) + yhh * du
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # upper left
                valid_pixel = np.nonzero((U1d == 0) * (V1d == 0))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')
                    xvalid = remap_x[V1d_min, U1d_min]
                    yvalid = remap_y[V1d_min, U1d_min]
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # upper right
                valid_pixel = np.nonzero((U1d == im_width - 1) * (V1d == 0))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')
                    xvalid = remap_x[V1d_min, U1d_min]
                    yvalid = remap_y[V1d_min, U1d_min]
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # bottom left
                valid_pixel = np.nonzero((U1d == 0) * (V1d == max_height - 1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')
                    xvalid = remap_x[V1d_min, U1d_min]
                    yvalid = remap_y[V1d_min, U1d_min]
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # bottom right
                valid_pixel = np.nonzero((U1d == im_width - 1) * (V1d == max_height - 1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')
                    xvalid = remap_x[V1d_min, U1d_min]
                    yvalid = remap_y[V1d_min, U1d_min]
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                mask_valid = np.nonzero((X > 0) * (X < im_width - 1) * (Y > 0) * (Y < databand.shape[0] - 1))[0]
                maskls[mask_valid] = 1
                X = X.reshape(U.shape)
                Y = Y.reshape(V.shape)

                Xmin = int(X.min())
                Xmax = int(np.ceil(X.max()))
                Ymin = int(Y.min())
                Ymax = int(np.ceil(Y.max()))
                strx = int(max(Xmin, 0))
                stpx = min(Xmax + 1, im_width)
                stry = max(Ymin, 0)
                stpy = min(Ymax + 1, databand.shape[0])
                temp = np.zeros_like(X)
                maskls = maskls.reshape(U.shape)
                if (strx < stpx) & (stry < stpy):
                    original = databand[stry:stpy, strx:stpx]
                    remap_out = cv2.remap(original, X - strx, Y - stry, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                          borderValue=0)
                    temp[(X >= X.min()) * (X <= X.max()) * (Y >= Y.min()) * (Y <= Y.max())] = remap_out.flatten()
                    temp = 1 * (temp < 1) + 255 * (temp > 254.8) + temp * (temp >= 1) * (temp <= 254.8)
                    temp = np.round(temp)
                    ms_band_data[line:line + line_max, sample:sample + samp_max] = temp
                    mask_band[line:line + line_max, sample:sample + samp_max] = maskls

                if band == 4:
                    os.remove(x_file_name)
                    os.remove(y_file_name)
            else:
                mask_band[line:line + line_max, sample:sample + samp_max] *= 0




        band_src.WriteArray(ms_band_data)
        mask_data *= mask_band

    # cv2.imwrite(r"D:\Data2APanSharpen\compar_last_scene\Gerald_42210_MS\level2a\lvl1.tif",lev1_im)
    print "There are %d pixels in the level 2A image with data." % (mask_data.sum())
    print "There are %d pixels in the level 2A that has been masked out." % ((mask_data == 0).sum())
    print "Saving Mask image."
    cv2.imwrite(in_file_name + "_mask.tif", mask_data * 255)
    print "Mask correction...."
    dst_ds = None
    dst_ds = gdal.Open(out_file_name, gdal.GA_Update)
    for band in [1, 2, 3, 4]:
        print "   correcting Band %d........." % band,
        if band == 1:
            bandk = dst_ds.GetRasterBand(3)
        elif band == 3:
            bandk = dst_ds.GetRasterBand(1)
        else:
            bandk = dst_ds.GetRasterBand(band)

        data_bandk = bandk.ReadAsArray()
        data_bandk *= mask_data
        bandk.WriteArray(data_bandk)
        print "done."
    print "Mask Correction completed!"

    print "done!"
    print "Compute the average elevation of the scene.............",
    avg_dem = 0.0
    num_nonzero_pixel = 0.0
    num_block_lines = 1000
    num_block_pixels = 1000
    for line in range(0, lv_height, num_block_lines):
        for sample in range(0, lv_width, num_block_pixels):
            line_max = min((lv_height - line), num_block_lines)
            samp_max = min(lv_width - sample, num_block_pixels)
            mask_sub = mask_data[line:(line + line_max), sample:(sample + samp_max)]
            num_nonzero_pixel += mask_sub.sum()
            h = dem_ds.ReadAsArray(sample, line, samp_max, line_max)
            avg_dem += (h * mask_sub.astype('float32')).sum()
    avg_dem /= num_nonzero_pixel
    print "done! The averaged elevation is: %f meters." % avg_dem

    print "Computing the vertices: "
    cl1 = np.round((xul - x2_up_left) / dx2) + 1
    rw1 = np.round((yul - y2_up_left) / dy2) + 1
    x1 = x2_up_left + dx2 * cl1
    y1 = y2_up_left + dy2 * rw1
    lat1, lon1 = utmLatlon.to_latlon(np.array([x1]), np.array([y1]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat1 = lat1[0]
    lon1 = lon1[0]

    cl2 = np.round((xur - x2_up_left) / dx2) + 1
    rw2 = np.round((yur - y2_up_left) / dy2) + 1
    x2 = x2_up_left + dx2 * cl2
    y2 = y2_up_left + dy2 * rw2
    lat2, lon2 = utmLatlon.to_latlon(np.array([x2]), np.array([y2]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat2 = lat2[0]
    lon2 = lon2[0]

    cl3 = np.round((xllc - x2_up_left) / dx2) + 1
    rw3 = np.round((yllc - y2_up_left) / dy2) + 1
    x3 = x2_up_left + dx2 * cl3
    y3 = y2_up_left + dy2 * rw3

    lat3, lon3 = utmLatlon.to_latlon(np.array([x3]), np.array([y3]), zonec, zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat3 = lat3[0]
    lon3 = lon3[0]
    cl4 = np.round((xlr - x2_up_left) / dx2) + 1
    rw4 = np.round((ylr - y2_up_left) / dy2) + 1
    x4 = x2_up_left + dx2 * cl4
    y4 = y2_up_left + dy2 * rw4
    lat4, lon4 = utmLatlon.to_latlon(np.array([x4]), np.array([y4]), zonec, zoneletter_c)
    lat4 = lat4[0]
    lon4 = lon4[0]
    cl5 = np.round((xc - x2_up_left) / dx2) + 1
    rw5 = np.round((yc - y2_up_left) / dy2) + 1
    x5 = x2_up_left + dx2 * cl5
    y5 = y2_up_left + dy2 * rw5
    lat5, lon5 = utmLatlon.to_latlon(np.array([x5]), np.array([y5]), zonec, zoneletter_c)
    lat5 = lat5[0]
    lon5 = lon5[0]
    print "Upper left vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw1, cl1)
    print "FRAME_X: %e, FRAME_COL: %e" % (x1, y1)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon1, lat1)
    print ".........................................................."

    print "Upper right vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw2, cl2)
    print "FRAME_X: %e, FRAME_COL: %e" % (x2, y2)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon2, lat2)
    print ".........................................................."

    print "Lower left vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw3, cl3)
    print "FRAME_X: %e, FRAME_COL: %e" % (x3, y3)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon3, lat3)
    print ".........................................................."

    print "Lower right vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw4, cl4)
    print "FRAME_X: %e, FRAME_COL: %e" % (x4, y4)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon4, lat4)
    print ".........................................................."

    print "Scene center.............................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw5, cl5)
    print "FRAME_X: %e, FRAME_COL: %e" % (x5, y5)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon5, lat5)
    print ".........................................................."
    dst_ds.SetGeoTransform([ x2_up_left, 15.0, 0, y2_up_left, 0, -15.0 ])

    srs = osr.SpatialReference()
    srs.SetWellKnownGeogCS("WGS84")
    if (lat5 >= 0) :
        srs.SetUTM(zonec, 1)
    else :
        srs.SetUTM(zonec, 0)

    dst_ds.SetProjection(srs.ExportToWkt())
    if save_dem:
        dem_ds_im.SetProjection(srs.ExportToWkt())

    upleft = [[cl1, rw1], [x1, y1], [lon1, lat1]]
    upright = [[cl2, rw2], [x2, y2], [lon2, lat2]]
    midpoint = [[cl5, rw5], [x5, y5], [lon5, lat5]]
    lowleft = [[cl3, rw3], [x3, y3], [lon3, lat3]]
    lowright = [[cl4, rw4], [x4, y4], [lon4, lat4]]
    map_info = [x2_up_left, y2_up_left, 15.0, 15.0, avg_dem, zonec, (lat5 >= 0)]
    return upleft, upright, midpoint, lowleft, lowright, map_info


def buildMS2AImageUsingCubicInterpolationWithOutSampling(out_file_name, in_file_name, lines, current_date, utc_gps, dut1, dem_directory,
                                          start_sample=1, im_width=6000, im_height=6000, save_dem=True,
                                          dem_interpolation_method="kriging", save_pixel_mapping=False):

    # im_width = 6000

    end_sample = start_sample + im_width - 1
    if (end_sample > 6000) or (start_sample < 1) :
        print "The intended sample is beyond the scope of the recorded GER file."

    line = lines[2]  # Get line for band #3

    latc, lonc, heightc = dps.findInterSectionPointArrayUsingKriging("MS", in_file_name,
                                                                    np.array([(end_sample + start_sample) / 2]),
                                                                    np.array([line + im_height / 2]), current_date,
                                                                    utc_gps, dut1, dem_directory)
    # = dps.findInterSectionPoint("MS",in_file_name,end_sample/2,line+im_height/2,current_date,utc_gps,dut1,dem_directory)
    xc, yc, zonec, zoneletter = utm.from_latlon(latc, lonc)
    latul, lonul, heightul = dps.findInterSectionPointArrayUsingKriging("MS", in_file_name, np.array([start_sample]),
                                                                        [line], current_date, utc_gps, dut1, dem_directory, band=3)

    xul, yul, zoneul, zoneletter = utm.from_latlon(latul, lonul, zonec)
    print "original image upper left UTM:", xul, yul

    latur, lonur, heightur = dps.findInterSectionPointArrayUsingKriging("MS", in_file_name, np.array([end_sample]),
                                                                        [line], current_date, utc_gps, dut1, dem_directory, band=3)
    xur, yur, zoneur, zoneletter = utm.from_latlon(latur, lonur, zonec)
    print "original image upper right UTM:", xur, yur
    latll, lonll, heightll = dps.findInterSectionPointArrayUsingKriging("MS", in_file_name, np.array([start_sample]),
                                                                        [line + im_height], current_date, utc_gps, dut1, dem_directory, band=3)
    xllc, yllc, zonell, zoneletter = utm.from_latlon(latll, lonll, zonec)
    print "original image lower left UTM:", xllc, yllc

    latlr, lonlr, heightlr = dps.findInterSectionPointArrayUsingKriging("MS", in_file_name, np.array([end_sample]),
                                                                        [line + im_height], current_date, utc_gps, dut1, dem_directory, band=3)
    xlr, ylr, zonelr, zoneletter_c = utm.from_latlon(latlr, lonlr, zonec)
    print "original image lower right UTM:", xlr, ylr

    print "original image center UTM:", xc, yc

    # hmin,hmax = util.findMinMaxHeight([latul,lonul],[latlr,lonlr],dem_directory)


    num_lines = np.ceil((yul - ylr) / 15.0 + 1)
    num_samples = np.ceil((xur - xllc) / 15.0 + 1)

    # determine the mapping function.
    x2_up_left = xllc
    y2_up_left = yul
    dx2 = 15.0
    dy2 = -15.0
    upleft_lat_lon = [latul + 30. / 3600., lonll - 30 / 3600.]
    lowright_lat_lon = [latlr - 30 / 3600., lonur + 30 / 3600.]
    latgrid, longrid, hgrid = util.load_dem_data(upleft_lat_lon, lowright_lat_lon, dem_directory)
    dem_temp = util.load_dem_file(13, 100, dem_directory)
    pixel_size = dem_temp.GetGeoTransform()[1] / 3600.
    hmin = hgrid.min()
    hmax = hgrid.max()
    print "The Minimum and maximum altitudes of the scene are %f and %f meters, respectively." % (hmin, hmax)

    num_samples_per_line = 100  # Smaller is faster, but less accurate
    step_sample = im_width / num_samples_per_line
    step_line = im_height / num_samples_per_line
    num_pairs = (im_height / step_line + 1) * (im_width / step_sample + 1)

    sample_step_size = 50
    posB1 = np.loadtxt(in_file_name + "B1.pos")
    posB2 = np.loadtxt(in_file_name + "B2.pos")
    posB3f = np.loadtxt(in_file_name + "B3.pos")
    posB4 = np.loadtxt(in_file_name + "B4.pos")
    sat_pos = [posB1, posB2, posB3f, posB4]

    timeB1 = np.loadtxt(in_file_name + "B1.tim")
    timeB2 = np.loadtxt(in_file_name + "B2.tim")
    timeB3f = np.loadtxt(in_file_name + "B3.tim")
    timeB4 = np.loadtxt(in_file_name + "B4.tim")

    sat_time = [timeB1, timeB2, timeB3f, timeB4]

    attB1 = np.loadtxt(in_file_name + "B1.att")
    attB2 = np.loadtxt(in_file_name + "B2.att")
    attB3f = np.loadtxt(in_file_name + "B3.att")
    attB4 = np.loadtxt(in_file_name + "B4.att")
    sat_att = [attB1, attB2, attB3f, attB4]

    band1 = gdal.Open(in_file_name + "B1.tif")
    band2 = gdal.Open(in_file_name + "B2.tif")
    band3 = gdal.Open(in_file_name + "B3.tif")
    band4 = gdal.Open(in_file_name + "B4.tif")
    data_height = band1.RasterYSize

    block_size = 1000
    block_offset = sample_step_size
    max_block_width = block_size + block_offset
    max_block_height = block_size + block_offset
    max_width = 6000
    min_line = min(lines)
    max_line = max(lines)
    offsetm = 100
    offset_min1 = max(-offsetm, 0 - lines[0])
    offset_max1 = min(offsetm, data_height - lines[0] - im_height)

    offset_min2 = max(-offsetm, 0 - lines[1])
    offset_max2 = min(offsetm, data_height - lines[1] - im_height)

    offset_min3 = max(-offsetm, 0 - lines[2])
    offset_max3 = min(offsetm, data_height - lines[2] - im_height)

    offset_min4 = max(-offsetm, 0 - lines[3])
    offset_max4 = min(offsetm, data_height - lines[3] - im_height)

    databand1 = band1.ReadAsArray(0, lines[0] - 1 + offset_min1, max_width, offset_max1 - offset_min1 + im_height)
    databand2 = band2.ReadAsArray(0, lines[1] - 1 + offset_min2, max_width, offset_max2 - offset_min2 + im_height)
    databand3 = band3.ReadAsArray(0, lines[2] - 1, max_width, im_height)
    databand4 = band4.ReadAsArray(0, lines[3] - 1 + offset_min4, max_width, offset_max4 - offset_min4 + im_height)
    image_data = [databand1, databand2, databand3, databand4]
    offset_mins = [offset_min1, offset_min2, offset_min3, offset_min4]

    all_map_file_exist = True


    for band in [1, 2, 3, 4]:
        all_map_file_exist = all_map_file_exist  and os.path.isfile(in_file_name + "x_b%d_Line%d.txt" % (band, lines[2]))


    if (not all_map_file_exist):

        x1, x2, x3, x4, y1, y2, y3, y4 = findSamplesPoints(in_file_name, sample_step_size, lines, sat_pos, sat_time,
                                                              sat_att, image_data, offset_mins, current_date, utc_gps,
                                                              dut1, dem_directory, im_width, im_height)

        np.savetxt(in_file_name + "x_b1_Line%d.txt" % lines[2], x1)
        np.savetxt(in_file_name + "x_b2_Line%d.txt" % lines[2], x2)
        np.savetxt(in_file_name + "x_b3_Line%d.txt" % lines[2], x3)
        np.savetxt(in_file_name + "x_b4_Line%d.txt" % lines[2], x4)

        np.savetxt(in_file_name + "y_b1_Line%d.txt" % lines[2], y1)
        np.savetxt(in_file_name + "y_b2_Line%d.txt" % lines[2], y2)
        np.savetxt(in_file_name + "y_b3_Line%d.txt" % lines[2], y3)
        np.savetxt(in_file_name + "y_b4_Line%d.txt" % lines[2], y4)
    else:

        x1 = np.loadtxt(in_file_name + "x_b1_Line%d.txt" % lines[2])
        x2 = np.loadtxt(in_file_name + "x_b2_Line%d.txt" % lines[2])
        x3 = np.loadtxt(in_file_name + "x_b3_Line%d.txt" % lines[2])
        x4 = np.loadtxt(in_file_name + "x_b4_Line%d.txt" % lines[2])

        y1 = np.loadtxt(in_file_name + "y_b1_Line%d.txt" % lines[2])
        y2 = np.loadtxt(in_file_name + "y_b2_Line%d.txt" % lines[2])
        y3 = np.loadtxt(in_file_name + "y_b3_Line%d.txt" % lines[2])
        y4 = np.loadtxt(in_file_name + "y_b4_Line%d.txt" % lines[2])

    try :

        print "try to find the matching image pair file for ger file."
        ger_pairs = np.loadtxt(in_file_name + "ger_pair_line%d.txt" % (lines[2]))
        lv2_pairs_min = np.loadtxt(in_file_name + "B3lv2_pair_min_line%d.txt" % (lines[2]))
        lv2_pairs_max = np.loadtxt(in_file_name + "B3lv2_pair_max_line%d.txt" % (lines[2]))


    except :

        print "The matching pair files have not been created."
        print "Generating the matching pair database."
        x_sampels = np.hstack((np.arange(0, im_width, step_sample), np.array([im_width - 1])))
        y_sampels = np.hstack((np.arange(0, im_height, step_line), np.array([im_height - 1])))

        ger_pairs = np.zeros((num_pairs, 2))

        cnt = 0
        lv2_pairs_min = np.zeros((num_pairs, 2))
        lv2_pairs_max = np.zeros((num_pairs, 2))
        for s_line in y_sampels:
            print "find matching pairs of line %d" % s_line
            s_samples = x_sampels

            lata_min, lona_min, ha = dps.findInterSectionPointArrayGivenAltitude("MS", in_file_name, s_samples,
                                                                               [lines[2] + s_line], hmin, current_date,
                                                                               utc_gps, dut1, band=3)
            lata_max, lona_max, ha = dps.findInterSectionPointArrayGivenAltitude("MS", in_file_name, s_samples,
                                                                               [lines[2] + s_line], hmax, current_date,
                                                                               utc_gps, dut1, band=3)

            num_s = s_samples.shape[0]
            x, y, z, zl = utmLatlon.from_latlon(lata_min, lona_min, zonec)
            cols = (x - x2_up_left) / dx2
            rows = (y - y2_up_left) / dy2
            str = cnt * num_s
            stp = str + num_s
            lv2_pairs_min[str:stp, 0] = cols
            lv2_pairs_min[str:stp, 1] = rows

            x, y, z, zl = utmLatlon.from_latlon(lata_max, lona_max, zonec)
            cols = (x - x2_up_left) / dx2
            rows = (y - y2_up_left) / dy2

            lv2_pairs_max[str:stp, 0] = cols
            lv2_pairs_max[str:stp, 1] = rows

            ger_pairs[str:stp, 0] = s_samples
            ger_pairs[str:stp, 1] = s_line
            cnt += 1
            # lv2_pair_min_list.append(lv2_pairs_min)
            # lv2_pair_max_list.append(lv2_pairs_max)
        np.savetxt(in_file_name + "B3lv2_pair_min_line%d.txt" % (lines[2]), lv2_pairs_min)
        np.savetxt(in_file_name + "B3lv2_pair_max_line%d.txt" % (lines[2]), lv2_pairs_max)

        print "completed...saving to files."
        np.savetxt(in_file_name + "ger_pair_line%d.txt" % (lines[2]), ger_pairs)




    numpairs = ger_pairs.shape[0]

    offsetlows = [0, 0, 0, 0]
    offsethighs = [0, 0, 0, 0]  # [offset1,offset2,0,offset4]

    # lv2_pairs_min =lv2_pair_min_list
    # lv2_pairs_max =lv2_pair_max_list #[lv2_pairs1_max,lv2_pairs2_max,lv2_pairs3_max,lv2_pairs4_max]

    lv_width = int(num_samples)
    lv_height = int(num_lines)

    gtiffDriver = gdal.GetDriverByName('GTiff')
    print "Interpolate DEM"

    dem_file_name = in_file_name + "DEM_%d.tif" % lines[2]


    dem_ds_im = gdal.Open(dem_file_name)

    if dem_ds_im is None:
        dem_ds_im = gtiffDriver.Create(dem_file_name, lv_width, lv_height, 1, gdal.GDT_Float32)
        dem_ds = dem_ds_im.GetRasterBand(1)
        mem = psutil.virtual_memory()
        mem_available = mem.available
        if dem_interpolation_method != "rbf":
            max_num_pixels_dem = (mem_available - 1024 * 1024 * 1024) / ((200) * 8)  # 400 memory block per pixels and 8 for double
        else:
            max_num_pixels_dem = 100 ** 2
        block_num_lines = int(np.sqrt(max_num_pixels_dem))
        block_num_pixels = block_num_lines
        off_set = 10
        block_num_lines2 = block_num_lines + off_set
        block_num_pixels2 = block_num_pixels + off_set
        for line in range(0, lv_height, block_num_lines):
            for sample in range(0, lv_width, block_num_pixels):
                line_max = min((lv_height - line), block_num_lines2)
                samp_max = min(lv_width - sample, block_num_pixels2)
                if (line == 0) & (sample == 0):
                    V, U = np.mgrid[0:int(line_max), 0:int(samp_max)]
                elif (line == 0) & (sample > 0):
                    V, U = np.mgrid[0:int(line_max), sample - off_set:int(samp_max + sample)]
                elif (line > 0) & (sample == 0):

                    V, U = np.mgrid[line - off_set:int(line_max + line), 0:int(samp_max)]
                else:
                    V, U = np.mgrid[line - off_set:int(line_max + line), sample - off_set:int(samp_max + sample)]

                u_earth = U * dx2 + x2_up_left
                v_earth = V * dy2 + y2_up_left
                late, lone = utmLatlon.to_latlon(u_earth, v_earth, zonec, zoneletter_c)

                # h = util.determineHeight(late,lone,dem_directory)
                print "[DEM]  coord:", late.min(), late.max(), lone.min(), lone.max()
                latgrid, longrid, hgrid = util.load_dem_data([late.max() + 30 * pixel_size, lone.min() - 30. * pixel_size],
                                                             [late.min() - 30 * pixel_size, lone.max() + 30. * pixel_size],
                                                             dem_directory)
                if dem_interpolation_method == "kriging":
                    h = util.interpolateDemGrid(late, lone, latgrid, longrid, hgrid, pixel_size)
                elif dem_interpolation_method == "linear":
                    h = util.interpolateDemGRidLinear(late, lone, latgrid, longrid, hgrid, pixel_size)
                elif dem_interpolation_method == "cubic":
                    h = util.interpolateDemGRidCubic(late, lone, latgrid, longrid, hgrid, pixel_size)
                elif dem_interpolation_method == "nearest":
                    h = util.interpolateDemGRidNearest(late, lone, latgrid, longrid, hgrid, pixel_size)
                elif dem_interpolation_method == "rbf":
                    h = util.interpolateDemGridRBF(late, lone, latgrid, longrid, hgrid, pixel_size)
                else:
                    print "Invalid interpolation technique"
                    exit(1)
                ofx = off_set * (sample != 0)
                ofy = off_set * (line != 0)
                dem_out = h[ofy:, ofx:].astype('float64')
                print "sample:%d, line:%d" % (sample, line), h.shape
                dem_ds.WriteArray(dem_out, sample, line)
        dem_ds_im = None
        dem_ds_im = gdal.Open(dem_file_name)
    dem_ds = dem_ds_im.GetRasterBand(1)
    image_map_info = []

    first_band = True

    if (not os.path.isfile(in_file_name + "band_map_line%d.npy" % lines[2])):
        lv2_geotrans = [x2_up_left, y2_up_left, dx2, dy2, zonec]
        band_map_info = findLV2RemapFuncitionBand3(in_file_name, lines[2], ger_pairs, lv2_pairs_min, lv2_pairs_max,
                                                  lv2_geotrans, dem_ds, hmin, hmax, current_date, utc_gps, dut1,
                                                  lv_width, lv_height, im_width, im_height)
        np.save(in_file_name + "band_map_Line%d.npy" % (lines[2]), band_map_info)
    else:
        band_map_info = np.load(in_file_name + "band_map_line%d.npy" % lines[2])
    print "Remove non-overalapping areas"
    dst_ds = gtiffDriver.Create(out_file_name, lv_width, lv_height, 4, gdal.GDT_Byte)


    print "Correcting Mask area........",

    mask_data = np.zeros((lv_height, lv_width), 'uint8')

    print "Working a"
    band3 = dst_ds.GetRasterBand(1)
    ms_band_data = np.zeros((lv_height, lv_width), 'uint8')
    lev1_im = np.zeros((im_height, im_width, 3), 'uint8')
    lev1_im[:, :, 2] = image_data[2]
    for line, sample, line_max, samp_max, x_file_name, y_file_name in band_map_info:
        databand = image_data[2]
        if (x_file_name is not None) and (y_file_name is not None):
            idx = x_file_name.find("TS1_2016297")
            # x_file_name = r"D:\Data2APanSharpen\compar_last_scene\Gerald_42210_MS\info\\" + x_file_name[idx:]
            idx = y_file_name.find("TS1_2016297")
            # y_file_name = r"D:\Data2APanSharpen\compar_last_scene\Gerald_42210_MS\info\\" + y_file_name[idx:]

            X = np.load(x_file_name)
            Y = np.load(y_file_name)
            Xmin = int(X.min())
            Xmax = int(np.ceil(X.max()))
            Ymin = int(Y.min())
            Ymax = int(np.ceil(Y.max()))
            strx = int(max(Xmin, 0))
            stpx = min(Xmax + 1, im_width)
            stry = max(Ymin, 0)
            stpy = min(Ymax + 1, im_height)
            temp = np.zeros_like(X)
            if (strx < stpx) & (stry < stpy):
                original = databand[stry:stpy, strx:stpx]
                remap_out = cv2.remap(original, X - strx, Y - stry, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                      borderValue=0)
                temp[(X >= X.min()) * (X <= X.max()) * (Y >= Y.min()) * (Y <= Y.max())] = remap_out.flatten()
                ms_band_data[line:line + line_max, sample:sample + samp_max] = temp
                # band3.WriteArray(sample, line, ms_band_data)
                mk = (X > 0) * (X < im_width) * (Y > 0) * (Y < im_height)

                mask_data[line:line + line_max, sample:sample + samp_max] = mk
        else:
            mask_data[line:line + line_max, sample:sample + samp_max] *= 0
    band3.WriteArray(ms_band_data)
    block_size = im_width
    for band in [1, 2 , 4]:
        if band == 1:
            band_src = dst_ds.GetRasterBand(3)
        elif band == 3:
            band_src = dst_ds.GetRasterBand(1)
        else:
            band_src = dst_ds.GetRasterBand(band)

        databand = image_data[band - 1]  # band_src.ReadAsArray(0,offset_mins[band-1]+lines[band-1],
        #                        #        im_width,im_height+offmax[band-1]-offsetlows[band-1])
        ms_band_data = np.zeros((lv_height, lv_width), 'uint8')
        mask_band = np.zeros((lv_height, lv_width), 'uint8')
        max_height = im_height

        # tempf = np.load(in_file_name+"_map_info_band_%d.npy"%band)
        if band == 1:
            remap_x, remap_y, mask = remapImageBandGridMethod(x1, y1, x3, y3, 0, 0, block_size, im_width, im_height, offset_min1, max_error=0.1)
                             # block_offset, max_error=0.1)
            outbb = cv2.remap(image_data[0], remap_x, remap_y, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                          borderValue=0)
            lev1_im[:, :, 0] = outbb
        elif band == 2:
            remap_x, remap_y, mask = remapImageBandGridMethod(x2, y2, x3, y3, 0, 0, block_size, im_width, im_height, offset_min2, max_error=0.1)
                                                  # block_offset, max_error=0.1)
            outbb = cv2.remap(image_data[1], remap_x, remap_y, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                              borderValue=0)
            lev1_im[:, :, 1] = outbb
        elif band == 4:
            remap_x, remap_y, mask = remapImageBandGridMethod(x4, y4, x3, y3, 0, 0, block_size, im_width, im_height, offset_min4, max_error=0.1)
                                                  # block_offset, max_error=0.1)

        for line, sample, line_max, samp_max, x_file_name, y_file_name in band_map_info:
            if (x_file_name is not None) and (y_file_name is not None):
                idx = x_file_name.find("TS1_2016297")
                # x_file_name = r"D:\Data2APanSharpen\compar_last_scene\Gerald_42210_MS\info\\" + x_file_name[idx:]
                idx = y_file_name.find("TS1_2016297")
                # y_file_name = r"D:\Data2APanSharpen\compar_last_scene\Gerald_42210_MS\info\\" + y_file_name[idx:]
                U = np.load(x_file_name)
                V = np.load(y_file_name)

                U1d = U.flatten()
                V1d = V.flatten()
                X = np.zeros_like(U1d) - 1000
                Y = np.zeros_like(U1d) - 1000
                maskls = np.zeros_like(U1d, 'uint8')
                # Inside
                valid_pixel = np.nonzero((U1d > 0) * (U1d < im_width - 1) * (V1d > 0) * (V1d < max_height - 1))[0]
                if len(valid_pixel) > 0:
                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    U1d_max = U1d_min + 1  # np.ceil(U1dvalid).astype('int')

                    V1d_min = np.floor(V1dvalid).astype('int')
                    V1d_max = V1d_min + 1  # np.ceil(V1dvalid).astype('int')
                    xll = remap_x[V1d_min, U1d_min]
                    xhl = remap_x[V1d_max, U1d_min]

                    xlh = remap_x[V1d_min, U1d_max]
                    xhh = remap_x[V1d_max, U1d_max]

                    yll = remap_y[V1d_min, U1d_min]
                    yhl = remap_y[V1d_max, U1d_min]

                    ylh = remap_y[V1d_min, U1d_max]
                    yhh = remap_y[V1d_max, U1d_max]
                    du = U1dvalid - U1d_min
                    dv = V1dvalid - V1d_min
                    xvalid = xll * (1 - du) * (1 - dv) + xhl * dv * (1 - du) + xlh * (1 - dv) * du + xhh * dv * du
                    yvalid = yll * (1 - du) * (1 - dv) + yhl * dv * (1 - du) + ylh * (1 - dv) * du + yhh * dv * du
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid

                # left_line
                valid_pixel = np.nonzero((U1d == 0) * (V1d > 0) * (V1d < max_height - 1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')

                    V1d_min = np.floor(V1dvalid).astype('int')
                    V1d_max = V1d_min + 1  # np.ceil(V1dvalid).astype('int')
                    xll = remap_x[V1d_min, U1d_min]
                    xhl = remap_x[V1d_max, U1d_min]
                    yll = remap_y[V1d_min, U1d_min]
                    yhl = remap_y[V1d_max, U1d_min]
                    dv = V1dvalid - V1d_min
                    xvalid = xll * (1 - dv) + xhl * dv
                    yvalid = yll * (1 - dv) + yhl * dv
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid

                # top line
                valid_pixel = np.nonzero((U1d > 0) * (U1d < im_width - 1) * (V1d == 0))[0]
                if len(valid_pixel) > 0:
                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    U1d_max = U1d_min + 1  # np.ceil(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')

                    xll = remap_x[V1d_min, U1d_min]

                    xlh = remap_x[V1d_min, U1d_max]

                    yll = remap_y[V1d_min, U1d_min]

                    ylh = remap_y[V1d_min, U1d_max]
                    du = U1dvalid - U1d_min

                    xvalid = xll * (1 - du) + xlh * du
                    yvalid = yll * (1 - du) + ylh * du
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # right line
                valid_pixel = np.nonzero((U1d == im_width - 1) * (V1d > 0) * (V1d < max_height - 1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_max = np.floor(U1dvalid).astype('int')

                    V1d_min = np.floor(V1dvalid).astype('int')
                    V1d_max = V1d_min + 1  # np.ceil(V1dvalid).astype('int')


                    xlh = remap_x[V1d_min, U1d_max]
                    xhh = remap_x[V1d_max, U1d_max]

                    ylh = remap_y[V1d_min, U1d_max]
                    yhh = remap_y[V1d_max, U1d_max]

                    dv = V1dvalid - V1d_min
                    xvalid = xlh * (1 - dv) + xhh * dv
                    yvalid = ylh * (1 - dv) + yhh * dv
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # buttom line
                valid_pixel = np.nonzero((U1d > 0) * (U1d < im_width - 1) * (V1d == max_height - 1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    U1d_max = U1d_min + 1  # np.ceil(U1dvalid).astype('int')


                    V1d_max = np.floor(V1dvalid).astype('int')

                    xhl = remap_x[V1d_max, U1d_min]
                    xhh = remap_x[V1d_max, U1d_max]
                    yhl = remap_y[V1d_max, U1d_min]
                    yhh = remap_y[V1d_max, U1d_max]
                    du = U1dvalid - U1d_min

                    xvalid = xhl * (1 - du) + xhh * du
                    yvalid = yhl * (1 - du) + yhh * du
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # upper left
                valid_pixel = np.nonzero((U1d == 0) * (V1d == 0))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')
                    xvalid = remap_x[V1d_min, U1d_min]
                    yvalid = remap_y[V1d_min, U1d_min]
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # upper right
                valid_pixel = np.nonzero((U1d == im_width - 1) * (V1d == 0))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')
                    xvalid = remap_x[V1d_min, U1d_min]
                    yvalid = remap_y[V1d_min, U1d_min]
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # bottom left
                valid_pixel = np.nonzero((U1d == 0) * (V1d == max_height - 1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')
                    xvalid = remap_x[V1d_min, U1d_min]
                    yvalid = remap_y[V1d_min, U1d_min]
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                # bottom right
                valid_pixel = np.nonzero((U1d == im_width - 1) * (V1d == max_height - 1))[0]
                if len(valid_pixel) > 0:

                    U1dvalid = U1d[valid_pixel]
                    V1dvalid = V1d[valid_pixel]
                    U1d_min = np.floor(U1dvalid).astype('int')
                    V1d_min = np.floor(V1dvalid).astype('int')
                    xvalid = remap_x[V1d_min, U1d_min]
                    yvalid = remap_y[V1d_min, U1d_min]
                    X[valid_pixel] = xvalid
                    Y[valid_pixel] = yvalid
                mask_valid = np.nonzero((X > 0) * (X < im_width - 1) * (Y > 0) * (Y < databand.shape[0] - 1))[0]
                maskls[mask_valid] = 1
                X = X.reshape(U.shape)
                Y = Y.reshape(V.shape)

                Xmin = int(X.min())
                Xmax = int(np.ceil(X.max()))
                Ymin = int(Y.min())
                Ymax = int(np.ceil(Y.max()))
                strx = int(max(Xmin, 0))
                stpx = min(Xmax + 1, im_width)
                stry = max(Ymin, 0)
                stpy = min(Ymax + 1, databand.shape[0])
                temp = np.zeros_like(X)
                maskls = maskls.reshape(U.shape)
                if (strx < stpx) & (stry < stpy):
                    original = databand[stry:stpy, strx:stpx]
                    remap_out = cv2.remap(original, X - strx, Y - stry, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                          borderValue=0)
                    temp[(X >= X.min()) * (X <= X.max()) * (Y >= Y.min()) * (Y <= Y.max())] = remap_out.flatten()
                    ms_band_data[line:line + line_max, sample:sample + samp_max] = temp
                    mask_band[line:line + line_max, sample:sample + samp_max] = maskls
            else:
                mask_band[line:line + line_max, sample:sample + samp_max] *= 0



            # if not save_pixel_mapping:
            #    os.remove(x_file_name)
            #    os.remove(y_file_name)
        # cv2.imwrite(r"D:\Data2APanSharpen\compar_last_scene\Gerald_42210_MS\level2a\mask%d.tif"%band, mask_band*255)
        band_src.WriteArray(ms_band_data)
        mask_data *= mask_band

    # cv2.imwrite(r"D:\Data2APanSharpen\compar_last_scene\Gerald_42210_MS\level2a\lvl1.tif",lev1_im)
    print "There are %d pixels in the level 2A image with data." % (mask_data.sum())
    print "There are %d pixels in the level 2A that has been masked out." % ((mask_data == 0).sum())
    print "Saving Mask image."
    cv2.imwrite(in_file_name + "_mask.tif", mask_data * 255)
    print "Mask correction...."
    dst_ds = None
    dst_ds = gdal.Open(out_file_name, gdal.GA_Update)
    for band in [1, 2, 3, 4]:
        print "   correcting Band %d........." % band,
        if band == 1:
            bandk = dst_ds.GetRasterBand(3)
        elif band == 3:
            bandk = dst_ds.GetRasterBand(1)
        else:
            bandk = dst_ds.GetRasterBand(band)

        data_bandk = bandk.ReadAsArray()
        data_bandk *= mask_data
        bandk.WriteArray(data_bandk)
        print "done."
    print "Mask Correction completed!"

    print "done!"
    print "Compute the average elevation of the scene.............",
    avg_dem = 0.0
    num_nonzero_pixel = 0.0
    num_block_lines = 1000
    num_block_pixels = 1000
    for line in range(0, lv_height, num_block_lines):
        for sample in range(0, lv_width, num_block_pixels):
            line_max = min((lv_height - line), num_block_lines)
            samp_max = min(lv_width - sample, num_block_pixels)
            mask_sub = mask_data[line:(line + line_max), sample:(sample + samp_max)]
            num_nonzero_pixel += mask_sub.sum()
            h = dem_ds.ReadAsArray(sample, line, samp_max, line_max)
            avg_dem += (h * mask_sub.astype('float32')).sum()
    avg_dem /= num_nonzero_pixel
    print "done! The averaged elevation is: %f meters." % avg_dem

    print "Computing the vertices: "
    cl1 = np.round((xul - x2_up_left) / dx2) + 1
    rw1 = np.round((yul - y2_up_left) / dy2) + 1
    x1 = x2_up_left + dx2 * cl1
    y1 = y2_up_left + dy2 * rw1
    lat1, lon1 = utmLatlon.to_latlon(np.array([x1]), np.array([y1]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat1 = lat1[0]
    lon1 = lon1[0]

    cl2 = np.round((xur - x2_up_left) / dx2) + 1
    rw2 = np.round((yur - y2_up_left) / dy2) + 1
    x2 = x2_up_left + dx2 * cl2
    y2 = y2_up_left + dy2 * rw2
    lat2, lon2 = utmLatlon.to_latlon(np.array([x2]), np.array([y2]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat2 = lat2[0]
    lon2 = lon2[0]

    cl3 = np.round((xllc - x2_up_left) / dx2) + 1
    rw3 = np.round((yllc - y2_up_left) / dy2) + 1
    x3 = x2_up_left + dx2 * cl3
    y3 = y2_up_left + dy2 * rw3

    lat3, lon3 = utmLatlon.to_latlon(np.array([x3]), np.array([y3]), zonec, zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat3 = lat3[0]
    lon3 = lon3[0]
    cl4 = np.round((xlr - x2_up_left) / dx2) + 1
    rw4 = np.round((ylr - y2_up_left) / dy2) + 1
    x4 = x2_up_left + dx2 * cl4
    y4 = y2_up_left + dy2 * rw4
    lat4, lon4 = utmLatlon.to_latlon(np.array([x4]), np.array([y4]), zonec, zoneletter_c)
    lat4 = lat4[0]
    lon4 = lon4[0]
    cl5 = np.round((xc - x2_up_left) / dx2) + 1
    rw5 = np.round((yc - y2_up_left) / dy2) + 1
    x5 = x2_up_left + dx2 * cl5
    y5 = y2_up_left + dy2 * rw5
    lat5, lon5 = utmLatlon.to_latlon(np.array([x5]), np.array([y5]), zonec, zoneletter_c)
    lat5 = lat5[0]
    lon5 = lon5[0]
    print "Upper left vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw1, cl1)
    print "FRAME_X: %e, FRAME_COL: %e" % (x1, y1)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon1, lat1)
    print ".........................................................."

    print "Upper right vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw2, cl2)
    print "FRAME_X: %e, FRAME_COL: %e" % (x2, y2)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon2, lat2)
    print ".........................................................."

    print "Lower left vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw3, cl3)
    print "FRAME_X: %e, FRAME_COL: %e" % (x3, y3)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon3, lat3)
    print ".........................................................."

    print "Lower right vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw4, cl4)
    print "FRAME_X: %e, FRAME_COL: %e" % (x4, y4)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon4, lat4)
    print ".........................................................."

    print "Scene center.............................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw5, cl5)
    print "FRAME_X: %e, FRAME_COL: %e" % (x5, y5)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon5, lat5)
    print ".........................................................."
    dst_ds.SetGeoTransform([ x2_up_left, 15.0, 0, y2_up_left, 0, -15.0 ])

    srs = osr.SpatialReference()
    srs.SetWellKnownGeogCS("WGS84")
    if (lat5 >= 0) :
        srs.SetUTM(zonec, 1)
    else :
        srs.SetUTM(zonec, 0)

    dst_ds.SetProjection(srs.ExportToWkt())
    if save_dem:
        dem_ds_im.SetProjection(srs.ExportToWkt())

    upleft = [[cl1, rw1], [x1, y1], [lon1, lat1]]
    upright = [[cl2, rw2], [x2, y2], [lon2, lat2]]
    midpoint = [[cl5, rw5], [x5, y5], [lon5, lat5]]
    lowleft = [[cl3, rw3], [x3, y3], [lon3, lat3]]
    lowright = [[cl4, rw4], [x4, y4], [lon4, lat4]]
    map_info = [x2_up_left, y2_up_left, 15.0, 15.0, avg_dem, zonec, (lat5 >= 0)]
    return upleft, upright, midpoint, lowleft, lowright, map_info

def computeMSImageCorners(out_file_name, in_file_name, lines, current_date, utc_gps, dut1, dem, dem_interpolation_method,
                          start_sample=1, im_width=6000, im_height=6000):

    # im_width = 6000
    lines[0] = lines[0]
    lines[1] = lines[1]
    lines[2] = lines[2]
    lines[3] = lines[3]
    end_sample = start_sample + im_width - 1
    if (end_sample > 6000) or (start_sample < 1) :
        print "The intended sample is beyond the scope of the recorded GER file."

    line = lines[2]

    latc, lonc, heightc = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name,
                                                                 np.array([(end_sample + start_sample) / 2]),
                                                                 np.array([line + im_height / 2]), current_date,
                                                                 utc_gps, dut1, dem, dem_interpolation_method, band=3)
    # = dps.findInterSectionPoint("MS",in_file_name,end_sample/2,line+im_height/2,current_date,utc_gps,dut1,dem_directory)
    xc, yc, zonec, zoneletter = utm.from_latlon(latc, lonc)
    latul, lonul, heightul = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name, np.array([start_sample]),
                                                                    [line], current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method, band=3)

    xul, yul, zoneul, zoneletter = utm.from_latlon(latul, lonul, zonec)
    print "original image upper left UTM:", xul, yul

    latur, lonur, heightur = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name, np.array([end_sample]),
                                                                    [line], current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method, band=3)
    xur, yur, zoneur, zoneletter = utm.from_latlon(latur, lonur, zonec)
    print "original image upper right UTM:", xur, yur
    latll, lonll, heightll = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name, np.array([start_sample]),
                                                                    [line + im_height], current_date, utc_gps, dut1,
                                                                    dem,
                                                                    dem_interpolation_method, band=3)
    xllc, yllc, zonell, zoneletter = utm.from_latlon(latll, lonll, zonec)
    print "original image lower left UTM:", xllc, yllc

    latlr, lonlr, heightlr = dps.findInterSectionPointArrayUsingDEM("MS", in_file_name, np.array([end_sample]),
                                                                    [line + im_height], current_date, utc_gps, dut1,
                                                                    dem,
                                                                    dem_interpolation_method, band=3)
    xlr, ylr, zonelr, zoneletter_c = utm.from_latlon(latlr, lonlr, zonec)
    print "original image lower right UTM:", xlr, ylr
    print "original image center UTM:", xc, yc
    num_lines = np.ceil((yul - ylr) / 15.0 + 1)
    num_samples = np.ceil((xur - xllc) / 15.0 + 1)
    lv_width = int(np.ceil(num_samples))
    lv_height = int(np.ceil(num_lines))

    print "The level 2A image has a size of %d x %d  pixels" % (lv_width, lv_height)
    # determine the mapping function.
    x2_up_left = xllc
    y2_up_left = yul
    dx2 = 15.0
    dy2 = -15.0

    latgrid, longrid, hgrid = dem.getValuesFromRetangularArea(latul, lonll, latlr,
                                                              lonur)  # util.load_dem_data(upleft_lat_lon,lowright_lat_lon,dem_directory)
    # dem_temp = util.load_dem_file(13,100,dem_directory)
    # pixel_size = dem_temp.GetGeoTransform()[1]/3600.
    hmin = hgrid.min()
    hmax = hgrid.max()


    num_lines = (yul - ylr) / 15.0 + 1
    num_samples = (xur - xllc) / 15.0 + 1
    print "image widht: %d, image height: %d" % (num_samples, num_lines)
    # print "positioning error uper-left:(%f,%f)"%(xul-4.0983527001634776e+05,yul- 4.4724851760478579e+06)
    # print "positioning error uper-right:(%f,%f)"%(xur-5.0465027001634776e+05,yur - 4.4545001760478579e+06)
    # print "positioning error lower-left:(%f,%f)"%(xll-3.8916527001634776e+05,yll- 4.3887551760478579e+06)
    # print "positioning error lower-right:(%f,%f)"%(xlr-4.8401027001634776e+05,ylr - 4.3706951760478579e+06)

    # determine the mapping function.
    x2_up_left = xllc
    y2_up_left = yul
    dx2 = 15.0
    dy2 = -15.0
    print "Computing the vertices: "
    cl1 = np.round((xul - x2_up_left) / dx2) + 1
    rw1 = np.round((yul - y2_up_left) / dy2) + 1
    x1 = x2_up_left + dx2 * cl1
    y1 = y2_up_left + dy2 * rw1
    lat1, lon1 = utmLatlon.to_latlon(np.array([x1]), np.array([y1]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat1 = lat1[0]
    lon1 = lon1[0]

    cl2 = np.round((xur - x2_up_left) / dx2) + 1
    rw2 = np.round((yur - y2_up_left) / dy2) + 1
    x2 = x2_up_left + dx2 * cl2
    y2 = y2_up_left + dy2 * rw2
    lat2, lon2 = utmLatlon.to_latlon(np.array([x2]), np.array([y2]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat2 = lat2[0]
    lon2 = lon2[0]

    cl3 = np.round((xllc - x2_up_left) / dx2) + 1
    rw3 = np.round((yllc - y2_up_left) / dy2) + 1
    x3 = x2_up_left + dx2 * cl3
    y3 = y2_up_left + dy2 * rw3
    lat3, lon3 = utmLatlon.to_latlon(np.array([x3]), np.array([y3]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat3 = lat3[0]
    lon3 = lon3[0]

    cl4 = np.round((xlr - x2_up_left) / dx2) + 1
    rw4 = np.round((ylr - y2_up_left) / dy2) + 1
    x4 = x2_up_left + dx2 * cl4
    y4 = y2_up_left + dy2 * rw4
    lat4, lon4 = utmLatlon.to_latlon(np.array([x4]), np.array([y4]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat4 = lat4[0]
    lon4 = lon4[0]

    cl5 = np.round((xc - x2_up_left) / dx2) + 1
    rw5 = np.round((yc - y2_up_left) / dy2) + 1
    x5 = x2_up_left + dx2 * cl5
    y5 = y2_up_left + dy2 * rw5
    lat5, lon5 = utmLatlon.to_latlon(np.array([x5]), np.array([y5]), zonec,
                                     zoneletter_c)  # utm.to_latlon(x3,y3,zonec,zoneletter_c)
    lat5 = lat5[0]
    lon5 = lon5[0]
    print "Upper left vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw1, cl1)
    print "FRAME_X: %e, FRAME_COL: %e" % (x1, y1)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon1, lat1)
    print ".........................................................."

    print "Upper right vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw2, cl2)
    print "FRAME_X: %e, FRAME_COL: %e" % (x2, y2)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon2, lat2)
    print ".........................................................."

    print "Lower left vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw3, cl3)
    print "FRAME_X: %e, FRAME_COL: %e" % (x3, y3)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon3, lat3)
    print ".........................................................."

    print "Lower right vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw4, cl4)
    print "FRAME_X: %e, FRAME_COL: %e" % (x4, y4)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon4, lat4)
    print ".........................................................."

    print "Scene center.............................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw5, cl5)
    print "FRAME_X: %e, FRAME_COL: %e" % (x5, y5)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon5, lat5)
    print ".........................................................."

    upleft = [[cl1, rw1], [x1, y1], [lon1, lat1]]
    upright = [[cl2, rw2], [x2, y2], [lon2, lat2]]
    midpoint = [[cl5, rw5], [x5, y5], [lon5, lat5]]
    lowleft = [[cl3, rw3], [x3, y3], [lon3, lat3]]
    lowright = [[cl4, rw4], [x4, y4], [lon4, lat4]]
    dem_file_name = in_file_name + "DEM_%d.tif" % lines[2]
    ms_im = gdal.Open(out_file_name)
    ms_b1 = ms_im.GetRasterBand(1)
    avg_dem = 0.0
    num_nonzero_pixels = 0.0
    block_num_lines = 1000
    block_num_pixels = 1000
    lv_height = ms_im.RasterYSize
    lv_width = ms_im.RasterXSize
    dem_im = gdal.Open(dem_file_name)
    dem_ds = dem_im.GetRasterBand(1)
    for line in range(0, lv_height, block_num_lines):
        for sample in range(0, lv_width, block_num_pixels):
            line_max = min((lv_height - line), block_num_lines)
            samp_max = min(lv_width - sample, block_num_pixels)
            h = dem_ds.ReadAsArray(sample, line, samp_max, line_max)
            data = ms_b1.ReadAsArray(sample, line, samp_max, line_max)
            mask = (data != 0).astype('float32')
            avg_dem += (h * mask).sum()
            num_nonzero_pixels += mask.sum()
    avg_dem /= num_nonzero_pixels
    map_info = [x2_up_left, y2_up_left, 15.0, 15.0, avg_dem, zonec, (lat5 >= 0)]
    return upleft, upright, midpoint, lowleft, lowright, map_info

def findLV2RemapFuncitionPANWithInterpolation(in_file_name, beg_line, ger_pairs, lv2_pair_min, lv2_pair_max, lv2_geotrans, dem_ds,
                            hmin, hmax, current_date, utc_gps, dut1, lv_width, lv_height, im_width, im_height):


    x2_up_left, y2_up_left, dx2, dy2, zonec = lv2_geotrans
    off_set = 10

    numpairs = ger_pairs.shape[0]
    print "  Band PAN....."
    print "  Finding the reversed model......."
    band_map_info = []
    A = np.zeros((numpairs, 12))
    u_mean = lv_width / 2.0
    v_mean = lv_height / 2.0
    u = lv2_pair_min[:, 0] - u_mean
    v = lv2_pair_min[:, 1] - v_mean + 1
    # print u.min(),u.max(),v.min(),v.max()
    A[:, 0] = 1.0
    A[:, 1] = u
    A[:, 2] = v
    A[:, 3] = u * v
    A[:, 4] = u ** 2
    A[:, 5] = v ** 2
    A[:, 6] = u * v * v
    A[:, 7] = v * u * u
    A[:, 8] = u ** 3
    A[:, 9] = v ** 3
    A[:, 10] = v * u ** 3
    A[:, 11] = u * v ** 3

    x_mean = ger_pairs[:, 0].mean()
    y_mean = ger_pairs[:, 1].mean()
    bx = ger_pairs[:, 0] - x_mean
    by = ger_pairs[:, 1] - y_mean
    a_x_min, errx, rnkx, s = np.linalg.lstsq(A, bx)
    # print rnk
    a_y_min, erry, rnky, s = np.linalg.lstsq(A, by)
    # print rnk
    if (rnkx == 12) and (rnky == 12):
        print "[PAN] Minimun altitude average errors: %f,%f" % (errx / numpairs, erry / numpairs)
    else:
        print "[PAN]  The model for mainimum altitude is too fitted. Reduce the number of variables."
        # A2 = A.copy()
        for rk in range(11, 0, -1):
            A2 = A[:, :rk]
            a_x_min2, errx, rnk, s = np.linalg.lstsq(A2, bx)
            a_y_min2, erry, rnk, s = np.linalg.lstsq(A2, by)
            if (len(a_x_min2) > 0) and (len(a_y_min2) > 0):
                a_x_min = np.zeros((12,))
                a_y_min = np.zeros((12,))
                a_x_min[:rk] = a_x_min2
                a_y_min[:rk] = a_y_min2
                break
        print ".....................The algorithm terminates with the matrix of order %d." % rk

    u = lv2_pair_max[:, 0] - u_mean
    v = lv2_pair_max[:, 1] - v_mean + 1
    # print u.min(),u.max(),v.min(),v.max()
    A[:, 0] = 1.0
    A[:, 1] = u
    A[:, 2] = v
    A[:, 3] = u * v
    A[:, 4] = u ** 2
    A[:, 5] = v ** 2
    A[:, 6] = u * v * v
    A[:, 7] = v * u * u
    A[:, 8] = u ** 3
    A[:, 9] = v ** 3
    A[:, 10] = v * u ** 3
    A[:, 11] = u * v ** 3
    x_mean = ger_pairs[:, 0].mean()
    y_mean = ger_pairs[:, 1].mean()
    bx = ger_pairs[:, 0] - x_mean
    by = ger_pairs[:, 1] - y_mean
    a_x_max, errx, rnkx, s = np.linalg.lstsq(A, bx)
    a_y_max, erry, rnky, s = np.linalg.lstsq(A, by)
    if (rnkx == 12) and (rnky == 12):
        print "[PAN] Maximum altitude average errors: %f,%f" % (errx / numpairs, erry / numpairs)
    else:
        print "[PAN]    model for maximum altitude is too fitted. Reduce the number of variables."
        # A2 = A.copy()
        for rk in range(11, 0, -1):
            A2 = A[:, :rk]
            a_x_max2, errx, rnk, s = np.linalg.lstsq(A2, bx)
            a_y_max2, erry, rnk, s = np.linalg.lstsq(A2, by)
            if (len(a_x_max2) > 0) and (len(a_y_max2) > 0):
                a_x_max = np.zeros((12,))
                a_y_max = np.zeros((12,))
                a_x_max[:rk] = a_x_max2
                a_y_max[:rk] = a_y_max2
                break
        print "....................The algorithm terminates with the matrix of order %d." % rk

    print "The reversed model is computed......"


    sat_pos = np.loadtxt(in_file_name + ".pos")
    captured_time = np.loadtxt(in_file_name + ".tim")
    sat_att = np.loadtxt(in_file_name + ".att")
    # block_info_filep = open(in_file_name + "Band%d.txt"%(band+1),"w")
    lv2_step_size = 10
    line = 0
    sample = 0


    line_max = lv_height
    samp_max = lv_width
    print "[PAN] Mapping Sample: %d to %d, and Line: %d to %d." % (sample, sample + samp_max, line,
                                                                  line + line_max)
    Ux = np.arange(lv2_step_size / 2, lv_width, lv2_step_size)
    Vx = np.arange(lv2_step_size / 2, lv_height, lv2_step_size)
    U, V = np.meshgrid(Ux, Vx)


    dem_data = dem_ds.ReadAsArray(0, 0, lv_width, lv_height)
    h = np.zeros_like(U, 'float64')
    h[:, :] = dem_data[lv2_step_size / 2::lv2_step_size, lv2_step_size / 2::lv2_step_size]

    # print "[%d] remapping line: %d to %d and sample: %d to %d"%(band+1,line,line+line_max,sample,sample+samp_max)

    U = U - u_mean
    V = V - v_mean

    U = U.flatten()
    V = V.flatten()
    h = h.flatten()
    print "Create LV2->LV1 tie points at the step of %d pixels" % lv2_step_size
    try:
        X, Y = dps.findGerFileLocationPreLoadFiles(U, V, h, a_x_min, a_y_min, a_x_max, a_y_max, x_mean, y_mean,
                                                   u_mean,
                                                   v_mean, hmin, hmax, "PAN", in_file_name, beg_line,
                                                   current_date,
                                                   utc_gps, dut1, (x2_up_left, y2_up_left, dx2, dy2, zonec),
                                                   im_width, im_height, sat_pos, captured_time, sat_att)
    except:
        np.save(in_file_name + "band_PAN_U_%d.npy" % (beg_line), U)
        np.save(in_file_name + "band_PAN_V_%d.npy" % (beg_line), V)
        np.save(in_file_name + "band_PAN_h_%d.npy" % (beg_line), h)
        np.save(in_file_name + "band_PAN_axmin_%d.npy" % (beg_line), a_x_min)
        np.save(in_file_name + "band_PAN_aymin_%d.npy" % (beg_line), a_y_min)
        np.save(in_file_name + "band_PAN_axmax_%d.npy" % (beg_line), a_x_max)
        np.save(in_file_name + "band_PAN_aymax_%d.npy" % (beg_line), a_y_max)
        np.save(in_file_name + "band_PAN_x_mean_y_mean_%d.npy" % (beg_line),
                np.array([x_mean, y_mean]))
        np.save(in_file_name + "band_PAN_u_mean_v_mean_%d.npy" % (beg_line),
                np.array([u_mean, v_mean]))
        np.save(in_file_name + "band_PAN_hminmax_%d.npy" % (beg_line),
                np.array([hmin, hmax]))
        print "filename", in_file_name
        print "Line:", beg_line
        print "data", current_date
        print "utc_gps", utc_gps
        print "dut1", dut1
        print "mapInfo", [x2_up_left, y2_up_left, dx2, dy2, zonec]
        np.save(in_file_name + "band_PAN_cap_time_%d.npy" % (beg_line), captured_time)
        np.save(in_file_name + "band_PAN_sat_pos_%d.npy" % (beg_line), sat_pos)
        np.save(in_file_name + "band_PAN_sat_att_%d.npy" % (beg_line), sat_att)
        exit()

    print "Done!"

    X = X.flatten()
    Y = Y.flatten()
    U2 = Ux
    V2 = Vx
    X2 = X.reshape(V2.shape[0], U2.shape[0]).T
    Y2 = Y.reshape(V2.shape[0], U2.shape[0]).T
    fx = inplt.RectBivariateSpline(U2, V2, X2, bbox=[0, lv_width, 0, lv_height])
    fy = inplt.RectBivariateSpline(U2, V2, Y2, bbox=[0, lv_width, 0, lv_height])

    mem = psutil.virtual_memory()
    mem_available = mem.available
    max_num_pixels = (mem_available - 1024 * 1024 * 1024) / ((100) * 8)  # 100 memory block per pixels and 8 for double
    num_block_lines = int(np.sqrt(max_num_pixels))
    num_block_pixels = num_block_lines
    print "Making the mapping function between LV2-LV1"
    for line in range(0, lv_height, num_block_lines):
        for sample in range(0, lv_width, num_block_pixels):
            line_max = min((lv_height - line), num_block_lines)
            samp_max = min(lv_width - sample, num_block_pixels)
            if (line == 0) & (sample == 0):
                V, U = np.mgrid[0:int(line_max), 0:int(samp_max)]
            elif (line == 0) & (sample > 0):
                V, U = np.mgrid[0:int(line_max), sample - off_set:int(samp_max + sample)]
            elif (line > 0) & (sample == 0):

                V, U = np.mgrid[line - off_set:int(line_max + line), 0:int(samp_max)]
            else:
                V, U = np.mgrid[line - off_set:int(line_max + line), sample - off_set:int(samp_max + sample)]

            U1 = U.flatten()
            V1 = V.flatten()
            X = fx.ev(U1, V1)
            Y = fy.ev(U1, V1)


            Xmin = int(X.min())
            Xmax = int(np.ceil(X.max()))
            Ymin = int(Y.min())
            Ymax = int(np.ceil(Y.max()))
            strx = int(max(Xmin, 0))
            stpx = min(Xmax + 1, im_width)

            stry = max(Ymin, 0)
            stpy = min(Ymax + 1, im_height)

            # print "[%d] Used the data from (%d,%d)->(%d,%d)"%(band+1,strx,stry,stpx,stpy)
            # maskxy = np.zero_like(U,'uint8')
            x_file_name = None
            y_file_name = None
            # print "Before:", mask_data[line:line+line_max,sample:sample+samp_max].max(), mask_data[line:line+line_max,sample:sample+samp_max].min()
            if (strx < stpx) & (stry < stpy):
                # original = databand[stry:stpy,strx:stpx]
                tr, tc = U.shape
                X = X.astype('float32')
                Y = Y.astype('float32')
                # remap_out = cv2.remap(original,X-strx,Y-stry,cv2.INTER_CUBIC,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
                # print remap_out.shape
                # print temp[(X>=X.min())*(X<=X.max())*(Y>=Y.min())*(Y<=Y.max())].shape
                X = X.reshape(tr, tc)
                Y = Y.reshape(tr, tc)
                # temp[(X>=X.min())*(X<=X.max())*(Y>=Y.min())*(Y<=Y.max())] = remap_out.flatten()
                maskxy = (X >= 0) * (Y >= 0) * (X <= im_width - 1) * (Y <= im_height - 1)
                xout = X.copy()
                yout = Y.copy()
                if (line == 0) & (sample == 0):
                    # outimage_data = temp
                    maskxy = maskxy


                elif (line == 0):
                    # outimage_data = temp[:,off_set:]
                    maskxy = maskxy[:, off_set:]
                    xout = xout[:, off_set:]
                    yout = yout[:, off_set:]


                elif (sample == 0):
                    # outimage_data = temp[off_set:,:]
                    maskxy = maskxy[off_set:, :]
                    xout = xout[off_set:, :]
                    yout = yout[off_set:, :]
                else:
                    # outimage_data = temp[off_set:,off_set:]
                    maskxy = maskxy[off_set:, off_set:]
                    xout = xout[off_set:, off_set:]
                    yout = yout[off_set:, off_set:]

                x_file_name = in_file_name + "X_BandPAN_Line%d_Sample%d.npy" % (line, sample)
                y_file_name = in_file_name + "Y_BandPAN_Line%d_Sample%d.npy" % (line, sample)
                np.save(x_file_name, xout)
                np.save(y_file_name, yout)
                # block_info_filep.writelines("%d, %d, %d, %d"%(line, sample, line_max, samp_max))
            band_map_info.append([line, sample, line_max, samp_max, x_file_name, y_file_name])

    band_map_info_array = np.array(band_map_info)
    # np.save(in_file_name + "_map_info_band_%d.npy" % (band + 1), band_map_info_array)
    print "Done."

    return band_map_info_array



def buildPAN2AImageUsingCubicInterpolation(out_file_name, in_file_name, beg_line, current_date, utc_gps, dut1, dem,
                                           filter2D, gain, dark_cur, start_sample=1, im_width=12000, im_height=12000,
                                           save_dem=True, dem_interpolation_method=demserice.digitalElevationModel.CUBIC):


    line = beg_line
    end_sample = start_sample + im_width - 1
    if (end_sample > 12000) or (start_sample < 1) :
        print "The intended sample is beyond the scope of the recorded GER file."
    # start_sample = start_sample-1
    # check number of line
    sat_times = np.loadtxt(in_file_name + ".tim")
    line_max = len(sat_times)
    im_height = min(line_max - beg_line, im_height)

    latc, lonc, heightc = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name,
                                                                    np.array([(end_sample + start_sample) / 2]),
                                                                    np.array([line + im_height / 2]), current_date,
                                                                    utc_gps, dut1, dem, dem_interpolation_method)
    xc, yc, zonec, zoneletter = utm.from_latlon(latc, lonc)

    # Upper left
    latul, lonul, heightul = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([start_sample]),
                                                                    [line], current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method)
    xul, yul, zoneul, zoneletter = utm.from_latlon(latul, lonul, zonec)
    print "original image upper left UTM:", xul, yul

    latur, lonur, heightur = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([end_sample]), [line],
                                                                    current_date, utc_gps, dut1, dem, dem_interpolation_method)
    xur, yur, zoneur, zoneletter = utm.from_latlon(latur, lonur, zonec)
    print "original image upper right UTM:", xur, yur
    latll, lonll, heightll = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([start_sample]),
                                                                    [line + im_height], current_date, utc_gps, dut1,
                                                                    dem, dem_interpolation_method)
    xll, yll, zonell, zoneletter = utm.from_latlon(latll, lonll, zonec)
    print "original image lower left UTM:", xll, yll

    latlr, lonlr, heightlr = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([end_sample]),
                                                                    [line + im_height], current_date, utc_gps, dut1,
                                                                    dem, dem_interpolation_method)
    xlr, ylr, zonelr, zoneletter_c = utm.from_latlon(latlr, lonlr, zonec)
    print "original image lower right UTM:", xlr, ylr



    latgrid, longrid, hgrid = dem.getValuesFromRetangularArea(latul, lonll, latlr,
                                                              lonur)  # util.load_dem_data(upleft_lat_lon,lowright_lat_lon,dem_directory)
    # dem_temp = util.load_dem_file(13,100,dem_directory)
    # pixel_size = dem_temp.GetGeoTransform()[1]/3600.
    hmin = hgrid.min()
    hmax = hgrid.max()

    print "The Minimum and maximum altitude of the scene is: %f and %f meters, respectively." % (hmin, hmax)
    num_lines = (yul - ylr) / 2.0 + 1
    num_samples = (xur - xll) / 2.0 + 1
    # determine the mapping function.
    x2_up_left = xll
    y2_up_left = yul
    dx2 = 2.0
    dy2 = -2.0

    gtiffDriver = gdal.GetDriverByName('GTiff')
    lv_width = int(np.ceil(num_samples))
    lv_height = int(np.ceil(num_lines))

    lv2_geotrans = [x2_up_left, y2_up_left, dx2, dy2, zonec]


    step_sample = 50  # im_width/200 # Smaller than 200 is faster, but less accurate
    step_line = 50  # im_height/200

    gain_numbers = np.loadtxt(in_file_name + ".gain").astype('int')
    nlines = gain_numbers.shape[0]
    glo = gain_numbers[:, 0].reshape((nlines, 1))
    gle = gain_numbers[:, 1].reshape((nlines, 1))
    gro = gain_numbers[:, 2].reshape((nlines, 1))
    gre = gain_numbers[:, 3].reshape((nlines, 1))

    in_im = gdal.Open(in_file_name + ".tif")
    max_width = in_im.RasterXSize
    band1 = in_im.GetRasterBand(1)
    ger_height = in_im.RasterYSize
    databand = np.zeros((im_height, im_width), 'float32')
    print "Perform image filtering...",
    x_sampels = np.hstack((np.arange(0, im_width, step_sample), np.array([im_width - 1])))
    y_sampels = np.hstack((np.arange(0, im_height, step_line), np.array([im_height - 1])))
    num_pairs = len(x_sampels) * len(y_sampels)
    for k in range(0, im_height, 1000):
        for m in range(0, im_width, 1000):
            # print "Building block (%d,%d)......" % (k, m)
            y_min = max(0, beg_line + k - 100)
            x_min = max(0, m - 100 + start_sample)
            x_off_l = start_sample + m - x_min
            y_off_l = beg_line + k - y_min
            x_max = min(max_width, m + 1000 + 100 + start_sample)
            y_max = min(ger_height, min(beg_line + im_height + 20, beg_line + k + 1000 + 100))
            load_width = x_max - x_min
            load_height = y_max - y_min
            one_block = band1.ReadAsArray(x_min, y_min, load_width, load_height)
            pixels = np.arange(x_min, x_min + load_width).reshape((1, load_width))
            gns = glo[y_min:(y_min + load_height), :] * (pixels < 6000) * (pixels % 2 == 0) + \
                  gle[y_min:(y_min + load_height), :] * (pixels < 6000) * (pixels % 2 == 1) + \
                  gro[y_min:(y_min + load_height), :] * (pixels >= 6000) * (pixels % 2 == 0) + \
                  gre[y_min:(y_min + load_height), :] * (pixels >= 6000) * (pixels % 2 == 1)


            pix_gain = np.zeros_like(one_block, 'float32')
            pix_drk = np.zeros_like(one_block, 'float32')
            for idg in range(len(gain)):
                pix_gain = pix_gain + (gns == (idg)) * gain[idg][pixels]
                pix_drk = pix_drk + (gns == (idg)) * dark_cur[idg][pixels]
            # print gain[2][pixels], pix_gain, pix_gain.min(), pix_gain.max()
            # print np.nonzero(pix_gain == 0.0)
            # pix_gain = gain[gns]
            # pix_drk = dark_cur[gns]
            one_block = one_block.astype('float32')
            one_block = (one_block - pix_drk) / pix_gain
            one_block = one_block.astype('float32')
            summ = cv2.GaussianBlur(one_block.astype('uint8'), (3, 3),
                                    3.3)  # cv2.filter2D(org_image,cv2.CV_32F,kernel, borderType=cv2.BORDER_REFLECT)
            edges = cv2.Canny(summ.astype('uint8'), 4, 8, L2gradient=False)
            edges = cv2.filter2D(edges, cv2.CV_8U, np.ones((7, 7)))

            # summ = cv2.filter2D(one_block, cv2.CV_32F, np.ones((3, 3), 'float32') / 9.0, borderType=cv2.BORDER_REFLECT)
            kernel = np.ones((3, 3), 'float32') / 9.0
            summ = signal.convolve2d(one_block, kernel, mode='same', fillvalue=0.0)
            gradient = np.abs(one_block - summ) * (edges > 0)  # np.sqrt(sumsq - (summ) ** 2) #np.abs(gradient) #
            # gradient = cv2.filter2D(gradient,cv2.CV_32F, np.ones((3, 3), 'float32') /9.0, borderType=cv2.BORDER_REFLECT)
            gradient[0, :] = 0
            gradient[1, :] = 0
            gradient[-1, :] = 0
            gradient[-2, :] = 0
            gradient[:, 0] = 0
            gradient[:, 1] = 0
            gradient[:, -1] = 0
            gradient[:, -2] = 0
            my_filter_im = np.zeros_like(one_block).astype('float32')
            idx, idy = np.nonzero(gradient < 0.75)
            my_filter_im[idx, idy] = one_block[idx, idy]
            idx, idy = np.nonzero((gradient >= 0.75) * (gradient < 1.25))
            tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[3], borderType=cv2.BORDER_REFLECT)
            my_filter_im[idx, idy] = tem[idx, idy]
            idx, idy = np.nonzero((gradient >= 1.25) * (gradient < 1.75))
            tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[4], borderType=cv2.BORDER_REFLECT)
            my_filter_im[idx, idy] = tem[idx, idy]
            idx, idy = np.nonzero((gradient >= 1.75) * (gradient < 2.25))
            tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[5], borderType=cv2.BORDER_REFLECT)
            my_filter_im[idx, idy] = tem[idx, idy]
            idx, idy = np.nonzero((gradient >= 2.25))
            tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[6], borderType=cv2.BORDER_REFLECT)
            my_filter_im[idx, idy] = tem[idx, idy]
            filtered_im = my_filter_im.copy()  # np.round((my_filter_im > 0) * (my_filter_im < 255) * my_filter_im + 255 * (my_filter_im >= 255))
            # filtered_im = cv2.filter2D(one_block, cv2.CV_8UC1, filter2D)
            # print y_off_l, x_off_l
            used_ar = filtered_im[y_off_l:y_off_l + 1000, x_off_l:x_off_l + 1000].astype('float32')
            rw, cl = used_ar.shape
            databand[k:k + rw, m:m + cl] = used_ar
    # try to load the LV2A and GER pixel pairs for both lowest and highest altitude.
    print "Done!"
    # cv2.imwrite(in_file_name + "temp.tif", databand.astype('uint8'))
    all_file_exist = os.path.isfile(in_file_name + "ger_pair_line%d.txt" % beg_line) and \
                     os.path.isfile(in_file_name + "lv2_pair_min_altitude_line%d.txt" % beg_line) and \
                     os.path.isfile(in_file_name + "lv2_pair_max_altitude_line%d.txt" % beg_line)
    if all_file_exist:
        print "Attempt to load files containing Level 2A and GER pixel paris..."
        ger_pairs = np.loadtxt(in_file_name + "ger_pair_line%d.txt" % (beg_line))
        lv2_pairs_min = np.loadtxt(in_file_name + "lv2_pair_min_altitude_line%d.txt" % (beg_line))
        lv2_pairs_max = np.loadtxt(in_file_name + "lv2_pair_max_altitude_line%d.txt" % (beg_line))
    else:
        ger_pairs = np.zeros((num_pairs, 2))
        lv2_pairs_min = np.zeros((num_pairs, 2))
        lv2_pairs_max = np.zeros((num_pairs, 2))
        print "The matching pair files have not been created."
        print "Generating the matching pair database."
        cnt = 0
        for s_line in y_sampels:
            print "find matching pairs of line %d" % s_line
            s_samples = x_sampels + start_sample
            lata_min, lona_min, ha = dps.findInterSectionPointArrayGivenAltitude("PAN", in_file_name, s_samples, [line + s_line], hmin,
                                                                       current_date, utc_gps, dut1)
            lata_max, lona_max, ha = dps.findInterSectionPointArrayGivenAltitude("PAN", in_file_name, s_samples, [line + s_line], hmax,
                                                                       current_date, utc_gps, dut1)

            num_s = s_samples.shape[0]
            x, y, z, zl = utmLatlon.from_latlon(lata_min, lona_min, zonec)
            cols = (x - x2_up_left) / dx2
            rows = (y - y2_up_left) / dy2
            str = cnt * num_s
            stp = str + num_s
            lv2_pairs_min[str:stp, 0] = cols
            lv2_pairs_min[str:stp, 1] = rows

            x, y, z, zl = utmLatlon.from_latlon(lata_max, lona_max, zonec)
            cols = (x - x2_up_left) / dx2
            rows = (y - y2_up_left) / dy2

            lv2_pairs_max[str:stp, 0] = cols
            lv2_pairs_max[str:stp, 1] = rows

            ger_pairs[str:stp, 0] = s_samples - 1
            ger_pairs[str:stp, 1] = s_line
            cnt += 1

        print "completed...saving to files."
        np.savetxt(in_file_name + "ger_pair_line%d.txt" % (beg_line), ger_pairs)
        np.savetxt(in_file_name + "lv2_pair_min_altitude_line%d.txt" % (beg_line), lv2_pairs_min)
        np.savetxt(in_file_name + "lv2_pair_max_altitude_line%d.txt" % (beg_line), lv2_pairs_max)

    dem_file_name = in_file_name + "DEM_%d.tif" % beg_line
    if os.path.isfile(dem_file_name):
        print "DEM file exits!"
        print "Loading......",
        dem_ds_im = gdal.Open(dem_file_name)
        dem_ds = dem_ds_im.GetRasterBand(1)
        print "done!"
    else:
        print "DEM file does not exist. Create a new DEM file."
        dem_ds_im = gtiffDriver.Create(dem_file_name, lv_width, lv_height, 1, gdal.GDT_Float32)
        dem_ds = dem_ds_im.GetRasterBand(1)
        mem = psutil.virtual_memory()
        mem_available = mem.available
        max_num_pixels_dem = (mem_available - 1024 * 1024 * 1024) / (
        (400) * 8)  # 400 memory block per pixels and 8 for double
        block_num_lines = int(np.sqrt(max_num_pixels_dem))
        block_num_pixels = block_num_lines
        off_set = 10
        block_num_lines2 = block_num_lines + off_set
        block_num_pixels2 = block_num_pixels + off_set
        for line in range(0, lv_height, block_num_lines):
            for sample in range(0, lv_width, block_num_pixels):

                # sample = 9402

                # line =0
                line_max = min((lv_height - line), block_num_lines2)
                samp_max = min(lv_width - sample, block_num_pixels2)
                if (line == 0) & (sample == 0):
                    V, U = np.mgrid[0:int(line_max), 0:int(samp_max)]
                elif (line == 0) & (sample > 0):
                    V, U = np.mgrid[0:int(line_max), sample - off_set:int(samp_max + sample)]
                elif (line > 0) & (sample == 0):

                    V, U = np.mgrid[line - off_set:int(line_max + line), 0:int(samp_max)]
                else:
                    V, U = np.mgrid[line - off_set:int(line_max + line), sample - off_set:int(samp_max + sample)]
                temp = np.zeros_like(U, 'uint8')
                u_earth = U * dx2 + x2_up_left
                v_earth = V * dy2 + y2_up_left
                late, lone = utmLatlon.to_latlon(u_earth, v_earth, zonec, zoneletter_c)


                # h = util.determineHeight(late,lone,dem_directory)
                print "[DEM]  coord:", late.min(), late.max(), lone.min(), lone.max()
                h = dem.interpolate(late, lone, dem_interpolation_method)
                ofx = off_set * (sample != 0)
                ofy = off_set * (line != 0)
                dem_out = h[ofy:, ofx:].astype('float32')
                print "sample:%d, line:%d" % (sample, line), h.shape
                dem_ds.WriteArray(dem_out, sample, line)
        dem_ds_im = None
        dem_ds_im = gdal.Open(dem_file_name)
        dem_ds = dem_ds_im.GetRasterBand(1)

    band_map_info = findLV2RemapFuncitionPANWithInterpolation(in_file_name, beg_line, ger_pairs, lv2_pairs_min, lv2_pairs_max,
                                              lv2_geotrans, dem_ds, hmin, hmax, current_date, utc_gps, dut1, lv_width,
                                              lv_height, im_width, im_height)

    #
    # resampling in y-direction
    gtiffDriver = gdal.GetDriverByName('GTiff')

    dst_ds = gtiffDriver.Create(out_file_name, lv_width, lv_height , 1, gdal.GDT_Byte)
    pan_b1 = dst_ds.GetRasterBand(1)


    # compute remap coordinate
    # We will remap for a 1000 lines at at time
    off_set = 10
    mem = psutil.virtual_memory()
    mem_available = mem.available
    max_num_pixels = 0.8 * (mem_available - (1024 * 1024 * 1024)) / ((400) * 8)  # 400 memory block per pixels and 8 for double
    num_lines = int(np.sqrt(max_num_pixels))
    num_pixels = num_lines
    print "The maximum number of lines and pixels are: %d,%d. " % (num_lines, num_pixels)



    pan_data = np.zeros((lv_height, lv_width), 'uint8')
    mask_data = np.zeros((lv_height, lv_width), 'uint8')

    for line, sample, line_max, samp_max, x_file_name, y_file_name in band_map_info:

        if (x_file_name is not None) and (y_file_name is not None):

            X = np.load(x_file_name)
            Y = np.load(y_file_name)
            Xmin = int(X.min())
            Xmax = int(np.ceil(X.max()))
            Ymin = int(Y.min())
            Ymax = int(np.ceil(Y.max()))
            strx = int(max(Xmin, 0))
            stpx = min(Xmax + 1, im_width)
            stry = max(Ymin, 0)
            stpy = min(Ymax + 1, im_height)
            temp = np.zeros_like(X)
            if (strx < stpx) & (stry < stpy):
                original = databand[stry:stpy, strx:stpx]
                remap_out = cv2.remap(original, X - strx, Y - stry, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                      borderValue=0)
                temp[(X >= X.min()) * (X <= X.max()) * (Y >= Y.min()) * (Y <= Y.max())] = remap_out.flatten()

                # band3.WriteArray(sample, line, ms_band_data)
                mk = (X > 0) * (X < im_width) * (Y > 0) * (Y < im_height)
                temp = 1 * (temp < 1) + 255 * (temp > 254.8) + temp * (temp >= 1) * (temp <= 254.8)
                temp = np.round(temp).astype('uint8')
                # temp = temp * mk

                pan_data[line:line + line_max, sample:sample + samp_max] = temp * mk
                mask_data[line:line + line_max, sample:sample + samp_max] = mk
            os.remove(x_file_name)
            os.remove(y_file_name)
        else:
            mask_data[line:line + line_max, sample:sample + samp_max] *= 0
    pan_b1.WriteArray(pan_data, 0, 0)

    avg_dem = 0.0
    num_nonzero_pixels = 0.0
    block_num_lines = 1000
    block_num_pixels = 1000
    for line in range(0, lv_height, block_num_lines):
        for sample in range(0, lv_width, block_num_pixels):
            line_max = min((lv_height - line), block_num_lines)
            samp_max = min(lv_width - sample, block_num_pixels)
            h = dem_ds.ReadAsArray(sample, line, samp_max, line_max)
            data = pan_data[line:(line + line_max), sample:(sample + samp_max)]
            mask = (data != 0).astype('float32')
            avg_dem += (h * mask).sum()
            num_nonzero_pixels += mask.sum()
    avg_dem /= num_nonzero_pixels
    print "Computing the vertices: "
    cl1 = np.round((xul - x2_up_left) / dx2) + 1
    rw1 = np.round((yul - y2_up_left) / dy2) + 1
    x1 = x2_up_left + dx2 * cl1
    y1 = y2_up_left + dy2 * rw1
    lat1, lon1 = utm.to_latlon(x1, y1, zonec, zoneletter_c)

    cl2 = np.round((xur - x2_up_left) / dx2) + 1
    rw2 = np.round((yur - y2_up_left) / dy2) + 1
    x2 = x2_up_left + dx2 * cl2
    y2 = y2_up_left + dy2 * rw2
    lat2, lon2 = utm.to_latlon(x2, y2, zonec, zoneletter_c)

    cl3 = np.round((xll - x2_up_left) / dx2) + 1
    rw3 = np.round((yll - y2_up_left) / dy2) + 1
    x3 = x2_up_left + dx2 * cl3
    y3 = y2_up_left + dy2 * rw3
    lat3, lon3 = utm.to_latlon(x3, y3, zonec, zoneletter_c)

    cl4 = np.round((xlr - x2_up_left) / dx2) + 1
    rw4 = np.round((ylr - y2_up_left) / dy2) + 1
    x4 = x2_up_left + dx2 * cl4
    y4 = y2_up_left + dy2 * rw4
    lat4, lon4 = utm.to_latlon(x4, y4, zonec, zoneletter_c)

    cl5 = np.round((xc - x2_up_left) / dx2) + 1
    rw5 = np.round((yc - y2_up_left) / dy2) + 1
    x5 = x2_up_left + dx2 * cl5
    y5 = y2_up_left + dy2 * rw5
    lat5, lon5 = utm.to_latlon(x5, y5, zonec, zoneletter_c)
    print "Upper left vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw1, cl1)
    print "FRAME_X: %e, FRAME_COL: %e" % (x1, y1)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon1, lat1)
    print ".........................................................."

    print "Upper right vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw2, cl2)
    print "FRAME_X: %e, FRAME_COL: %e" % (x2, y2)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon2, lat2)
    print ".........................................................."

    print "Lower left vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw3, cl3)
    print "FRAME_X: %e, FRAME_COL: %e" % (x3, y3)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon3, lat3)
    print ".........................................................."

    print "Lower right vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw4, cl4)
    print "FRAME_X: %e, FRAME_COL: %e" % (x4, y4)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon4, lat4)
    print ".........................................................."

    print "Scene center.............................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw5, cl5)
    print "FRAME_X: %e, FRAME_COL: %e" % (x5, y5)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon5, lat5)
    print ".........................................................."
    dst_ds.SetGeoTransform([ x2_up_left, 2.0, 0, y2_up_left, 0, -2.0 ])
    srs = osr.SpatialReference()
    srs.SetWellKnownGeogCS("WGS84")
    if (lat5 >= 0) :
        srs.SetUTM(zonec, 1)
    else :
        srs.SetUTM(zonec, 0)

    dst_ds.SetProjection(srs.ExportToWkt())

    upleft = [[cl1, rw1], [x1, y1], [lon1, lat1]]
    upright = [[cl2, rw2], [x2, y2], [lon2, lat2]]
    midpoint = [[cl5, rw5], [x5, y5], [lon5, lat5]]
    lowleft = [[cl3, rw3], [x3, y3], [lon3, lat3]]
    lowright = [[cl4, rw4], [x4, y4], [lon4, lat4]]
    map_info = [x2_up_left, y2_up_left, 2.0, 2.0, avg_dem, zonec, (lat5 >= 0)]
    return upleft, upright, midpoint, lowleft, lowright, map_info


def computePANImageCorners(out_file_name, in_file_name, beg_line, current_date, utc_gps, dut1, dem, dem_interpolation_method,
                                         filter2D, start_sample=1, im_width=12000, im_height=12000):



    line = beg_line
    end_sample = start_sample + im_width - 1
    if (end_sample > 12000) or (start_sample < 1) :
        print "The intended sample is beyond the scope of the recorded GER file."
    start_sample = start_sample

    latc, lonc, heightc = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name,
                                                                 np.array([(end_sample + start_sample) / 2]),
                                                                 np.array([line + im_height / 2]), current_date,
                                                                 utc_gps, dut1, dem, dem_interpolation_method)
    xc, yc, zonec, zoneletter = utm.from_latlon(latc, lonc)

    # Upper left
    latul, lonul, heightul = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([start_sample]),
                                                                    [line], current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method)
    xul, yul, zoneul, zoneletter = utm.from_latlon(latul, lonul, zonec)
    print "original image upper left UTM:", xul, yul

    latur, lonur, heightur = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([end_sample]), [line],
                                                                    current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method)
    xur, yur, zoneur, zoneletter = utm.from_latlon(latur, lonur, zonec)
    print "original image upper right UTM:", xur, yur
    latll, lonll, heightll = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([start_sample]),
                                                                    [line + im_height], current_date, utc_gps, dut1,
                                                                    dem, dem_interpolation_method)
    xll, yll, zonell, zoneletter = utm.from_latlon(latll, lonll, zonec)
    print "original image lower left UTM:", xll, yll

    latlr, lonlr, heightlr = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([end_sample]),
                                                                    [line + im_height], current_date, utc_gps, dut1,
                                                                    dem, dem_interpolation_method)
    xlr, ylr, zonelr, zoneletter_c = utm.from_latlon(latlr, lonlr, zonec)
    print "original image lower right UTM:", xlr, ylr

    latgrid, longrid, hgrid = dem.getValuesFromRetangularArea(latul, lonll, latlr,
                                                              lonur)  # util.load_dem_data(upleft_lat_lon,lowright_lat_lon,dem_directory)
    # dem_temp = util.load_dem_file(13,100,dem_directory)
    # pixel_size = dem_temp.GetGeoTransform()[1]/3600.
    hmin = hgrid.min()
    hmax = hgrid.max()
    num_lines = (yul - ylr) / 2.0 + 1
    num_samples = (xur - xll) / 2.0 + 1
    # determine the mapping function.
    x2_up_left = xll
    y2_up_left = yul
    dx2 = 2.0
    dy2 = -2.0

    cl1 = np.round((xul - x2_up_left) / dx2) + 1
    rw1 = np.round((yul - y2_up_left) / dy2) + 1
    x1 = x2_up_left + dx2 * cl1
    y1 = y2_up_left + dy2 * rw1
    lat1, lon1 = utm.to_latlon(x1, y1, zonec, zoneletter_c)

    cl2 = np.round((xur - x2_up_left) / dx2) + 1
    rw2 = np.round((yur - y2_up_left) / dy2) + 1
    x2 = x2_up_left + dx2 * cl2
    y2 = y2_up_left + dy2 * rw2
    lat2, lon2 = utm.to_latlon(x2, y2, zonec, zoneletter_c)

    cl3 = np.round((xll - x2_up_left) / dx2) + 1
    rw3 = np.round((yll - y2_up_left) / dy2) + 1
    x3 = x2_up_left + dx2 * cl3
    y3 = y2_up_left + dy2 * rw3
    lat3, lon3 = utm.to_latlon(x3, y3, zonec, zoneletter_c)

    cl4 = np.round((xlr - x2_up_left) / dx2) + 1
    rw4 = np.round((ylr - y2_up_left) / dy2) + 1
    x4 = x2_up_left + dx2 * cl4
    y4 = y2_up_left + dy2 * rw4
    lat4, lon4 = utm.to_latlon(x4, y4, zonec, zoneletter_c)

    cl5 = np.round((xc - x2_up_left) / dx2) + 1
    rw5 = np.round((yc - y2_up_left) / dy2) + 1
    x5 = x2_up_left + dx2 * cl5
    y5 = y2_up_left + dy2 * rw5
    lat5, lon5 = utm.to_latlon(x5, y5, zonec, zoneletter_c)
    print "Upper left vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw1, cl1)
    print "FRAME_X: %e, FRAME_COL: %e" % (x1, y1)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon1, lat1)
    print ".........................................................."

    print "Upper right vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw2, cl2)
    print "FRAME_X: %e, FRAME_COL: %e" % (x2, y2)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon2, lat2)
    print ".........................................................."

    print "Lower left vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw3, cl3)
    print "FRAME_X: %e, FRAME_COL: %e" % (x3, y3)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon3, lat3)
    print ".........................................................."

    print "Lower right vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw4, cl4)
    print "FRAME_X: %e, FRAME_COL: %e" % (x4, y4)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon4, lat4)
    print ".........................................................."

    print "Scene center.............................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw5, cl5)
    print "FRAME_X: %e, FRAME_COL: %e" % (x5, y5)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon5, lat5)
    print ".........................................................."

    upleft = [[cl1, rw1], [x1, y1], [lon1, lat1]]
    upright = [[cl2, rw2], [x2, y2], [lon2, lat2]]
    midpoint = [[cl5, rw5], [x5, y5], [lon5, lat5]]
    lowleft = [[cl3, rw3], [x3, y3], [lon3, lat3]]
    lowright = [[cl4, rw4], [x4, y4], [lon4, lat4]]
    dem_file_name = in_file_name + "DEM_%d.tif" % beg_line
    pan_im = gdal.Open(out_file_name)
    pan_b1 = pan_im.GetRasterBand(1)
    avg_dem = 0.0
    num_nonzero_pixels = 0.0
    block_num_lines = 1000
    block_num_pixels = 1000
    lv_height = pan_im.RasterYSize
    lv_width = pan_im.RasterXSize
    dem_im = gdal.Open(dem_file_name)
    dem_ds = dem_im.GetRasterBand(1)
    for line in range(0, lv_height, block_num_lines):
        for sample in range(0, lv_width, block_num_pixels):
            line_max = min((lv_height - line), block_num_lines)
            samp_max = min(lv_width - sample, block_num_pixels)
            h = dem_ds.ReadAsArray(sample, line, samp_max, line_max)
            data = pan_b1.ReadAsArray(sample, line, samp_max, line_max)
            mask = (data != 0).astype('float32')
            avg_dem += (h * mask).sum()
            num_nonzero_pixels += mask.sum()
    avg_dem /= num_nonzero_pixels


    map_info = [x2_up_left, y2_up_left, 2.0, 2.0, avg_dem, zonec, (lat5 >= 0)]

    return upleft, upright, midpoint, lowleft, lowright, map_info


def buildMSForPanSharpenImageUsingCubicInterpolation(out_file_name, pan_out_file, pan_in_file_name, ms_in_file_name,
                                                     pansharpen_info_dir, beg_line_pan,
                                                     current_date, utc_gps, dut1, dem_directory, start_sample=1,
                                                     im_width=12000, im_height=12000, ms_width_max=6000, ms_height_max=6000):


    pan_line = beg_line_pan
    # ms_lines = beg_line_ms
    end_sample = start_sample + im_width - 1
    if (end_sample > 12000) or (start_sample < 1) :
        print "The intended sample is beyond the scope of the recorded GER file."
    # start_sample = start_sample-1
    # compute pan scene information
    latc, lonc, heightc = dps.findInterSectionPointArrayUsingKriging("PAN", pan_in_file_name,
                                                                    np.array([(end_sample + start_sample) / 2]),
                                                                    np.array([pan_line + im_height / 2]), current_date,
                                                                    utc_gps, dut1, dem_directory)
    xc, yc, zonec, zoneletter = utm.from_latlon(latc, lonc)

    # Upper left
    latul, lonul, heightul = dps.findInterSectionPointArrayUsingKriging("PAN", pan_in_file_name, np.array([start_sample]), [pan_line], current_date, utc_gps, dut1, dem_directory)
    xul, yul, zoneul, zoneletter = utm.from_latlon(latul, lonul, zonec)
    print "original image upper left UTM:", xul, yul

    latur, lonur, heightur = dps.findInterSectionPointArrayUsingKriging("PAN", pan_in_file_name, np.array([end_sample]), [pan_line], current_date, utc_gps, dut1, dem_directory)
    xur, yur, zoneur, zoneletter = utm.from_latlon(latur, lonur, zonec)
    print "original image upper right UTM:", xur, yur
    latll, lonll, heightll = dps.findInterSectionPointArrayUsingKriging("PAN", pan_in_file_name, np.array([start_sample]), [pan_line + im_height], current_date, utc_gps, dut1, dem_directory)
    xll, yll, zonell, zoneletter = utm.from_latlon(latll, lonll, zonec)
    print "original image lower left UTM:", xll, yll

    latlr, lonlr, heightlr = dps.findInterSectionPointArrayUsingKriging("PAN", pan_in_file_name, np.array([end_sample]), [pan_line + im_height], current_date, utc_gps, dut1, dem_directory)
    xlr, ylr, zonelr, zoneletter_c = utm.from_latlon(latlr, lonlr, zonec)
    print "original image lower right UTM:", xlr, ylr

    print "original image center UTM:", xc, yc

    hmin, hmax = util.findMinMaxHeight([latul, lonul], [latlr, lonlr], dem_directory)
    print "The Minimum and maximum altitude of the scene is: %f and %f meters, respectively." % (hmin, hmax)
    num_lines = (yul - ylr) / 2.0 + 1
    num_samples = (xur - xll) / 2.0 + 1
    # determine the mapping function.
    x2_up_left = xll
    y2_up_left = yul
    dx2 = 2.0
    dy2 = -2.0
    dem_temp = util.load_dem_file(13, 99, dem_directory)
    pixel_size = dem_temp.GetGeoTransform()[1] / 3600.
    gtiffDriver = gdal.GetDriverByName('GTiff')
    lv_width = int(num_samples)
    lv_height = int(num_lines)
    # dem_ds_im = gtiffDriver.Create(pan_in_file_name+"_dem.tif", lv_width, lv_height , 1, gdal.GDT_Float32)
    # dem_ds = dem_ds_im.GetRasterBand(1)


    # find the begining and end line of MS
    ms_lines = []
    aline = np.arange(6000) + 1
    print "Find the beginning line....."
    for band in [1, 2, 3, 4]:
        print "Band:%d" % (band)
        ms_im = gdal.Open(ms_in_file_name + "B%d.tif" % band)
        raw_height = ms_im.RasterYSize
        raw_width = ms_im.RasterXSize
        dis = []

        for line in range(0, raw_height, 1000):
            latms, lonms, h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline, [line], heightul,
                                                                        current_date, utc_gps, dut1, band)
            dist1 = np.sqrt((latms - latul) ** 2 + (lonms - lonul) ** 2)
            dist1 = dist1.min()
            dis.append(dist1)
        dis = np.array(dis)
        best_k = np.nonzero(dis == dis.min())[0][0]
        dis = []
        km1 = max(0, best_k - 1) * 1000
        kp1 = min((best_k + 1) * 1000, raw_height)
        print "     The best line is between %d and %d" % (km1, kp1)
        for line in range(km1, kp1, 100):
            latms, lonms, h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline, [line], heightul,
                                                                          current_date, utc_gps, dut1, band)
            dist1 = np.sqrt((latms - latul) ** 2 + (lonms - lonul) ** 2)
            dist1 = dist1.min()
            dis.append(dist1)
        dis = np.array(dis)
        best_k = np.nonzero(dis == dis.min())[0][0]
        kp1 = km1 + min((best_k + 1) * 100, raw_height)
        km1 = km1 + max(0, best_k - 1) * 100
        print "     The best line is between %d and %d" % (km1, kp1)
        dis = []
        for line in range(km1, kp1, 10):
            latms, lonms, h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline, [line],
                                                                          heightul,
                                                                          current_date, utc_gps, dut1, band)
            dist1 = np.sqrt((latms - latul) ** 2 + (lonms - lonul) ** 2)
            dist1 = dist1.min()
            dis.append(dist1)
        dis = np.array(dis)
        best_k = np.nonzero(dis == dis.min())[0][0]

        kp1 = km1 + min((best_k + 1) * 10, raw_height)
        km1 = km1 + max(0, best_k - 1) * 10
        print "     The best line is between %d and %d" % (km1, kp1)
        dis = []
        for line in range(km1, kp1):
            latms, lonms, h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline, [line],
                                                                          heightul,
                                                                          current_date, utc_gps, dut1, band)
            dist1 = np.sqrt((latms - latul) ** 2 + (lonms - lonul) ** 2)
            dist1 = dist1.min()
            dis.append(dist1)
        dis = np.array(dis)
        best_k = np.nonzero(dis == dis.min())[0][0]
        best_line = best_k + km1
        latms, lonms, h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline, [best_line],
                                                                      heightul,
                                                                      current_date, utc_gps, dut1, band)
        dist1 = np.sqrt((latms - latul) ** 2 + (lonms - lonul) ** 2)
        opt_samples = np.nonzero(dist1 == dist1.min())[0][0]

        print "best line:%d for band %d at sample %d" % (best_k + km1 - 5, band, opt_samples)
        ms_lines.append(best_k + km1 - 5)

    print ms_lines

    # We need to link MS to PAN
    ms_step_sample = 30  # Smaller than  is faster, but less accurate
    ms_step_line = 30

    ms_width = (min(6000, ms_width_max) / ms_step_sample) * ms_step_sample
    ms_height = (min(ms_height_max, int(im_height * 1.1 / 7.5)) / ms_step_line) * ms_step_line

    num_pairs = (ms_height / ms_step_line + 1) * (ms_width / ms_step_sample + 1)


    cnt = 0

    try:
        lv2_pair_min_list = []
        lv2_pair_max_list = []
        print "try to find the matching image pair file for ger file."
        ger_pairs = np.loadtxt(pansharpen_info_dir + "/ger_pairpansharp%d.txt" % beg_line_pan)
        for band in [1, 2, 3, 4]:
            print "try to load matching image pair files for MS Band %d." % band
            lv2_pairs_min = np.loadtxt(pansharpen_info_dir + "/B%dpansharp_pair_min%d.txt" % (band, beg_line_pan))
            lv2_pairs_max = np.loadtxt(pansharpen_info_dir + "/B%dpansharp_pair_max%d.txt" % (band, beg_line_pan))
            lv2_pair_min_list.append(lv2_pairs_min)
            lv2_pair_max_list.append(lv2_pairs_max)


    except:
        lv2_pair_min_list = []
        lv2_pair_max_list = []
        print "The matching pair files have not been created."
        print "Generating the matching pair database."
        x_sampels = np.hstack((np.arange(0, ms_width, ms_step_sample), np.array([ms_width - 1])))
        y_sampels = np.hstack((np.arange(0, ms_height, ms_step_line), np.array([ms_height - 1])))

        ger_pairs = np.zeros((num_pairs, 2))

        for band in [1, 2, 3, 4]:
            cnt = 0
            lv2_pairs_min = np.zeros((num_pairs, 2))
            lv2_pairs_max = np.zeros((num_pairs, 2))
            for s_line in y_sampels:
                print "find matching pairs of line %d" % s_line
                s_samples = x_sampels

                lata_min, lona_min, ha = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, s_samples,
                                                                                     [ms_lines[band - 1] + s_line], hmin,
                                                                                     current_date, utc_gps, dut1,
                                                                                     band=band)
                lata_max, lona_max, ha = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, s_samples,
                                                                                     [ms_lines[band - 1] + s_line], hmax,
                                                                                     current_date, utc_gps, dut1,
                                                                                     band=band)

                num_s = s_samples.shape[0]
                x, y, z, zl = utmLatlon.from_latlon(lata_min, lona_min, zonec)
                cols = (x - x2_up_left) / dx2
                rows = (y - y2_up_left) / dy2
                str = cnt * num_s
                stp = str + num_s
                # print str, stp
                lv2_pairs_min[str:stp, 0] = cols
                lv2_pairs_min[str:stp, 1] = rows


                x, y, z, zl = utmLatlon.from_latlon(lata_max, lona_max, zonec)
                cols = (x - x2_up_left) / dx2
                rows = (y - y2_up_left) / dy2

                lv2_pairs_max[str:stp, 0] = cols
                lv2_pairs_max[str:stp, 1] = rows


                if band == 4:
                    ger_pairs[str:stp, 0] = s_samples
                    ger_pairs[str:stp, 1] = s_line
                cnt += 1
            lv2_pair_min_list.append(lv2_pairs_min)
            lv2_pair_max_list.append(lv2_pairs_max)
            np.savetxt(pansharpen_info_dir + "/B%dpansharp_pair_min%d.txt" % (band, beg_line_pan), lv2_pairs_min)
            np.savetxt(pansharpen_info_dir + "/B%dpansharp_pair_max%d.txt" % (band, beg_line_pan), lv2_pairs_max)

        print "completed...saving to files."
        np.savetxt(pansharpen_info_dir + "/ger_pairpansharp%d.txt" % beg_line_pan, ger_pairs)


    # Remove all pairs with out of the PAN scene

    numpairs = ger_pairs.shape[0]

    offsetlows = [0, 0, 0, 0]
    offsethighs = [0, 0, 0, 0]  # [offset1,offset2,0,offset4]

    lv2_pairs_min = lv2_pair_min_list
    lv2_pairs_max = lv2_pair_max_list  # [lv2_pairs1_max,lv2_pairs2_max,lv2_pairs3_max,lv2_pairs4_max]

    gtiffDriver = gdal.GetDriverByName('GTiff')
    lv_width = int(num_samples)
    lv_height = int(num_lines)
    dst_ds = gtiffDriver.Create(out_file_name, lv_width, lv_height, 4, gdal.GDT_Byte)
    gtiffDriver = gdal.GetDriverByName('GTiff')
    lv_width = int(num_samples)
    lv_height = int(num_lines)
    u_mean = num_samples / 2.0
    v_mean = num_lines / 2.0
    pan_file = gdal.Open(pan_out_file)
    band1_pan = pan_file.GetRasterBand(1)
    # dem_ds_im = gtiffDriver.Create(pan_in_file_name + "_dem%d.tif"%beg_line_pan, lv_width, lv_height, 1, gdal.GDT_Float32)
    dem_ds_im = gdal.Open(pan_in_file_name + "DEM_%d.tif" % beg_line_pan)
    dem_ds = dem_ds_im.GetRasterBand(1)

    for band in [0, 1, 2, 3]:
        u = lv2_pairs_min[band][:, 0]
        v = lv2_pairs_min[band][:, 1]
        # remove negative coordinate and larger than output image size
        idx = np.nonzero((u >= 0) * (v >= 0) * (u <= lv_width) * (v <= lv_height))
        idx = idx[0].flatten()
        u = u[idx]
        v = v[idx]
        gx = ger_pairs[idx, 0]
        gy = ger_pairs[idx, 1]
        num_pairs = len(idx)
        A = np.zeros((num_pairs, 12))

        u = u - u_mean
        v = v - v_mean + 1
        # print u.min(),u.max(),v.min(),v.max()
        A[:, 0] = 1.0
        A[:, 1] = u
        A[:, 2] = v
        A[:, 3] = u * v
        A[:, 4] = u ** 2
        A[:, 5] = v ** 2
        A[:, 6] = u * v * v
        A[:, 7] = v * u * u
        A[:, 8] = u ** 3
        A[:, 9] = v ** 3
        A[:, 10] = v * u ** 3
        A[:, 11] = u * v ** 3

        x_mean = 3000
        y_mean = 3000
        bx = gx - x_mean
        by = gy - y_mean
        a_x_min, errx, rnk, s = np.linalg.lstsq(A, bx)
        a_y_min, erry, rnk, s = np.linalg.lstsq(A, by)
        print errx, erry
        print A.shape
        print bx.shape
        print by.shape
        print "[%d] Minimun altitude average errors: %f,%f" % (band + 1, errx / numpairs, erry / num_pairs)

        u = lv2_pairs_max[band][:, 0]
        v = lv2_pairs_max[band][:, 1]

        # remove negative coordinate and larger than output image size
        idx = np.nonzero((u >= 0) * (v >= 0) * (u <= lv_width) * (v <= lv_height))
        idx = idx[0].flatten()
        print idx.shape
        u = u[idx]
        v = v[idx]
        gx = ger_pairs[idx, 0]
        gy = ger_pairs[idx, 1]
        num_pairs = len(idx)
        A = np.zeros((num_pairs, 12))

        u = u - u_mean
        v = v - v_mean + 1
        # print u.min(),u.max(),v.min(),v.max()
        A[:, 0] = 1.0
        A[:, 1] = u
        A[:, 2] = v
        A[:, 3] = u * v
        A[:, 4] = u ** 2
        A[:, 5] = v ** 2
        A[:, 6] = u * v * v
        A[:, 7] = v * u * u
        A[:, 8] = u ** 3
        A[:, 9] = v ** 3
        A[:, 10] = v * u ** 3
        A[:, 11] = u * v ** 3


        bx = gx - x_mean
        by = gy - y_mean
        a_x_max, errx, rnk, s = np.linalg.lstsq(A, bx)
        a_y_max, erry, rnk, s = np.linalg.lstsq(A, by)
        print "[%d] Maximum altitude average errors: %f,%f" % (band + 1, errx / numpairs, erry / num_pairs)

        if band == 0:
            bandk = dst_ds.GetRasterBand(3)
        elif band == 2:
            bandk = dst_ds.GetRasterBand(1)
        else:
            bandk = dst_ds.GetRasterBand(band + 1)



        # compute remap coordinate
        # We will remap for a 1000 lines at at time
        src_image = None
        src_image = gdal.Open(ms_in_file_name + "B%d.tif" % (band + 1))
        band_src = src_image.GetRasterBand(1)
        print src_image, band_src, (ms_in_file_name + "B%d.tif" % (band + 1))
        print  (0, offsetlows[band] + ms_lines[band], ms_width,
                                        ms_height + 200 + offsethighs[band] - offsetlows[band])
        databand = band_src.ReadAsArray(0, int(ms_lines[band]), ms_width, ms_height + 200)

        mem = psutil.virtual_memory()
        mem_available = mem.available
        max_num_pixels = (mem_available - (1024 * 1024 * 1024)) / ((400) * 8)  # 400 memory block per pixels and 8 for double
        num_lines = int(np.sqrt(max_num_pixels))
        num_pixels = num_lines
        print "[%d] The maximum number of lines and pixels are: %d,%d. " % (band + 1, num_lines, num_pixels)
        # num_lines = 1000
        # num_pixels = 1000
        off_set = 0
        num_lines2 = num_lines + off_set
        num_pixels2 = num_pixels + off_set
        print "num_line:%d, num_pixel:%d" % (num_lines2, num_pixels2)
        outimage = np.zeros((lv_height, lv_width), 'uint8')
        sat_pos = np.loadtxt(ms_in_file_name + "B%d.pos" % (band + 1))
        captured_time = np.loadtxt(ms_in_file_name + "B%d.tim" % (band + 1))
        sat_att = np.loadtxt(ms_in_file_name + "B%d.att" % (band + 1))

        for line in range(0, lv_height, num_lines):
            for sample in range(0, lv_width, num_pixels):
                # line = 9700
                # sample = 700

                line_max = min((lv_height - line), num_lines2)
                samp_max = min(lv_width - sample, num_pixels2)
                if (line == 0) & (sample == 0):
                    V, U = np.mgrid[0:int(line_max), 0:int(samp_max)]
                elif (line == 0) & (sample > 0):
                    V, U = np.mgrid[0:int(line_max), sample - off_set:int(samp_max + sample)]
                elif (line > 0) & (sample == 0):

                    V, U = np.mgrid[line - off_set:int(line_max + line), 0:int(samp_max)]
                else:
                    V, U = np.mgrid[line - off_set:int(line_max + line), sample - off_set:int(samp_max + sample)]

                temp = np.zeros_like(U, 'uint8')
                u_earth = U * dx2 + x2_up_left
                v_earth = V * dy2 + y2_up_left
                late, lone = utmLatlon.to_latlon(u_earth, v_earth, zonec, zoneletter_c)

                # h = util.determineHeight(late,lone,dem_directory)
                print "[%d]  coord:" % (band + 1), late.min(), late.max(), lone.min(), lone.max()
                latgrid, longrid, hgrid = util.load_dem_data(
                    [late.max() + 30 * pixel_size, lone.min() - 30. * pixel_size],
                    [late.min() - 30 * pixel_size, lone.max() + 30. * pixel_size], dem_directory)

                # if band == 0:
                #     h = util.interpolateDemGrid(late, lone, latgrid, longrid, hgrid, pixel_size)
                #
                #     #dem_data = np.zeros_like(U, "float64")
                #     ofx = off_set * (sample != 0)
                #     ofy = off_set * (line != 0)
                #     dem_out = h[ofy:, ofx:].astype('float64')
                #     print "sample:%d, line:%d" % (sample, line), h.shape
                #     dem_ds.WriteArray(dem_out, sample, line)
                # else:
                urw, ucl = U.shape
                dem_data = dem_ds.ReadAsArray(sample, line, ucl, urw)
                ofx = off_set * (sample != 0)
                ofy = off_set * (line != 0)
                h = np.zeros_like(U, 'float64')

                h[ofy:, ofx:] = dem_data[:urw - ofy, :ucl - ofx]
                print "[%d] remapping line: %d to %d and sample: %d to %d" % (
                band + 1, line, line + line_max, sample, sample + samp_max)


                U = U - u_mean
                V = V - v_mean

                U = U.flatten()
                V = V.flatten()
                h = h.flatten()
                X, Y = dps.findGerFileLocationPreLoadFiles(U, V, h, a_x_min, a_y_min, a_x_max, a_y_max, x_mean, y_mean,
                                                           u_mean,
                                                           v_mean, hmin, hmax, "MS", ms_in_file_name, ms_lines[band],
                                                           current_date,
                                                           utc_gps, dut1, (x2_up_left, y2_up_left, dx2, dy2, zonec),
                                                           ms_width, ms_height, sat_pos, captured_time, sat_att,
                                                           band=band + 1)

                Xmin = int(X.min())
                Xmax = int(np.ceil(X.max()))
                Ymin = int(Y.min())
                Ymax = int(np.ceil(Y.max()))
                strx = int(max(Xmin, 0))
                stpx = min(Xmax + 1, im_width)

                stry = max(Ymin, 0)
                stpy = min(Ymax + 1, im_height)

                print "[%d] Used the data from (%d,%d)->(%d,%d)" % (band + 1, strx, stry, stpx, stpy)
                if (strx < stpx) & (stry < stpy):
                    original = databand[stry:stpy, strx:stpx]
                    tr, tc = temp.shape
                    X = X.astype('float32')
                    Y = Y.astype('float32')
                    remap_out = cv2.remap(original, X - strx, Y - stry, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                          borderValue=0)
                    # print remap_out.shape
                    # print temp[(X>=X.min())*(X<=X.max())*(Y>=Y.min())*(Y<=Y.max())].shape
                    X = X.reshape(tr, tc)
                    Y = Y.reshape(tr, tc)
                    print "Load PAN image from (%d,%d) to (%d,%d)" % (sample, line, sample + samp_max, line + line_max)
                    pan_data = band1_pan.ReadAsArray(sample, line, samp_max , line_max)
                    print "Successfully load PAN image of size", pan_data.shape
                    temp[(X >= X.min()) * (X <= X.max()) * (Y >= Y.min()) * (Y <= Y.max())] = remap_out.flatten()
                    if (line == 0) & (sample == 0):
                        outimage[line:line + line_max, sample:sample + samp_max] = temp * (pan_data > 0)
                    elif (line == 0):
                        outimage[line:line + line_max, sample:sample + samp_max] = temp[:, off_set:] * (pan_data > 0)
                    elif (sample == 0):
                        outimage[line:line + line_max, sample:sample + samp_max] = temp[off_set:, :] * (pan_data > 0)
                    else:
                        outimage[line:line + line_max, sample:sample + samp_max] = temp[off_set:, off_set:] * (pan_data > 0)
        bandk.WriteArray(outimage, 0, 0)



    cl1 = np.round((xul - x2_up_left) / dx2) + 1
    rw1 = np.round((yul - y2_up_left) / dy2) + 1
    x1 = x2_up_left + dx2 * cl1
    y1 = y2_up_left + dy2 * rw1
    lat1, lon1 = utm.to_latlon(x1, y1, zonec, zoneletter_c)

    cl2 = np.round((xur - x2_up_left) / dx2) + 1
    rw2 = np.round((yur - y2_up_left) / dy2) + 1
    x2 = x2_up_left + dx2 * cl2
    y2 = y2_up_left + dy2 * rw2
    lat2, lon2 = utm.to_latlon(x2, y2, zonec, zoneletter_c)

    cl3 = np.round((xll - x2_up_left) / dx2) + 1
    rw3 = np.round((yll - y2_up_left) / dy2) + 1
    x3 = x2_up_left + dx2 * cl3
    y3 = y2_up_left + dy2 * rw3
    lat3, lon3 = utm.to_latlon(x3, y3, zonec, zoneletter_c)

    cl4 = np.round((xlr - x2_up_left) / dx2) + 1
    rw4 = np.round((ylr - y2_up_left) / dy2) + 1
    x4 = x2_up_left + dx2 * cl4
    y4 = y2_up_left + dy2 * rw4
    lat4, lon4 = utm.to_latlon(x4, y4, zonec, zoneletter_c)

    cl5 = np.round((xc - x2_up_left) / dx2) + 1
    rw5 = np.round((yc - y2_up_left) / dy2) + 1
    x5 = x2_up_left + dx2 * cl5
    y5 = y2_up_left + dy2 * rw5
    lat5, lon5 = utm.to_latlon(x5, y5, zonec, zoneletter_c)
    print "Upper left vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw1, cl1)
    print "FRAME_X: %e, FRAME_COL: %e" % (x1, y1)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon1, lat1)
    print ".........................................................."

    print "Upper right vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw2, cl2)
    print "FRAME_X: %e, FRAME_COL: %e" % (x2, y2)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon2, lat2)
    print ".........................................................."

    print "Lower left vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw3, cl3)
    print "FRAME_X: %e, FRAME_COL: %e" % (x3, y3)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon3, lat3)
    print ".........................................................."

    print "Lower right vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw4, cl4)
    print "FRAME_X: %e, FRAME_COL: %e" % (x4, y4)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon4, lat4)
    print ".........................................................."

    print "Scene center.............................................."
    print "FRAME_ROW: %d, FRAME_COL: %d" % (rw5, cl5)
    print "FRAME_X: %e, FRAME_COL: %e" % (x5, y5)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f" % (lon5, lat5)
    print ".........................................................."
    dst_ds.SetGeoTransform([ x2_up_left, 2.0, 0, y2_up_left, 0, -2.0 ])
    srs = osr.SpatialReference()
    srs.SetWellKnownGeogCS("WGS84")
    if (lat5 >= 0) :
        srs.SetUTM(zonec, 1)
    else :
        srs.SetUTM(zonec, 0)


    dst_ds.SetProjection(srs.ExportToWkt())
    upleft = [[cl1, rw1], [x1, y1], [lon1, lat1]]
    upright = [[cl2, rw2], [x2, y2], [lon2, lat2]]
    midpoint = [[cl5, rw5], [x5, y5], [lon5, lat5]]
    lowleft = [[cl3, rw3], [x3, y3], [lon3, lat3]]
    lowright = [[cl4, rw4], [x4, y4], [lon4, lat4]]
    return upleft, upright, midpoint, lowleft, lowright



def buildPANImageUsingCubicInterpolation(out_file_name, in_file_name, beg_line, current_date, utc_gps, ut1_utc,
                                         filter2D, start_sample=1, im_width=12000, im_height=12000):
    max_width = 12000

    band1 = gdal.Open(in_file_name + ".tif")
    beg_line -= 1
    start_sample -= 1

    gtiffDriver = gdal.GetDriverByName('GTiff')
    dst_ds = gtiffDriver.Create(out_file_name, im_width, im_height, 1, gdal.GDT_Byte)
    pan_b1 = dst_ds.GetRasterBand(1)

    # load as a block of 1000x1000 overlapped by 100

    for k in range(0, im_height, 1000):
        for m in range(0, im_width, 1000):
            print "Building block (%d,%d)......" % (k, m)
            y_min = max(0, beg_line + k - 100)
            x_min = max(0, m - 100 + start_sample)
            x_off_l = start_sample + m - x_min
            y_off_l = beg_line + k - y_min
            x_max = min(max_width, m + 1000 + 100 + start_sample)
            y_max = min(beg_line + im_height + 20, beg_line + k + 1000 + 100)
            x_off_h = x_max - (m + 1000) + (start_sample - 1)
            y_off_h = y_max - (beg_line + 1000 + k)
            load_width = x_max - x_min
            load_height = y_max - y_min
            one_block = band1.ReadAsArray(x_min, y_min, load_width, load_height)
            filtered_im = cv2.filter2D(one_block, cv2.CV_8UC1, filter2D)
            used_ar = filtered_im[y_off_l:y_off_l + 1000, x_off_l:x_off_l + 1000]

            # one_line = np.round((one_line-dark_currents)/gains)
            # out_line = one_line*(one_line <255.0) + 255.0*(one_line>=255)
            # outPAN = one_line.astype('uint8')
            pan_b1.WriteArray(used_ar, m, k)


if __name__ == "__main__":
    # cpf_file =  "/media/professor/Data and Backup/LEVEL0/CPF file/CPF_20110106_Delta_UT/THEOS_1_20110104_000000_20110106_000000.CPF"
    # cpf_file = r"D:\level1A_development\GER\THEOS_1_20150915_000000_20150917_000000.CPF"
    # gp,dp = readGainsAndDarkCurrent(cpf_file,"PAN", 6)
    # g1, d1 = readGainsAndDarkCurrent(cpf_file,1,5)
    # g2, d2 = readGainsAndDarkCurrent(cpf_file,2,5)
    # g3, d3 = readGainsAndDarkCurrent(cpf_file,3,5)
    # g4, d4 = readGainsAndDarkCurrent(cpf_file,4,4)
    # g4 = np.ones(g4.shape)
    # d4 = np.zeros(d4.shape)
    # g1 = np.ones(g4.shape)
    # d1 = np.zeros(d4.shape)
    # g2 = np.ones(g4.shape)
    # d2 = np.zeros(d4.shape)
    # g3 = np.ones(g4.shape)
    # d3 = np.zeros(d4.shape)
    # import matplotlib.pyplot as plt
    # plt.plot(d4)
    # plt.show()
    file_name = r"D:\level1A_development\GER\TS1_2015308_37179_004_"
    # buildRMImage(file_name,7299,7363,7428,7493,g1,g2,g3,g4,d1,d2,d3,d4)
    # gains =[g1,g2,g3,g4]
    # dark_curr = [d1,d2,d3,d4]
    out_file = file_name + "out.tif"
    # buildPANImageUsingCubicInterpolation(out_file ,file_name,43221,gp,dp,[2015,1,1],-16.0)
    buildMSImageUsingCubicInterpolation(out_file, file_name, [5379, 5441, 5503, 5565], [2015, 11, 4], -17.0, -0.200)
