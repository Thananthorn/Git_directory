import cv2

from osgeo import gdal

import matplotlib.pyplot as plt
import numpy as np
import scipy.optimize as opt


def meanSquareError(parms, ref, test):
    height, width = ref.shape
    mat = np.zeros((2, 3), 'float32')
    s = parms[0]
    theta = parms[1]
    tx = parms[2]
    ty = parms[3]
    mat[0, 0] = s * np.cos(theta)
    mat[0, 1] = -s * np.sin(theta)
    mat[0, 2] = tx
    mat[1, 0] = -mat[0, 1]
    mat[1, 1] = mat[0, 0]
    mat[1, 2] = ty
    mat = mat.reshape(2, 3).astype('float32')
    dest = cv2.warpAffine(test, mat, (width, height))
    error = (ref - dest) * (ref != 0)
    n_valid = ((ref != 0)).astype('float32').sum()
    mse = (error ** 2).sum() / n_valid
    return mse

def registerImages(ref, test):
    # mat0 = np.zeros((2,3),'float32')
    # mat0[0,0] = 1.0
    # mat0[1,1] = 1.0
    # mat0 = mat0.flatten()
    scale = 1.0
    theta = 0.0
    error_min = 1e100
    for tx in range(-5, 6):
        for ty in range(-5, 6):
            pars = [scale, theta, tx, ty]
            error = meanSquareError(pars, ref, test)
            if error < error_min:
                error_min = error
                pars0 = pars
    # tx = 0.0
    # ty = 0.0
    # pars0 =[scale, theta,tx,ty]
    print "Iniitial tx:%f, ty:%f" % (pars0[2], pars0[3])
    matopt = opt.fmin(meanSquareError, pars0, args=(ref, test))
    return matopt


def anorm2(a):
    return (a * a).sum(-1)


def anorm(a):
    return np.sqrt(anorm2(a))







def surf(img, HassianThreshold=200, nOctave=4, level=2):
    surf_params = (0, 200, 3, 1)
    surf_obj = cv2.SURF(HassianThreshold, nOctave, level, False, True)
    key_points, desc = surf_obj.detectAndCompute(img, None, useProvidedKeypoints=False)
    return key_points, desc


def keypoints2point_array(keypoints):
    points = np.zeros((len(keypoints), 2))
    id = 0
    for key in keypoints:
        (x, y) = key.pt
        points[id, 0] = x
        points[id, 1] = y
        id += 1
    return points


def match(desc1, desc2, points1, points2):
    res = []
    for i in xrange(len(desc1)):
        dist = anorm(desc2 - desc1[i])
        pix_dist = anorm(points2 * 0.75 / 2.0 - points1[i])
        dist = dist * (pix_dist <= 10.0) + dist.max() * (pix_dist > 10.0)
        n1, n2 = dist.argsort()[:2]
        r = dist[n1] / dist[n2]
        res.append((i, n1, r, dist[n1]))
    return res


def find_matching_key_points(keypoint1, keypoint2, res_list):
    error_threshold = 0.20
    maximum_r_rank = 50
    res_dist = np.zeros((len(res_list)))
    distance = np.zeros((len(res_list)))
    id = 0
    for res in res_list:
        distance[id] = res[3]
        res_dist[id] = res[2]
        id += 1
    im1_points = []
    im2_points = []
    res_dist_sort = np.sort(res_dist)
    maximum_r_rank = min(len(res_list) - 1, maximum_r_rank)
    for res in res_list:
        if (res[2] < res_dist_sort[maximum_r_rank]):
            error = res[3]
            if (error < error_threshold):
                (x1, y1) = keypoint1[res[1]].pt
                (x2, y2) = keypoint2[res[0]].pt
                im1_points.append([int(x1), int(y1)])
                im2_points.append([int(x2), int(y2)])

    return im1_points, im2_points


def findMatchingPoints(ref, test):
    keypoint2, desc2 = surf(ref, 300, 2, 1)
    if desc2 is not None:
        if (len(desc2) > 0):
            keypoint1, desc1 = surf(test, 300, 2, 1)
            if (len(desc1) > 0):
                desc1 = desc1.reshape((len(keypoint1), 64))
                point1 = keypoints2point_array(keypoint1)
                point2 = keypoints2point_array(keypoint2)
                desc2 = desc2.reshape((len(keypoint2), 64))
                res_data = match(np.array(desc2), np.array(desc1), point2, point1)
                matching_point1, matching_point2 = find_matching_key_points(keypoint1, keypoint2, res_data);
                matching_points = []
                for point1 in matching_point1:
                    pointx1 = point1
                    pointx2 = point2
                    matching_points.append((pointx1, pointx2))
                num_points = len(matching_points)

    return num_points, matching_points



if __name__ == "__main__":
    test_file = r"D:\Data2APanSharpen\THEOS_37649\GERAL_PAN\THEOS_1_LEVEL0_1_111037649_37649_MS_PB_TOP_2_2_2015-12-06_16-55-11\output\IMAGERY.tif"
    ref_file = r"D:\Data2APanSharpen\THEOS_37649\LEVEL_2A\MS\TH_CAT_160302043146169_1_TESTING_DATA_37649_MS_2_3\TH_CAT_160302043146169_1\IMAGERY.TIF"
    test_im = gdal.Open(test_file)
    ref_im = gdal.Open(ref_file)
    for band in [1, 2, 3, 4]:
        testb = test_im.GetRasterBand(band)
        refb = ref_im.GetRasterBand(band)
        testd = testb.ReadAsArray()
        refd = refb.ReadAsArray()
        num, points = findMatchingPoints(refd, testd)
        print points
        # matopt = registerImages(refd,testd)
        # print "%d:  scale:%f, theta: %f, tx: %f, ty:%f"%(band, matopt[0],matopt[1]*180.0/np.pi,matopt[2],matopt[3])

