import cv2

from osgeo import gdal
from osgeo import osr
import utm

import locationutil as util
import numpy as np
import utmLatlon


if __name__ == "__main__":
    dem_dir = r"D:\globedem"
    pan_file = r"D:\Data2APanSharpen\THEOS_37541\GERAL_PAN\THEOS_1_LEVEL0_1_111037541_37541_PAN_PB_TOP_1_13_2015-11-29_07-39-24\pan_output21946\IMAGERY.TIF"
    pan = gdal.Open(pan_file)
    geotrans = pan.GetGeoTransform()
    xul = geotrans[0]
    yul = geotrans[3]
    dx = geotrans[1]
    dy = geotrans[5]
    xlr = xul + dx * pan.RasterXSize
    ylr = yul + dy * pan.RasterYSize
    wkt = pan.GetProjection()
    src = osr.SpatialReference(wkt=wkt)
    zone = src.GetUTMZone()
    print zone
    if zone >= 0:
        latul, lonul = utm.to_latlon(xul, yul, zone, northern=True)
    else:
        latul, lonul = utm.to_latlon(xul, yul, -zone, northern=False)

    if zone >= 0:
        latlr, lonlr = utm.to_latlon(xlr, ylr, zone, northern=True)
    else:
        latlr, lonlr = utm.to_latlon(xlr, ylr, -zone, northern=False)
    dem_temp = util.load_dem_file(13, 99, dem_dir)
    pixel_size = dem_temp.GetGeoTransform()[1] / 3600.
    print latul, lonul, latlr, lonlr
    lata, lona, h = util.load_dem_data([latul + 30 * pixel_size, lonul - 30 * pixel_size], [latlr - 30 * pixel_size, lonlr + 30 * pixel_size], dem_dir)
    h_max = h.max()
    h_min = h.min()
    print "maximum h is: %f, minimum h is: %f" % (h_max, h_min)

    lv_height = pan.RasterYSize
    lv_width = pan.RasterXSize
    num_lines = 1000
    num_pixels = 1000
    off_set = 10
    drive = gdal.GetDriverByName("GTiff")
    drive.Register()
    dem = drive.Create(r"D:\Data2APanSharpen\THEOS_37541\GERAL_PAN\THEOS_1_LEVEL0_1_111037541_37541_PAN_PB_TOP_1_13_2015-11-29_07-39-24\pan_output21946\gdem_kriging.tif", lv_width, lv_height, 3, gdal.GDT_Byte)
    demred = dem.GetRasterBand(1)
    demgreen = dem.GetRasterBand(2)
    demblue = dem.GetRasterBand(3)
    for line in range(0, lv_height, num_lines):
        for sample in range(0, lv_width, num_pixels) :

            line_max = min((lv_height - line), num_lines)
            samp_max = min(lv_width - sample, num_pixels)
            if (line == 0) & (sample == 0):
                V, U = np.mgrid[0:int(line_max), 0:int(samp_max)]
            elif (line == 0) & (sample > 0):
                V, U = np.mgrid[0:int(line_max), sample - off_set:int(samp_max + sample)]
            elif (line > 0) & (sample == 0):

                V, U = np.mgrid[line - off_set:int(line_max + line), 0:int(samp_max)]
            else:
                V, U = np.mgrid[line - off_set:int(line_max + line), sample - off_set:int(samp_max + sample)]
            temp = np.zeros_like(U, 'uint8')
            u_earth = U * dx + xul
            v_earth = V * dy + yul
            if zone > 0 :
                late, lone = utmLatlon.to_latlon(u_earth, v_earth, zone, northern=True)
            else:
                late, lone = utmLatlon.to_latlon(u_earth, v_earth, -zone, northern=False)

            # h = util.determineHeight(late,lone,dem_directory)
            print "[PAN]  coord:", late.min(), late.max(), lone.min(), lone.max()
            latgrid, longrid, hgrid = util.load_dem_data([late.max() + 5 * pixel_size, lone.min() - 5.*pixel_size],
                                                       [late.min() - 5 * pixel_size, lone.max() + 5.*pixel_size], dem_dir)

            # lattt = late[110,110]
            # lontt = lone[110,110]
            # print lattt-8.997866911783666
            # print lontt - 99.54871548743743
            #
            # err = (8.997866911783666-latgrid)**2 + (99.54871548743743-longrid)**2
            # kk,mm = np.nonzero(err == err.min())
            # demm = gdal.Open(r"D:\gdem\gls\n%02de%03d.bil"%(int(lattt),int(lontt)))
            # geod = demm.GetGeoTransform()
            # rwd = int(np.round((lattt*3600.-geod[3])/geod[5]))
            # cld = int(np.round((lontt*3600.-geod[0])/geod[1]))
            # demdat = demm.ReadAsArray(cld-5,rwd-5,10,10)
            h = util.interpolateDemGrid(late, lone, latgrid, longrid, hgrid, pixel_size)
            ofx = off_set * (sample != 0)
            ofy = off_set * (line != 0)
            dem_out = h[ofy:, ofx:].astype('float64')
            rw, cl = dem_out.shape
            hsv = np.zeros((rw, cl, 3), 'uint8') + 255
            hsv[:, :, 0] = 170 - 170 * (dem_out - h_min) / h_max
            rgb = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)

            print "sample:%d, line:%d" % (sample, line), h.shape
            demred.WriteArray(rgb[:, :, 0], sample, line)
            demgreen.WriteArray(rgb[:, :, 1], sample, line)
            demblue.WriteArray(rgb[:, :, 2], sample, line)
