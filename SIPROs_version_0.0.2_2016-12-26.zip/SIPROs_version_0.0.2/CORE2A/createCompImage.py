import cv2

from osgeo import gdal

import numpy as np


if __name__ == "__main__":
    myf = r"D:\Data2APanSharpen\highLat\UK\GERALD_UK\PAN\level2aScene1\IMAGERY.tif"
    org = r"D:\Data2APanSharpen\highLat\UK\PAN_SCENE1_2A\TH_CAT_161216073439599_1\IMAGERY.TIF"
    # myf = org
    outf = r"D:\Data2APanSharpen\highLat\UK\GERALD_UK\PAN\level2aScene1\cmpInterpolateCubic"

    myim = gdal.Open(myf)
    orgim = gdal.Open(org)
    n_band = orgim.RasterCount
    for band in range(n_band):
        myimb1 = myim.GetRasterBand(band + 1)
        orgimb1 = orgim.GetRasterBand(band + 1)
        mygeo = myim.GetGeoTransform()
        orgeo = orgim.GetGeoTransform()
        mygeo = orgeo
        offx = (mygeo[0] - orgeo[0]) / orgeo[1]
        offy = (mygeo[3] - orgeo[3]) / orgeo[5]
        mywidth = myim.RasterXSize
        myheight = myim.RasterYSize
        orgwidth = orgim.RasterXSize
        orgheight = orgim.RasterYSize
        outimage = np.zeros((orgheight, orgwidth, 3), 'uint8')
        # original in green color
        orgdata = orgimb1.ReadAsArray()
        outimage[:, :, 1] = orgdata
        orgdata = None
        mydata = myimb1.ReadAsArray()
        # my is in red
        if (offx < 0) & (offy < 0):
            x = -int(np.round(offx))
            y = -int(np.round(offy))
            width = min(orgwidth, mywidth - x)
            height = min(orgheight, myheight - y)
            outimage[:height, :width, 2] = mydata[y:(y + height), x:(width + x)]
        elif (offx < 0) & (offy >= 0):
            x = -int(np.round(offx))
            y = int(np.round(offy))
            width = min(orgwidth, mywidth - x)
            height = min(orgheight - y, myheight)
            outimage[y:(height + y), :width, 2] = mydata[:(height), x:(width + x)]
        elif (offx >= 0) & (offy < 0):
            x = int(np.round(offx))
            y = -int(np.round(offy))
            width = min(orgwidth - x, mywidth)
            height = min(orgheight, myheight)
            outimage[:height, x:(width + x), 2] = mydata[y:(y + height), :(width)]
        else:
            x = int(np.round(offx))
            y = int(np.round(offy))
            width = min(orgwidth - x, mywidth)
            height = min(orgheight - y, myheight)
            outimage[y:(y + height), x:(width + x), 2] = mydata[:(height), :(width)]
        cv2.imwrite(outf + "%d.tif" % (band + 1), outimage)
