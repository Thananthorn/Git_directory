__author__ = 'professor'
# import gdal
import datetime
import platform
import time

import dutil
import locationutil as util
import matplotlib.pyplot as plt
import numpy as np
import scipy.interpolate as interpol
import xml.etree.ElementTree as ET


if platform.system() == "Windows":
    from osgeo import gdal
else:
    import gdal
# import utm

def computeJDtime(date, time, utc_gps) :
    t1 = time
    hour1 = int(np.floor(t1 / 3600.0))
    t1 -= hour1 * 3600.0
    minute1 = int(np.floor(t1) / 60.0)
    second1 = t1 - minute1 * 60.0
    micsec1 = second1 - int(np.floor(second1))
    micsec1 = int(micsec1 * 1e6)
    second1 = int(second1)
    tt1 = dutil.datetime(date[0], date[1], date[2], hour1, minute1, second1, micsec1)
    JD1 = tt1.to_jd() + utc_gps / (24 * 60.*60.)
    return JD1

def w(x):
    a = -0.5
    a3 = a + 2.0
    a2 = -a - 3.0
    b3 = a
    b2 = -5.0 * a
    b1 = 8 * a
    b0 = -4 * a
    absx = np.abs(x)
    absx3 = absx ** 3
    absx2 = absx ** 2
    y1 = a3 * absx3 ** 3 + a2 * absx2 + 1.0
    y2 = b3 * absx3 + b2 * absx2 + b1 * absx + b0
    y = y1 * (absx <= 1.0) + y2 * (absx > 1) * (absx < 2.0)
    return y

def find_pixel_shift(in_file_name, lines, current_date, utc_gps) :
    im_height = 6000
    im_width = 6000
    samples = np.arange(1, im_width + 1, 100)
    samples2 = np.arange(1, im_width + 1, 100).reshape((60, 1))
    samples_full = np.arange(1, im_width + 1)
    posB1 = np.loadtxt(in_file_name + "B1.pos")
    posB2 = np.loadtxt(in_file_name + "B2.pos")
    posB3 = np.loadtxt(in_file_name + "B3.pos")
    posB4 = np.loadtxt(in_file_name + "B4.pos")

    timeB1 = np.loadtxt(in_file_name + "B1.tim")
    timeB2 = np.loadtxt(in_file_name + "B2.tim")
    timeB3 = np.loadtxt(in_file_name + "B3.tim")
    timeB4 = np.loadtxt(in_file_name + "B4.tim")

    attB1 = np.loadtxt(in_file_name + "B1.att")
    attB2 = np.loadtxt(in_file_name + "B2.att")
    attB3 = np.loadtxt(in_file_name + "B3.att")
    attB4 = np.loadtxt(in_file_name + "B4.att")

    band1 = gdal.Open(in_file_name + "B1.tif")
    band2 = gdal.Open(in_file_name + "B2.tif")
    band3 = gdal.Open(in_file_name + "B3.tif")
    band4 = gdal.Open(in_file_name + "B4.tif")


    # out_im = np.zeros((im_height,im_height,4),'uint8')
    out_line0 = np.zeros((1, im_width), 'uint8')
    posB1 = posB1[lines[0]:lines[0] + im_height]
    posB2 = posB2[lines[1]:lines[1] + im_height]
    posB3 = posB3[lines[2]:lines[2] + im_height]
    posB4 = posB4[lines[3]:lines[3] + im_height]

    timeB1 = timeB1[lines[0]:lines[0] + im_height]
    timeB2 = timeB2[lines[1]:lines[1] + im_height]
    timeB3 = timeB3[lines[2]:lines[2] + im_height]
    timeB4 = timeB4[lines[3]:lines[3] + im_height]

    attB1 = attB1[lines[0]:lines[0] + im_height]
    attB2 = attB2[lines[1]:lines[1] + im_height]
    attB3 = attB3[lines[2]:lines[2] + im_height]
    attB4 = attB4[lines[3]:lines[3] + im_height]
    band1 = gdal.Open(in_file_name + "B1.tif")
    band2 = gdal.Open(in_file_name + "B2.tif")
    band3 = gdal.Open(in_file_name + "B3.tif")
    band4 = gdal.Open(in_file_name + "B4.tif")
    t1 = 0
    t2 = 0
    t3 = 0
    t4 = 0
    t5 = 0
    a_offset = []
    steps = 100
    n_samples = 6000 / 100
    for k in range(0, 6000, 5000):
        tst = time.clock()
        jd1 = computeJDtime(current_date, timeB1[k], utc_gps)
        jd2 = computeJDtime(current_date, timeB2[k], utc_gps)
        jd3 = computeJDtime(current_date, timeB3[k], utc_gps)
        jd4 = computeJDtime(current_date, timeB4[k], utc_gps)
        tsp = time.clock()
        t1 += tsp - tst
        # print t1
        tst = time.clock()
        uecef1 = util.computeUECEF(jd1, samples, attB1[k], 1)
        uecef2 = util.computeUECEF(jd2, samples, attB2[k], 2)
        uecef3 = util.computeUECEF(jd3, samples, attB3[k], 3)
        uecef4 = util.computeUECEF(jd4, samples, attB4[k], 4)
        tsp = time.clock()
        t2 += tsp - tst
        tst = time.clock()
        earth_post1 = util.findEarthSurfacePosition(uecef1, posB1[k])
        earth_post2 = util.findEarthSurfacePosition(uecef2, posB2[k])
        earth_post3 = util.findEarthSurfacePosition(uecef3, posB3[k])
        earth_post4 = util.findEarthSurfacePosition(uecef4, posB4[k])
        tsp = time.clock()
        t3 += tsp - tst
        tst = time.clock()
        lat1, lon1, height1 = util.itrf2latlon(earth_post1)
        lat2, lon2, height2 = util.itrf2latlon(earth_post2)
        lat3, lon3, height3 = util.itrf2latlon(earth_post3)
        lat4, lon4, height4 = util.itrf2latlon(earth_post4)
        # lat1_samp = lat1[::100]
        # lon1_samp = lon1[::100]
        # samp = samples[::100]
        # samp = samples[::100].reshape((im_width/100,1))
        onesam = np.ones((n_samples, 1))
        AA = np.hstack((onesam, samples2 , samples2 ** 2, samples2 ** 3))  # ,samples.reshape(im_width,1)**3))
        bb = lon1
        par = np.linalg.lstsq(AA, bb)[0]
        lon1 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)
        bb = lat1
        par = np.linalg.lstsq(AA, bb)[0]
        lat1 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)

        bb = lon2
        par = np.linalg.lstsq(AA, bb)[0]
        lon2 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)
        bb = lat2
        par = np.linalg.lstsq(AA, bb)[0]
        lat2 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)

        bb = lon3
        par = np.linalg.lstsq(AA, bb)[0]
        lon3 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)
        bb = lat3
        par = np.linalg.lstsq(AA, bb)[0]
        lat3 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)

        bb = lon4
        par = np.linalg.lstsq(AA, bb)[0]
        lon4 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)
        bb = lat4
        par = np.linalg.lstsq(AA, bb)[0]
        lat4 = (par[0] + par[1] * samples_full + par[2] * samples_full ** 2 + par[3] * samples_full ** 3)
        # plt.show()

        # lat3_samp = lat3[::100]
        # lon3_samp = lon3[::100]
        tsp = time.clock()
        t4 += tsp - tst
        tst = time.clock()
        distances13 = (lat1.reshape((im_width, 1)) - lat3.reshape((1, im_width))) ** 2
        distances13 += (lon1.reshape((im_width, 1)) - lon3.reshape((1, im_width))) ** 2
        distances13 = np.sqrt(distances13)
        distances13_min = distances13.min(0).reshape((1, im_width))
        distances13_min = np.repeat(distances13_min, im_width, 0)
        tsp = time.clock()
        t5 += tsp - tst
        tst = time.clock()
        # print t1,t2,t3,t4,t5
        [a, b] = np.nonzero(distances13 == distances13_min)
        idx = 0
        bsub = []
        B = np.array([[-1., 1, -1, 1], [0, 0, 0, 1], [1, 1, 1, 1], [8, 4, 2, 1]])
        Bin = np.linalg.inv(B)
        for a0 in a:

            an2 = max(0, a0 - 2)
            an1 = max(0, a0 - 1)
            ap1 = min(im_width - 1, a0 + 1)
            ap2 = min(im_width - 1, a0 + 2)
            distances13x = distances13[:, idx].flatten()
            A = np.array([[an2 ** 2, an2, 1], [an1 ** 2, an1, 1], [a0 ** 2, a0, 1], [ap1 ** 2, ap1, 1], [ap2 ** 2, ap2, 1]]).astype('float64')
            bv = np.array([distances13x[an2], distances13x[an1], distances13x[a0], distances13x[ap1], distances13x[ap2]])
            par = np.linalg.lstsq(A, bv)[0]
            b_best = -par[1] / (2.0 * par[0])
            bsub.append(b_best)
            idx += 1
        # b_sub = np.array(bsub)-2.0*int(bsub[0])
        a_sub = np.array(bsub)
        a_sub = a_sub * (a_sub <= im_width - 1) * (a_sub >= 0) + (im_width - 1) * (a_sub > im_width)
        # print a_sub
        a_offset.append(a_sub)
        print a_sub[1000]
        # print a_sub[0:50]
        one_lineB1 = band1.ReadAsArray(0, lines[0] + k - 1, im_width, 1).astype('float32')[0]
        # f = interpol.interp1d(samples,one_lineB1[0],kind='cubic')
        # inter_line = f(b_sub)
        # b_int =b_sub
        b0 = np.floor(a_sub).astype('int32')
        bp1 = b0 + 1
        bp1 = bp1 * (bp1 < im_width) + (im_width - 1) * (bp1 >= im_width)
        bp2 = b0 + 2
        bp2 = bp2 * (bp2 < im_width) + (im_width - 1) * (bp2 >= im_width)
        bn1 = b0 - 1
        bn1 = bn1 * (bn1 >= 0)
        p0 = one_lineB1[b0]
        p1 = one_lineB1[bp1]
        p2 = one_lineB1[bp2]
        m1 = one_lineB1[bn1]
        y = np.vstack((m1, p0, p1, p2))
        err = a_sub - b0
        By = np.dot(Bin, y)
        xv = np.vstack((err ** 3, err ** 2, err, err ** 0))
        # print err.shape
        lnB1 = (xv * By).sum(0)
        # print "line:%d"%k, lnB1[:50]
        # print one_lineB1[:50]
    a_offset = np.array(a_offset)



    # std = a_offset.std(0)
    data = a_offset[:, 1000]
    ln = np.arange(0, 6000, steps)
    num = ln.shape[0]
    one = np.ones((num, 1))
    ln = ln.reshape(num, 1)


    A = np.hstack((one, ln))
    print A.shape, data.shape
    par = np.linalg.lstsq(A, data)[0]
    ln = ln.flatten()
    plt.plot(ln, a_offset[:, 1000], ln, par[0] + par[1] * ln)
    plt.show()
    err = a_offset[:, 1000] - par[0] - par[1] * ln
    print np.abs(err).mean(), np.abs(err).max()

    # print inter_line
def determineHeight(in_file_name, pix, curr_line, target_location, currdate, utc_gps) :
    im_height = 6000
    im_width = 6000
    samples = np.arange(im_width)

    sat_pos = np.loadtxt(in_file_name + "B3.pos")
    captured_time = np.loadtxt(in_file_name + "B3.tim")
    sat_att = np.loadtxt(in_file_name + "B3.att")
    k = curr_line - 1
    jd = computeJDtime(currdate, captured_time[k], utc_gps)
    uecef1 = util.computeUECEF(jd, pix, sat_att[k], 3)
    # uecef6000 = util.computeUECEF(jd,1,sat_att[k],3)
    xt, yt, zt = util.latlon2itrf(target_location[0], target_location[1], 0)
    pos = sat_pos[k]
    u = uecef1.flatten()
    v = np.array([xt, yt, zt])
    w0 = pos
    a = np.inner(u, u)
    b = np.inner(u, v)
    c = np.inner(v, v)
    d = np.inner(u, w0)
    e = np.inner(v, w0)
    sc = (b * e - c * d) / (a * c - b ** 2)
    tc = (a * e - b * d) / (a * c - b ** 2)
    # print sc, tc
    h = (tc - 1.0) * np.sqrt(xt ** 2 + yt ** 2 + zt ** 2)
    # print h
    est_loc = pos + sc * u
    lat, lon, height = util.itrf2latlon(est_loc)
    err_vec = pos + sc * u - tc * v
    err = np.linalg.norm(err_vec)
    print "target:", target_location, "estimated: %f,%f" % (lat, lon)
    print "err: %f,%f at hight = %f" % (target_location[0] - lat, target_location[1] - lon, h)


def findInterSectionPoint(im_type, in_file_name, pix, curr_line, currdate, utc_gps, dut1, dem_directory):

    if im_type == "MS":
        sat_pos = np.loadtxt(in_file_name + "B3.pos")
        captured_time = np.loadtxt(in_file_name + "B3.tim")
        sat_att = np.loadtxt(in_file_name + "B3.att")
    elif im_type == "PAN":
        sat_pos = np.loadtxt(in_file_name + ".pos")
        captured_time = np.loadtxt(in_file_name + ".tim")
        sat_att = np.loadtxt(in_file_name + ".att")

    k = curr_line - 1
    # jd = computeJDtime(currdate,captured_time[k],utc_gps)
    year = currdate[0]
    month = currdate[1]
    day = currdate[2]
    hour = int(captured_time[k] / 3600.)
    minute = int((captured_time[k] - hour * 3600.0) / 60.0)
    seconds = captured_time[k] % 60.0
    sec = int(seconds)
    microsec = int(1e6 * (seconds - sec))
    if im_type == "PAN" :
        lat, lon, h = util.computeViewLatLong("PAN", pix, sat_pos[k], sat_att[k], year, month, day, hour, minute, sec, microsec, utc_gps, dut1, dem_directory)
    else:
        lat, lon, h = util.computeViewLatLong(3, pix, sat_pos[k], sat_att[k], year, month, day, hour, minute, sec, microsec, utc_gps, dut1, dem_directory)
    print "elevation = %f" % h
    return lat, lon, h

def findViewingAngles(im_type, in_file_name, curr_line, mid_s, currdate, utc_gps, dut1, mid_lat, mid_lon):
    if im_type == "MS":
        sat_pos = np.loadtxt(in_file_name + "B3.pos")
        captured_time = np.loadtxt(in_file_name + "B3.tim")
        sat_att = np.loadtxt(in_file_name + "B3.att")
        sat_vel = np.loadtxt(in_file_name + "B3.vel")
    elif im_type == "PAN":
        sat_pos = np.loadtxt(in_file_name + ".pos")
        captured_time = np.loadtxt(in_file_name + ".tim")
        sat_att = np.loadtxt(in_file_name + ".att")
        sat_vel = np.loadtxt(in_file_name + ".vel")

    k = curr_line - 1
    # jd = computeJDtime(currdate,captured_time[k],utc_gps)
    year = currdate[0]
    month = currdate[1]
    day = currdate[2]
    hour = int(captured_time[k] / 3600.)
    minute = int((captured_time[k] - hour * 3600.0) / 60.0)
    seconds = captured_time[k] % 60.0
    sec = int(seconds)
    microsec = int(1e6 * (seconds - sec))
    pos = sat_pos[curr_line]
    att = sat_att[curr_line]
    vel = sat_vel[curr_line]

    if im_type == "PAN" :
        alpha, alpha_along, alpha_accross = util.computeSceneViewingAngles(mid_s, "PAN", pos, att, vel, year, month, day, \
                                                                                      hour, minute, sec, microsec, utc_gps, dut1)
        util.computeSatAngles(pos, alpha, mid_lat, mid_lon)
    else:
        alpha, alpha_along, alpha_accross = util.computeSceneViewingAngles(mid_s, 3, pos, att, vel, year, month, day, \
                                                                      hour, minute, sec, microsec, utc_gps, dut1)
    sat_incidence, sat_azimuth, sat_altitude = util.computeSatAngles(pos, alpha, mid_lat, mid_lon)
    return alpha, alpha_along, alpha_accross, sat_incidence, sat_azimuth, sat_altitude
def findOrientationAngle(im_type, file_name, mid_line, date, utc_gps, dut1, dem_dir):
    if im_type == "PAN":
        width = 12000
        height = 12000
    elif im_type == "MS":
        width = 6000
        height = 6000
    # compute mid points
    latmid, lonmid, hmid = findInterSectionPoint(im_type, file_name, width / 2 , mid_line, date, utc_gps, dut1, dem_dir)
    latmidn1, lonmidn1, hmidn1 = findInterSectionPoint(im_type, file_name, 1 , mid_line, date, utc_gps, dut1, dem_dir)
    latmidp1, lonmidp1, hmidp1 = findInterSectionPoint(im_type, file_name, width, mid_line, date, utc_gps, dut1, dem_dir)
    # xm,ym,zone,letter = utm.from_latlon(latmid,lonmid)
    # xmn1,ymn1,zone,letter = utm.from_latlon(latmidn1,lonmidn1)
    # xmp1,ymp1,zone,letter = utm.from_latlon(latmidp1,lonmidp1)
    # dx = ((xm-xmn1) + (xmp1-xm))/2.0
    # dy = ((ym-ymn1) + (ymp1-ym))/2.0
    # print "dx:%f, dy:%f"%(dx,dy)
    # theta2 = np.arctan2(-dy,dx)*180.0/np.pi


    d2r = np.pi / 180.0
    mid_lat = latmid
    mid_lon = lonmid
    nadir_lat = latmidp1
    nadir_lon = lonmidp1

    x = np.cos(mid_lat * d2r) * np.sin(nadir_lat * d2r) - np.sin(mid_lat * d2r) * np.cos(nadir_lat * d2r) * np.cos((nadir_lon - mid_lon) * d2r)
    y = np.sin((nadir_lon - mid_lon) * d2r) * np.cos(nadir_lat * d2r)
    or_1 = np.arctan2(y, x) / d2r

    mid_lat = latmidn1
    mid_lon = lonmidn1
    nadir_lat = latmid
    nadir_lon = lonmid

    x = np.cos(mid_lat * d2r) * np.sin(nadir_lat * d2r) - np.sin(mid_lat * d2r) * np.cos(nadir_lat * d2r) * np.cos((nadir_lon - mid_lon) * d2r)
    y = np.sin((nadir_lon - mid_lon) * d2r) * np.cos(nadir_lat * d2r)
    or_2 = np.arctan2(y, x) / d2r
    theta2 = (or_1 + or_2) / 2.0 - 90.0

    # print "theta2:",theta2
    return theta2

def findSunAngles(im_type, in_file_name, center_line, date, utc_gps, dut1, lat, lon) :
    def sind(x):
        y = np.sin((x) * np.pi / 180.)
        return y
    def cosd(x):
        y = np.cos((x) * np.pi / 180.)
        return y
    if im_type == "MS":

        captured_time = np.loadtxt(in_file_name + "B3.tim")

    elif im_type == "PAN":

        captured_time = np.loadtxt(in_file_name + ".tim")

    dt = datetime.datetime(date[0], date[1], date[2])
    d = dt.timetuple().tm_yday
    t = captured_time[center_line - 1]
    tutc = (t + utc_gps) / (60.*60.)
    tmst = tutc + (lon / 15.)
    x1 = 1.00554 * d - 6.28306
    x2 = 1.93946 * d + 23.35089
    et = -7.67825 * sind(x1) - 10.09176 * sind(x2)
    ttst = tmst + et / 60.
    ttst = ttst - 12.
    ah = ttst * 15.
    a3 = 0.9683 * d - 78.00878
    delta = 23.4856 * sind(a3)
    # theta = 360*ttst/(24.*60.*60.)
    delta = 23.4856 * sind(0.9683 * d - 78.00878)
    amuzero = sind(lat) * sind(delta) + cosd(lat) * cosd(delta) * cosd(ah)
    sun_ev = np.arcsin(amuzero) * 180.0 / np.pi
    az = cosd(delta) * sind(ah) / cosd(sun_ev)
    caz = (-cosd(lat) * sind(delta) + sind(lat) * cosd(delta) * cosd(ah)) / cosd(sun_ev)
    sun_azimuth = np.arcsin(az) * 180.0 / np.pi
    if caz <= 0 :
        sun_azimuth = sun_azimuth - 180.0
    elif (caz > 0) and (az <= 0) :
        sun_azimuth = 360. + sun_azimuth
    sun_azimuth = sun_azimuth + 180.
    if sun_azimuth > 360. :
        sun_azimuth = sun_azimuth - 360.

    # sun_ev = np.arcsin(sind(lat)*sind(delta)+cosd(lat)*cosd(delta)*cosd(theta))*180./np.pi
    # sun_azimuth = np.arcsin((cosd(delta)*sind(theta))/cosd(sun_ev))*180.0/np.pi
    return sun_ev, sun_azimuth


if __name__ == "__main__" :
    file_name = "/media/professor/Data and Backup/LEVEL0/2013-12-03_REV27231/THEOS_1_LEVEL0_1_111027231_27231_MS_PB_TOP_2_22_2013-12-03_03-24-32/TS1_2013337_27231_022_B3"
    # find_pixel_shift(file_name,[26741,26813,26885,26957],[2015,1,2],-16.0)
    # file_name =r"C:\LEVEL0\THEOS_1_LEVEL0_1_111032837_32837_MS_PB_TOP_2_8_2015-01-02_03-26-33\TS1_2015002_32837_008_"
    # dem_file = r"C:\Users\professor\Dropbox\THEOS_LEVEL1ADEVELOPMENT\n17e099.bil"
    dem_dir = "/media/professor/Backup and Data/LEVEL0/DEMSRTM/srtm/gls/"
    lat = 17.251740
    lon = 101.281563
    dem_file = dem_dir + "n%de%03d.bil" % (int(lat), int(lon))
    dem = gdal.Open(dem_file)
    latsec = lat * 3600.
    lonsec = lon * 3600.
    geotrans = dem.GetGeoTransform()
    off_lat = latsec - geotrans[3]
    off_lon = lonsec - geotrans[0]
    print "actual pixel (%f,%f)" % (off_lat / geotrans[5], off_lon / geotrans[1])

    latout, lonout, hout = findInterSectionPoint("MS", file_name, 1 , 46237, [2013, 12, 3], -16.0, -0.1, dem_dir)
    print "lat: %f, lon: %f, h: %f" % (latout, lonout, hout)
    errory = (latout - lat) * 6371000 * np.pi / 180.0
    errorx = (lonout - lon) * 6371000 * np.pi / 180.0
    error = np.sqrt(errorx ** 2 + errory ** 2)
    print "errors %f meter(s)" % (error)
    latsec = latout * 3600.
    lonsec = lonout * 3600.
    # geotrans = dem.GetGeoTransform()
    off_lat = latsec - geotrans[3]
    off_lon = lonsec - geotrans[0]
    latmid, lonmid, hmid = findInterSectionPoint("PAN", file_name, 3000 , 46237, [2013, 12, 3], -16.0, -0.1, dem_dir)
    print "estimated pixel (%f,%f)" % (off_lat / geotrans[5], off_lon / geotrans[1])
    al, al_along, al_across, sat_incidence, sat_azimuth = findViewingAngles("MS", file_name, \
                                                                           1 , 46237, [2013, 12, 3], -16.0, -0.1, latmid, lonmid)
    print "viewing Angle: %f, Along Track:%f, Across Track: %f" % (al, al_along, al_across)
    print "satellite incidence angle %f, satellite azimuth angle: %f" % (sat_incidence, sat_azimuth)
    incidenangle = findOrientationAngle("MS", file_name, 46237, [2013, 12, 3], -16.0, -0.1, dem_dir)
    print "Incidence Angle: %f" % incidenangle

