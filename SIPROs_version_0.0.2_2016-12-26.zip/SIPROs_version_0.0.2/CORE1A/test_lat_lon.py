from osgeo import gdal

import numpy as np


def load_dem_file(lat, lon, dem_directory):
    lat = int(lat)
    lon = int(lon)
    if (lat >= 0) & (lon >= 0) :
        dem_file = dem_directory + "\\n%02de%03d.bil" % (lat, lon)
        # dem_file01 = dem_directory + "n%02de%03d.bil"%(lat,lon)
    elif (lat > 0) & (lon < 0) :
        dem_file = dem_directory + "\\n%02dw%03d.bil" % (lat, -lon)
    elif (lat < 0) & (lon >= 0):
        dem_file = dem_directory + "\\s%02de%03d.bil" % (-lat, lon)
    else:
        dem_file = dem_directory + "\\s%02dw%03d.bil" % (-lat, -lon)
    dem = gdal.Open(dem_file)
    return dem

def load_dem_data(upleft, lowright, dem_dir) :
    lat_int_min = int(np.floor(upleft[0]))
    lon__int_min = int(np.floor(upleft[1]))
    lat_int_max = int(np.floor(lowright[0]))
    lon_int_max = int(np.floor(lowright[1]))
    latsec_min = upleft[0] * 3600.
    lonsec_min = upleft[1] * 3600.
    latsec_max = lowright[0] * 3600.
    lonsec_max = lowright[1] * 3600.
    # load DEM file
    dem = load_dem_file(lat_int_max, lon__int_min, dem_dir)
    dem_geo = dem.GetGeoTransform()
    xorg = dem_geo[0]
    yorg = dem_geo[3]
    xstep = dem_geo[1]
    ystep = dem_geo[5]
    latsec_min = int((upleft[0] * 3600. - yorg) / ystep) * ystep + yorg
    lonsec_min = int((upleft[1] * 3600. - xorg) / xstep) * xstep + xorg
    latsec_max = int((lowright[0] * 3600. - yorg) / ystep) * ystep + yorg
    lonsec_max = int((lowright[1] * 3600. - xorg) / xstep) * xstep + xorg

    x_size = int((lowright[1] - upleft[1]) * 3600. / xstep)
    y_size = int((lowright[0] - upleft[0]) * 3600. / ystep)
    lat_grid = np.zeros((y_size, x_size), 'float64')
    lon_grid = np.zeros((y_size, x_size), 'float64')
    h_grid = np.zeros((y_size, x_size), 'float64')
    for lat in range(lat_int_min, lat_int_max - 1, -1):
        for lon in range(lon__int_min, lon_int_max + 1) :
            dem = load_dem_file(lat, lon, dem_dir)
            dem_x_size = dem.RasterXSize
            dem_y_size = dem.RasterYSize
            dem_geo = dem.GetGeoTransform()
            x_min_dem = int((dem_geo[0] - lonsec_min) / xstep)
            y_min_dem = int((dem_geo[3] - latsec_min) / ystep)
            x_max_dem = x_min_dem + dem_x_size
            y_max_dem = y_min_dem + dem_y_size
            x_min = max(x_min_dem, 0)
            y_min = max(y_min_dem, 0)
            x_max = min(x_max_dem, x_size)
            y_max = min(y_max_dem, y_size)
            x_min_dem = x_min - x_min_dem
            y_min_dem = y_min - y_min_dem
            lon_a = dem_geo[0] + np.arange(x_min_dem, x_min_dem + x_max - x_min) * xstep
            lat_a = dem_geo[3] + np.arange(y_min_dem, y_min_dem + y_max - y_min) * ystep
            lon_temp, lat_temp = np.meshgrid(lon_a, lat_a)
            lat_grid[y_min:y_max, x_min:x_max] = lat_temp
            lon_grid[y_min:y_max, x_min:x_max] = lon_temp
            h_grid[y_min:y_max, x_min:x_max] = dem.ReadAsArray(x_min_dem, y_min_dem, x_max - x_min, y_max - y_min)
    return lat_grid, lon_grid, h_grid



if __name__ == "__main__" :
    dem_dir = r"D:\level1A_development\srtm\gls"
    upleft = [-31.02, 29.97]
    lowright = [-31.02 - 0.04, 29.97 + 0.04]
    print load_dem_data(upleft, lowright, dem_dir)
