"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import cv2
import datetime
import os
import platform
import struct
import sys

from commomTools import LV1_2ProductionConstants
import numpy as np
import scipy.interpolate as ipl
import xml.etree.ElementTree as ET


if platform.system() == "Windows":
    from osgeo import gdal
else:
    import gdal



class ger_const_ms :
    width = 6000
    nband = 4
    lcnt_offset = 14
    time_per_line = 0.0021602

    MFH = ['File_Type', 'Rec_Name', 'Rec_Size', 'SFHR_Nb', 'SFHR_Size', 'DSR_Nb', 'DSR_Size', 'First_DSR',
           'Last_DSR', 'new_line1', 'Date_First', 'space1', 'Date_Last', 'space2', 'Date_Source', 'space3', 'Sat_Id',
           'Channel', 'space4', 'Instr_Id', 'new_line2', 'OBT_First', 'space5', 'OBT_Last', 'space6', 'Num_First',
           'Num_Last', 'TF_Size', 'new_line3', 'Acq_Center', 'Proc_Center', 'Telemetry_Id', 'Reserved', 'new_line4',
           'Format_Doc', 'Format_Ed', 'Format_Rev', 'Copyright', 'new_line5']
    MFH_len = {'File_Type':16, 'Rec_Name':4, 'Rec_Size':8, 'SFHR_Nb':8, 'SFHR_Size':8, 'DSR_Nb':8, 'DSR_Size':8, 'First_DSR':8,
           'Last_DSR':8, 'new_line1':2, 'Date_First':18, 'space1':6, 'Date_Last':18, 'space2':6, 'Date_Source':2, 'space3':2, 'Sat_Id':16,
           'Channel':2, 'space4':2, 'Instr_Id':10, 'new_line2':2, 'OBT_First':18, 'space5':6, 'OBT_Last':18, 'space6':6, 'Num_First':8,
           'Num_Last':8, 'TF_Size':8, 'new_line3':2, 'Acq_Center':16, 'Proc_Center':16, 'Telemetry_Id':10, 'Reserved':162, 'new_line4':2,
           'Format_Doc':32, 'Format_Ed':2, 'Format_Rev':2, 'Copyright':32, 'new_line5':2}
    SGR = ['Rec_Name', 'Rec_Size', 'SFHR_Name', 'File_Name', 'Coding_Flag', 'View_Mode', 'Comp_Ratio', 'Beg_Format',
           'End_Format', 'Beg_LineCount', 'End_LineCount', 'new_line1', 'SADR_Nb', 'LSR_Nb', 'LostSynch_Nb',
           'CER_Nb', 'SOFR_Nb', 'space', 'new_line2']
    SGR_len = {'Rec_Name':4, 'Rec_Size':8, 'SFHR_Name':6, 'File_Name':4, 'Coding_Flag':13, 'View_Mode':4, 'Comp_Ratio':4, 'Beg_Format':8,
           'End_Format':8, 'Beg_LineCount':8, 'End_LineCount':8, 'new_line1':2, 'SADR_Nb':6, 'LSR_Nb':6, 'LostSynch_Nb':6,
           'CER_Nb':6, 'SOFR_Nb':6, 'space':19, 'new_line2':2}

    SFHR = ['Rec_Name', 'Rec_Size', 'SFHR_Name', 'Date', 'Attitude_Q1', 'Attitude_Q2', 'Attitude_Q3',
            'Attitude_Q4', 'Rates_Rx', 'Rates_Ry', 'Rates_Rz', 'Position_Px', 'Position_Py', 'Position_Pz',
            'Velocity_Vx', 'Velocity_Vy', 'Velocity_Vz', 'Gyro_Gx', 'Gyro_Gy', 'Gyro_Gz', 'Spare', 'new_line']


    SFHR_len = {'Rec_Name':4, 'Rec_Size': 8, 'SFHR_Name':6, 'Date': 20, 'Attitude_Q1':4, 'Attitude_Q2':4, 'Attitude_Q3':4,
                'Attitude_Q4':4, 'Rates_Rx': 4, 'Rates_Ry':4, 'Rates_Rz':4, 'Position_Px':4, 'Position_Py':4, 'Position_Pz':4,
                'Velocity_Vx':4, 'Velocity_Vy':4, 'Velocity_Vz':4, 'Gyro_Gx':4, 'Gyro_Gy':4, 'Gyro_Gz':4, 'Spare':25, 'new_line':1}

    LSR = ['Rec_Name', 'Rec_Size', 'SFHR_Name', 'Band_1', 'Beg_DSR_1', 'End_DSR_1', 'Band_2',
               'Beg_DSR_2', 'End_DSR_2', 'Band_3', 'Beg_DSR_3', 'End_DSR_3', 'Band_4', 'Beg_DSR_4',
               'End_DSR_4', 'Reserved', 'new_line' ]


    LSR_len = {'Rec_Name':4, 'Rec_Size':8, 'SFHR_Name':6, 'Band_1':5, 'Beg_DSR_1':10, 'End_DSR_1':10, 'Band_2':5,
               'Beg_DSR_2':10, 'End_DSR_2':10, 'Band_3':5, 'Beg_DSR_3':10, 'End_DSR_3':10, 'Band_4':5, 'Beg_DSR_4':10,
               'End_DSR_4':10, 'Reserved':8, 'new_line':2 }

    CER = ['Rec_Name', 'Rec_Size', 'SFHR_Name', 'DSR_Num', 'ExcNb_PAN', 'ExcNb_B1', 'ExcNb_B2',
           'ExcNb_B3', 'ExcNb_B4', 'reserved']

    CER_len = {'Rec_Name':4, 'Rec_Size':8, 'SFHR_Name':6, 'DSR_Num':10, 'ExcNb_PAN':5, 'ExcNb_B1':4, 'ExcNb_B2':4,
              'ExcNb_B3':4, 'ExcNb_B4':4, 'reserved':1521}
    SOFR = ['Rec_Name', 'Rec_Size', 'SFHR_Name', 'SFSY', 'SFID', 'SFLN', 'SFSC', 'IAD', \
           'IGPSTYear', 'IGPSTDay', 'IGPSTHour', 'IGPSTMinute', 'IGPSTSec', \
           'CST', 'CAD', 'SAD', 'LCNT', 'Spare']
    SOFR_len = {'Rec_Name':4, 'Rec_Size':8, 'SFHR_Name':6, 'SFSY':8, 'SFID':1, 'SFLN':3, 'SFSC':3, 'IAD':32, \
           'IGPSTYear':2, 'IGPSTDay':2, 'IGPSTHour':1, 'IGPSTMinute':1, 'IGPSTSec':1, \
           'CST':2, 'CAD':8, 'SAD':16, 'LCNT':3, 'Spare':155}
    GDB = ['ADB_Size', 'MDB_Size', 'DSR_Num', 'Spare']

    GDB_len = {'ADB_Size':4, 'MDB_Size':4, 'DSR_Num':4, 'Spare':116}

    ADB = ['SFSC', 'Line_Counter', 'IAD', 'Image_Line', 'IL_Status', 'Year', 'Day', 'Hour', 'Minute',
           'Second', 'Microsec', 'Spare']

    ADB_len = {'SFSC':4, 'Line_Counter':4, 'IAD':16, 'Image_Line':4, 'IL_Status':1, 'Year':4, 'Day':2, 'Hour':1, 'Minute':1,
       'Second':1, 'Microsec':4, 'Spare':86}




class ger_const_pan :
    width = 12000
    time_per_line = 0.0003086
    lcnt_offset = 2

    MFH = ['File_Type', 'Rec_Name', 'Rec_Size', 'SFHR_Nb', 'SFHR_Size', 'DSR_Nb', 'DSR_Size', 'First_DSR',
           'Last_DSR', 'new_line1', 'Date_First', 'space1', 'Date_Last', 'space2', 'Date_Source', 'space3', 'Sat_Id',
           'Channel', 'space4', 'Instr_Id', 'new_line2', 'OBT_First', 'space5', 'OBT_Last', 'space6', 'Num_First',
           'Num_Last', 'TF_Size', 'new_line3', 'Acq_Center', 'Proc_Center', 'Telemetry_Id', 'Reserved', 'new_line4',
           'Format_Doc', 'Format_Ed', 'Format_Rev', 'Copyright', 'new_line5']
    MFH_len = {'File_Type':16, 'Rec_Name':4, 'Rec_Size':8, 'SFHR_Nb':8, 'SFHR_Size':8, 'DSR_Nb':8, 'DSR_Size':8, 'First_DSR':8,
           'Last_DSR':8, 'new_line1':2, 'Date_First':18, 'space1':6, 'Date_Last':18, 'space2':6, 'Date_Source':2, 'space3':2, 'Sat_Id':16,
           'Channel':2, 'space4':2, 'Instr_Id':10, 'new_line2':2, 'OBT_First':18, 'space5':6, 'OBT_Last':18, 'space6':6, 'Num_First':8,
           'Num_Last':8, 'TF_Size':8, 'new_line3':2, 'Acq_Center':16, 'Proc_Center':16, 'Telemetry_Id':10, 'Reserved':162, 'new_line4':2,
           'Format_Doc':32, 'Format_Ed':2, 'Format_Rev':2, 'Copyright':32, 'new_line5':2}
    SGR = ['Rec_Name', 'Rec_Size', 'SFHR_Name', 'File_Name', 'Coding_Flag', 'View_Mode', 'Comp_Ratio', 'Beg_Format',
           'End_Format', 'Beg_LineCount', 'End_LineCount', 'new_line1', 'SADR_Nb', 'LSR_Nb', 'LostSynch_Nb',
           'CER_Nb', 'SOFR_Nb', 'space', 'new_line2']
    SGR_len = {'Rec_Name':4, 'Rec_Size':8, 'SFHR_Name':6, 'File_Name':4, 'Coding_Flag':13, 'View_Mode':4, 'Comp_Ratio':4, 'Beg_Format':8,
           'End_Format':8, 'Beg_LineCount':8, 'End_LineCount':8, 'new_line1':2, 'SADR_Nb':6, 'LSR_Nb':6, 'LostSynch_Nb':6,
           'CER_Nb':6, 'SOFR_Nb':6, 'space':19, 'new_line2':2}

    SFHR = ['Rec_Name', 'Rec_Size', 'SFHR_Name', 'Date', 'Attitude_Q1', 'Attitude_Q2', 'Attitude_Q3',
            'Attitude_Q4', 'Rates_Rx', 'Rates_Ry', 'Rates_Rz', 'Position_Px', 'Position_Py', 'Position_Pz',
            'Velocity_Vx', 'Velocity_Vy', 'Velocity_Vz', 'Gyro_Gx', 'Gyro_Gy', 'Gyro_Gz', 'Spare', 'new_line']


    SFHR_len = {'Rec_Name':4, 'Rec_Size': 8, 'SFHR_Name':6, 'Date': 20, 'Attitude_Q1':4, 'Attitude_Q2':4, 'Attitude_Q3':4,
                'Attitude_Q4':4, 'Rates_Rx': 4, 'Rates_Ry':4, 'Rates_Rz':4, 'Position_Px':4, 'Position_Py':4, 'Position_Pz':4,
                'Velocity_Vx':4, 'Velocity_Vy':4, 'Velocity_Vz':4, 'Gyro_Gx':4, 'Gyro_Gy':4, 'Gyro_Gz':4, 'Spare':25, 'new_line':1}

    LSR = ['Rec_Name', 'Rec_Size', 'SFHR_Name', 'Band_1', 'Beg_DSR_1', 'End_DSR_1', 'Band_2',
               'Beg_DSR_2', 'End_DSR_2', 'Band_3', 'Beg_DSR_3', 'End_DSR_3', 'Band_4', 'Beg_DSR_4',
               'End_DSR_4', 'Reserved', 'new_line' ]


    LSR_len = {'Rec_Name':4, 'Rec_Size':8, 'SFHR_Name':6, 'Band_1':5, 'Beg_DSR_1':10, 'End_DSR_1':10, 'Band_2':5,
               'Beg_DSR_2':10, 'End_DSR_2':10, 'Band_3':5, 'Beg_DSR_3':10, 'End_DSR_3':10, 'Band_4':5, 'Beg_DSR_4':10,
               'End_DSR_4':10, 'Reserved':8, 'new_line':2 }

    CER = ['Rec_Name', 'Rec_Size', 'SFHR_Name', 'DSR_Num', 'ExcNb_PAN', 'ExcNb_B1', 'ExcNb_B2',
           'ExcNb_B3', 'ExcNb_B4', 'reserved']

    CER_len = {'Rec_Name':4, 'Rec_Size':8, 'SFHR_Name':6, 'DSR_Num':10, 'ExcNb_PAN':5, 'ExcNb_B1':4, 'ExcNb_B2':4,
              'ExcNb_B3':4, 'ExcNb_B4':4, 'reserved':1521}
    SOFR = ['Rec_Name', 'Rec_Size', 'SFHR_Name', 'SFSY', 'SFID', 'SFLN', 'SFSC', 'IAD', \
           'IGPSTYear', 'IGPSTDay', 'IGPSTHour', 'IGPSTMinute', 'IGPSTSec', \
           'CST', 'CAD', 'SAD', 'LCNT', 'Spare']
    SOFR_len = {'Rec_Name':4, 'Rec_Size':8, 'SFHR_Name':6, 'SFSY':8, 'SFID':1, 'SFLN':3, 'SFSC':3, 'IAD':128, \
           'IGPSTYear':2, 'IGPSTDay':2, 'IGPSTHour':1, 'IGPSTMinute':1, 'IGPSTSec':1, \
           'CST':2, 'CAD':8, 'SAD':16, 'LCNT':3, 'Spare':59}
    GDB = ['ADB_Size', 'MDB_Size', 'DSR_Num', 'Spare']

    GDB_len = {'ADB_Size':4, 'MDB_Size':4, 'DSR_Num':4, 'Spare':116}

    ADB = ['SFSC', 'Line_Counter', 'IAD', 'Image_Line', 'IL_Status', 'Year', 'Day', 'Hour', 'Minute',
           'Second', 'Microsec', 'Spare']

    ADB_len = {'SFSC':4, 'Line_Counter':4, 'IAD':16, 'Image_Line':4, 'IL_Status':1, 'Year':4, 'Day':2, 'Hour':1, 'Minute':1,
       'Second':1, 'Microsec':4, 'Spare':86}


class extended_interp1d:
    def __init__(self, time, data):
        self.cubic = ipl.interp1d(time, data, kind="cubic")
        n_data = data.shape[0]
        time = np.array(time)
        A = np.zeros((n_data, 4))
        A[:, 0] = 1.0
        A[:, 1] = time
        A[:, 2] = time ** 2
        A[:, 3] = time ** 3
        coef, r, rn, s = np.linalg.lstsq(A, data)
        self.coef = coef
        self.time_min = time.min()
        self.time_max = time.max()
        self.time_mid = (self.time_max + self.time_min) / 2.0
        self.time_span = self.time_max - self.time_min
        # print "time min: %f time max:%f"%(self.time_min, self.time_max)
    def get_values(self, x):
        # if (x >= self.time_min) and (x <= self.time_max):
        #     yc = self.cubic(x)
        #     yp = self.coef[0] + self.coef[1] * x + self.coef[2] * (x ** 2) + self.coef[3] * (x ** 3)
        #
        #     a = 1.0 - 2.0 * np.abs(x - self.time_mid) / (self.time_span)
        #     a = a * (a>0)
        #     y = yp #a * yc + (1 - a) * yp
        # else:
        #     y = self.coef[0] + self.coef[1] * x + self.coef[2] * (x ** 2) + self.coef[3] * (x ** 3)
        # if (x>=self.time_min) and (x<=self.time_max):
        #
        # elif (x > self.time_max):
        #     yc_max = self.cubic(self.time_max)
        #     t = self.time_max
        #     yp_max =self.coef[0] + self.coef[1]*t + self.coef[2] * (t**2) + self.coef[3] * (t**3)
        #     y = self.coef[0] + self.coef[1]*x + self.coef[2] * (x**2) + self.coef[3] * (x**3)
        #     y = yc_max+(y-yp_max)
        # elif (x < self.time_min):
        #     yc_min = self.cubic(self.time_min)
        #     t = self.time_min
        #     yp_min = self.coef[0] + self.coef[1] * t + self.coef[2] * (t ** 2) + self.coef[3] * (t ** 3)
        #     y = self.coef[0] + self.coef[1] * x + self.coef[2] * (x ** 2) + self.coef[3] * (x ** 3)
        #     y = yc_min - (y - yp_min)
        # y = yipl*(x>=self.time_min)*(x<=self.time_max) + ycub*(x<self.time_min) + ycub*(x>self.time_max)
        # print "there are %d data less than time min. " % ((x<self.time_min).sum())
       # print "there are %d data greater than time max. " % ((x > self.time_max).sum())
        try :
            if(x >= self.time_min) and (x <= self.time_max):
                y = self.cubic(x)
            elif (x > self.time_max):
                y = self.cubic(self.time_max)
            elif (x < self.time_min) :
                y = self.cubic(self.time_min)
        except:
            print x
            print self.time_max
            print self.time_min
        return y
class theos_ger_file:



    def __init__(self, imtype, file_name='', gains=None, darkcurrents=None):

        if imtype == "MS":
            self.ger_const = ger_const_ms
            self.im_type = "MS"
        elif imtype == "PAN" :
            self.ger_const = ger_const_pan
            self.im_type = "PAN"
        else :
            print "image type must be MS or PAN!!"
            sys.exit(1)
        self.year = 0
        self.month = 0
        self.day = 0
        self.bad_lines = None
        self.degraded_lines = None
        self.modified = False
        if file_name == '' :
            self.file_name = ''
            self.MFH = []
            self.SGR = []
            self.SADR = []
            self.LSR = []
            self._CER = []
            self._SOFR = []
            self.ADB = []
            self.GDB = []
            self.image = []
            self.band = 0


        else:
            self.file_name = file_name
            try :
                print "Opening a file " + file_name
                fp = open(file_name, "rb")  # Open File
                self.fp = fp
                print "reading MFH!"
                self.read_MFH(fp)  # Load MFH
                print "reading SGR!"
                self.read_SGR(fp)  # Load SGR
                print "reading SADR!"
                self.read_SADR(fp)  # Load SADR
                print "reading LSR!"
                self.read_LSR(fp)  # Load LSR
                print "reading CER!"
                self.read_CER(fp)  # Load _CER
                print "reading SOFR!"
                self.read_SOFR(fp)
                fp.close()
            except  IOError :
                print "File cannot be loaded!!"
        if (gains is not None) and (darkcurrents is not None) :
            self.gains = gains
            self.darkcurrents = darkcurrents
        else:
            self.gains = 1.0
            self.darkcurrents = 0.0


    def read_MFH(self, fp):
        self.MFH = {}
        for mfh_header in self.ger_const.MFH :
            txt = fp.read(self.ger_const.MFH_len[mfh_header])
            # print mfh_header," = ",txt
            if (mfh_header.find('new_line') == -1) & (mfh_header.find('space') == -1) & (mfh_header.find('Reserved')):
                # We don't write new_lne, space or reserved into the list
                try:  # Try to read it as integer first, if we cannot, read it as string
                    self.MFH[mfh_header] = int(txt)
                except ValueError:
                    self.MFH[mfh_header] = txt
            if mfh_header == "OBT_First" :
                self.year = int(txt[0:4])
                self.month = int(txt[4:6])
                self.day = int(txt[6:8])
        self.num_DSR = int(self.MFH["DSR_Nb"])  # Determine number of num_SDSR

    def read_SGR(self, fp):
        self.SGR = {}
        for sgr_header in self.ger_const.SGR :

            txt = fp.read(self.ger_const.SGR_len[sgr_header])
            # print sgr_header,":", txt
            # print sgr_header, " = ",txt
            if (sgr_header.find('new_line') == -1) & (sgr_header.find('space') == -1) :
                try:
                    self.SGR[sgr_header] = int(txt)
                except ValueError:
                    self.SGR[sgr_header] = txt
        self.num_SADR = int(self.SGR["SADR_Nb"])
        self.num_LSR = int(self.SGR["LSR_Nb"])
        self.num_CER = int(self.SGR["CER_Nb"])
        self.num_SOFR = int(self.SGR["SOFR_Nb"])

    def transTo754(self, data_int):
        if data_int <> 0 :
            data_temp1 = data_int >> 7
            data_temp1 = data_temp1 & 0xfffffffe
            signed_bit = (data_int & 0x80000000)
            data_temp1 = data_temp1 & 0x007fffff
            if (signed_bit != 0) :
                data_temp1 = data_temp1 ^ 0x807fffff;
                data_temp1 = data_temp1 + 1;
            data_temp2 = long(data_int & 0x000000ff)
            data_temp2 = (data_temp2 - 1) + 127;
            data_temp2 = data_temp2 & 0x00ff
            data_temp2 = data_temp2 << 23
            data_temp1 = data_temp1 ^ data_temp2
            templ = struct.pack("L", data_temp1)
            # print templ
            f = struct.unpack('f', templ[:4])

            return f[0]
        else :
            return 0.0

    def read_SADR(self, fp):
        self.SADR = []
        self.sat_times = []
        self.sat_positions = []
        self.sat_attitude = []
        self.sat_velocity = []
        self.sat_rate = []
        for it in np.arange(self.num_SADR) :
            sadr_line = {}
            data_float = False
            position = [0, 0, 0]
            attitude = [0, 0, 0, 0]
            velocity = [0, 0, 0]
            rate = [0, 0, 0]

            for sfhr_header in self.ger_const.SFHR :
                if data_float :
                    data = fp.read(4)
                    d_int = struct.unpack_from('I', data[::-1])
                    xx = self.transTo754(d_int[0])
                    # print sfhr_header,"=",xx
                    sadr_line[sfhr_header] = xx
                else:
                    txt = fp.read(self.ger_const.SFHR_len[sfhr_header])
                    # print sfhr_header,"=",txt
                    if (sfhr_header.find("Spare") == -1) & (sfhr_header.find("new_line") == -1) :
                        try:
                            sadr_line[sfhr_header] = int(txt)
                        except ValueError:
                            sadr_line[sfhr_header] = txt
                if sfhr_header == 'Date' :
                    date = float(txt)
                    sec = date % (100.0)
                    mins = ((date - sec) % 10000.0) / 100.0
                    hour = ((date - sec - mins * 100) % (1000000.0)) / 10000.0
                    sat_time = hour * 3600.0 + mins * 60.0 + sec
                    self.sat_times.append(sat_time)
                if sfhr_header == "Position_Px" :
                    position[0] = xx
                if sfhr_header == "Position_Py" :
                    position[1] = xx
                if sfhr_header == "Position_Pz" :
                    position[2] = xx

                if sfhr_header == "Velocity_Vx" :
                    velocity[0] = xx
                if sfhr_header == "Velocity_Vy" :
                    velocity[1] = xx
                if sfhr_header == "Velocity_Vz" :
                    velocity[2] = xx

                if sfhr_header == "Attitude_Q1" :
                    attitude[0] = xx
                if sfhr_header == "Attitude_Q2" :
                    attitude[1] = xx
                if sfhr_header == "Attitude_Q3" :
                    attitude[2] = xx
                if sfhr_header == "Attitude_Q4" :
                    attitude[3] = xx
                if sfhr_header == "Rates_Rx":
                    rate[0] = xx
                if sfhr_header == "Rates_Ry":
                    rate[1] = xx
                if sfhr_header == "Rates_Rz":
                    rate[2] = xx

                if sfhr_header == 'Date' :
                    data_float = True;
                elif sfhr_header == 'Gyro_Gz':
                    data_float = False
            self.sat_positions.append(position)
            self.sat_attitude.append(attitude)
            self.sat_velocity.append(velocity)
            self.SADR.append(sadr_line)
            self.sat_rate.append(rate)
        sat_time = []
        att = []
        pos = []
        vel = []
        for it in range(len(self.sat_times)):
            sat_time.append(self.sat_times[it])
            att.append(self.sat_attitude[it])
            pos.append(self.sat_positions[it])
            vel.append(self.sat_velocity[it])


        att = np.array(att)
        pos = np.array(pos)
        vel = np.array(vel)
        sat_times = np.array(sat_time)
        self.fatt0_cubic_spline = extended_interp1d(sat_times, att[:, 0])
        self.fatt1_cubic_spline = extended_interp1d(sat_times, att[:, 1])  # ipl.interp1d(self.sat_times,att[:,1],kind="cubic")
        self.fatt2_cubic_spline = extended_interp1d(sat_times, att[:, 2])  # ipl.interp1d(self.sat_times,att[:,2],kind="cubic")
        self.fatt3_cubic_spline = extended_interp1d(sat_times, att[:, 3])  # ipl.interp1d(self.sat_times,att[:,3],kind="cubic")
        self.fp0 = extended_interp1d(sat_times, pos[:, 0])  # ipl.interp1d(self.sat_times,pos[:,0],kind='cubic')
        self.fp1 = extended_interp1d(sat_times, pos[:, 1])  # ipl.interp1d(self.sat_times,pos[:,1],kind='cubic')
        self.fp2 = extended_interp1d(sat_times, pos[:, 2])  # ipl.interp1d(self.sat_times,pos[:,2],kind='cubic')
        self.fv0 = extended_interp1d(sat_times, vel[:, 0])  # ipl.interp1d(self.sat_times,vel[:,0],kind='cubic')
        self.fv1 = extended_interp1d(sat_times, vel[:, 1])  # ipl.interp1d(self.sat_times,vel[:,1],kind='cubic')
        self.fv2 = extended_interp1d(sat_times, vel[:, 2])  # ipl.interp1d(self.sat_times,vel[:,2],kind='cubic')

    def find_polynomial3D(self, x, Y):
        n_data, n_dim = Y.shape
        A = np.zeros((n_data, 4))
        A[:, 0] = 1.0
        A[:, 1] = x
        A[:, 2] = x ** 2
        A[:, 3] = x ** 3
        coefs = []
        for k in range(n_dim):
            coef, r, rn, s = np.linalg.lstsq(A, Y[:, k])
            coefs.append(coef)
        return coefs

    def read_LSR(self, fp):
        self.LSR = []

        for it in np.arange(self.num_LSR) :
            lsr_line = {}
            for lsr_header in self.ger_const.LSR :
                txt = fp.read(self.ger_const.LSR_len[lsr_header])
                # print lsr_header,"=",txt
                if (lsr_header.find("Reserved") == -1) & (lsr_header.find("new_line") == -1) :
                    try :
                        lsr_line[lsr_header] = int(txt)
                    except ValueError:
                        lsr_line[lsr_header] = txt
                if "Beg_DSR" in lsr_header:
                    try:
                        beg_bad_line = int(txt)
                    except:
                        pass
                if "End_DSR" in lsr_header:
                    try:
                        end_bad_line = int(txt)
                        if self.bad_lines is None:
                            self.bad_lines = []
                        for k in range(beg_bad_line, end_bad_line + 1):
                            self.bad_lines.append(k)
                    except:
                        pass


            self.LSR.append(lsr_line)

    def read_CER(self, fp):
        self._CER = []

        for it in np.arange(self.num_CER) :
            cer_line = {}
            reserved_len = self.ger_const.CER_len['reserved']
            for cer_header in self.ger_const.CER :
                if cer_header != 'reserved':
                    txt = fp.read(self.ger_const.CER_len[cer_header])
                else:
                    txt = fp.read(reserved_len)
                # if cer_header == 'Rec_Size' :
                #    reserved_len = int(txt) - 4-8-6-10-5-4-4-4-4
                # print cer_header,"=",txt
                if cer_header.find("reserved") == -1 :
                    try :
                        cer_line[cer_header] = int(txt)
                    except ValueError:
                         cer_line[cer_header] = txt
            self._CER.append(cer_line)

    def read_SOFR(self, fp):
        self._SOFR = []
        for it in np.arange(self.num_SOFR) :
            sofr_line = {}
            for sofr_header in self.ger_const.SOFR :
                txt = fp.read(self.ger_const.SOFR_len[sofr_header])
                # print sofr_header, ":", txt
                if (sofr_header == 'Rec_size') :
                    save_data = int(txt)
                elif ((sofr_header == 'SFLN') | (sofr_header == 'SFSC') | (sofr_header == 'LCNT')) :
                    txt = '\x00' + txt
                    # print txt[3]
                    save_data = struct.unpack_from("I", txt[::-1])[0]
                elif ((sofr_header == 'IGPSTHour') | (sofr_header == 'IGPSTMinute') | (sofr_header == 'IGPSTSec')) :
                    save_data = struct.unpack_from("B", txt[::-1])[0]
                elif ((sofr_header == 'IGPSTYear') | (sofr_header == 'IGPSTDay')) :
                    save_data = struct.unpack_from("H", txt[::-1])[0]
                else :
                    save_data = txt
                sofr_line[sofr_header] = save_data
                if sofr_header == 'IGPSTYear':
                    self.gps_year = save_data


                elif sofr_header == 'IGPSTDay':
                    self.gps_day = save_data

                elif sofr_header == 'IGPSTHour' :
                    self.gps_hour = save_data

                elif sofr_header == 'IGPSTMinute' :
                    self.gps_minute = save_data

                elif sofr_header == 'IGPSTSec' :
                    self.gps_second = save_data


            self._SOFR.append(sofr_line)

    def read_image(self, num_line=-1):
        print "Loading Image and ADB data"
        fp = open(self.file_name, "rb")
        # move to image area
        fp.seek(640 + self.num_SADR * self.SADR[0]["Rec_Size"] + self.num_LSR * 128  # Still don't know why 128
                + self.num_CER * self._CER[0]["Rec_Size"] + self.num_SOFR * 256)
        self.GDB = []
        self.ADB = []
        if num_line == -1 :
            num_line_read = self.MFH['DSR_Nb']
        else:
            num_line_read = num_line
        self.image = np.zeros((num_line_read , self.ger_const.width), 'uint8')
        for line in np.arange(num_line_read) :
            # print "Load line #",line
            gdb_line = self.readGDB(fp)
            adb_line = self.readADB(fp)
            image_line = fp.read(self.ger_const.width)
            im_line = np.frombuffer(image_line, 'uint8')
            self.GDB.append(gdb_line)
            self.ADB.append(adb_line)
            self.image[line, :] = im_line
        imageout = self.image
        fp.close()
        return imageout


    def read_write_image(self, out_file_name, num_line=-1):


        print "Loading Image and ADB data"
        fp = open(self.file_name, "rb")
        # move to image area
        fp.seek(640 + self.num_SADR * self.SADR[0]["Rec_Size"] + self.num_LSR * 128  # Still don't know why 128
                + self.num_CER * self._CER[0]["Rec_Size"] + self.num_SOFR * 256)
        self.GDB = []
        self.ADB = []
        if num_line == -1 :
            num_line_read = self.MFH['DSR_Nb']
        else:
            num_line_read = num_line
        gtiffDriver = gdal.GetDriverByName('GTiff')
        self.out_im_file = out_file_name
        dst_ds = gtiffDriver.Create(out_file_name, self.ger_const.width, num_line_read, 1, gdal.GDT_Byte)
        im_band = dst_ds.GetRasterBand(1)
        # self.image_line = np.zeros((1 ,self.ger_const.width),'uint8')
        bad_lines = []
        degraded_lines = []

        for line in np.arange(num_line_read) :
            # print "Load line #",line
            gdb_line = self.readGDB(fp)
            adb_line = self.readADB(fp)
            image_line = fp.read(self.ger_const.width)
            im_line = np.frombuffer(image_line, 'uint8')
            num_zeros = (im_line == 0).sum()
            if (num_zeros > 0) & (num_zeros < self.ger_const.width):
                idx = np.nonzero(im_line == 0)[0]
                min_pixels = idx.min()
                max_pixels = idx.max()
                degraded_lines.append([line + 1, min_pixels + 1, max_pixels + 1])
                bad_lines.append(line)
            elif (num_zeros == self.ger_const.width):
                bad_lines.append(line)
                if self.bad_lines is not None:
                    if self.bad_lines.count(line + 1) == 0:
                        self.bad_lines.append(line + 1)

            self.GDB.append(gdb_line)
            self.ADB.append(adb_line)
            # self.image[line,:] = im_line
            try:
                im_line = im_line.reshape((1, self.ger_const.width))
                im_band.WriteArray(im_line, 0, line)
            except :
                break
        # imageout = self.image
        fp.close()
        if len(degraded_lines) > 0:
            self.degraded_lines = degraded_lines
        Nmax = LV1_2ProductionConstants.LOSS_LINE_N_MAX
        fixing_lines = []
        if (len(bad_lines) > 0) & LV1_2ProductionConstants.LOSS_LINE_CORRECTION:
            print "Attempt to correct  the band lines"
            for bad_line in bad_lines:
                if (num_line_read - bad_line) > Nmax:
                    bad_data = im_band.ReadAsArray(0, bad_line - Nmax, self.ger_const.width , 2 * Nmax + 1)
                    bad_pixels = np.nonzero(bad_data[Nmax , :] == 0)[0]
                    print "There are %d bad pixels in line %d" % (bad_pixels.size, bad_line)
                    interested_areas = bad_data[:, bad_pixels]
                    valid_data = (interested_areas > 0).astype('int')
                    n_top = np.zeros((bad_pixels.size), 'int') - 1
                    n_down = np.zeros((bad_pixels.size), 'int') - 1
                    for idr in range(Nmax):
                        n_top = n_top * (1 - valid_data[idr, :]) + idr * valid_data[idr, :]
                        n_down = n_down * (1 - valid_data[2 * Nmax - idr, :]) + (2 * Nmax - idr) * valid_data[2 * Nmax - idr, :]
                    fixing_line = bad_data[Nmax, :]
                    ok_pixels = (n_top >= 0) * (n_down >= 0) * (n_down - n_top < Nmax)
                    fixable_pixels = bad_pixels[ok_pixels ]
                    print "We are able to fix %d pixels in line: %d" % (len(fixable_pixels), bad_line)
                    if len(fixable_pixels) > 0:

                        n_top = n_top[ok_pixels]
                        n_down = n_down[ok_pixels]
                        top_data = bad_data[n_top, fixable_pixels].astype('float32')
                        down_data = bad_data[n_down, fixable_pixels].astype('float32')
                        corrected_data = top_data + ((Nmax - n_top) * (down_data - top_data)) / (n_down - n_top)
                        corrected_data = corrected_data * (corrected_data > 0) + 255 * (corrected_data > 255.0)
                        corrected_data = corrected_data.astype('uint8')
                        fixing_line[fixable_pixels] = corrected_data
                        fixing_lines.append([fixing_line, bad_line])
            for lin_data, bad_line in fixing_lines:
                im_band.WriteArray(lin_data.reshape(1, self.ger_const.width), 0, bad_line)




                    # num_zeros_up = (bad_data[Nmax,:]==0).astype('int')
                    # num_zeros_down = (bad_data[Nmax, :] == 0).astype('int')
                    # for idx in range(Nmax):
                    #    num_zeros = (bad_data[Nmax+idx,:]==0).astype('int')
                    #    num_zeros_down  = (num_zeros_down+1)*num_zeros*(num_zeros_down > 0)
                    #    num_zeros = (bad_data[Nmax - idx, :] == 0).astype('int')
                    #    num_zeros_up = (num_zeros_up + 1) * num_zeros * (num_zeros_up > 0)
                    # num_zeros = (num_zeros_down + num_zeros_up -1)*(num_zeros >0)
                    # fixable = np.nonzero((num_zeros<=Nmax)*num_zeros)
                    # print "fixable pixels: ", len(fixable[0])








        dst_ds = None
        # return imageout
    def readGDB(self, fp):

        gdb_line = {}
        for gdb_header in self.ger_const.GDB :
            if gdb_header != 'Spare' :
                data = fp.read(4)
                gdb_line[gdb_header] = struct.unpack_from("I", data[::-1])[0]
            else:
                data = fp.read(self.ger_const.GDB_len[gdb_header])

        return gdb_line

    def readADB(self, fp):

        adb_line = {}
        for adb_header in self.ger_const.ADB :
            if adb_header != 'Spare' :
                if (self.ger_const.ADB_len[adb_header] == 1) :
                    data = fp.read(1)
                    adb_line[adb_header] = struct.unpack_from("B", data)[0]
                elif (self.ger_const.ADB_len[adb_header] == 2) :
                    data = fp.read(2)
                    adb_line[adb_header] = struct.unpack_from("H", data[::-1])[0]
                elif (self.ger_const.ADB_len[adb_header] == 4) :
                    data = fp.read(4)
                    if adb_header != 'Microsec':
                        adb_line[adb_header] = struct.unpack_from("I", data[::-1])[0]
                    else:
                        # d_int = struct.unpack("f",data[::-1])
                        temp = struct.unpack_from("I", data[::-1])[0]
                        # print "%d"%temp
                        # xx = d_int[0] #self.transTo754(d_int[0])
                        adb_line[adb_header] = temp
                elif (self.ger_const.ADB_len[adb_header] == 16) :
                    data = fp.read(16)
                    adb_line[adb_header] = data
            else:
                data = fp.read(self.ger_const.ADB_len[adb_header])
        return adb_line

    def computeSatPositionVelocityAttitude(self, time):
        from heapq import nsmallest
        if (len(self.sat_attitude) == 0) | (len(self.sat_positions) == 0) | (len(self.sat_times) == 0) :
            print "ERROR: No Satellite Information Exists!!"
            return None
        elif (len(self.sat_attitude) != len(self.sat_times)) | (len(self.sat_times) != len(self.sat_positions)) :
            print "Error: Data is not completed!!"
            return None
        else:
            nearbytimes = nsmallest(8, self.sat_times, key=lambda x: abs(x - time))
            idx = self.sat_times.index(min(nearbytimes))
            # att = np.array(self.sat_attitude[idx:idx+8])
            # f0 = ipl.interp1d(nearbytimes,att[:,0])
            # f1 = ipl.interp1d(nearbytimes,att[:,1])
            # f2 = ipl.interp1d(nearbytimes,att[:,2])
            # f3 = ipl.interp1d(nearbytimes,att[:,3])
            # attitude = np.zeros((4,))
            # attitude[0] = f0(time)
            # attitude[1] = f1(time)
            # attitude[2] = f2(time)
            # attitude[3] = f3(time)

            pout = 0.0
            attitude = 0.0
            vout = 0.0
            for j in range(idx, idx + 8) :
                t_fac = 1.0
                for i in range(idx, idx + 8):
                    if (i != j) :
                        t_fac *= (time - self.sat_times[i]) / (self.sat_times[j] - self.sat_times[i])
                pout += np.array(self.sat_positions[j]) * t_fac
                vout += np.array(self.sat_velocity[j]) * t_fac
                attitude += np.array(self.sat_attitude[j]) * t_fac
            return pout, vout, attitude

    def write_MFH(self, file_name):
        print "writing MFH!"
        fp = open(file_name, "w")
        for mfh_header in self.ger_const.MFH :
            try :
                data = self.MFH[mfh_header]
                if isinstance(data, int) :
                    fp.write(mfh_header + "    :    %d" % data + "\n")
                elif isinstance(data, float) :
                    fp.write(mfh_header + "    :    %f" % data + "\n")
                else :
                    fp.write(mfh_header + "    :    " + data + "\n")
            except :
                pass

        fp.close()
    def write_SGR(self, file_name):
        print "writing SGR!"
        fp = open(file_name, "w")
        fp.write("#################  SGR FILE ################\n")
        fp.write('#             ' + self.file_name + '            #\n')
        fp.write("############################################\n")
        for sgr_header in self.ger_const.SGR :
            try :
                data = self.SGR[sgr_header]
                if isinstance(data, int) :
                    fp.write(sgr_header + "    :    %d" % data + "\n")
                elif isinstance(data, float) :
                    fp.write(sgr_header + "    :    %f" % data + "\n")
                else :
                    fp.write(sgr_header + "    :    " + data + "\n")
            except :
                pass
        fp.close()

    def write_SADR(self, file_name):
        print "writing SADR!"
        fp = open(file_name, "w")
        fp.write("#################  SADR FILE ################\n")
        fp.write('#             ' + self.file_name + '            #\n')
        fp.write("############################################\n")
        sadr_len = len(self.SADR)
        for idx in np.arange(sadr_len):
            fp.write("[%d]##############################\n" % idx)
            for sfhr_header in self.ger_const.SFHR :
                try :
                    data = self.SADR[idx][sfhr_header]
                    if isinstance(data, int) :
                        fp.write("    " + sfhr_header + "    :    %d" % data + "\n")
                    elif isinstance(data, float) :
                        fp.write("    " + sfhr_header + "    :    %f" % data + "\n")
                    else :
                        fp.write("    " + sfhr_header + "    :    " + data + "\n")
                except :
                    pass
            fp.write("#############################################\n")
        fp.close()


    def write_LSR(self, file_name):
        print "writing LSR!"
        fp = open(file_name, "w")
        fp.write("#################  LSR FILE ################\n")
        fp.write('#             ' + self.file_name + '            #\n')
        fp.write("############################################\n")
        lsr_len = len(self.LSR)
        for idx in np.arange(lsr_len):
            fp.write("[%d]##############################\n" % idx)
            for lsr_header in self.ger_const.LSR :
                try :
                    data = self.LSR[idx][lsr_header]
                    if isinstance(data, int) :
                        fp.write("    " + lsr_header + "    :    %d" % data + "\n")
                    elif isinstance(data, float) :
                        fp.write("    " + lsr_header + "    :    %f" % data + "\n")
                    else :
                        fp.write("    " + lsr_header + "    :    " + data + "\n")
                except :
                    pass
            fp.write("#############################################\n")
        fp.close()
    def write_CER(self, file_name):
        print "writing CER!"
        fp = open(file_name, "w")
        fp.write("#################  CER FILE ################\n")
        fp.write('#             ' + self.file_name + '            #\n')
        fp.write("############################################\n")
        cer_len = len(self._CER)
        for idx in np.arange(cer_len):
            fp.write("\n\n[%d]##############################\n" % idx)
            for cer_header in self.ger_const.CER :
                try :
                    data = self._CER[idx][cer_header]
                    if isinstance(data, int) :
                        fp.write("    " + cer_header + "    :    %d" % data + "\n")
                    elif isinstance(data, float) :
                        fp.write("    " + cer_header + "    :    %f" % data + "\n")
                    else :
                        fp.write("    " + cer_header + "    :    " + data + "\n")
                except :
                    pass
            fp.write("#############################################\n")
        fp.close()

    def write_SOFR(self, file_name):
        print "writing SOFR!"
        fp = open(file_name, "w")
        fp.write("#################  SOFR FILE ################\n")
        fp.write('#             ' + self.file_name + '            #\n')
        fp.write("############################################\n")
        sofr_len = len(self._SOFR)
        for idx in np.arange(sofr_len):
            fp.write("\n\n[%d]##############################\n" % idx)
            for sofr_header in self.ger_const.SOFR :
                try :
                    data = self._SOFR[idx][sofr_header]
                    if isinstance(data, int) :
                        fp.write("    " + sofr_header + "    :    %d" % data + "\n")
                    elif isinstance(data, float) :
                        fp.write("    " + sofr_header + "    :    %f" % data + "\n")
                    else :
                        fp.write("    " + sofr_header + "    :    " + data + "\n")
                except :
                    pass
            fp.write("#############################################\n")
        fp.close()

    def write_GDB(self, file_name):
        print "writing GDB!"
        fp = open(file_name, "w")
        fp.write("#################  GDB FILE ################\n")
        fp.write('#             ' + self.file_name + '            #\n')
        fp.write("############################################\n\b")
        gdb_len = len(self.GDB)
        for idx in np.arange(gdb_len):
            txt = "\n[%d] " % (idx + 1)
            for gdb_header in self.ger_const.GDB :
                try :
                    data = self.GDB[idx][gdb_header]
                    if isinstance(data, int) :
                        txt += "  " + gdb_header + " : %d" % data
                    elif isinstance(data, float) :
                        txt += "  " + gdb_header + " : %f" % data
                    else :
                        txt += "  " + gdb_header + " : " + data
                except :
                    pass
            fp.write(txt)
        fp.close()

    def write_ADB(self, file_name):
        print "writing ADB!"
        modified = self.modified

        flight_position_file_name = file_name[:-4] + ".pos"
        flight_velocity_file_name = file_name[:-4] + ".vel"
        flight_attitude_file_name = file_name[:-4] + ".att"
        flight_time_file_name = file_name[:-4] + ".tim"
        gains_file_name = file_name[:-4] + ".gain"
        # f_pixel_pos = open(pixel_local_file_name,"wb")
        # f_pos = open(flight_position_file_name,"w")
        # f_vec = open(flight_velocity_file_name,"w")
        # f_att = open(flight_attitude_file_name,"w")
        # f_tim = open(flight_time_file_name,"w")
        fp = open(file_name, "w")
        fp.write("#################  ADB FILE ################\n")
        fp.write('#             ' + self.file_name + '            #\n')
        fp.write("############################################\n\b")
        adb_len = len(self.ADB)
        positions = np.zeros((adb_len, 3))
        attitudes = np.zeros((adb_len, 4))
        velocities = np.zeros((adb_len, 3))
        true_times = np.zeros((adb_len,))
        self.line_gain_numbers = []
        rm_im = gdal.Open(self.out_im_file, gdal.GA_Update)
        band1 = rm_im.GetRasterBand(1)
        # pb = progressbar.ProgressBar(maximum=adb_len,win_name="Writing ADB")
        if self.im_type == "PAN":
            gain_array = np.zeros((adb_len, 4), 'int')
        elif self.im_type == "MS":
            gain_array = np.zeros((adb_len, 1), 'int')


        for idx in np.arange(adb_len):
            txt = "\n[%d] " % (idx + 1)
            progress = float(idx) / float(adb_len) * 100
            if idx % 10000 == 0:
                print "writing.............%f %%" % progress
            # pb.updateValue(float(idx))
            for adb_header in self.ger_const.ADB :
                if adb_header != 'IAD':
                    try :
                        data = self.ADB[idx][adb_header]
                        if isinstance(data, int) :
                            txt += "  " + adb_header + " : %d" % data
                        elif isinstance(data, float) :
                            txt += "  " + adb_header + " : %f" % data
                        else :
                            txt += "  " + adb_header + " : " + data
                    except :
                        pass
                else:
                    data = self.ADB[idx][adb_header]
                    byte1 = ord(data[0])
                    byte2 = ord(data[1])
                    byte3 = ord(data[2])
                    byte4 = ord(data[3])

                    byte5 = ord(data[4])
                    byte6 = ord(data[5])
                    byte7 = ord(data[6])
                    byte8 = ord(data[7])

                    byte9 = ord(data[8])
                    byte10 = ord(data[9])
                    byte11 = ord(data[10])
                    byte12 = ord(data[11])

                    byte13 = ord(data[12])
                    byte14 = ord(data[13])
                    byte15 = ord(data[14])
                    byte16 = ord(data[15])

                    if self.im_type == "MS":
                        init = byte1 >> 7
                        ipu = (byte1 & 0x7F) >> 6
                        band = (byte1 & 0x3F) >> 5
                        gain = (byte3 & 0xF0) >> 4
                        self.line_gain_numbers.append(gain)
                        gain_array[idx, 0] = gain
                        if modified:
                            data1line = band1.ReadAsArray(0, idx, 6000, 1)
                            data1linef = data1line.astype('float32').flatten()

                            gainv = self.gains[gain]
                            darkcv = self.darkcurrents[gain]
                            data1linef = (data1linef - darkcv) / gainv
                            data1linef = data1linef * (data1linef < 255) + 255 * (data1linef >= 255)
                            data1linef = data1linef * (data1line < 255) + 255 * (data1line >= 255)
                            data1linef = np.round(data1linef) * (data1line > 0)
                            data1line = data1linef.astype('uint8')
                            band1.WriteArray(data1line, 0, idx)

                        # begoff = (byte3&0x0f)<<16+byte4
                        txt += " init: %d" % init
                        txt += " ipu: %d" % ipu
                        if band == 1:
                            txt += " band: MS "
                        else :
                            txt += " band: PAN"
                        txt += " gain: %d" % gain
                        # txt += " begoff: %d"%begoff
                    elif self.im_type == "PAN":
                        initlo = byte1 >> 7
                        ipulo = (byte1 & 0x7F) >> 6
                        bandlo = (byte1 & 0x3F) >> 5
                        gainlo = (byte9 & 0xF0) >> 4
                        gain_array[idx, 0] = gainlo
                        if modified:
                            data1line = band1.ReadAsArray(0, idx, 12000, 1)
                            data1linef = data1line.astype('float32').flatten()

                            if gainlo <= 10:
                                gainvlo = self.gains[gainlo][0:6000:2]
                                darkcvlo = self.darkcurrents[gainlo][0:6000:2]
                                gaintemp = gainlo
                            else :
                                print "Gain number Error at line %d with gain number %d." % (idx, gainlo)
                                print "Replace the previous gain number of %d" % gaintemp
                                gainlo = gaintemp
                                gainvlo = self.gains[gainlo][0:6000:2]
                                darkcvlo = self.darkcurrents[gainlo][0:6000:2]

                        txt += " init LO: %d" % initlo
                        txt += " ipu LO: %d" % ipulo
                        if bandlo == 1:
                            txt += " band LO: MS "
                        else :
                            txt += " band LO: PAN"
                        txt += " gain LO: %d" % gainlo

                        initle = byte2 >> 7
                        ipule = (byte2 & 0x7F) >> 6
                        bandle = (byte2 & 0x3F) >> 5
                        gainle = (byte10 & 0xF0) >> 4
                        gain_array[idx, 1] = gainle
                        if modified:
                            gainvle = self.gains[gainle][1:6000:2]
                            darkcvle = self.darkcurrents[gainle][1:6000:2]


                        txt += " init LE: %d" % initle
                        txt += " ipu LE: %d" % ipule
                        if bandle == 1:
                            txt += " band LE: MS "
                        else :
                            txt += " band LE: PAN"
                        txt += " gain LE: %d" % gainle

                        initro = byte3 >> 7
                        ipuro = (byte3 & 0x7F) >> 6
                        bandro = (byte3 & 0x3F) >> 5
                        gainro = (byte11 & 0xF0) >> 4
                        gain_array[idx, 2] = gainro
                        if modified:
                            gainvro = self.gains[gainro][6000::2]
                            darkcvro = self.darkcurrents[gainro][6000::2]


                        txt += " init RO : %d" % initro
                        txt += " ipu RO: %d" % ipuro
                        if bandro == 1:
                            txt += " band RO: MS "
                        else :
                            txt += " band RO: PAN"
                        txt += " gain RO: %d" % gainro

                        initre = byte4 >> 7
                        ipure = (byte4 & 0x7F) >> 6
                        bandre = (byte4 & 0x3F) >> 5
                        gainre = (byte12 & 0xF0) >> 4
                        gain_array[idx, 3] = gainre
                        if modified:
                            gainvre = self.gains[gainre][6001::2]
                            darkcvre = self.darkcurrents[gainre][6001::2]


                        txt += " init RE : %d" % initre
                        txt += " ipu RE: %d" % ipure
                        if bandre == 1:
                            txt += " band RE: MS "
                        else :
                            txt += " band RE: PAN"
                        txt += " gain RE: %d" % gainre
                        self.line_gain_numbers.append([gainlo, gainle, gainro, gainre])
                        if modified:
                            data1linef[0:6000:2] = (data1linef[0:6000:2] - darkcvlo) / gainvlo
                            data1linef[1:6000:2] = (data1linef[1:6000:2] - darkcvle) / gainvle
                            data1linef[6000::2] = (data1linef[6000::2] - darkcvro) / gainvro
                            data1linef[6001::2] = (data1linef[6001::2] - darkcvre) / gainvre
                            data1linef = data1linef * (data1linef < 255) + 255 * (data1linef >= 254.8)
                            data1linef = data1linef * (data1line < 255) + 255 * (data1line >= 254.8)
                            data1line = np.round(data1linef).astype('uint8')
                            band1.WriteArray(data1line, 0, idx)


                if adb_header == 'SFSC' :
                    sfsc = data
                if adb_header == 'Line_Counter':
                    lcnt = data
                if adb_header == 'Microsec' :
                    microsec = data



            # txt =''
            txt += "  actual year : %d" % self.gps_year
            day_year = str(self.gps_year) + ' ' + str(self.gps_day)
            dt = datetime.datetime.strptime(day_year, '%Y %j')
            txt += "  actual month: %d" % dt.month
            txt += "  actual day : %d" % dt.day
            if idx == 0:
                self.year = dt.year
                self.month = dt.month
                self.day = dt.day

            gpstime = self.gps_hour * 60 * 60. + self.gps_minute * 60.0 + self.gps_second

            # true_time = gpstime +(float(lcnt)-self.ger_const.lcnt_offset) * 0.0003086 + float(sfsc) * 8 * self.ger_const.time_per_line \
            #            + self.ger_const.time_per_line*np.round(float(microsec)/(self.ger_const.time_per_line*1e6))
            if idx == 0:
                true_time = gpstime + (float(lcnt) - self.ger_const.lcnt_offset) * 0.0003086 + float(
                    sfsc) * 8 * self.ger_const.time_per_line
                last_line_time = gpstime + (float(lcnt) - self.ger_const.lcnt_offset) * 0.0003086 + float(
                    sfsc) * 8 * self.ger_const.time_per_line + self.ger_const.time_per_line * adb_len
                if last_line_time > self.sat_times[-1]:
                    num_addition_samples = int(np.ceil((last_line_time - self.sat_times[-1]) / 0.25))
                    print "we need to interplate %d more flight info." % num_addition_samples
                    new_length = len(self.sat_times) + num_addition_samples
                    sat_times = np.zeros(new_length)
                    sat_times[:-num_addition_samples] = np.array(self.sat_times)
                    att = np.zeros((new_length, 4))
                    att[:-num_addition_samples, :] = np.array(self.sat_attitude)
                    pos = np.zeros((new_length, 3))
                    pos[:-num_addition_samples, :] = np.array(self.sat_positions)
                    vel = np.zeros((new_length, 3))
                    vel[:-num_addition_samples, :] = np.array(self.sat_velocity)
                    angles = np.zeros((new_length, 3))
                    q0 = att[:-num_addition_samples, 0]
                    q1 = att[:-num_addition_samples, 1]
                    q2 = att[:-num_addition_samples, 2]
                    q3 = att[:-num_addition_samples, 3]
                    ysq = q2 * q2
                    t0 = 2.0 * (q0 * q1 + q2 * q3)
                    t1 = 1 - 2.0 * (q1 * q1 + ysq)

                    roll = np.arctan2(t0 , t1)
                    t2 = 2.0 * (q0 * q2 - q3 * q1)
                    t2 = 1.0 * (t2 > 1.0) - 1.0 * (t2 < -1) + t2 * (t2 <= 1.0) * (t2 >= -1)
                    pith = np.arcsin(t2)
                    t3 = +2.0 * (q0 * q3 + q1 * q2)
                    t4 = +1.0 - 2.0 * (ysq + q3 * q3)
                    yaw = np.arctan2(t3, t4)  # 2.*(q0*q3+q1*q2),1-2.*(q2**2+q3**2))
                    ratex = (roll[2:] - roll[:-2]) / 0.5
                    ratey = (pith[2:] - pith[:-2]) / 0.5
                    ratez = (yaw[2:] - yaw[:-2]) / 0.5

                    mratex = np.zeros(len(self.sat_rate))  # np.array(self.sat_rate[:,0])
                    mratey = np.zeros(len(self.sat_rate))
                    mratez = np.zeros(len(self.sat_rate))
                    for xx in range(len(self.sat_rate)):
                        mratex[xx] = self.sat_rate[xx][0]
                        mratey[xx] = self.sat_rate[xx][1]
                        mratez[xx] = self.sat_rate[xx][2]

                    biasx = np.mean(ratex - mratex[1:-1])
                    biasy = np.mean(ratey - mratey[1:-1])
                    biasz = np.mean(ratez - mratez[1:-1])

                    angles[:-num_addition_samples, 0] = roll
                    angles[:-num_addition_samples, 1] = pith
                    angles[:-num_addition_samples, 2] = yaw
                    num_used_samples = 20


                    st = np.array(self.sat_times[-num_used_samples:])
                    spos = np.array(self.sat_positions[-num_used_samples:])
                    satt = np.array(self.sat_attitude[-num_used_samples:])
                    svel = np.array(self.sat_velocity[-num_used_samples:])
                    stmin = st.min()
                    st = st - stmin
                    A = np.zeros((num_used_samples, 4))
                    A[:, 0] = 1.0
                    A[:, 1] = st
                    A[:, 2] = st * st
                    A[:, 3] = st ** 3

                    coefatt, r, rnk, s = np.linalg.lstsq(A, satt)

                    coefpos, r, rnk, s = np.linalg.lstsq(A, spos)
                    coefvel, r, rnk, s = np.linalg.lstsq(A, svel)
                    sadr_len = len(self.sat_times)
                    for lt in range(num_addition_samples):
                        st1 = self.sat_times[-1] + 0.25 * lt - stmin
                        atto = coefatt[0] + coefatt[1] * st1 + coefatt[2] * (st1 ** 2) + coefatt[3] * (st1 ** 3)

                        poso = coefpos[0] + coefpos[1] * st1 + coefpos[2] * (st1 ** 2) + coefpos[3] * (st1 ** 3)

                        velo = coefvel[0] + coefvel[1] * st1 + coefvel[2] * (st1 ** 2) + coefvel[3] * (st1 ** 3)

                        st1 = self.sat_times[-1] + 0.25 * (1 + lt) - stmin
                        sat_times[sadr_len + lt] = st1 + stmin
                        att2 = coefatt[0] + coefatt[1] * st1 + coefatt[2] * (st1 ** 2) + coefatt[3] * (st1 ** 3)
                        # self.sat_attitude.append(att2-atto + self.sat_attitude[-1])
                        # att[sadr_len + lt] = att2 - atto + att[sadr_len + lt - 1]

                        pos2 = coefpos[0] + coefpos[1] * st1 + coefpos[2] * (st1 ** 2) + coefpos[3] * (st1 ** 3)
                        pos[sadr_len + lt] = pos2 - poso + pos[sadr_len + lt - 1]
                        # self.sat_positions.append(pos2-poso + self.sat_positions[-1])

                        vel2 = coefvel[0] + coefvel[1] * st1 + coefvel[2] * (st1 ** 2) + coefvel[3] * (st1 ** 3)
                        vel[sadr_len + lt] = vel2 - velo + vel[sadr_len + lt - 1]
                        # self.sat_velocity.append(vel2 - velo + self.sat_velocity[-1])
                        angles[sadr_len + lt, 0] = angles[sadr_len - 1, 0] + (self.sat_rate[-1][0] - biasx) * (0.25 * lt + 0.25)
                        angles[sadr_len + lt, 1] = angles[sadr_len - 1, 1] + (self.sat_rate[-1][1] - biasy) * (0.25 * lt + 0.25)
                        angles[sadr_len + lt, 2] = angles[sadr_len - 1, 2] + (self.sat_rate[-1][2] - biasz) * (0.25 * lt + 0.25)
                        rolls = angles[sadr_len + lt, 0]
                        pitchs = angles[sadr_len + lt, 1]
                        yaws = angles[sadr_len + lt, 2]
                        t0 = np.cos(yaws * 0.5)
                        t1 = np.sin(yaws * 0.5)
                        t2 = np.cos(rolls * 0.5)
                        t3 = np.sin(rolls * 0.5)
                        t4 = np.cos(pitchs * 0.5)
                        t5 = np.sin(pitchs * 0.5)
                        q0 = t0 * t2 * t4 + t1 * t3 * t5
                        q1 = t0 * t3 * t4 - t1 * t2 * t5
                        q2 = t0 * t2 * t5 + t1 * t3 * t4
                        q3 = t1 * t2 * t4 - t0 * t3 * t5
                        sign0 = np.sign(q0 * att[sadr_len - 1][0])
                        sign1 = np.sign(q1 * att[sadr_len - 1][1])
                        sign2 = np.sign(q2 * att[sadr_len - 1][2])
                        sign3 = np.sign(q3 * att[sadr_len - 1][3])
                        signs = np.array([sign0, sign1, sign2, sign3])
                        if (signs.mean() > 0):  # all the same sign
                            att[sadr_len + lt] = np.array([q0, q1, q2, q3])
                        elif (signs.mean() < 0):  # all the same sign
                            att[sadr_len + lt] = -np.array([q0, q1, q2, q3])
                        elif (signs.mean() == 0):  # all the same sign
                            att[sadr_len + lt] = np.sign(q0 * att[sadr_len - 1][0]) * np.array([q0, q1, q2, q3])
                else:
                    new_length = len(self.sat_times)
                    sat_times = np.zeros(new_length)
                    sat_times[:] = np.array(self.sat_times)
                    att = np.zeros((new_length, 4))
                    att[:, :] = np.array(self.sat_attitude)
                    pos = np.zeros((new_length, 3))
                    pos[:, :] = np.array(self.sat_positions)
                    vel = np.zeros((new_length, 3))
                    vel[:, :] = np.array(self.sat_velocity)
                    angles = np.zeros((new_length, 3))
                    q0 = att[: , 0]
                    q1 = att[: , 1]
                    q2 = att[: , 2]
                    q3 = att[: , 3]
                    ysq = q2 * q2
                    t0 = 2.0 * (q0 * q1 + q2 * q3)
                    t1 = 1 - 2.0 * (q1 * q1 + ysq)

                    roll = np.arctan2(t0, t1)
                    t2 = 2.0 * (q0 * q2 - q3 * q1)
                    t2 = 1.0 * (t2 > 1.0) - 1.0 * (t2 < -1) + t2 * (t2 <= 1.0) * (t2 >= -1)
                    pith = np.arcsin(t2)
                    t3 = +2.0 * (q0 * q3 + q1 * q2)
                    t4 = +1.0 - 2.0 * (ysq + q3 * q3)
                    yaw = np.arctan2(t3, t4)  # 2.*(q0*q3+q1*q2),1-2.*(q2**2+q3**2))


                    mratex = np.zeros(len(self.sat_rate))  # np.array(self.sat_rate[:,0])
                    mratey = np.zeros(len(self.sat_rate))
                    mratez = np.zeros(len(self.sat_rate))
                    for xx in range(len(self.sat_rate)):
                        mratex[xx] = self.sat_rate[xx][0]
                        mratey[xx] = self.sat_rate[xx][1]
                        mratez[xx] = self.sat_rate[xx][2]



                    angles[: , 0] = roll
                    angles[: , 1] = pith
                    angles[: , 2] = yaw

                self.fatt0_cubic_spline = extended_interp1d(sat_times, att[:, 0])
                self.fatt1_cubic_spline = extended_interp1d(sat_times, att[:,
                                                                       1])  # ipl.interp1d(self.sat_times,att[:,1],kind="cubic")
                self.fatt2_cubic_spline = extended_interp1d(sat_times, att[:,
                                                                       2])  # ipl.interp1d(self.sat_times,att[:,2],kind="cubic")
                self.fatt3_cubic_spline = extended_interp1d(sat_times, att[:,
                                                                       3])  # ipl.interp1d(self.sat_times,att[:,3],kind="cubic")
                self.fp0 = extended_interp1d(sat_times,
                                             pos[:, 0])  # ipl.interp1d(self.sat_times,pos[:,0],kind='cubic')
                self.fp1 = extended_interp1d(sat_times,
                                             pos[:, 1])  # ipl.interp1d(self.sat_times,pos[:,1],kind='cubic')
                self.fp2 = extended_interp1d(sat_times,
                                             pos[:, 2])  # ipl.interp1d(self.sat_times,pos[:,2],kind='cubic')
                self.fv0 = extended_interp1d(sat_times,
                                             vel[:, 0])  # ipl.interp1d(self.sat_times,vel[:,0],kind='cubic')
                self.fv1 = extended_interp1d(sat_times,
                                             vel[:, 1])  # ipl.interp1d(self.sat_times,vel[:,1],kind='cubic')
                self.fv2 = extended_interp1d(sat_times,
                                             vel[:, 2])  # ipl.interp1d(self.sat_times,vel[:,2],kind='cubic')

                self.froll = extended_interp1d(sat_times, angles[:, 0])
                self.fpitch = extended_interp1d(sat_times, angles[:, 1])
                self.fyaw = extended_interp1d(sat_times, angles[:, 2])



            else:
                true_time = true_times[idx - 1] + self.ger_const.time_per_line
            true_times[idx] = true_time
            # save_time = true_time
            hour = int(np.floor(true_time / 3600.0))
            true_time -= hour * 3600.0
            minute = int(np.floor(true_time) / 60.0)
            second = true_time - minute * 60.0
            microsec = int((second % 1.0) * 1e6)
            txt += "  actual hour : %d" % hour
            txt += "  actual minute : %d" % minute
            txt += "  actual second : %f" % second
            given_time = hour * 3600.0 + minute * 60.0 + second
            roll = self.froll.get_values(given_time)
            pitch = self.fpitch.get_values(given_time)
            yaw = self.fyaw.get_values(given_time)
            t0 = np.cos(yaw * 0.5)
            t1 = np.sin(yaw * 0.5)
            t2 = np.cos(roll * 0.5)
            t3 = np.sin(roll * 0.5)
            t4 = np.cos(pitch * 0.5)
            t5 = np.sin(pitch * 0.5)


            q0 = t0 * t2 * t4 + t1 * t3 * t5
            q1 = t0 * t3 * t4 - t1 * t2 * t5
            q2 = t0 * t2 * t5 + t1 * t3 * t4
            q3 = t1 * t2 * t4 - t0 * t3 * t5

            attitude = np.array([q0, q1, q2, q3])
            #                      self.fatt1_cubic_spline.get_values(given_time),
            #                      self.fatt2_cubic_spline.get_values(given_time),
            #                      self.fatt3_cubic_spline.get_values(given_time)])

            # xt = np.array([1.0,given_time,given_time**2, given_time**3])
            p0 = self.fp0.get_values(given_time)
            p1 = self.fp1.get_values(given_time)
            p2 = self.fp2.get_values(given_time)


            v0 = self.fv0.get_values(given_time)
            v1 = self.fv1.get_values(given_time)
            v2 = self.fv2.get_values(given_time)


            position = [p0, p1, p2]
            velocity = [v0, v1, v2]
            txt += "\n     PositionX: %f\n     PositionY: %f\n     PositionZ: %f" % (position[0], position[1], position[2])
            txt += "\n     Attitude1: %f\n     Attitude2: %f\n     Attitude3: %f\n     Attitude4: %f" % (attitude[0], attitude[1], attitude[2], attitude[3])

            positions[idx, :] = np.array(position)
            velocities[idx, :] = np.array(velocity)
            attitudes[idx, :] = np.array(attitude)

            fp.write(txt)
            fp.flush()
        rm_im = None

        np.savetxt(flight_position_file_name, positions, fmt="%.24e")
        np.savetxt(flight_velocity_file_name, velocities, fmt="%.24e")
        np.savetxt(flight_attitude_file_name, attitudes, fmt="%.24e")
        np.savetxt(flight_time_file_name, true_times, fmt="%.24e")
        np.savetxt(gains_file_name, gain_array, fmt="%d")
        fp.close()


    def write_image(self, file_name):
        cv2.imwrite(file_name, self.image)

def readGainsAndDarkCurrent(cpf_file, band, gain_number):
    tree = ET.parse(cpf_file)
    root = tree.getroot()
    if band == "PAN":
        gains_txt = root.findall("./RadiometricParameters/PAN/G%d/DetectorRelativeGains" % (gain_number))[0].text
        darkCurrent_txt = root.findall("./RadiometricParameters/PAN/G%d/DarkCurrents" % (gain_number))[0].text
    else:
        gains_txt = root.findall("./RadiometricParameters/B%d/G%d/DetectorRelativeGains" % (band, gain_number))[0].text
        darkCurrent_txt = root.findall("./RadiometricParameters/B%d/G%d/DarkCurrents" % (band, gain_number))[0].text
    # print gains_txt
    gains_txt = gains_txt.split(",")

    darkCurrent_txt = darkCurrent_txt.split(",")
    gains = []
    darkCurrents = []
    for it in range(len(gains_txt)):
        gains.append(float(gains_txt[it]))
        darkCurrents.append(float(darkCurrent_txt[it]))
    gains = np.array(gains)
    darkCurrents = np.array(darkCurrents)
    return gains, darkCurrents


def readGerMSFiles(file_names, out_file_names, cpf_file_name, force_run=False):
    """

    :param file_names: List of Input file names for each MS bands with ."ger" suffix
    :param out_file_names:  List of output file names for each MS bands without suffix
    :param cpf_file_name:  CPF file use
    :return:  None
    """
    g1 = []
    g2 = []
    g3 = []
    g4 = []
    d1 = []
    d2 = []
    d3 = []
    d4 = []

    for gnumber in range(1, 11) :
        g, d = readGainsAndDarkCurrent(cpf_file_name, 1, gnumber)
        g1.append(g)
        d1.append(d)

        g, d = readGainsAndDarkCurrent(cpf_file_name, 2, gnumber)
        g2.append(g)
        d2.append(d)

        g, d = readGainsAndDarkCurrent(cpf_file_name, 3, gnumber)
        g3.append(g)
        d3.append(d)

        g, d = readGainsAndDarkCurrent(cpf_file_name, 4, gnumber)
        g4.append(g)
        d4.append(d)
    gain = [g1, g2, g3, g4]
    darkcurrent = [d1, d2, d3, d4]
    extensions = ["mfh", "sgr", "sadr", "lsr", "_cer", "sofr", "tif", "gdb", "adb"]
    band_bad_lines = []
    band_degraded_lines = []
    for k in range(4) :
        t_m_ger = os.lstat(file_names[k]).st_mtime
        outfilename = out_file_names[k]

        if force_run == False :
            all_file_exists = True
            for extension in extensions :
                all_file_exists = all_file_exists & (os.path.isfile(outfilename + "." + extension))
                if all_file_exists :
                    t_m_f = os.lstat(outfilename + "." + extension).st_mtime
                    all_file_exists &= t_m_f > t_m_ger
                else:
                    break
            if not all_file_exists:
                theos_ger_data = theos_ger_file("MS", file_names[k], gain[k], darkcurrent[k])
                theos_ger_data.band = k + 1
                # theos_ger_data.band = 1
                theos_ger_data.write_MFH(outfilename + ".mfh")
                theos_ger_data.write_SGR(outfilename + ".sgr")
                theos_ger_data.write_SADR(outfilename + ".sadr")
                theos_ger_data.write_LSR(outfilename + ".lsr")
                theos_ger_data.write_CER(outfilename + "._cer")
                theos_ger_data.write_SOFR(outfilename + ".sofr")
                theos_ger_data.read_write_image(outfilename + ".tif")
                theos_ger_data.write_GDB(outfilename + ".gdb")
                theos_ger_data.write_ADB(outfilename + ".adb")
                year = theos_ger_data.year
                month = theos_ger_data.month
                day = theos_ger_data.day


                if theos_ger_data.bad_lines is not None:
                    bad_line_array = np.array(theos_ger_data.bad_lines)
                    band_bad_lines.append(theos_ger_data.bad_lines)
                    np.savetxt(outfilename + ".bln", bad_line_array, "%d")
                else:
                    band_bad_lines.append(None)
                if theos_ger_data.degraded_lines is not None:
                    degraded_lines = np.array(theos_ger_data.degraded_lines)
                    band_degraded_lines.append(theos_ger_data.degraded_lines)
                    np.savetxt(outfilename + ".dln", degraded_lines, "%d")
                else:
                    band_degraded_lines.append(None)
                if k == 2:
                    sadr_times = theos_ger_data.sat_times
                    sadr_positions = theos_ger_data.sat_positions
                    sadr_velocity = theos_ger_data.sat_velocity
                    sadr_attitude = theos_ger_data.sat_attitude
                    np.savetxt(outfilename + "sadr_times.txt", sadr_times)
                    np.savetxt(outfilename + "sadr_position.txt", sadr_positions)
                    np.savetxt(outfilename + "sadr_velocity.txt", sadr_velocity)
                    np.savetxt(outfilename + "sadr_attitude.txt", sadr_attitude)

                print "year: %d, month: %d, day: %d" % (year, month, day)
            else:
                # reading the date infomation from .mfh file
                with open(outfilename + ".mfh", "r") as mfh_fp:
                    txt = mfh_fp.read()
                    ob_line = txt.find("OBT_First")
                    txt2 = txt[ob_line:]
                    st = txt2.find(":") + 1
                    stp = txt2.find("\n")
                    data = txt2[st:stp]
                    while data[0] == " ":
                        data = data[1:]
                    year = int(data[:4])
                    month = int(data[4:6])
                    day = int(data[6:8])

                if os.path.isfile(outfilename + ".bln"):
                    bad_line_array = np.loadtxt(outfilename + ".bln", dtype=np.int64)
                    band_bad_lines.append(bad_line_array)
                else:
                    band_bad_lines.append(None)
                if os.path.isfile(outfilename + ".dln"):
                    degraded_lines = np.loadtxt(outfilename + ".dln", dtype=np.int64)
                    band_degraded_lines.append(degraded_lines)
                else:
                    band_degraded_lines.append(None)

        else:
            theos_ger_data = theos_ger_file("MS", file_names[k], gain[k], darkcurrent[k])
            theos_ger_data.band = k
            theos_ger_data.write_MFH(outfilename + ".mfh")
            theos_ger_data.write_SGR(outfilename + ".sgr")
            theos_ger_data.write_SADR(outfilename + ".sadr")
            theos_ger_data.write_LSR(outfilename + ".lsr")
            theos_ger_data.write_CER(outfilename + "._cer")
            theos_ger_data.write_SOFR(outfilename + ".sofr")
            theos_ger_data.read_write_image(outfilename + ".tif")
            theos_ger_data.write_GDB(outfilename + ".gdb")
            theos_ger_data.write_ADB(outfilename + ".adb")
            year = theos_ger_data.year
            month = theos_ger_data.month
            day = theos_ger_data.day
            if theos_ger_data.bad_lines is not None:
                bad_line_array = np.array(theos_ger_data.bad_lines)
                band_bad_lines.append(theos_ger_data.bad_lines)
                np.savetxt(outfilename + ".bln", bad_line_array, "%d")
            else:
                band_bad_lines.append(None)
            if theos_ger_data.degraded_lines is not None:
                degraded_lines = np.array(theos_ger_data.degraded_lines)
                band_degraded_lines.append(theos_ger_data.degraded_lines)
                np.savetxt(outfilename + ".dln", degraded_lines, "%d")
            else:
                band_degraded_lines.append(None)

            if k == 2:
                sadr_times = theos_ger_data.sat_times
                sadr_positions = theos_ger_data.sat_positions
                sadr_velocity = theos_ger_data.sat_velocity
                sadr_attitude = theos_ger_data.sat_attitude
                np.savetxt(outfilename + "sadr_times.txt", sadr_times)
                np.savetxt(outfilename + "sadr_position.txt", sadr_positions)
                np.savetxt(outfilename + "sadr_velocity.txt", sadr_velocity)
                np.savetxt(outfilename + "sadr_attitude.txt", sadr_attitude)

    return year, month, day, band_bad_lines, band_degraded_lines



def readGerPANFiles(file_names, outfile_names, cpf_file_name, force_run=False):
    """

    :param file_names: List of Input file names for each MS bands with ."ger" suffix
    :param out_file_names:  List of output file names for each MS bands without suffix
    :param cpf_file_name:  CPF file use
    :return:  year, month, day of the file
    """
    gain = []
    dark_cur = []


    for gnumber in range(1, 11) :
        g, d = readGainsAndDarkCurrent(cpf_file_name, "PAN", gnumber)
        gain.append(g)
        dark_cur.append(d)

    file_name = file_names[0]
    outfilename = outfile_names[0]



    t_m_ger = os.lstat(file_name).st_mtime
    extensions = ["mfh", "sgr", "sadr", "lsr", "_cer", "sofr", "tif", "gdb", "adb"]
    if force_run == False :
        all_file_exists = True
        for extension in extensions :
            all_file_exists = all_file_exists & (os.path.isfile(outfilename + "." + extension))
            if all_file_exists :
                t_m_f = os.lstat(outfilename + "." + extension).st_mtime
                all_file_exists &= t_m_f > t_m_ger
            else:
                break
        if not all_file_exists:
            theos_ger_data = theos_ger_file("PAN", file_name, gain, dark_cur)
            theos_ger_data.band = 1
            theos_ger_data.write_MFH(outfilename + ".mfh")
            theos_ger_data.write_SGR(outfilename + ".sgr")
            theos_ger_data.write_SADR(outfilename + ".sadr")
            theos_ger_data.write_LSR(outfilename + ".lsr")
            theos_ger_data.write_CER(outfilename + "._cer")
            theos_ger_data.write_SOFR(outfilename + ".sofr")
            theos_ger_data.read_write_image(outfilename + ".tif")
            theos_ger_data.write_GDB(outfilename + ".gdb")
            theos_ger_data.write_ADB(outfilename + ".adb")
            year = theos_ger_data.year
            month = theos_ger_data.month
            day = theos_ger_data.day
            if theos_ger_data.bad_lines is not None:
                bad_line_array = np.array(theos_ger_data.bad_lines)
                band_bad_lines = [theos_ger_data.bad_lines]
                np.savetxt(outfilename + ".bln", bad_line_array, "%d")
            else:
                band_bad_lines = [None]
            if theos_ger_data.degraded_lines is not None:
                degraded_lines = np.array(theos_ger_data.degraded_lines)
                band_degraded_lines = [theos_ger_data.degraded_lines]
                np.savetxt(outfilename + ".dln", degraded_lines, "%d")
            else:
                band_degraded_lines = [None]

            print "year: %d, month: %d, day: %d" % (year, month, day)
        else:
            # reading the date infomation from .mfh file
            with open(outfilename + ".mfh", "r") as mfh_fp:
                txt = mfh_fp.read()
                ob_line = txt.find("OBT_First")
                txt2 = txt[ob_line:]
                st = txt2.find(":") + 1
                stp = txt2.find("\n")
                data = txt2[st:stp]
                while data[0] == " ":
                    data = data[1:]
                year = int(data[:4])
                month = int(data[4:6])
                day = int(data[6:8])
            if os.path.isfile(outfilename + ".bln"):
                bad_line_array = np.loadtxt(outfilename + ".bln", dtype=np.int64)
                band_bad_lines = [bad_line_array]
            else:
                band_bad_lines = [None]
            if os.path.isfile(outfilename + ".dln"):
                degraded_lines = np.loadtxt(outfilename + ".dln", dtype=np.int64)
                band_degraded_lines = [degraded_lines]
            else:
                band_degraded_lines = [None]


    else:
        theos_ger_data = theos_ger_file("PAN", file_name, gain, dark_cur)
        theos_ger_data.band = 1
        theos_ger_data.write_MFH(outfilename + ".mfh")
        theos_ger_data.write_SGR(outfilename + ".sgr")
        theos_ger_data.write_SADR(outfilename + ".sadr")
        theos_ger_data.write_LSR(outfilename + ".lsr")
        theos_ger_data.write_CER(outfilename + "._cer")
        theos_ger_data.write_SOFR(outfilename + ".sofr")
        theos_ger_data.read_write_image(outfilename + ".tif")
        theos_ger_data.write_GDB(outfilename + ".gdb")
        theos_ger_data.write_ADB(outfilename + ".adb")
        year = theos_ger_data.year
        month = theos_ger_data.month
        day = theos_ger_data.day
        if theos_ger_data.bad_lines is not None:
            bad_line_array = np.array(theos_ger_data.bad_lines)
            band_bad_lines = [theos_ger_data.bad_lines]
            np.savetxt(outfilename + ".bln", bad_line_array, "%d")
        else:
            band_bad_lines = [None]
        if theos_ger_data.degraded_lines is not None:
            degraded_lines = np.array(theos_ger_data.degraded_lines)
            band_degraded_lines = [theos_ger_data.degraded_lines]
            np.savetxt(outfilename + ".dln", degraded_lines, "%d")
        else:
            band_degraded_lines = [None]
        sadr_times = theos_ger_data.sat_times
        sadr_positions = theos_ger_data.sat_positions
        sadr_velocity = theos_ger_data.sat_velocity
        sadr_attitude = theos_ger_data.sat_attitude
        np.savetxt(outfilename + "sadr_times.txt", sadr_times)
        np.savetxt(outfilename + "sadr_position.txt", sadr_positions)
        np.savetxt(outfilename + "sadr_velocity.txt", sadr_velocity)
        np.savetxt(outfilename + "sadr_attitude.txt", sadr_attitude)
    return year, month, day, band_bad_lines, band_degraded_lines




if __name__ == "__main__":
    # file_name = sys.argv[1]
    # file_name =r"C:\LEVEL0\Image Level 0\2015-01-01_REV32823\THEOS_1_LEVEL0_1_111032823_32823_MS_PB_TOP_2_8_2015-01-01_03-45-17\TS1_2015001_32823_008_B3"
    file_names = []
    out_files = []


    for k in range(1, 5):
        # print "reading band %d"%k
        # file_name = "/media/professor/Backup and Data/LEVEL0/Image Level 0/2015-01-01_REV32823/THEOS_1_LEVEL0_1_111032823_32823_MS_PB_TOP_2_8_2015-01-01_03-45-17/TS1_2015001_32823_008_B%d"%k

        # file_name = "/media/professor/Backup and Data/LEVEL0/Image Level 0/2015-01-02_REV32837/THEOS_1_LEVEL0_1_111032837_32837_MS_PB_TOP_2_8_2015-01-02_03-26-33/TS1_2015002_32837_008_B4"
        # file_name_ger = file_name+".ger"
        # file_name = "/media/professor/Data and Backup/LEVEL0/2013-12-03_REV27231/THEOS_1_LEVEL0_1_111027231_27231_MS_PB_TOP_2_22_2013-12-03_03-24-32/TS1_2013337_27231_022_B%d"%k
        file_name = r"D:\level1A_development\GER\TS1_2015308_37179_004_B%d" % k
        file_name_ger = file_name + ".GER"
        file_names.append(file_name_ger)
        out_files.append(file_name)

        # if os.path.exists(file_name+".ger") :
        #    file_name_ger = file_name+".ger"
        # elif os.path.exists(file_name+".GER") :
        #    file_name_ger = file_name+".GER"
        # else:
        #    print "Invalid file name!!"
        # theos_ger_data = theos_ger_file("MS",file_name_ger)
        # theos_ger_data.band = k
        # print "info: ", theos_ger_data.computeSatPositionAttitude(03*60*60.+45*60.0+18.000 )
        # image = theos_ger_data.read_image()
        # theos_ger_data.read_write_image(file_name+".tif")
        # theos_ger_data.write_MFH(file_name+".mfh")
        # theos_ger_data.write_SGR(file_name+".sgr")
        # theos_ger_data.write_SADR(file_name+".sadr")
        # theos_ger_data.write_LSR(file_name+".lsr")
        # theos_ger_data.write_CER(file_name+"._cer")
        # theos_ger_data.write_SOFR(file_name+".sofr")
        # theos_ger_data.write_GDB(file_name+".gdb")
        # theos_ger_data.write_ADB(file_name+".adb")
        # print "loading completed."

    cpf_file = r"D:\level1A_development\GER\THEOS_1_20150915_000000_20150917_000000.CPF"

    readGerMSFiles(file_names, out_files, cpf_file)
    print "loading completed."
    # rw,cl = image.shape
    # im2 = cv2.resize(image,(cl/32,rw/32))
    # cv2.imshow("image",im2)
    # theos_ger_data.write_image(file_name+".tif")
    # cv2.waitKey(0)









