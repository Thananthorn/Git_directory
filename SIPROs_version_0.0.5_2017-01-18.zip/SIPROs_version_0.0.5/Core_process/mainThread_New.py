"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""


import CompleteLevel1A as level1asystem
import CompleteLevel2A as level2asystem
import digitalElevationModel as demservice

import os , sys , traceback , zipfile

from PyQt4.QtGui import QApplication , QFileDialog , QMessageBox # I import this for use browse file.


# SYSTEM CONSTANTS
class demDirectory:
    SRTM90 = "C:/Worker/Support-Worker/Sipros_system/dem/SRTM_90"
    GLOBE = "C:/Worker/Support-Worker/Sipros_system/dem/globe"
    THEOS = "C:/Worker/Support-Worker/Sipros_system/dem/THEOS_DEM"


class processingLevel:
    LEVEL1A = "1A"
    LEVEL2A = "2A"


class sensorType:
    MS = "MS"
    PAN = "PAN"


# SCENE INFORMATION TO USED
class sceneInfo:
    ger_dir = ""
    cpf_file = ""

    begin_lines = ""
    start_sample = 0
    im_width = 0
    im_height = 0
    info_dir = ""
    target_dir = ""
    rev_num = ""
    grid_id = ""
    line_shifted = 0


# PROCESSING LEVEL AND DATA TYPE
class processSetup:
    processing_level = ""
    sensor = ""
    dem_interpolation = demservice.digitalElevationModel.CUBIC
    dem_type = demservice.THEOS_DEM
    apf_file = "C:/Worker/Support-Worker/Sipros_system/APF/THEOS_nominal.APF"


def callProcessingSystem(scene_info, process_setup):  # main call thread of the main process
    ger_directory = scene_info.ger_dir
    cpf_file = scene_info.cpf_file
    apf_file = process_setup.apf_file
    begin_lines = scene_info.begin_lines
    dem_type = process_setup.dem_type
    info_directory = scene_info.info_dir
    destination_directory = scene_info.target_dir
    rev_num = scene_info.rev_num
    grid_ref = scene_info.grid_id
    dem_interpolation_method = process_setup.dem_interpolation
    line_shifted = scene_info.line_shifted
    start_sample = scene_info.start_sample
    im_width = scene_info.im_width
    im_height = scene_info.im_height
    dem_dir = demDirectory

    if processSetup.processing_level == processingLevel.LEVEL1A:
        level1asystem.buildLevel1AImage(processSetup.sensor, ger_directory, cpf_file, apf_file, begin_lines, dem_type,
                                        info_directory, destination_directory, rev_num, grid_ref, dem_dir,
                                        dem_interpolation=dem_interpolation_method, line_shifted=line_shifted,
                                        start_sample=start_sample, im_width=im_width, im_height=im_height,
                                        force_run=False)
    elif processSetup.processing_level == processingLevel.LEVEL2A:
        level2asystem.buildLevel2AImage(processSetup.sensor, ger_directory, cpf_file, apf_file, begin_lines, dem_type,
                                        info_directory, destination_directory, rev_num, grid_ref, dem_dir,
                                        dem_interpolation=dem_interpolation_method, line_shift=line_shifted,
                                        start_sample=start_sample, im_width=im_width, im_height=im_height,
                                        force_run=False)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    #if windows open this.
    GERALD_keep = "//172.27.188.133/thaichote_gerald/GERALD"  # Path to keep Gerald directory in network drive.
    GERALD_local = "C:/Worker/Support-Worker/Sipros_system/GERALD"  # Path to keep Gerald directory in Local drive.
    GERALD_info = "C:/Worker/Support-Worker/Sipros_system/Extraction_files"  # Path to keep directory of extract files from Gerald file.
    Product_keep = "C:/Worker/Support-Worker/Sipros_system/Product_files"  # Path to keep directory of product files from process.
    CPF_directory = "C:/Worker/Support-Worker/Sipros_system/CPF_PROCESSING/CPF_file"  # All CPF file keep in this directory.
    CPF_index = "C:/Worker/Support-Worker/Sipros_system/CPF_PROCESSING/CPF_index"  # Directory to keep index file who create by cpf_logic.
    Log_path = "C:/Worker/Support-Worker/Sipros_system/LOG"  # Directory to keep log file from product process.
    product_detail = "C:/Worker/Support-Worker/Sipros_system/Command_files"  # Directory to get command to process
    
#     #if linux open this.
#     GERALD_keep = "/home/asuna/worker/2016-12/LAB/GERALD_SIM"  # Path to keep Gerald directory in network drive.
#     GERALD_local = "/home/asuna/worker/2016-12/LAB/GERALD_Local"  # Path to keep Gerald directory in Local drive.
#     GERALD_info = "/home/asuna/worker/2016-12/LAB/EXTRACTION"  # Path to keep directory of extract files from Gerald file.
#     Product_keep = "/home/asuna/worker/2016-12/LAB/PRODUCT"  # Path to keep directory of product files from process.
#     CPF_directory = "/home/asuna/worker/2016-12/LAB/CPF_PROCESS/CPF_FILE"  # All CPF file keep in this directory.
#     CPF_index = "/home/asuna/worker/2016-12/LAB/CPF_PROCESS/CPF_INDEX"  # Directory to keep index file who create by cpf_logic.
#     Log_path = "/home/asuna/worker/2016-12/LAB/LOG"  # Directory to keep log file from product process.
#     product_detail = "/home/asuna/worker/2016-12/LAB/COMMAND"  # Directory to get command to process

    
    
    sceneInfo.ger_dir = "C:/Worker/Support-Worker/Sipros_system/GERALD/THEOS_1_LEVEL0_1_111027827_27827_MS_PB_TOP_2_12_2014-01-14_03-19-07"
    sceneInfo.cpf_file = "C:/Worker/Support-Worker/Sipros_system/CPF_PROCESSING/CPF_file/THEOS_1_20131230_000000_20131231_000000.CPF"

    sceneInfo.begin_lines = [1,61,121,181]
    sceneInfo.start_sample = 1
    sceneInfo.im_width = 6000
    sceneInfo.im_height = 6000
    sceneInfo.info_dir = "C:/Worker/Support-Worker/Sipros_system/Extraction_files/Level2A/THEOS_1_LEVEL0_1_111027827_27827_MS_PB_TOP_2_12_2014-01-14_03-19-07"
    sceneInfo.target_dir = "C:/Worker/Support-Worker/Sipros_system/Product_files/Level_2A/THEOS_1_LEVEL0_1_111027827_27827_MS_PB_TOP_2_12_2014-01-14_03-19-07"
    sceneInfo.rev_num = "27827"
    sceneInfo.grid_id = "0262-0322"
    sceneInfo.line_shifted = 0
    
    processSetup.processing_level = processingLevel.LEVEL2A
    processSetup.sensor = sensorType.MS
    
    scene_info = sceneInfo
    process_setup = processSetup
    callProcessingSystem(scene_info, process_setup)
