"""

Copyright 2017 GISTDA


This software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa cooperatiopn
between GISTDA and Kasetsart Universit under the SIPPO project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, distribute,
and/or shell copies of the Software for the education purposes without any prior notification to GISTDA.

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
 OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.

 """

import cv2

from osgeo import gdal

import numpy as np


def computeRMS(im1, im2, dx, dy):
    im3 = cv2.getRectSubPix(im2, (im1.shape[1], im1.shape[0]),
                            ((im1.shape[1] - 1.) / 2. + dx, (im1.shape[0] - 1.) / 2. + dy))
    # im12 = im2[:,:]
    idx, idy = np.nonzero((im1 > 0) * (im3 > 0))
    rms = im1[idx, idy].astype('float32') - im3[idx, idy].astype('float32')
    rms = rms ** 2
    rms = rms.mean()
    rms = np.sqrt(rms)
    return rms

if __name__ == "__main__":
    myf = r"D:\lastscene\level1a\IMAGERY.tif"
    # My file
    org = r"D:\lastscene\MS\TH_CAT_161114085743236_1\IMAGERY.TIF"
    # original Image

    outf = r"D:\lastscene\level1a\cmpInterpolateCubic"
    myim = gdal.Open(myf)
    orgim = gdal.Open(org)
    n_band = orgim.RasterCount
    for band in range(n_band):
        myimb1 = myim.GetRasterBand(band + 1)
        orgimb1 = orgim.GetRasterBand(band + 1)
        offx = 0
        offy = 0
        mywidth = myim.RasterXSize
        myheight = myim.RasterYSize
        orgwidth = orgim.RasterXSize
        orgheight = orgim.RasterYSize
        outimage = np.zeros((orgheight, orgwidth, 3), 'uint8')
        # original in green color
        orgdata = orgimb1.ReadAsArray()
        outimage[:, :, 1] = orgdata
        orgdata = None
        mydata = myimb1.ReadAsArray()
        U, V = np.mgrid[:orgwidth, :orgheight]
        U = U.T - offx
        V = V.T - offy
        imout = cv2.getRectSubPix(mydata, (orgwidth, orgheight), ((orgwidth - 1.) / 2. - offx, (orgheight - 1.) / 2. - offy))
        outimage[:, :, 2] = imout

        cv2.imwrite(outf + "%d.tif" % (band + 1), outimage)


        nrw, ncl = imout.shape
        im1 = outimage[nrw / 2 - 1000: nrw / 2 + 1000, ncl / 2 - 1000: ncl / 2 + 1000, 2].astype('float32')
        im2 = outimage[nrw / 2 - 1000: nrw / 2 + 1000, ncl / 2 - 1000: ncl / 2 + 1000, 1].astype('float32')
        nrw, ncl = im1.shape
        nrw = (nrw / 2) * 2
        ncl = (ncl / 2) * 2
        im1 = im1[:nrw, :ncl]
        im2 = im2[:nrw, :ncl]

        dx_best = 0
        dy_best = 0
        rms_min = computeRMS(im1, im2, 0, 0)
        print "Root Mean Square Error: %f for Band %d with offset (%f,%f)!" % (rms_min, band + 1, offx, offy)
        if rms_min > 0:

            for dx in np.arange(-1, 1.1, 0.1):
                for dy in np.arange(-1, 1.1, 0.1):
                    rms = computeRMS(im1, im2, dx, dy)
                    # print dx, dy, rms
                    if rms < rms_min:
                        rms_min = rms
                        dx_best = dx
                        dy_best = dy

        print "dx = %f, dy = %f, rms = %f." % (dx_best, dy_best, rms_min)
