"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

 """

import cv2

import determine_pixel_shift as dps
import locationutil as util
import numpy as np
import scipy.signal as signal
from systemConstants import LV1_2ProductionConstants
import utmLatlon
import xml.etree.ElementTree as ET


def readGainsAndDarkCurrent(cpf_file, band, gain_number):
    """
    read CPF file
    :param cpf_file:
    :param band: BAND "PAN", "1", "2", "3", 4"
    :param gain_number:  "Gain number 0 to 9
    :return:
    array of relative gains and dark currrents for each CCD sensor
    """
    tree = ET.parse(cpf_file)
    root = tree.getroot()
    if band == "PAN":
        gains_txt = root.findall("./RadiometricParameters/PAN/G%d/DetectorRelativeGains" % (gain_number))[0].text
        darkCurrent_txt = root.findall("./RadiometricParameters/PAN/G%d/DarkCurrents" % (gain_number))[0].text
    else:
        gains_txt = root.findall("./RadiometricParameters/B%d/G%d/DetectorRelativeGains" % (band, gain_number))[0].text
        darkCurrent_txt = root.findall("./RadiometricParameters/B%d/G%d/DarkCurrents" % (band, gain_number))[0].text
    # print gains_txt
    gains_txt = gains_txt.split(",")

    darkCurrent_txt = darkCurrent_txt.split(",")
    gains = []
    darkCurrents = []
    for it in range(len(gains_txt)):
        gains.append(float(gains_txt[it]))
        darkCurrents.append(float(darkCurrent_txt[it]))
    gains = np.array(gains)
    darkCurrents = np.array(darkCurrents)
    return gains, darkCurrents
def readDataBand(gdalband , sample, line, width, height, gain, dark_curr, gain_numbers, im_type):

    pixels = np.arange(sample, sample + width).reshape((1, width))
    y_min = line
    im_data = gdalband.ReadAsArray(sample, line, width, height)

    if im_type == "PAN":
        nlines = gain_numbers.shape[0]
        glo = gain_numbers[:, 0].reshape((nlines, 1))
        gle = gain_numbers[:, 1].reshape((nlines, 1))
        gro = gain_numbers[:, 2].reshape((nlines, 1))
        gre = gain_numbers[:, 3].reshape((nlines, 1))
        gns = glo[y_min:(y_min + height), :] * (pixels < 6000) * (pixels % 2 == 0) + \
              gle[y_min:(y_min + height), :] * (pixels < 6000) * (pixels % 2 == 1) + \
              gro[y_min:(y_min + height), :] * (pixels >= 6000) * (pixels % 2 == 0) + \
              gre[y_min:(y_min + height), :] * (pixels >= 6000) * (pixels % 2 == 1)
    elif im_type == "MS":
        nlines = gain_numbers.shape[0]
        g = gain_numbers.reshape((nlines, 1))
        gns = np.repeat(g[y_min:(y_min + height), :], width, 1)
    pix_gain = np.zeros_like(im_data, 'float32')
    pix_drk = np.zeros_like(im_data, 'float32')
    for idg in range(len(gain)):
        pix_gain = pix_gain + (gns == (idg)) * gain[idg][pixels]
        pix_drk = pix_drk + (gns == (idg)) * dark_curr[idg][pixels]
    # print gain[2][pixels], pix_gain, pix_gain.min(), pix_gain.max()
    # print np.nonzero(pix_gain == 0.0)
    # pix_gain = gain[gns]
    # pix_drk = dark_cur[gns]
    im_data = im_data.astype('float32')
    saturated_pix = (im_data >= 254.8).astype('float32')
    if LV1_2ProductionConstants.EQUALIZATION:
        im_data = (im_data - pix_drk) / pix_gain
    im_data = im_data * (1 - saturated_pix) + LV1_2ProductionConstants.MAX_DN * saturated_pix
    im_data = im_data.astype('float32')
    return im_data

def findSamplesPoints(in_file_name, step, lines, sat_pos, sat_time, sat_att, image_data, offset_mins, current_date,
                      utc_gps, dut1, dem, dem_interpolation_method, im_width, im_height, precision_error=1.0,
                      max_percision_error=5.0, process_box=500, im_register=False):
    """
    Find the sample points used for Band to Ban registration on MS Image
    :param in_file_name: a string containing file name prefix of MS data
    :param step: Number of step grid
    :param lines:  starting lines of all MS bands
    :param sat_pos: Array of satellite Position
    :param sat_time: Array of satellite time
    :param sat_att: Array of satellite Attitude
    :param image_data: List of image data from all bands
    :param offset_mins: # The offset in the data loading
    :param current_date: [Year, month, day] of image acquisition date
    :param utc_gps: UTC-GPS time
    :param dut1: UT1-UTC time
    :param dem: Dem object
    :param dem_interpolation_method: Dem interpolation techqiue
    :param im_width:  width of Band 3 Scene
    :param im_height: Height of Band 3 scene
    :param precision_error: The desired precion erros
    :param max_percision_error: The maximum allowed errors
    :param process_box: Processing Box size
    :param im_register: Flag to indicate fine tune registration using image to image registration.
    :return:
        x1out, x2out, x3out, x4out, y1out, y2out, y3out, y4outx1out, x2out, x3out, x4out, y1out, y2out, y3out, y4out:
        tie points for Band1, Band2, Band3 and Band4
    """


    pos1, pos2, pos3, pos4 = sat_pos
    time1, time2, time3, time4 = sat_time
    att1, att2, att3, att4 = sat_att

    x1 = []
    y1 = []
    x2 = []
    y2 = []
    x3 = []
    y3 = []
    x4 = []
    y4 = []



    for block_line in range(0, im_height, process_box) :
        for block_sample in range(0, im_width, process_box):

            # block_line = 5500
            mid_sample = block_sample + process_box / 2
            mid_line = block_line + process_box / 2

            print "Find the initial shift at the middle of an image (%d,%d)" % (mid_sample, mid_line)
            lat3a, lon3a, h3a = dps.findInterSectionPointArrayUsingDEMPreloaded("MS", in_file_name, np.array([mid_sample]),
                                                                                [mid_line + lines[2]], pos3, time3, att3,
                                                                                current_date, utc_gps, dut1, dem,
                                                                                dem_interpolation_method, band=3)

            x3a, y3a, zn3, zt3 = utmLatlon.from_latlon(lat3a, lon3a)
            dx_init = np.zeros((4,))
            dy_init = np.zeros((4,))
            for band in [1, 2, 4]:
                best_solution_found = False
                dx = 0
                dy = 0
                while not best_solution_found:
                    err_min = 1e100

                    for tx in [-1, 0, 1]:
                        for ty in [-1, 0, 1]:
                            latb, lonb, hb = util.computeViewLatLongArrayWithHeight(band, np.array([dx]) + tx + mid_sample,
                                                                                    np.array([dy]) + ty + mid_line, h3a,
                                                                                    lines[band - 1],
                                                                                    sat_pos[band - 1],
                                                                                    sat_att[band - 1],
                                                                                    sat_time[band - 1],
                                                                                    current_date[0], current_date[1],
                                                                                    current_date[2], utc_gps, dut1)
                            xb, yb, zn, zt = utmLatlon.from_latlon(latb, lonb, zn3)
                            error = np.sqrt((xb - x3a) ** 2 + (yb - y3a) ** 2)[0]
                            if error < err_min:
                                err_min = error
                                dx_temp = tx
                                dy_temp = ty

                    if (dx_temp == 0) and (dy_temp == 0):
                        best_solution_found = True

                        dx_init[band - 1] = dx
                        dy_init[band - 1] = dy
                    else:
                        dx += dx_temp
                        dy += dy_temp

                print "The initial dislacement for Band %d is (%d,%d)" % (band, dx_init[band - 1], dy_init[band - 1])
            bline = block_line
            bsample = block_sample
            # block_width = im_width
            max_block_height = process_box
            max_block_width = process_box
            block_height = min((im_height - bline), max_block_height)
            block_width = min(im_width - bsample, max_block_width)
            line_str = block_line
            line_stp = line_str + block_height
            sample_str = block_sample
            sample_stp = sample_str + block_width
            samples2 = np.arange(sample_str + step / 2, sample_stp, step)



            for line in range(line_str + step / 2 , line_stp, step):
                print "working on Line: %d" % (line)


                lat3a, lon3a, h3a = dps.findInterSectionPointArrayUsingDEMPreloaded("MS", in_file_name, samples2 + 1,
                                                                                        [line + lines[2]], pos3, time3,
                                                                                        att3, current_date,
                                                                                        utc_gps, dut1, dem,
                                                                                        dem_interpolation_method,
                                                                                        band=3)
                x3a, y3a, zn3, zt3 = utmLatlon.from_latlon(lat3a, lon3a, zn3)
                # x3.append(samples2)
                # y3.append(line*np.ones_like(samples2))
                sard_times = np.loadtxt(in_file_name + "B%dsadr_times.txt" % 3)
                sard_last_time = sard_times[-1]
                valid_pixels = np.ones_like(samples2)
                for band in [1, 2, 4]:
                    sx_in = (samples2 + dx_init[band - 1]).astype('float64')
                    sy_in = (np.array(line + dy_init[band - 1]) * np.ones_like(samples2)).astype('float64')
                    err_sx = np.ones_like(sx_in) * 2.0
                    err_sy = np.ones_like(sx_in) * 2.0
                    num_fail = 0
                    idx = np.arange(len(samples2))
                    it = 0
                    while it < LV1_2ProductionConstants.MAX_ITERATION_BAND2BAND_CORRESPONDING_POINTS :
                        sx = sx_in[idx]
                        sy = sy_in[idx]
                        hb = h3a[idx]
                        lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy,
                                                                              hb, lines[band - 1], sat_pos[band - 1],
                                                                              sat_att[band - 1], sat_time[band - 1],
                                                                              current_date[0], current_date[1],
                                                                              current_date[2], utc_gps, dut1)
                        xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon, zn3)
                        errx = xb - x3a[idx]
                        erry = yb - y3a[idx]


                        lat1, lon1, ht = util.computeViewLatLongArrayWithHeight(band, sx + 1.0, sy,
                                                                                hb, lines[band - 1], sat_pos[band - 1],
                                                                                sat_att[band - 1], sat_time[band - 1],
                                                                                current_date[0], current_date[1],
                                                                                current_date[2], utc_gps, dut1)
                        lat2, lon2, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy + 1.0,
                                                                                hb, lines[band - 1], sat_pos[band - 1],
                                                                                sat_att[band - 1], sat_time[band - 1],
                                                                                current_date[0], current_date[1],
                                                                                current_date[2], utc_gps, dut1)
                        xb1, yb1, zn, zt = utmLatlon.from_latlon(lat1, lon1, zn3)
                        xb2, yb2, zn, zt = utmLatlon.from_latlon(lat2, lon2, zn3)

                        total_errors = np.sqrt(errx ** 2 + erry ** 2)
                        gx = 2.0 * errx * (xb1 - xb) + 2.0 * (erry) * (yb1 - yb)
                        gy = 2.0 * errx * (xb2 - xb) + 2.0 * (erry) * (yb2 - yb)
                        lamb = (0.1 / total_errors)
                        lamb = (lamb > 0.001) * 0.001 + (lamb <= 0.001) * lamb

                        lamb = (lamb < 1e-7) * 1e-7 + (lamb >= 1e-7) * lamb

                        itx = 0
                        it_max = 100
                        new_total_error = total_errors.copy()
                        while (new_total_error >= total_errors).sum() and (itx < it_max):
                            sxt = sx - lamb * gx
                            syt = sy - lamb * gy

                            lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sxt, syt,
                                                                                  hb, lines[band - 1],
                                                                                  sat_pos[band - 1],
                                                                                  sat_att[band - 1], sat_time[band - 1],
                                                                                  current_date[0], current_date[1],
                                                                                  current_date[2], utc_gps, dut1)

                            try:
                                xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon, zn3)
                                errold_x = errx.copy()
                                errold_y = erry.copy()
                                errx = xb - x3a[idx]
                                erry = yb - y3a[idx]

                                old_total_error = new_total_error.copy()
                                new_total_error = np.sqrt(errx ** 2 + erry ** 2)
                                lamb = (lamb / 2.0) * (new_total_error >= total_errors) + \
                                       (lamb / 2.0) * (new_total_error < total_errors) * (
                                           new_total_error < old_total_error) + \
                                       (lamb) * (new_total_error < total_errors) * (new_total_error >= old_total_error)

                                errx = errx * (new_total_error >= total_errors) + \
                                       errx * (new_total_error < total_errors) * (new_total_error < old_total_error) + \
                                       errold_x * (new_total_error < total_errors) * (
                                           new_total_error >= old_total_error)

                                erry = erry * (new_total_error >= total_errors) + \
                                       erry * (new_total_error < total_errors) * (new_total_error < old_total_error) + \
                                       errold_y * (new_total_error < total_errors) * (
                                           new_total_error >= old_total_error)

                                itx += 1
                            except:
                                lamb = lamb / 10.0

                                itx += 1

                        sx = sx - (lamb * 2) * gx
                        sy = sy - (lamb * 2) * gy
                        sx_in[idx] = sx
                        sy_in[idx] = sy
                        err_sx[idx] = errx
                        err_sy[idx] = erry

                        if itx == it_max:
                            # print "[%d] cannot improve the performance any future!" % (band),
                            # print "..... error x: %f, error y: %f." % ( errxm, errym)
                            # print "Exiting the solution searching"
                            # print "Try to randomly move around. "
                            sx_bestold = sx.copy()
                            sy_bestold = sy.copy()
                            if num_fail < 5:
                                sx = sx_bestold + 2.0 * (
                                np.random.rand(sx.shape[0]) - 0.5)  # samples2 + dx_init[band - 1]
                                sy = sy_bestold + 2.0 * (np.random.rand(
                                    sx.shape[0]) - 0.5)  # np.array(line + dy_init[band - 1]) * np.ones_like(samples2)
                                num_fail += 1
                            else:
                                print "Warning: There are saving %d pixels from Band %d with positioning error more than " \
                                      "%f meters." % (sx.shape[0], band, precision_error)

                                id_max = np.nonzero((np.abs(err_sx) > max_percision_error) + (np.abs(err_sy) > max_percision_error))[0]

                                valid_pixels[id_max] = 0

                        idx = np.nonzero((np.abs(err_sx) > precision_error) + (np.abs(err_sy) > precision_error))[0]
                        if len(idx) == 0 :  # and (not brute_force):

                            it = 200
                        else:
                            it += 1




                    if band == 1:
                        # print "1:", np.abs(sx1-sx_in).mean() , np.abs(sy1-sy_in).mean(),  np.abs(sx1-sx_in).max() , np.abs(sy1-sy_in).max()
                        sx1 = sx_in.copy()  # x1.append(sx)
                        sy1 = sy_in.copy()  # y1.append(sy)
                    elif band == 2:
                        # print "2:", np.abs(sx2 - sx_in).mean(), np.abs(sy2 - sy_in).mean(),  np.abs(sx2-sx_in).max() , np.abs(sy2-sy_in).max()
                        sx2 = sx_in.copy()  # x2.append(sx)
                        sy2 = sy_in.copy()  # y2.append(sy)
                    elif band == 4:
                        # print "4:", np.abs(sx4 - sx_in).mean(), np.abs(sy4 - sy_in).mean(),   np.abs(sx4-sx_in).max() , np.abs(sy4-sy_in).max()
                        sx4 = sx_in.copy()  # x4.append(sx)
                        sy4 = sy_in.copy()  # sy4.append(sy)




                if (sx1 is not None) & (sy1 is not None) & (sx2 is not None) & (sy2 is not None) & (sx4 is not None) & (sy4 is not None):

                    id_ready = np.nonzero(valid_pixels)[0]
                    id_max = np.nonzero(valid_pixels == 0)[0]
                    if np.any(sx1) is None:
                        print sx1
                    if len(id_max) > 0 :
                        print "Warning: We need to remove %d pixels due to the maximum error is more than the " \
                              "maximum limit of %f meters" % (id_max.shape[0], max_percision_error)
                        if valid_pixels.sum() > 0 :
                            x1.append(sx1[id_ready])
                            x2.append(sx2[id_ready])
                            x3.append(samples2[id_ready])
                            x4.append(sx4[id_ready])

                            y1.append(sy1[id_ready])
                            y2.append(sy2[id_ready])
                            y3.append(line * np.ones_like(samples2[id_ready]))
                            y4.append(sy4[id_ready])
                    else:
                        x1.append(sx1)
                        x2.append(sx2)
                        x3.append(samples2)
                        x4.append(sx4)

                        y1.append(sy1)
                        y2.append(sy2)
                        y3.append(line * np.ones_like(samples2))
                        y4.append(sy4)

    num_items = 0
    for item in x1:
        num_items += len(item)
    x1out = np.zeros((num_items,))
    x2out = np.zeros((num_items,))
    x3out = np.zeros((num_items,))
    x4out = np.zeros((num_items,))

    y1out = np.zeros((num_items,))
    y2out = np.zeros((num_items,))
    y3out = np.zeros((num_items,))
    y4out = np.zeros((num_items,))

    num_list = len(x1)
    str = 0
    for list_id in range(num_list):
        stp = str + len(x1[list_id])
        x1out[str:stp] = x1[list_id]
        x2out[str:stp] = x2[list_id]
        x3out[str:stp] = x3[list_id]
        x4out[str:stp] = x4[list_id]

        y1out[str:stp] = y1[list_id]
        y2out[str:stp] = y2[list_id]
        y3out[str:stp] = y3[list_id]
        y4out[str:stp] = y4[list_id]
        str = stp


    if im_register :
        print "Fine Tuning using SIFT-based image-to-image registration"
        print "Find keys points between images"
        size_width = 1000
        margins = 100
        sf = cv2.SIFT()
        FLANN_INDEX_KDTREE = 0
        index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
        search_params = dict(checks=50)  # or pass empty dictionary
        flann = cv2.FlannBasedMatcher(index_params, search_params)
        bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
        keys_points = []
        descriotors = []
        points13out = list()
        points23out = list()
        points43out = list()
        for band in  range(4):
            data_h, data_w = image_data[band].shape
            keys_band = []
            des_band = []
            for k in range(0, data_h, size_width):
                for m in range(0, data_w, size_width):
                    str_row = max(0, k - margins)
                    str_col = max(0, m - margins)
                    stp_row = min(data_h, k + size_width + margins)
                    stp_col = min(data_w, m + size_width + margins)
                    data_k = image_data[band][str_row:stp_row, str_col:stp_col]
                    data_k = (data_k > 0) * (data_k < 255) * data_k + 255 * (data_k >= 255)
                    data_k = np.round(data_k).astype('uint8')
                    keys, des = sf.detectAndCompute(data_k, None)
                    for cnt in range(len(keys)):
                        pt = keys[cnt].pt
                        x = pt[0] + str_col
                        y = pt[1] + str_row
                        if (y > k) and (y < k + size_width) and (x > m) and (x < m + size_width):
                            keys_band.append(np.array([x, y]))
                            des_band.append(des[cnt])
            if len(keys_band) > 0:
                keys_band = np.array(keys_band)
                des_band = np.array(des_band)
                print "There are %d key points for Band %d." % (len(keys_band), band + 1)

            keys_points.append(keys_band)
            descriotors.append(des_band)

        num_sample_points = x3out.size
        wd = step / 2
        for k in range(num_sample_points):
            sx3 = int(x3out[k])
            sy3 = int(y3out[k])
            if (sx3 >= wd) & (sx3 < im_width - wd) & (sy3 >= wd) & (sy3 < im_height - wd):
                valid_area = (keys_points[2][:, 0] >= sx3 - wd) * (keys_points[2][:, 0] < sx3 + wd)
                valid_area *= (keys_points[2][:, 1] >= sy3 - wd) * (keys_points[2][:, 1] < sy3 + wd)
                id_keys = np.nonzero(valid_area)[0]
                if (len(id_keys) > 0):
                    keys3 = keys_points[2][id_keys, :]
                    des3 = descriotors[2][id_keys, :].astype('float32')
                    for band in [1, 2, 4]:

                        band_id = band - 1
                        if band == 1:
                            sxb = x1out[k]
                            syb = y1out[k]
                        elif band == 2:
                            sxb = x2out[k]
                            syb = y2out[k]
                        elif band == 4:
                            syb = y1out[k]
                        bandheight = image_data[band - 1].shape[0]
                        max_lineb = bandheight + offset_mins[band - 1]
                        if (sxb >= wd) & (sxb < im_width - wd) & (syb >= wd) & (syb < max_lineb - wd):

                            valid_area = (keys_points[band_id][:, 0] >= sxb - wd) * (keys_points[band_id][:, 0] < sxb + wd)
                            valid_area *= (keys_points[band_id][:, 1] >= syb - wd - offset_mins[band_id]) * \
                                          (keys_points[band_id][:, 1] < syb + wd - offset_mins[band_id])
                            id_keys = np.nonzero(valid_area)[0]
                            if (len(id_keys) > 0):
                                keysb = keys_points[band_id][id_keys, :]
                                desb = descriotors[band_id][id_keys, :].astype('float32')
                                if len(keys3) >= 1 and len(keysb) > 1:
                                    matches = flann.knnMatch(des3, desb, k=2)
                                    scores = np.zeros(len(matches))
                                    # matchesMask = [[0, 0] for i in range(len(matches))]
                                    cnt = 0

                                    for (m0, m1) in matches:
                                        scores[cnt] = m1.distance / m0.distance
                                        cnt += 1

                                    if scores.max() > 2:
                                        good_points = np.nonzero(scores > 2)[0]

                                        dx = 0
                                        dy = 0
                                        num_good_points = len(good_points)

                                        for pnt in good_points:
                                            mbest = matches[pnt][0]
                                            p3 = np.round(keys3[mbest.queryIdx])
                                            # print "p3:", p3
                                            # image_data_in[2][int(p3[1]), int(p3[0])] = 255
                                            pb = np.round(keysb[mbest.trainIdx])
                                            # print "pb: ", pb
                                            # image_data_in[band_id][int(pb[1]),  int(pb[0])] = 255
                                            tx = pb[0] - p3[0] - (sxb - sx3)
                                            ty = pb[1] + offset_mins[band_id] - p3[1] - (syb - sy3)
                                            if sy3 < 5000:
                                                if abs(tx) <= 1 and abs(ty) < 1 :
                                                    dx += tx
                                                    dy += ty
                                                else:
                                                    num_good_points -= 1
                                            else:
                                                if abs(tx) <= 3 and abs(ty) < 3 :
                                                    dx += tx
                                                    dy += ty
                                                else:
                                                    num_good_points -= 1



                                            if band == 1:
                                                points13out.append(np.array([pb, p3]))
                                            elif band == 2:
                                                points23out.append(np.array([pb, p3]))
                                            elif band == 4:
                                                points43out.append(np.array([pb, p3]))
                                            # if matches[pnt][0].distance < min_distace:
                                            #    min_distace = matches[pnt][0].distance

                                        if num_good_points > 0:
                                            dx = dx / num_good_points
                                            dy = dy / num_good_points
                                        # print "new dx =%f, dy = %f." % (dx, dy)
                                        if band == 1:
                                            x1out[k] += dx
                                            y1out[k] += dy
                                        elif band == 2:
                                            x2out[k] += dx
                                            y2out[k] += dy
                                        elif band == 4:
                                            x4out[k] += dx
                                            y4out[k] += dy

    return x1out, x2out, x3out, x4out, y1out, y2out, y3out, y4out


def remapImageBandGridMethod(xb, yb, x3, y3, line_str, sample_str, block_size, im_width, im_height, offset_min,
                             max_error=0.1, desired_size=500):

    end_line = min(line_str + block_size, im_height)
    end_sample = min(sample_str + block_size, im_width)
    print "working on line:%d to %d and sample: %d to %d" % (line_str, end_line, sample_str, end_sample)
    block_height = end_line - line_str
    block_width = end_sample - sample_str
    out_x = np.zeros((block_height, block_width), 'float32')
    out_y = np.zeros((block_height, block_width), 'float32')
    mask = np.ones((block_height, block_width), 'uint8')
    idx = np.nonzero((x3 >= sample_str) * (x3 < end_sample) * (y3 >= line_str) * (y3 < end_line))[0]
    u = x3[idx]
    v = y3[idx]
    num_samples = u.size
    mid_sample = np.median(u)
    mid_line = np.median(v)
    ut = (u - mid_sample).astype('float64')
    vt = (v - mid_line).astype('float64')
    AA = np.zeros((num_samples, 6), 'float64')
    AA[:, 0] = 1.0
    AA[:, 1] = ut
    AA[:, 2] = vt
    AA[:, 3] = ut * vt
    AA[:, 4] = ut ** 2
    AA[:, 5] = vt ** 2

    x1 = xb[idx]
    y1 = yb[idx]
    b = x1 - mid_sample
    par_x1 = np.linalg.lstsq(AA, b)[0]
    errx1 = (np.abs(np.dot(AA, par_x1) - b).max())
    print "max error column: %f" % errx1

    b = y1 - mid_line
    par_y1 = np.linalg.lstsq(AA, b)[0]
    erry1 = (np.abs(np.dot(AA, par_y1) - b).max())
    print "max error row: %f" % erry1
    if ((errx1 > max_error) or (erry1 > max_error)) and (block_size > desired_size):
        new_block_size = desired_size  # max(block_size / 2,500)
        for sub_line in range(line_str, end_line, new_block_size):
            for sub_sample in range(sample_str, end_sample, new_block_size):

                lstr = sub_line - line_str
                sstr = sub_sample - sample_str
                sub_block_line_end = min(sub_line + new_block_size, end_line)
                sub_block_sample_end = min(sub_sample + new_block_size, end_sample)
                sub_out_x, sub_out_y, sub_mask = remapImageBandGridMethod(xb, yb, x3, y3, sub_line, sub_sample,
                                                                 new_block_size, im_width, im_height, offset_min,
                                                                 max_error)

                sub_block_line_end -= line_str
                sub_block_sample_end -= sample_str
                print lstr, sstr, sub_block_line_end, sub_block_sample_end
                w = sub_block_sample_end - sstr
                h = sub_block_line_end - lstr
                out_x[lstr:sub_block_line_end, sstr: sub_block_sample_end] = sub_out_x[:h, :w]
                out_y[lstr:sub_block_line_end, sstr: sub_block_sample_end] = sub_out_y[:h, :w]
                mask[lstr:sub_block_line_end, sstr: sub_block_sample_end] = sub_mask[:h, :w]
    else:
        bline = line_str
        bsample = sample_str
        V, U = np.mgrid[bline:bline + block_height, bsample:bsample + block_width]

        sub_mask = np.ones_like(U, "uint8")

        u1d = U.flatten()
        v1d = V.flatten()
        num_pairs = u1d.size
        A = np.zeros((num_pairs, 6))
        ut = (u1d - mid_sample).astype('float64')
        vt = (v1d - mid_line).astype('float64')
        A[:, 0] = 1.0
        A[:, 1] = ut
        A[:, 2] = vt
        A[:, 3] = ut * vt
        A[:, 4] = ut ** 2
        A[:, 5] = vt ** 2

        sub_mask = sub_mask.flatten()

        x = np.dot(A, par_x1) + mid_sample
        y = np.dot(A, par_y1) + mid_line - offset_min
        x = x.astype('float32')
        y = y.astype('float32')
        out_x = x.reshape(U.shape)
        out_y = y.reshape(U.shape)
        idx = np.nonzero((x < 0))[0]
        sub_mask[idx] = 0
        idx = np.nonzero((x > im_width - 1))[0]
        sub_mask[idx] = 0
        # mask[y > im_height-1, x > im_width-1] = 0

        sub_mask = sub_mask.reshape(U.shape)
        out_x = out_x
        out_y = out_y
        mask = sub_mask



    return out_x, out_y, mask


def gainCorrectionPAN(one_block, x_min, y_min, load_width, load_height, glo, gle , gro, gre, gain, dark_cur):
    pixels = np.arange(x_min, x_min + load_width).reshape((1, load_width))
    gns = glo[y_min:(y_min + load_height), :] * (pixels < 6000) * (pixels % 2 == 0) + \
          gle[y_min:(y_min + load_height), :] * (pixels < 6000) * (pixels % 2 == 1) + \
          gro[y_min:(y_min + load_height), :] * (pixels >= 6000) * (pixels % 2 == 0) + \
          gre[y_min:(y_min + load_height), :] * (pixels >= 6000) * (pixels % 2 == 1)

    pix_gain = np.zeros_like(one_block, 'float32')
    pix_drk = np.zeros_like(one_block, 'float32')
    for idg in range(len(gain)):
        pix_gain = pix_gain + (gns == (idg)) * gain[idg][pixels]
        pix_drk = pix_drk + (gns == (idg)) * dark_cur[idg][pixels]
    one_block = one_block.astype('float32')
    one_block = (one_block - pix_drk) / pix_gain
    one_block = one_block.astype('float32')
    return one_block

def panDeconvolution(one_block, filter2D):
    summ = cv2.GaussianBlur(one_block.astype('uint8'), LV1_2ProductionConstants.PAN_GAUSSIAN_SIZE,
                            LV1_2ProductionConstants.PAN_GAUSSIAN_SIGMA)
    edges = cv2.Canny(summ.astype('uint8'), LV1_2ProductionConstants.PAN_CANNY_TH1,
                      LV1_2ProductionConstants.PAN_CANNY_TH2, L2gradient=False)
    edges = cv2.filter2D(edges, cv2.CV_8U, LV1_2ProductionConstants.PAN_EDGE_KERNEL)

    kernel = LV1_2ProductionConstants.PAN_SUM_KERNEL
    summ = signal.convolve2d(one_block, kernel, mode='same', fillvalue=0.0)
    gradient = np.abs(one_block - summ) * (edges > 0)

    gradient[0, :] = 0
    gradient[1, :] = 0
    gradient[-1, :] = 0
    gradient[-2, :] = 0
    gradient[:, 0] = 0
    gradient[:, 1] = 0
    gradient[:, -1] = 0
    gradient[:, -2] = 0
    my_filter_im = np.zeros_like(one_block).astype('float32')
    idx, idy = np.nonzero(gradient < LV1_2ProductionConstants.PAN_TH1)
    my_filter_im[idx, idy] = one_block[idx, idy]
    idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH1) * (
        gradient < LV1_2ProductionConstants.PAN_TH2))
    tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[3], borderType=cv2.BORDER_REFLECT)
    my_filter_im[idx, idy] = tem[idx, idy]
    idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH2) * (
        gradient < LV1_2ProductionConstants.PAN_TH3))
    tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[4], borderType=cv2.BORDER_REFLECT)
    my_filter_im[idx, idy] = tem[idx, idy]
    idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH3) * (
        gradient < LV1_2ProductionConstants.PAN_TH4))
    tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[5], borderType=cv2.BORDER_REFLECT)
    my_filter_im[idx, idy] = tem[idx, idy]
    idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH4))
    tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[6], borderType=cv2.BORDER_REFLECT)
    my_filter_im[idx, idy] = tem[idx, idy]
    filtered_im = my_filter_im.copy()
    return filtered_im
