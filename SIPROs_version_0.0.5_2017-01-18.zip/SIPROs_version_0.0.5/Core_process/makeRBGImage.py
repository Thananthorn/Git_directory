import cv2

from osgeo import gdal

import numpy as np


def makeRGB(theos_file, rgb_file):
    im = gdal.Open(theos_file)
    width = im.RasterXSize
    height = im.RasterYSize
    imout = np.zeros((height, width, 3), 'uint8')
    rgb = [2, 1 , 0]
    cnt = 0
    for band in [1, 2, 3]:

        im_band = im.GetRasterBand(band)
        im_data = im_band.ReadAsArray()
        imout[:, :, rgb[cnt]] = im_data
        cnt += 1

    cv2.imwrite(rgb_file, imout)


if __name__ == "__main__":
    theos_fil = r"D:\lastscene\42934\THEOS_1_LEVEL0_1_111042934_42934_MS_PB_TOP_2_28_2016-12-13_14-19-33\level1a\IMAGERY.TIF"
    out_file = r"D:\lastscene\42934\THEOS_1_LEVEL0_1_111042934_42934_MS_PB_TOP_2_28_2016-12-13_14-19-33\level1a\rgb50.tif"
    makeRGB(theos_fil, out_file)
