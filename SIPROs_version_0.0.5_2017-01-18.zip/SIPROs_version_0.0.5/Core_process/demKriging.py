import numpy as np
import scipy.optimize as opt


def linear(h, a, c):
    '''
    Linear model of the semivariogram
    '''
    a = np.float32(a)
    c = np.float32(c)
    low = (c / a) * h
    high = c
    y = low * (h <= a)
    y += high * (h > a)

    return y

def spherical(h, a, c):
    a = np.float32(a)
    c = np.float32(c)
    low = c * (1.5 * (h / a) - 0.5 * (h / a) ** 3.0)
    high = c
    y = low * (h <= a)
    y += high * (h > a)
    return y

def covariance(fct, param):
    '''
    Input:  (fct)   function that takes data and parameters
            (param) list or tuple of parameters
    Output: (inner) function that only takes data as input
                    parameters are set internally
    '''
    def inner(h):
        return param[-1] - fct(h, *param)
    return inner

def exponential(h, a, c):
    '''
    Exponential model of the semivariogram
    '''
    a = np.float32(a)
    c = np.float32(c)

    return c * (1.0 - np.exp(-3.0 * h / a))

def gaussian(h, a, c):
    '''
    Gaussian model of the semivariogram
    '''
    a = np.float32(a)
    c = np.float32(c)
    low = c * (1.5 * (h / a) - 0.5 * (h / a) ** 3.0)
    high = c
    y = low * (h <= a)
    y += high * (h > a)
    return c * (1.0 - np.exp(-3.0 * h ** 2.0 / a ** 2.0))

def power(h, w, c):
    '''
    Power model of the semivariogram
    '''
    return c * h ** w

def semivariogram(dem_grid, delta_degree, N):
    ssq = dict()
    num_sample = dict()
    # dem_grid = dem_grid -dem_grid.mean()

    for k in range(N):
        for m in range(N):
            if (k > 0) or (m > 0):
                dist = k * k + m * m
                if (k == 0) :
                    err = dem_grid[:, :-m] - dem_grid[k:, m:]

                elif (m == 0):
                    err = dem_grid[:-k, :] - dem_grid[k:, m:]
                else:
                    err1 = dem_grid[:-k, :-m] - dem_grid[k:, m:]
                    err2 = dem_grid[k:, :-m] - dem_grid[:-k, m:]
                    err = np.vstack((err1, err2))
                if ssq.has_key(dist) :
                    ssq[dist] += (err ** 2).sum()
                    num_sample[dist] += err.shape[0] * err.shape[1]
                else:
                    ssq[dist] = (err ** 2).sum()
                    num_sample[dist] = err.shape[0] * err.shape[1]

    n = len(ssq)
    semivar2 = np.zeros((n, 2))
    cnt = 0
    for key in ssq.keys():
        # print "%d:,%d,%d"%(key,num_sample[key],ssq[key])
        semivar2[cnt, 0] = ssq[key] / (2.0 * num_sample[key])
        semivar2[cnt, 1] = np.sqrt(float(key)) * delta_degree
        cnt += 1
    kk = np.argsort(semivar2[:, 1])
    semivar = np.zeros((n, 2))
    semivar[:, 0] = semivar2[kk, 0]
    semivar[:, 1] = semivar2[kk, 1]
    return semivar


def findOptModel(semivar, c, model, grid_size):
    def cost(a, data, dist, c, model):
        modelv = model(dist, a, c)
        err = ((modelv - data) ** 2).mean()

        return err
    data = semivar[:, 0]
    dist = semivar[:, 1]
    a = opt.fminbound(cost, dist.min(), dist.max() * 10.0, args=(data, dist, c, model), disp=0)
    return covariance(model, (a, c))

def Kmatrix(covfct, grid_size=3 / 3600.0, N=4):
    Ns = N * N
    K = np.zeros((Ns, Ns))
    for k in range(0, Ns):
        for m in range(0, Ns) :
            j = k % N
            i = k / N
            q = m % N
            p = m / N
            K[k, m] = np.sqrt(float(i - p) ** 2 + float(j - q) ** 2) * grid_size
    K = covfct(K)
    K = K.reshape(Ns, Ns)
    K2 = np.ones((Ns + 1, Ns + 1))
    K2[:Ns, :Ns] = K
    K2[-1, -1] = 0


    return K2

def find_dist_and_dem_vectors(lat, lon, lat_grid, lon_grid, dem_grid, covfct, grid_size=3. / 3600., N=4):
    lat_max = lat_grid.max()
    lon_min = lon_grid.min()
    n_point = len(lat.flatten())
    diff_lat = lat_max - lat.flatten()
    diff_lon = lon.flatten() - lon_min
    step_lat = (diff_lat / grid_size).astype('float32')
    step_lon = (diff_lon / grid_size).astype('float32')
    step_lat_int = step_lat.astype('int32')
    step_lon_int = step_lon.astype('int32')
    small_step_lat = (step_lat - step_lat_int).astype('float32')
    small_step_lon = (step_lon - step_lon_int).astype('float32')
    if N % 2 == 0 :
        str = -N / 2 + 1
        stp = N / 2
    else:
        str = -N / 2
        stp = N / 2
    Ns = N * N
    idx = np.arange(str, stp + 1)
    row_diff = np.repeat(np.repeat(idx.reshape(N, 1, 1), N, 1), n_point, 2)
    col_diff = np.repeat(np.repeat(idx.reshape(1, N, 1), N, 0), n_point, 2)
    ps = np.sqrt((row_diff.astype('float32') - small_step_lat) ** 2 + (col_diff.astype('float32') - small_step_lon) ** 2)
    ps = ps.reshape((Ns, n_point)) * grid_size
    rows = (row_diff + step_lat_int).reshape(Ns, n_point)
    cols = (col_diff + step_lon_int).reshape(Ns, n_point)
    dem_out = dem_grid[rows, cols]
    ks = covfct(dem_out)
    return ps, ks
