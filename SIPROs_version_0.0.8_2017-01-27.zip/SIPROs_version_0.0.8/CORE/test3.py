import sys
from PyQt4.QtGui import *
app = QApplication(sys.argv)
label = QLabel()
pixmap = QPixmap("/home/asuna/worker/2017-01/LAB/COMMAND/42934-MS_time_2016-12-13_05-36-28_filename_16-1.JPG")
label.setPixmap(pixmap)
label.show()
sys.exit(app.exec_())
