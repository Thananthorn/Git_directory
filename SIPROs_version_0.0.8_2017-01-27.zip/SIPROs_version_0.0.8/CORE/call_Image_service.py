from PyQt4.QtCore import QObject , SIGNAL  
from PyQt4.QtGui import QApplication , QWidget , QShortcut , QKeySequence , QFileDialog , QMessageBox
import cv2 , subprocess
import os , shutil , zipfile , time
from osgeo import gdal
from osgeo import osr
import sys , traceback 
from xml.dom import minidom
import xml.dom.minidom

from Image_Service import Ui_Service
import numpy as np
import scene_info as read_scene


class  Image_ServiceQT(QWidget):
	def __init__(self):
		QWidget.__init__(self)
		self.ui = Ui_Service()
		self.ui.setupUi(self)

		self.cuf_path = r"C:/Worker/Support-Worker/Producting_system/CUF_PROCESSING/"
		# self.cuf_path = "/home/asuna/worker/2016-03-26/SIPROs_v5.8.10/CUF_PROCESSING"
		self.Product_detail = r"C:/Worker/Support-Worker/Producting_system/Image_detail/"
		# self.Product_detail = "/home/asuna/worker/2016-03-26/SIPROs_v5.8.10/Image_detail"

		self.cpf_directory = r"C:/Worker/Support-Worker/Producting_system/CPF_PROCESSING/CPF"
		self.cpf_index_directory = r"C:/Worker/Support-Worker/Producting_system/CPF_PROCESSING/index_CPF"
		
		self.Revolution_Number = ""
		
		self.Order_type = ""
		self.Product_Height = ""

		self.Order_filename = ""
		self.Order_browsename = ""
		
		self.segment_count = ""
		self.scene_count = ""
		self.level = ""

		self.ui.order_by_time.setEnabled(False)
		self.ui.order_by_scene_rank.setEnabled(False)

		self.ui.revolution_number.setFocus()

		self.ui.year.setText("yyyy")
		self.ui.year.setEnabled(False)
		self.ui.month.setText("mm")
		self.ui.month.setEnabled(False)
		self.ui.date.setText("dd")
		self.ui.date.setEnabled(False)

		self.ui.center_hh.setText("hh")
		self.ui.center_hh.setEnabled(False)
		self.ui.center_mm.setText("mn")
		self.ui.center_mm.setEnabled(False)
		self.ui.center_ss.setText("ss")
		self.ui.center_ss.setEnabled(False)

		self.ui.strip_id.setText("id")
		self.ui.strip_id.setEnabled(False)
		self.ui.scene_rank.setText("nn")
		self.ui.scene_rank.setEnabled(False)

		self.ui.total_strip.clear()
		self.ui.total_scene.clear()

		self.ui.select_level.setCurrentIndex(0)

		QShortcut(QKeySequence("Ctrl+Q"), self , self.close)
		
		QObject.connect(self.ui.call_rev , SIGNAL("clicked()") , self.read_rev)
		# QObject.connect(self.ui.order_all , SIGNAL("clicked()") , self.oder_All_rev)

		QObject.connect(self.ui.button_ms , SIGNAL("clicked()") , self.type_MS)
		QObject.connect(self.ui.button_pan , SIGNAL("clicked()") , self.type_PAN)

		QObject.connect(self.ui.order_by_time , SIGNAL("clicked()"), self.order_by_date_time)
		QObject.connect(self.ui.order_by_scene_rank , SIGNAL("clicked()"), self.order_by_filename_and_scene)

		QObject.connect(self.ui.appy_scene , SIGNAL("clicked()"), self.read_order_data)
		QObject.connect(self.ui.order_scene , SIGNAL("clicked()"), self.send_command_to_process)

		QObject.connect(self.ui.clear_all , SIGNAL("clicked()"), self.clear_all)

		for root , directory , file in os.walk(self.Product_detail , topdown=False):
			for dirname in directory :
				directory_name = os.path.join(root , dirname)
				shutil.rmtree(directory_name)

	def read_rev(self):
		Revolution_Number = self.ui.revolution_number.text()
		self.Revolution_Number = Revolution_Number
		if self.Revolution_Number != "" :
			if len(self.Revolution_Number) < 6 :
				if len(self.Revolution_Number) == 5 :
					try :
						self.Revolution_Number = int(self.Revolution_Number)
					except :
						QMessageBox.warning(self , "Warning", "Sir you input worng revolution number.")
						print traceback.format_exc()

					self.Revolution_Number = "0" + str(self.Revolution_Number)
					cufzip_file_path = os.path.abspath(self.cuf_path + "THEOS_1_" + self.Revolution_Number + "_IGS_CUF.zip")
					print cufzip_file_path
					segment_count , scene_count = read_scene.ReadData(cufzip_file_path , self.Product_detail)
					self.segment_count = segment_count
					self.scene_count = scene_count
					total_strip = self.ui.total_strip.setText(self.segment_count)
					total_scene = self.ui.total_scene.setText(self.scene_count)
					
				else : QMessageBox.warning(self , "Warning", "Sir you input worng revolution number.")
			
			elif len(self.Revolution_Number) == 6 :
				self.Revolution_Number = str(self.Revolution_Number)
				try :
					self.Revolution_Number = int(self.Revolution_Number)
				except :
					QMessageBox.warning(self , "Warning", "Sir you input worng revolution number.")
					print traceback.format_exc()

				self.Revolution_Number = "0" + str(self.Revolution_Number)
				cufzip_file_path = os.path.abspath(self.cuf_path + "THEOS_1_" + self.Revolution_Number + "_IGS_CUF.zip")
				print cufzip_file_path

				segment_count , scene_count = read_scene.ReadData(cufzip_file_path , self.Product_detail)
				self.segment_count = segment_count
				self.scene_count = scene_count
				total_strip = self.ui.total_strip.setText(self.segment_count)
				total_scene = self.ui.total_scene.setText(self.scene_count)

			else : QMessageBox.warning(self , "Warning", "Sir you input worng revolution number.")

		elif self.Revolution_Number == "" :
			QMessageBox.warning(self , "Warning", "Input revolution number.")

	def type_MS(self):
		self.ui.button_ms.setChecked(True)
		self.ui.button_pan.setChecked(False)
		self.ui.product_height.clear()
		self.Order_type = "MS"
		self.ui.product_height.setText(str(6000))
		self.level = self.ui.select_level.currentText()
		level = self.ui.select_level.currentIndex()
		print self.level , level

		if level == 0 :
			self.ui.order_by_time.setEnabled(False)
			self.ui.order_by_scene_rank.setEnabled(False)
			self.ui.order_by_time.setChecked(False)
			self.ui.order_by_scene_rank.setChecked(False)
			
			self.ui.strip_id.clear()
			self.ui.strip_id.setText("id")
			self.ui.strip_id.setEnabled(False)
			self.ui.scene_rank.clear()
			self.ui.scene_rank.setText("nn")
			self.ui.scene_rank.setEnabled(False)
			self.ui.year.clear()
			self.ui.year.setText("yyyy")
			self.ui.year.setEnabled(False)
			self.ui.month.clear()
			self.ui.month.setText("mm")
			self.ui.month.setEnabled(False)
			self.ui.date.clear()
			self.ui.date.setText("dd")
			self.ui.date.setEnabled(False)

			self.ui.center_hh.clear()
			self.ui.center_hh.setText("hh")
			self.ui.center_hh.setEnabled(False)
			self.ui.center_mm.clear()
			self.ui.center_mm.setText("mn")
			self.ui.center_mm.setEnabled(False)
			self.ui.center_ss.clear()
			self.ui.center_ss.setText("ss")
			self.ui.center_ss.setEnabled(False)
		
		elif level == 1:
			self.ui.order_by_time.setEnabled(True)
			self.ui.order_by_scene_rank.setEnabled(True)

		elif level == 2:
			self.ui.order_by_time.setEnabled(True)
			self.ui.order_by_scene_rank.setEnabled(True)	

	def type_PAN(self):
		self.ui.button_ms.setChecked(False)
		self.ui.button_pan.setChecked(True)
		self.ui.product_height.clear()
		self.Order_type = "PAN"
		self.ui.product_height.setText(str(12000))
		self.level = self.ui.select_level.currentText()
		level = self.ui.select_level.currentIndex()
		print self.level , level

		if level == 0 :
			self.ui.order_by_time.setEnabled(False)
			self.ui.order_by_scene_rank.setEnabled(False)
			self.ui.order_by_time.setChecked(False)
			self.ui.order_by_scene_rank.setChecked(False)
			
			self.ui.strip_id.clear()
			self.ui.strip_id.setText("id")
			self.ui.strip_id.setEnabled(False)
			self.ui.scene_rank.clear()
			self.ui.scene_rank.setText("nn")
			self.ui.scene_rank.setEnabled(False)
			self.ui.year.clear()
			self.ui.year.setText("yyyy")
			self.ui.year.setEnabled(False)
			self.ui.month.clear()
			self.ui.month.setText("mm")
			self.ui.month.setEnabled(False)
			self.ui.date.clear()
			self.ui.date.setText("dd")
			self.ui.date.setEnabled(False)

			self.ui.center_hh.clear()
			self.ui.center_hh.setText("hh")
			self.ui.center_hh.setEnabled(False)
			self.ui.center_mm.clear()
			self.ui.center_mm.setText("mn")
			self.ui.center_mm.setEnabled(False)
			self.ui.center_ss.clear()
			self.ui.center_ss.setText("ss")
			self.ui.center_ss.setEnabled(False)
		
		elif level == 1:
			self.ui.order_by_time.setEnabled(True)
			self.ui.order_by_scene_rank.setEnabled(True)

		elif level == 2:
			self.ui.order_by_time.setEnabled(True)
			self.ui.order_by_scene_rank.setEnabled(True)
		
	def order_by_date_time(self):
		self.ui.order_by_time.setChecked(True)
		self.ui.order_by_scene_rank.setChecked(False)

		self.ui.strip_id.clear()
		self.ui.strip_id.setText("id")
		self.ui.strip_id.setEnabled(False)
		self.ui.scene_rank.clear()
		self.ui.scene_rank.setText("nn")
		self.ui.scene_rank.setEnabled(False)

		self.ui.year.clear()
		self.ui.year.setEnabled(True)
		self.ui.month.clear()
		self.ui.month.setEnabled(True)
		self.ui.date.clear()
		self.ui.date.setEnabled(True)

		self.ui.center_hh.clear()
		self.ui.center_hh.setEnabled(True)
		self.ui.center_mm.clear()
		self.ui.center_mm.setEnabled(True)
		self.ui.center_ss.clear()
		self.ui.center_ss.setEnabled(True)
		self.ui.year.setFocus()

	def order_by_filename_and_scene(self):
		self.ui.order_by_scene_rank.setChecked(True)
		self.ui.order_by_time.setChecked(False)

		self.ui.year.clear()
		self.ui.year.setText("yyyy")
		self.ui.year.setEnabled(False)
		self.ui.month.clear()
		self.ui.month.setText("mm")
		self.ui.month.setEnabled(False)
		self.ui.date.clear()
		self.ui.date.setText("dd")
		self.ui.date.setEnabled(False)

		self.ui.center_hh.clear()
		self.ui.center_hh.setText("hh")
		self.ui.center_hh.setEnabled(False)
		self.ui.center_mm.clear()
		self.ui.center_mm.setText("mn")
		self.ui.center_mm.setEnabled(False)
		self.ui.center_ss.clear()
		self.ui.center_ss.setText("ss")
		self.ui.center_ss.setEnabled(False)

		self.ui.strip_id.clear()
		self.ui.strip_id.setEnabled(True)
		self.ui.scene_rank.clear()
		self.ui.scene_rank.setEnabled(True)
		self.ui.strip_id.setFocus()

	def read_order_data(self):
		strip_id = self.ui.strip_id.text()
		scene_rank = self.ui.scene_rank.text()

		year = self.ui.year.text()
		month = self.ui.month.text()
		date = self.ui.date.text()
		hour = self.ui.center_hh.text()
		minute = self.ui.center_mm.text()
		second = self.ui.center_ss.text()

		if (strip_id != "") and (scene_rank != "") and (year == "yyyy") and (month == "mm") and (date == "dd") and (hour == "hh") and (minute == "mn") and (second == "ss") :
			order_name = self.Product_detail + self.Revolution_Number + "/" + self.Order_type + "/Filename_%s/Scenerank_%s" % (strip_id, scene_rank)
			order_filename = order_name + ".cmp"
			order_browsename = order_name + ".JPG"

			img = cv2.imread(order_browsename)
			cv2.imshow("Browse iamge" , img)
			cv2.waitKey(0) & 0xFF
			cv2.destroyAllWindows()

			self.Order_filename = order_filename
			self.Order_browsename = order_browsename

			comand_filename = self.Order_filename
			command_list = []
			command_file = open(comand_filename , "r")

			for i in range(61):
				read_command_from_file = command_file.readline()
				Pre_command_value = read_command_from_file.strip("\n")
				command_value = Pre_command_value.strip("[]")
				command_list.append(command_value)
			command_file.close()

			Begin_reception_date = str(command_list[0])
			Begin_reception_time = str(command_list[1])
			End_reception_date = str(command_list[2])
			End_reception_time = str(command_list[3])
			Orbit_cycle = str(command_list[4])
			Revolution_number = str(command_list[5])
			Mission = str(command_list[6])
			Satellite = str(command_list[7])
			Passrank = str(command_list[8])
			PassID = str(command_list[9])
			Segment_count = str(command_list[10])
			Segment_info = str(command_list[11])
			FileName = str(command_list[12])
			Gerald_name = str(command_list[13])
			Segment_rank = str(command_list[14])
			Instrument = str(command_list[15])  
			Transmission_mode = str(command_list[16])
			Segment_quality = str(command_list[17])
			Begin_segment_viewing_date = str(command_list[18])
			Begin_segment_viewing_time = str(command_list[19])
			End_segment_viewing_date = str(command_list[20]) 
			End_segment_viewing_time = str(command_list[21])
			Compression_ratio = str(command_list[22])   
			SpectralMode = str(command_list[23])  
			band_offset = str(command_list[24])
			Reference_Band = str(command_list[25])
			Along_track_viewing_angle = str(command_list[26])
			Across_track_viewing_angle = str(command_list[27])
			ABS_Gain = str(command_list[28])
			scene_info = str(command_list[29])
			scene_count = str(command_list[30])
			scene_rank = str(command_list[31])
			Grid_ref = str(command_list[32])
			Technical_quality = str(command_list[33])
			Cloud_cover = str(command_list[34])
			Snow_cover = str(command_list[35])
			Center_scene_viewing_date = str(command_list[36])
			Center_scene_viewing_time = str(command_list[37])
			Begin_scene_viewing_date = str(command_list[38])
			Begin_scene_viewing_time = str(command_list[39])
			End_scene_viewing_date = str(command_list[40])
			End_scene_viewing_time = str(command_list[41])
			Coupling_mode = str(command_list[42])  
			Orientation_angle = str(command_list[43])
			Incidence_angle = str(command_list[44])
			Sun_elevation = str(command_list[45])
			Sun_azimuth = str(command_list[46])
			Latitude_NW = str(command_list[47])
			Longitude_NW = str(command_list[48])
			Latitude_NE = str(command_list[49])
			Longitude_NE = str(command_list[50])
			Latitude_SW = str(command_list[51])
			Longitude_SW = str(command_list[52])
			Latitude_SE = str(command_list[53])
			Longitude_SE = str(command_list[54])
			Center_scene_latitude = str(command_list[55])
			Center_scene_longitude = str(command_list[56])
			if SpectralMode == "MS":
				beginline = [int(command_list[57]) , int(command_list[58]) , int(command_list[59]) , int(command_list[60])]
			elif SpectralMode == "PAN":
				beginline = str(command_list[57])

			self.ui.gerald_name.setText(Gerald_name)
			self.ui.dsr_begin.setText(str(beginline))
			self.ui.grid_ref.setText(Grid_ref)
			self.ui.log_data.clear()
			
			self.ui.log_data.append("Begin Reception : %s/%s/%s %s:%s:%s " % (Begin_reception_date[:-4], Begin_reception_date[4:-2], Begin_reception_date[6:], Begin_reception_time[:-8], Begin_reception_time[2:-6], Begin_reception_time[4:]))
			self.ui.log_data.append("End Reception : %s/%s/%s %s:%s:%s" % (End_reception_date[:-4], End_reception_date[4:-2], End_reception_date[6:] , End_reception_time[:-8] , End_reception_time[2:-6], End_reception_time[4:]))
			self.ui.log_data.append("OrbitCycle : %s\nRevolutionNumber : %s\nMission : %s\nSatellite ID: %s\nPassrank : %s\nPassID : %s" % (Orbit_cycle , Revolution_number , Mission , Satellite , Passrank , PassID))
			self.ui.log_data.append("Segment count : %s" % Segment_count)
			self.ui.log_data.append("%s" % Segment_info)
			self.ui.log_data.append("FileName : %s" % FileName)
			self.ui.log_data.append("Gerald name : %s" % Gerald_name)
			self.ui.log_data.append("Segment rank : %s" % Segment_rank)
			self.ui.log_data.append("Instrument : %s" % Instrument)
			self.ui.log_data.append("Transmission mode : %s" % Transmission_mode)
			self.ui.log_data.append("Segment quality : %s" % Segment_quality)
			self.ui.log_data.append("Begin segment viewing date : %s/%s/%s" % (Begin_segment_viewing_date[:-4], Begin_segment_viewing_date[4:-2], Begin_segment_viewing_date[6:]))
			self.ui.log_data.append("Begin segment viewing time : %s:%s:%s" % (Begin_segment_viewing_time[:-4] , Begin_segment_viewing_time[2:-2], Begin_segment_viewing_time[4:]))
			self.ui.log_data.append("End segment viewing date : %s/%s/%s" % (End_segment_viewing_date[:-4], End_segment_viewing_date[4:-2], End_segment_viewing_date[6:]))
			self.ui.log_data.append("End segment viewing time : %s:%s:%s" % (End_segment_viewing_time[:-4], End_segment_viewing_time[2:-2], End_segment_viewing_time[4:]))
			self.ui.log_data.append("Compression ratio : %s" % Compression_ratio)
			self.ui.log_data.append("SpectralMode : %s" % SpectralMode)
			self.ui.log_data.append("Band offset : %s" % band_offset)
			self.ui.log_data.append("Reference Band : %s" % Reference_Band)
			self.ui.log_data.append("Along track viewing angle : %s" % Along_track_viewing_angle)
			self.ui.log_data.append("Across track viewing angle : %s" % Across_track_viewing_angle)
			self.ui.log_data.append("ABS Gain : %s" % ABS_Gain)
			self.ui.log_data.append("%s" % scene_info)
			self.ui.log_data.append("Scene rank : %s" % scene_rank)
			self.ui.log_data.append("Grid reference : %s" % Grid_ref)
			self.ui.log_data.append("Technical quality : %s" % Technical_quality)
			self.ui.log_data.append("Cloud cover : %s" % Cloud_cover) 
			self.ui.log_data.append("Snow cover : %s" % Snow_cover)
			self.ui.log_data.append("Center scene viewing date : %s/%s/%s" % (Center_scene_viewing_date[:-4], Center_scene_viewing_date[4:-2], Center_scene_viewing_date[6:]))
			self.ui.log_data.append("Center scene viewing time :%s:%s:%s" % (Center_scene_viewing_time[:-4], Center_scene_viewing_time[2:-2], Center_scene_viewing_time[4:]))
			self.ui.log_data.append("Begin scene viewing date : %s/%s/%s" % (Begin_scene_viewing_date[:-4], Begin_scene_viewing_date[4:-2], Begin_scene_viewing_date[6:]))
			self.ui.log_data.append("Begin scene viewing time : %s:%s:%s" % (Begin_scene_viewing_time[:-4], Begin_scene_viewing_time[2:-2], Begin_scene_viewing_time[4:]))
			self.ui.log_data.append("End scene viewing date : %s/%s/%s" % (End_scene_viewing_date[:-4], End_scene_viewing_date[4:-2], End_scene_viewing_date[6:]))
			self.ui.log_data.append("End scene viewing time : %s:%s:%s" % (End_scene_viewing_time[:-4], End_scene_viewing_time[2:-2], End_scene_viewing_time[4:]))
			self.ui.log_data.append("Coupling mode : %s" % Coupling_mode)
			self.ui.log_data.append("Orientation angle : %s" % Orientation_angle) 
			self.ui.log_data.append("Incidence angle : %s" % Incidence_angle)
			self.ui.log_data.append("Sun elevation : %s" % Sun_elevation)
			self.ui.log_data.append("Sun azimuth : %s" % Sun_azimuth)
			self.ui.log_data.append("Latitude NW : %s" % Latitude_NW)
			self.ui.log_data.append("Longitude NW : %s" % Longitude_NW)
			self.ui.log_data.append("Latitude NE : %s" % Latitude_NE)
			self.ui.log_data.append("Longitude NE : %s" % Longitude_NE)
			self.ui.log_data.append("Latitude SW : %s" % Latitude_SW)
			self.ui.log_data.append("Longitude SW : %s" % Longitude_SW)
			self.ui.log_data.append("Latitude SE : %s" % Latitude_SE)
			self.ui.log_data.append("Longitude SE : %s" % Longitude_SE)
			self.ui.log_data.append("Center scene latitude : %s" % Center_scene_latitude)
			self.ui.log_data.append("Center scene longitude : %s" % Center_scene_longitude)
			self.ui.log_data.append("Begin line : %s" % beginline)
		
		elif (strip_id == "id") and (scene_rank == "nn") and (year != "") and (month != "") and (date != "") and (hour != "") and (minute != "") and (second != "") :
			order_name = self.Product_detail + self.Revolution_Number + "/" + self.Order_type + "/%s-%s-%s/%s%s%s" % (year, month, date, hour, minute, second)
			order_filename = order_name + ".cmp"
			order_browsename = order_name + ".JPG"

			img = cv2.imread(order_browsename)
			cv2.imshow("Browse iamge" , img)
			cv2.waitKey(0) & 0xFF
			cv2.destroyAllWindows()

			self.Order_filename = order_filename
			self.Order_browsename = order_browsename

			comand_filename = self.Order_filename
			command_list = []
			command_file = open(comand_filename , "r")

			for i in range(61):
				read_command_from_file = command_file.readline()
				Pre_command_value = read_command_from_file.strip("\n")
				command_value = Pre_command_value.strip("[]")
				command_list.append(command_value)
			command_file.close()

			Begin_reception_date = str(command_list[0])
			Begin_reception_time = str(command_list[1])
			End_reception_date = str(command_list[2])
			End_reception_time = str(command_list[3])
			Orbit_cycle = str(command_list[4])
			Revolution_number = str(command_list[5])
			Mission = str(command_list[6])
			Satellite = str(command_list[7])
			Passrank = str(command_list[8])
			PassID = str(command_list[9])
			Segment_count = str(command_list[10])
			Segment_info = str(command_list[11])
			FileName = str(command_list[12])
			Gerald_name = str(command_list[13])
			Segment_rank = str(command_list[14])
			Instrument = str(command_list[15])  
			Transmission_mode = str(command_list[16])
			Segment_quality = str(command_list[17])
			Begin_segment_viewing_date = str(command_list[18])
			Begin_segment_viewing_time = str(command_list[19])
			End_segment_viewing_date = str(command_list[20]) 
			End_segment_viewing_time = str(command_list[21])
			Compression_ratio = str(command_list[22])   
			SpectralMode = str(command_list[23])  
			band_offset = str(command_list[24])
			Reference_Band = str(command_list[25])
			Along_track_viewing_angle = str(command_list[26])
			Across_track_viewing_angle = str(command_list[27])
			ABS_Gain = str(command_list[28])
			scene_info = str(command_list[29])
			scene_count = str(command_list[30])
			scene_rank = str(command_list[31])
			Grid_ref = str(command_list[32])
			Technical_quality = str(command_list[33])
			Cloud_cover = str(command_list[34])
			Snow_cover = str(command_list[35])
			Center_scene_viewing_date = str(command_list[36])
			Center_scene_viewing_time = str(command_list[37])
			Begin_scene_viewing_date = str(command_list[38])
			Begin_scene_viewing_time = str(command_list[39])
			End_scene_viewing_date = str(command_list[40])
			End_scene_viewing_time = str(command_list[41])
			Coupling_mode = str(command_list[42])  
			Orientation_angle = str(command_list[43])
			Incidence_angle = str(command_list[44])
			Sun_elevation = str(command_list[45])
			Sun_azimuth = str(command_list[46])
			Latitude_NW = str(command_list[47])
			Latitude_NE = str(command_list[49])
			Longitude_NE = str(command_list[50])
			Latitude_SW = str(command_list[51])
			Longitude_SW = str(command_list[52])
			Latitude_SE = str(command_list[53])
			Longitude_SE = str(command_list[54])
			Center_scene_latitude = str(command_list[55])
			Center_scene_longitude = str(command_list[56])
			if SpectralMode == "MS":
				beginline = [int(command_list[57]) , int(command_list[58]) , int(command_list[59]) , int(command_list[60])]
			elif SpectralMode == "PAN":
				beginline = str(command_list[57])

			self.ui.gerald_name.setText(Gerald_name)
			self.ui.dsr_begin.setText(str(beginline))
			self.ui.grid_ref.setText(Grid_ref)
			self.ui.log_data.clear()

			self.ui.log_data.append("Begin Reception : %s/%s/%s %s:%s:%s " % (Begin_reception_date[:-4], Begin_reception_date[4:-2], Begin_reception_date[6:], Begin_reception_time[:-8], Begin_reception_time[2:-6], Begin_reception_time[4:]))
			self.ui.log_data.append("End Reception : %s/%s/%s %s:%s:%s" % (End_reception_date[:-4], End_reception_date[4:-2], End_reception_date[6:] , End_reception_time[:-8] , End_reception_time[2:-6], End_reception_time[4:]))
			self.ui.log_data.append("OrbitCycle : %s\nRevolutionNumber : %s\nMission : %s\nSatellite ID: %s\nPassrank : %s\nPassID : %s" % (Orbit_cycle , Revolution_number , Mission , Satellite , Passrank , PassID))
			self.ui.log_data.append("Segment count : %s" % Segment_count)
			self.ui.log_data.append("%s" % Segment_info)
			self.ui.log_data.append("FileName : %s" % FileName)
			self.ui.log_data.append("Gerald name : %s" % Gerald_name)
			self.ui.log_data.append("Segment rank : %s" % Segment_rank)
			self.ui.log_data.append("Instrument : %s" % Instrument)
			self.ui.log_data.append("Transmission mode : %s" % Transmission_mode)
			self.ui.log_data.append("Segment quality : %s" % Segment_quality)
			self.ui.log_data.append("Begin segment viewing date : %s/%s/%s" % (Begin_segment_viewing_date[:-4], Begin_segment_viewing_date[4:-2], Begin_segment_viewing_date[6:]))
			self.ui.log_data.append("Begin segment viewing time : %s:%s:%s" % (Begin_segment_viewing_time[:-4] , Begin_segment_viewing_time[2:-2], Begin_segment_viewing_time[4:]))
			self.ui.log_data.append("End segment viewing date : %s/%s/%s" % (End_segment_viewing_date[:-4], End_segment_viewing_date[4:-2], End_segment_viewing_date[6:]))
			self.ui.log_data.append("End segment viewing time : %s:%s:%s" % (End_segment_viewing_time[:-4], End_segment_viewing_time[2:-2], End_segment_viewing_time[4:]))
			self.ui.log_data.append("Compression ratio : %s" % Compression_ratio)
			self.ui.log_data.append("SpectralMode : %s" % SpectralMode)
			self.ui.log_data.append("Band offset : %s" % band_offset)
			self.ui.log_data.append("Reference Band : %s" % Reference_Band)
			self.ui.log_data.append("Along track viewing angle : %s" % Along_track_viewing_angle)
			self.ui.log_data.append("Across track viewing angle : %s" % Across_track_viewing_angle)
			self.ui.log_data.append("ABS Gain : %s" % ABS_Gain)
			self.ui.log_data.append("%s" % scene_info)
			self.ui.log_data.append("Scene rank : %s" % scene_rank)
			self.ui.log_data.append("Grid reference : %s" % Grid_ref)
			self.ui.log_data.append("Technical quality : %s" % Technical_quality)
			self.ui.log_data.append("Cloud cover : %s" % Cloud_cover) 
			self.ui.log_data.append("Snow cover : %s" % Snow_cover)
			self.ui.log_data.append("Center scene viewing date : %s/%s/%s" % (Center_scene_viewing_date[:-4], Center_scene_viewing_date[4:-2], Center_scene_viewing_date[6:]))
			self.ui.log_data.append("Center scene viewing time :%s:%s:%s" % (Center_scene_viewing_time[:-4], Center_scene_viewing_time[2:-2], Center_scene_viewing_time[4:]))
			self.ui.log_data.append("Begin scene viewing date : %s/%s/%s" % (Begin_scene_viewing_date[:-4], Begin_scene_viewing_date[4:-2], Begin_scene_viewing_date[6:]))
			self.ui.log_data.append("Begin scene viewing time : %s:%s:%s" % (Begin_scene_viewing_time[:-4], Begin_scene_viewing_time[2:-2], Begin_scene_viewing_time[4:]))
			self.ui.log_data.append("End scene viewing date : %s/%s/%s" % (End_scene_viewing_date[:-4], End_scene_viewing_date[4:-2], End_scene_viewing_date[6:]))
			self.ui.log_data.append("End scene viewing time : %s:%s:%s" % (End_scene_viewing_time[:-4], End_scene_viewing_time[2:-2], End_scene_viewing_time[4:]))
			self.ui.log_data.append("Coupling mode : %s" % Coupling_mode)
			self.ui.log_data.append("Orientation angle : %s" % Orientation_angle) 
			self.ui.log_data.append("Incidence angle : %s" % Incidence_angle)
			self.ui.log_data.append("Sun elevation : %s" % Sun_elevation)
			self.ui.log_data.append("Sun azimuth : %s" % Sun_azimuth)
			self.ui.log_data.append("Latitude NW : %s" % Latitude_NW)
			self.ui.log_data.append("Longitude NW : %s" % Longitude_NW)
			self.ui.log_data.append("Latitude NE : %s" % Latitude_NE)
			self.ui.log_data.append("Longitude NE : %s" % Longitude_NE)
			self.ui.log_data.append("Latitude SW : %s" % Latitude_SW)
			self.ui.log_data.append("Longitude SW : %s" % Longitude_SW)
			self.ui.log_data.append("Latitude SE : %s" % Latitude_SE)
			self.ui.log_data.append("Longitude SE : %s" % Longitude_SE)
			self.ui.log_data.append("Center scene latitude : %s" % Center_scene_latitude)
			self.ui.log_data.append("Center scene longitude : %s" % Center_scene_longitude)
			self.ui.log_data.append("Begin line : %s" % beginline)

		else : 
			QMessageBox.warning(self , "Warning", "Sir you input worng order.")
			print str(traceback.format_exc())

	def send_command_to_process(self):
		order_directory = r"\\172.27.188.133\thaichote_gerald\order_to_process"
		levelprocess = "Level_%s" % self.level
		order_path = order_directory + "/" + levelprocess
		order_file = self.Order_filename
		try :
			shutil.copy2(order_file , order_path)
			print "copy %s to %s" % (order_file , order_directory)
		except:
			error_name = str(traceback.format_exc())

	def clear_all(self):

		self.ui.revolution_number.clear()
		self.ui.revolution_number.setFocus()

		self.ui.total_strip.clear()
		self.ui.total_scene.clear()

		self.ui.select_level.setCurrentIndex(0)

		self.ui.product_height.clear()

		self.ui.strip_id.clear()
		self.ui.scene_rank.clear()

		self.ui.year.clear()
		self.ui.year.setText("yyyy")
		self.ui.year.setEnabled(False)

		self.ui.month.clear()
		self.ui.month.setText("mm")
		self.ui.month.setEnabled(False)

		self.ui.date.clear()
		self.ui.date.setText("dd")
		self.ui.date.setEnabled(False)

		self.ui.center_hh.clear()
		self.ui.center_hh.setText("hh")
		self.ui.center_hh.setEnabled(False)

		self.ui.center_mm.clear()
		self.ui.center_mm.setText("nn")
		self.ui.center_mm.setEnabled(False)

		self.ui.center_ss.clear()
		self.ui.center_ss.setText("ss")
		self.ui.center_ss.setEnabled(False)

		self.ui.strip_id.setText("id")
		self.ui.strip_id.setEnabled(False)

		self.ui.scene_rank.setText("nn")
		self.ui.scene_rank.setEnabled(False)

		self.ui.gerald_name.clear()
		self.ui.dsr_begin.clear()
		self.ui.grid_ref.clear()

		self.ui.log_data.clear()

		self.ui.button_ms.setChecked(False)
		self.ui.button_pan.setChecked(False)

		self.ui.order_by_scene_rank.setChecked(False)
		self.ui.order_by_time.setChecked(False)

		self.ui.order_by_time.setEnabled(False)
		self.ui.order_by_scene_rank.setEnabled(False)

		self.Revolution_Number = ""
		
		self.Order_type = ""
		self.Product_Height = ""

		self.Order_filename = ""
		self.Order_browsename = ""
		
		self.segment_count = ""
		self.scene_count = ""
		self.level = ""

		for root , directory , file in os.walk(self.Product_detail , topdown=False):
			for dirname in directory :
				directory_name = os.path.join(root , dirname)
				shutil.rmtree(directory_name)


if __name__ == "__main__":
	app = QApplication(sys.argv)
	
	myapp = Image_ServiceQT()
	myapp.show()

	sys.exit(app.exec_())
