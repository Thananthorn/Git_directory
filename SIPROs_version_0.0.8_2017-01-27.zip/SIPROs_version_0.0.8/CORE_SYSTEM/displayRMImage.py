"""
Copyright 2017 GISTDA


This software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa cooperatiopn
between GISTDA and Kasetsart Universit under the SIPPO project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, distribute,
and/or shell copies of the Software for the education purposes without any prior notification to GISTDA.

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

 """

import cv2
#from osgeo import gdal
import platform
if platform.system() =="Windows":
    from osgeo import gdal
else:
    import gdal
import numpy as np
import time
from threading import Thread

from PyQt4 import QtGui
import sys

class displayRMImage(Thread):
    def __init__(self, file_name, win_name=""):#, onMouseClickTask = None):
        self.width = None
        self.height = None
        self.num_bands = None
        self.xorg = 0
        self.yorg = 0

        self.overview_name = win_name
        self.partial_name = win_name
        self.windows_name = win_name
        self.overview_image = None
        self.partial_image = None
        #self.onMouseClickTask = onMouseClickTask
        self.file_name = file_name

        try:
            self.file_p = gdal.Open(file_name)
        except IOError:
            print "Image Cannot be loaded"
        if self.file_p is None:
            print ("Unsupported format")

        else:
            self.width = self.file_p.RasterXSize
            self.height = self.file_p.RasterYSize
            self.num_bands = self.file_p.RasterCount
            self.xorg = self.width / 2
            self.yorg = self.height / 2

        self.display_width_max = 512
        self.display_height_max = 512
        self.display_width = 512/3
        self.display_height = 512/3
        self.scale = 50
        self.band_list = None
        # initial The scale
        app = QtGui.QApplication(sys.argv)
        screen_rect = app.desktop().screenGeometry()

        width, height = screen_rect.width(), screen_rect.height()
        print width, height
        width = 0.7*width
        height = 0.7*height
        self.scale = int(max(self.width/width, self.height/height))

        Thread.__init__(self)


    def createOverView(self, band_list, scale):
        # We will display 2 windows
        # The summary and the full scale
        if self.file_p is None:
            return None

        if len(band_list) == 3:
            color = True
        else:
            color = False

        if color:
            red_id = band_list[0]
            green_id = band_list[1]
            blue_id = band_list[2]

            red = self.file_p.GetRasterBand(red_id)
            green = self.file_p.GetRasterBand(green_id)
            blue = self.file_p.GetRasterBand(blue_id)
            width = self.width
            height = self.height

            show_width = np.ceil(float(width) / float(scale))
            show_height = np.ceil(float(height) / float(scale))

            im_show = np.zeros((show_height, show_width, 3), 'uint8')

            show_line = 0
            str = time.clock()

            for line in range(0, height, scale):
                # Read line
                #print line
                red_data = red.ReadAsArray(0, line, width, 1)
                green_data = green.ReadAsArray(0, line, width, 1)
                blue_data = blue.ReadAsArray(0, line, width, 1)
                im_show[show_line, :, 2] = red_data[0, ::scale]
                im_show[show_line, :, 1] = green_data[0, ::scale]
                im_show[show_line, :, 0] = blue_data[0, ::scale]
                show_line += 1
            stp = time.clock()
            # print "Total Image = ", (stp-str)
            #cv2.imshow("Scale 1:%d"%scale,im_show)
            #cv2.waitKey(0)

        else:
            gray_id = band_list[0]

        return im_show

    def createPartialFullScale(self, xorg, yorg, x_size, y_size, band_list):
        if self.file_p is None:
            return None

        if len(band_list) == 3:
            color = True
        else:
            color = False

        if color:
            red_id = band_list[0]
            green_id = band_list[1]
            blue_id = band_list[2]

            red = self.file_p.GetRasterBand(red_id)
            green = self.file_p.GetRasterBand(green_id)
            blue = self.file_p.GetRasterBand(blue_id)
            width = self.width
            height = self.height

            max_width = xorg + x_size
            if max_width > width:
                x_size = x_size - (max_width - width)

            max_height = yorg + y_size
            if max_width > width:
                y_size = y_size - (max_height - height)




            # print x_size, y_size
            im_show = np.zeros((y_size, x_size, 3), 'uint8')

            str = time.clock()

            im_show[:, :, 2] = red.ReadAsArray(xorg, yorg, x_size, y_size)
            im_show[:, :, 1] = green.ReadAsArray(xorg, yorg, x_size, y_size)
            im_show[:, :, 0] = blue.ReadAsArray(xorg, yorg, x_size, y_size)
            stp = time.clock()
            #print "Total Image = ", (stp-str)

            #cv2.imshow("Scale 1:1",im_show)
            #cv2.waitKey(0)

        else:
            gray_id = band_list[0]
        im_show = cv2.resize(im_show,(x_size*10,y_size*10),interpolation=cv2.INTER_NEAREST)
        return im_show


    def displayBothFullAndOverView(self):

        xorg = self.xorg
        yorg = self.yorg
        band_list = self.band_list
        scale = self.scale

        display_x = self.display_width
        display_y = self.display_height
        if self.overview_image is None:
            im_overview = self.createOverView(band_list, scale)
            self.overview_image = im_overview.copy()
        else:
            im_overview = self.overview_image.copy()
        height, width, bands = im_overview.shape
        im_partial = self.createPartialFullScale(xorg, yorg, display_x, display_y, band_list)
        # add a red rectangle to overview image
        xorg_ovw = xorg / scale
        yorg_ovw = yorg / scale
        xend = min(xorg_ovw + display_x / scale, width)
        yend = min(yorg_ovw + display_y / scale, height)
        #print xend, yend, height, width

        im_overview[yorg_ovw:yend, xorg_ovw, 2] = 255
        im_overview[yorg_ovw:yend, xorg_ovw, 0] = 0
        im_overview[yorg_ovw:yend, xorg_ovw, 1] = 0

        im_overview[yorg_ovw:yend, xend - 1, 2] = 255
        im_overview[yorg_ovw:yend, xend - 1, 0] = 0
        im_overview[yorg_ovw:yend, xend - 1, 1] = 0

        im_overview[yorg_ovw, xorg_ovw:xend, 2] = 255
        im_overview[yorg_ovw, xorg_ovw:xend, 0] = 0
        im_overview[yorg_ovw, xorg_ovw:xend, 1] = 0

        im_overview[yend - 1, xorg_ovw:xend, 2] = 255
        im_overview[yend - 1, xorg_ovw:xend, 0] = 0
        im_overview[yend - 1, xorg_ovw:xend, 1] = 0
        self.overview_name = self.windows_name + "scale 1:%d" % scale
        self.partial_name = self.windows_name + "scale 1:2"
        #cv2.namedWindow(self.partial_name)
        #cv2.createTrackbar("bright", self.partial_name,0.05, 0.1, self.onChange)

        cv2.imshow(self.overview_name, im_overview)
        cv2.imshow(self.partial_name, im_partial)
        self.partial_image=im_partial

    def onChange(self, val):
        pass

    def onSelectNewPartialView(self, event, x, y, flags, param):
        if event == cv2.EVENT_LBUTTONUP:
            self.xorg = x * self.scale
            self.yorg = y * self.scale

    def onMouseClickTask(self, event, x, y, flags, param):
        if event == cv2.EVENT_RBUTTONUP:
            cv2.imwrite(self.file_name[:-4]+"(%d_%d).tif"%(x,y),self.partial_image)


    def run(self):
        self.displayBothFullAndOverView()
        cv2.setMouseCallback(self.overview_name, self.onSelectNewPartialView)
        #if self.onMouseClickTask is not None:
        cv2.setMouseCallback(self.partial_name, self.onMouseClickTask)
        xx = 10
        while (xx) != 27:
            self.displayBothFullAndOverView()
            xx = (cv2.waitKey(100) & 255)
            # print xx



if __name__ == "__main__":
    #im = displayRMImage("/media/professor/Backup and Data/LEVEL0/Image Level 1A/01012015_Rev32823/2-TH_CAT_150101043224195_1_1M_S972268_Rev32823_01Jan2014/TH_CAT_150101043224195_1/IMAGERY.TIF",win_name="img1")
    #im = displayRMImage("/media/professor/Backup and Data/LEVEL0/Image Level 0/2015-01-02_REV32837/THEOS_1_LEVEL0_1_111032837_32837_MS_PB_TOP_2_8_2015-01-02_03-26-33/TS1_2015002_32837_008_ms.tif", win_name="image1")
    #im = displayRMImage("/media/professor/Backup and Data/LEVEL0/Image Level 1A/02012015_Rev32837/6-TH_CAT_150102050901960_1_1M_S972591_Rev32837_02Jan2015/TH_CAT_150102050901960_1/IMAGERY.TIF", win_name="image1")
    #im = displayRMImage("/media/professor/Backup and Data/LEVEL0/Image Level 0/2015-01-01_REV32823/THEOS_1_LEVEL0_1_111032823_32823_MS_PB_TOP_2_8_2015-01-01_03-45-17/TS1_2015001_32823_008_ms.tif",win_name="img2")
    #im1 = displayRMImage("/media/professor/Backup and Data/LEVEL0/Image Level 0/2015-01-01_REV32823/THEOS_1_LEVEL0_1_111032823_32823_PAN_PB_TOP_1_7_2015-01-01_03-45-16/TS1_2015001_32823_007_PANout.tif",win_name="img1")
    im1 = displayRMImage(r"D:\Data2APanSharpen\2016-05-27\field error\THEOS_1_LEVEL0_1_111039919_39919_MS_PB_TOP_2_6_2016-05-15_03-34-46\GERALD\output\IMAGERY.tif",win_name="img1")
    #im.displayWhole([1,2,3],scale=20)
    im1.band_list = [1,2 ,3]
    im1.start()

    #im2.band_list = [1,1,1 ]
    #im2.scale = 50
    #im2.start()


