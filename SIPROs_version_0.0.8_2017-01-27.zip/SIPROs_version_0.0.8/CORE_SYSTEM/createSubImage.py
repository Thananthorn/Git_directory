from osgeo import gdal
import numpy as np
import cv2
import utm
from osgeo import osr

if __name__ == "__main__":
    lat, lon  = 8.997443, 99.550554

    fn =r"D:\Data2APanSharpen\StrechImage\Product\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51_dem_globe_scene2\old_product\TH_CAT_160511081330552_1\IMAGERY.tif"
    #fn = r"D:\Data2APanSharpen\2016-05-27\Tested Images\revolution_39848_new\old_product\TH_CAT_160511081330552_1\IMAGERY.tif"
    #fn = r"D:\Data2APanSharpen\2016-05-27\bridge error\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\GERALD\info\TS1_2016131_39848_022__dem.tif"
    outfn = r"D:\Data2APanSharpen\StrechImage\GERALD\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\output\cloudOrg.tif"
    im = gdal.Open(fn)
    geot = im.GetGeoTransform()

    #fn = r"D:\Data2APanSharpen\2016-05-27\bridge error\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\GERALD\info\TS1_2016131_39848_022__dem.tif"
    #outfn = r"D:\Data2APanSharpen\2016-05-27\bridge error\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\GERALD\demfarm.tif"
    #im = gdal.Open(fn)
    nbands = im.RasterCount
    size = 6532-6130,5243-4320
    if nbands == 4:
        data = np.zeros((size[0],size[1],3),'uint8')
        x,y,t1,t1 = utm.from_latlon(lat,lon)
        row = 6130 #int((y-geot[3])/geot[5])
        col = 4320 #int((x-geot[0])/geot[1])

        for band in range(3):
            bd = im.GetRasterBand(band+1)
            data[:,:,2-band] = bd.ReadAsArray(col-size[1]/2,row-size[0]/2,size[1],size[0])
        out = cv2.resize(data,(1024,1024),interpolation=cv2.INTER_NEAREST)
        cv2.imwrite(outfn,out)
    else:
        data = np.zeros((256,256),'float32')
        x,y,t1,t1 = utm.from_latlon(lat,lon)
        row = int((y-geot[3])/geot[5])
        col = int((x-geot[0])/geot[1])
        bd = im.GetRasterBand(1)
        data[:,:] = bd.ReadAsArray(col-128,row-128,256,256)
        out = cv2.resize(data,(1024,1024),interpolation=cv2.INTER_NEAREST)/2.0
        out = out.astype('uint8')
        cv2.imwrite(outfn,out)
        print data[128-5:128+5,128-5:128+5]