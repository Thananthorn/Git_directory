from osgeo import gdal
import cv2
import numpy as np
def makeRGB(theos_file,rgb_file):
    im = gdal.Open(theos_file)
    width = im.RasterXSize
    height = im.RasterYSize
    imout = np.zeros((height,width,3),'uint8')
    rgb = [0, 1 ,2]
    cnt = 0
    for band in [1,2,3]:

        im_band = im.GetRasterBand(band)
        im_data = im_band.ReadAsArray()
        imout[:,:,rgb[cnt]] = im_data
        cnt += 1

    cv2.imwrite(rgb_file,imout)


if __name__ == "__main__":
    theos_fil = r"D:\THEOS_37591_CASE_city\GEARL_PAN\info_sharpen\remap.tif"
    out_file = r"D:\THEOS_37591_CASE_city\GEARL_PAN\info_sharpen\rgb_remap.tif"
    makeRGB(theos_fil,out_file)
