"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import numpy as np

class nutation2000b:

    def __init__(self,jdtime):
        table = np.array([ [ 0, 0, 0, 0,1,
                    -172064161.0, -174666.0, 33386.0, 92052331.0, 9086.0, 15377.0],
                    [ 0, 0, 2,-2,2,
                    -13170906.0, -1675.0, -13696.0, 5730336.0, -3015.0, -4587.0],
                    [ 0, 0, 2, 0,2,-2276413.0,-234.0, 2796.0, 978459.0,-485.0,1374.0],
                    [ 0, 0, 0, 0,2,2074554.0,  207.0, -698.0,-897492.0, 470.0,-291.0],
                    [ 0, 1, 0, 0,0,1475877.0,-3633.0,11817.0, 73871.0,-184.0,-1924.0],
                    [ 0, 1, 2,-2,2,-516821.0, 1226.0, -524.0, 224386.0,-677.0,-174.0],
                    [ 1, 0, 0, 0,0, 711159.0,   73.0, -872.0,  -6750.0,   0.0, 358.0],
                    [ 0, 0, 2, 0,1,-387298.0, -367.0,  380.0, 200728.0,  18.0, 318.0],
                    [ 1, 0, 2, 0,2,-301461.0,  -36.0,  816.0, 129025.0, -63.0, 367.0],
                    [ 0,-1, 2,-2,2, 215829.0, -494.0,  111.0, -95929.0, 299.0, 132.0],
                    [ 0, 0, 2,-2,1, 128227.0,  137.0,  181.0, -68982.0,  -9.0,  39.0],
                    [-1, 0, 2, 0,2, 123457.0,   11.0,   19.0, -53311.0,  32.0,  -4.0],
                    [-1, 0, 0, 2,0, 156994.0,   10.0, -168.0,  -1235.0,   0.0,  82.0],
                    [ 1, 0, 0, 0,1,  63110.0,   63.0,   27.0, -33228.0,   0.0,  -9.0],
                    [-1, 0, 0, 0,1, -57976.0,  -63.0, -189.0,  31429.0,   0.0, -75.0],
                    [-1, 0, 2, 2,2, -59641.0,  -11.0,  149.0,  25543.0, -11.0,  66.0],
                    [ 1, 0, 2, 0,1, -51613.0,  -42.0,  129.0,  26366.0,   0.0,  78.0],
                    [-2, 0, 2, 0,1,  45893.0,   50.0,   31.0, -24236.0, -10.0,  20.0],
                    [ 0, 0, 0, 2,0,  63384.0,   11.0, -150.0,  -1220.0,   0.0,  29.0],
                    [ 0, 0, 2, 2,2, -38571.0,   -1.0,  158.0,  16452.0, -11.0,  68.0],
                    [ 0,-2, 2,-2,2,  32481.0,    0.0,    0.0, -13870.0,   0.0,   0.0],
                    [-2, 0, 0, 2,0, -47722.0,    0.0,  -18.0,    477.0,   0.0, -25.0],
                    [ 2, 0, 2, 0,2, -31046.0,   -1.0,  131.0,  13238.0, -11.0,  59.0],
                    [ 1, 0, 2,-2,2,  28593.0,    0.0,   -1.0, -12338.0,  10.0,  -3.0],
                    [-1, 0, 2, 0,1,  20441.0,   21.0,   10.0, -10758.0,   0.0,  -3.0],
                    [ 2, 0, 0, 0,0,  29243.0,    0.0,  -74.0,   -609.0,   0.0,  13.0],
                    [ 0, 0, 2, 0,0,  25887.0,    0.0,  -66.0,   -550.0,   0.0,  11.0],
                    [ 0, 1, 0, 0,1, -14053.0,  -25.0,   79.0,   8551.0,  -2.0, -45.0],
                    [-1, 0, 0, 2,1,  15164.0,   10.0,   11.0,  -8001.0,   0.0,  -1.0],
                    [ 0, 2, 2,-2,2, -15794.0,   72.0,  -16.0,   6850.0, -42.0,  -5.0],
                    [ 0, 0,-2, 2,0,  21783.0,    0.0,   13.0,   -167.0,   0.0,  13.0],
                    [ 1, 0, 0,-2,1, -12873.0,  -10.0,  -37.0,   6953.0,   0.0, -14.0],
                    [ 0,-1, 0, 0,1, -12654.0,   11.0,   63.0,   6415.0,   0.0,  26.0],
                    [-1, 0, 2, 2,1, -10204.0,    0.0,   25.0,   5222.0,   0.0,  15.0],
                    [ 0, 2, 0, 0,0,  16707.0,  -85.0,  -10.0,    168.0,  -1.0,  10.0],
                    [ 1, 0, 2, 2,2,  -7691.0,    0.0,   44.0,   3268.0,   0.0,  19.0],
                    [-2, 0, 2, 0,0, -11024.0,    0.0,  -14.0,    104.0,   0.0,   2.0],
                    [ 0, 1, 2, 0,2,   7566.0,  -21.0,  -11.0,  -3250.0,   0.0,  -5.0],
                    [ 0, 0, 2, 2,1,  -6637.0,  -11.0,   25.0,   3353.0,   0.0,  14.0],
                    [ 0,-1, 2, 0,2,  -7141.0,   21.0,    8.0,   3070.0,   0.0,   4.0],
                    [ 0, 0, 0, 2,1,  -6302.0,  -11.0,    2.0,   3272.0,   0.0,   4.0],
                    [ 1, 0, 2,-2,1,   5800.0,   10.0,    2.0,  -3045.0,   0.0,  -1.0],
                    [ 2, 0, 2,-2,2,   6443.0,    0.0,   -7.0,  -2768.0,   0.0,  -4.0],
                    [-2, 0, 0, 2,1,  -5774.0,  -11.0,  -15.0,   3041.0,   0.0,  -5.0],
                    [ 2, 0, 2, 0,1,  -5350.0,    0.0,   21.0,   2695.0,   0.0,  12.0],
                    [ 0,-1, 2,-2,1,  -4752.0,  -11.0,   -3.0,   2719.0,   0.0,  -3.0],
                    [ 0, 0, 0,-2,1,  -4940.0,  -11.0,  -21.0,   2720.0,   0.0,  -9.0],
                    [-1,-1, 0, 2,0,   7350.0,    0.0,   -8.0,    -51.0,   0.0,   4.0],
                    [ 2, 0, 0,-2,1,   4065.0,    0.0,    6.0,  -2206.0,   0.0,   1.0],
                    [ 1, 0, 0, 2,0,   6579.0,    0.0,  -24.0,   -199.0,   0.0,   2.0],
                    [ 0, 1, 2,-2,1,   3579.0,    0.0,    5.0,  -1900.0,   0.0,   1.0],
                    [ 1,-1, 0, 0,0,   4725.0,    0.0,   -6.0,    -41.0,   0.0,   3.0],
                    [-2, 0, 2, 0,2,  -3075.0,    0.0,   -2.0,   1313.0,   0.0,  -1.0],
                    [ 3, 0, 2, 0,2,  -2904.0,    0.0,   15.0,   1233.0,   0.0,   7.0],
                    [ 0,-1, 0, 2,0,   4348.0,    0.0,  -10.0,    -81.0,   0.0,   2.0],
                    [ 1,-1, 2, 0,2,  -2878.0,    0.0,    8.0,   1232.0,   0.0,   4.0],
                    [ 0, 0, 0, 1,0,  -4230.0,    0.0,    5.0,    -20.0,   0.0,  -2.0],
                    [-1,-1, 2, 2,2,  -2819.0,    0.0,    7.0,   1207.0,   0.0,   3.0],
                    [-1, 0, 2, 0,0,  -4056.0,    0.0,    5.0,     40.0,   0.0,  -2.0],
                    [ 0,-1, 2, 2,2,  -2647.0,    0.0,   11.0,   1129.0,   0.0,   5.0],
                    [-2, 0, 0, 0,1,  -2294.0,    0.0,  -10.0,   1266.0,   0.0,  -4.0],
                    [ 1, 1, 2, 0,2,   2481.0,    0.0,   -7.0,  -1062.0,   0.0,  -3.0],
                    [ 2, 0, 0, 0,1,   2179.0,    0.0,   -2.0,  -1129.0,   0.0,  -2.0],
                    [-1, 1, 0, 1,0,   3276.0,    0.0,    1.0,     -9.0,   0.0,   0.0],
                    [ 1, 1, 0, 0,0,  -3389.0,    0.0,    5.0,     35.0,   0.0,  -2.0],
                    [ 1, 0, 2, 0,0,   3339.0,    0.0,  -13.0,   -107.0,   0.0,   1.0],
                    [-1, 0, 2,-2,1,  -1987.0,    0.0,   -6.0,   1073.0,   0.0,  -2.0],
                    [ 1, 0, 0, 0,2,  -1981.0,    0.0,    0.0,    854.0,   0.0,   0.0],
                    [-1, 0, 0, 1,0,   4026.0,    0.0, -353.0,   -553.0,   0.0,-139.0],
                    [ 0, 0, 2, 1,2,   1660.0,    0.0,   -5.0,   -710.0,   0.0,  -2.0],
                    [-1, 0, 2, 4,2,  -1521.0,    0.0,    9.0,    647.0,   0.0,   4.0],
                    [-1, 1, 0, 1,1,   1314.0,    0.0,    0.0,   -700.0,   0.0,   0.0],
                    [ 0,-2, 2,-2,1,  -1283.0,    0.0,    0.0,    672.0,   0.0,   0.0],
                    [ 1, 0, 2, 2,1,  -1331.0,    0.0,    8.0,    663.0,   0.0,   4.0],
                    [-2, 0, 2, 2,2,   1383.0,    0.0,   -2.0,   -594.0,   0.0,  -2.0],
                    [-1, 0, 0, 0,2,   1405.0,    0.0,    4.0,   -610.0,   0.0,   2.0],
                    [ 1, 1, 2,-2,2,   1290.0,    0.0,    0.0,   -556.0,   0.0,   0.0]])
        DJC = 36525.0
        DJ00 = 2451545.0
        TURNAS = 1296000.0
        DAS2R = 4.848136811095359935899141e-6
        D2PI = 6.283185307179586476925287
        U2R = DAS2R / 1e7

        DAS2R = 4.848136811095359935899141e-6
        DMAS2R = (DAS2R / 1e3)
        DPPLAN = -0.135 * DMAS2R
        DEPLAN =  0.388 * DMAS2R
        if np.isscalar(jdtime):
            jdtime = np.array([jdtime])

        t = (jdtime-DJ00)/DJC
        self.t = t.copy()
        PRECOR = -0.29965 * DAS2R
        OBLCOR = -0.02524 * DAS2R
        dpsipr = PRECOR * t;
        depspr = OBLCOR * t;

        self.eps0 = DAS2R * (84381.448  + (-46.8150   +  (-0.00059   + ( 0.001813) * t) * t) * t)

        n_data = t.shape[0]
        n_term = table.shape[0]
        t = t.reshape((1,n_data))
        t = np.repeat(t,n_term,0)

        nl = table[:,0].reshape((n_term,1))
        nl = np.repeat(nl,n_data,1)
        nlp = table[:,1].reshape((n_term,1))
        nlp = np.repeat(nlp,n_data,1)
        nf = table[:,2].reshape((n_term,1))
        nf = np.repeat(nf,n_data,1)
        nd = table[:,3].reshape((n_term,1))
        nd = np.repeat(nd,n_data,1)
        nom = table[:,4].reshape((n_term,1))
        nom = np.repeat(nom,n_data,1)
        ps = table[:,5].reshape((n_term,1))
        ps = np.repeat(ps,n_data,1)
        pst = table[:,6].reshape((n_term,1))
        pst = np.repeat(pst,n_data,1)
        pc = table[:,7].reshape((n_term,1))
        pc = np.repeat(pc,n_data,1)
        ec = table[:,8].reshape((n_term,1))
        ec = np.repeat(ec,n_data,1)
        ect = table[:,9].reshape((n_term,1))
        ect = np.repeat(ect,n_data,1)
        es = table[:,10].reshape((n_term,1))
        es = np.repeat(es,n_data,1)

        el = ((485868.249036 + (1717915923.2178) * t) % TURNAS) * DAS2R

        # Mean anomaly of the Sun. */
        elp = ((1287104.79305 + (129596581.0481) * t)% TURNAS) * DAS2R

        # Mean argument of the latitude of the Moon. *
        f = ((335779.526232 + (1739527262.8478) * t)% TURNAS) * DAS2R

        #Mean elongation of the Moon from the Sun. */
        d = ((1072260.70369 + (1602961601.2090) * t)% TURNAS) * DAS2R


        # Mean longitude of the ascending node of the Moon. */
        om = ((450160.398036 + (-6962890.5431) * t)% TURNAS) * DAS2R
        arg = nl*el+nlp*elp+nf*f+nd*d+nom*om
        arg = arg % D2PI
        sarg = np.sin(arg)
        carg = np.cos(arg)
        dp = (ps + pst * t) * sarg + pc * carg
        de = (ec + ect * t) * carg + es * sarg
        dp = dp.sum(0)
        de = de.sum(0)
        dpsils = dp * U2R
        depsls = de * U2R
        dpsipl = DPPLAN
        depspl = DEPLAN
        self.dpsi = dpsils + dpsipl
        self.deps = depsls + depspl
        self.eps0 += depspr
        self.num_data = n_data
    def getNulMat(self):
        dPsi = self.dpsi
        depsi = self.deps
        epsi_bar = self.eps0
        epsi = depsi + epsi_bar
        cosd = np.cos
        sind = np.sin
        self.C = np.array([[cosd(dPsi), -sind(dPsi)*cosd(epsi_bar), -sind(dPsi)*sind(epsi_bar)],\
                 [cosd(epsi)*sind(dPsi), cosd(epsi)*cosd(dPsi)*cosd(epsi_bar)+sind(epsi)*sind(epsi_bar),\
                  cosd(epsi)*cosd(dPsi)*sind(epsi_bar)-sind(epsi)*cosd(epsi_bar)],\
                  [sind(epsi)*sind(dPsi), sind(epsi)*cosd(dPsi)*cosd(epsi_bar)-cosd(epsi)*sind(epsi_bar),\
                  sind(epsi)*cosd(dPsi)*sind(epsi_bar)+cosd(epsi)*cosd(epsi_bar)]])
        if self.num_data == 1:
            return self.C.reshape((3,3))
        else:
            return self.C
    def Rz(self,theta,rbw):
        s = np.sin(theta)
        c = np.cos(theta)

        a00 =   c*rbw[0,0,:] + s*rbw[1,0,:]
        a01 =   c*rbw[0,1,:] + s*rbw[1,1,:]
        a02 =   c*rbw[0,2,:] + s*rbw[1,2,:]
        a10 = - s*rbw[0,0,:] + c*rbw[1,0,:]
        a11 = - s*rbw[0,1,:] + c*rbw[1,1,:]
        a12 = - s*rbw[0,2,:] + c*rbw[1,2,:]

        rbw[0,0,:] = a00
        rbw[0,1,:] = a01
        rbw[0,2,:] = a02
        rbw[1,0,:] = a10
        rbw[1,1,:] = a11
        rbw[1,2,:] = a12
        rbwout = rbw.copy()
        return rbwout
    def Ry(self,theta,r):

        s = np.sin(theta)
        c = np.cos(theta)

        a00 = c*r[0,0,:] - s*r[2,0,:]
        a01 = c*r[0,1,:] - s*r[2,1,:]
        a02 = c*r[0,2,:] - s*r[2,2,:]
        a20 = s*r[0,0,:] + c*r[2,0,:]
        a21 = s*r[0,1,:] + c*r[2,1,:]
        a22 = s*r[0,2,:] + c*r[2,2,:]

        r[0,0,:] = a00
        r[0,1,:] = a01
        r[0,2,:] = a02
        r[2,0,:] = a20
        r[2,1,:] = a21
        r[2,2,:] = a22
        return r.copy()

    def Rx(self,phi,r):

        s = np.sin(phi)
        c = np.cos(phi)

        a10 =   c*r[1,0,:] + s*r[2,0,:]
        a11 =   c*r[1,1,:] + s*r[2,1,:]
        a12 =   c*r[1,2,:] + s*r[2,2,:]
        a20 = - s*r[1,0,:] + c*r[2,0,:]
        a21 = - s*r[1,1,:] + c*r[2,1,:]
        a22 = - s*r[1,2,:] + c*r[2,2,:]

        r[1,0,:] = a10
        r[1,1,:] = a11
        r[1,2,:] = a12
        r[2,0,:] = a20
        r[2,1,:] = a21
        r[2,2,:] = a22
        return r.copy()

    def getprecsssionMatrix(self):
        DAS2R = 4.848136811095359935899141e-6
        EPS0 = 84381.448 * DAS2R
        t = self.t
        # Frame bias. */
        DPBIAS = -0.041775  * DAS2R
        DEBIAS = -0.0068192 * DAS2R

        #/* The ICRS RA of the J2000.0 equinox (Chapront et al., 2002) */
        DRA0 = -0.0146 * DAS2R
        dpsibi = DPBIAS
        depsbi = DEBIAS
        dra0 = DRA0
        #/* Precession angles (Lieske et al. 1977) */
        psia77 = (5038.7784 + (-1.07259 + (-0.001147) * t) * t) * t * DAS2R
        oma77  =  EPS0 + ((0.05127 + (-0.007726) * t) * t) * t * DAS2R
        chia   = (  10.5526 + (-2.38064 + (-0.001125) * t) * t) * t * DAS2R

        #/* Precession and obliquity corrections (radians per century) */
        PRECOR = -0.29965 * DAS2R
        OBLCOR = -0.02524 * DAS2R
        #/* Precession rate contributions with respect to IAU 1976/80. */
        dpsipr = PRECOR * t
        depspr = OBLCOR * t
        psia = psia77 + dpsipr
        oma  = oma77  + depspr
        rbw = np.zeros((3,3,self.num_data))
        rbw[0,0,:]=1.0
        rbw[1,1,:]=1.0
        rbw[2,2,:]=1.0
        rbw =self.Rz(dra0,rbw)
        rbw= self.Ry(dpsibi*np.sin(EPS0), rbw)
        rbw = self.Rx(-depsbi, rbw)
        rb = rbw.copy()
        rp = np.zeros((3,3,self.num_data))
        rp[0,0,:]=1.0
        rp[1,1,:]=1.0
        rp[2,2,:]=1.0
        rp = self.Rx(EPS0, rp)
        rp = self.Rz(-psia, rp)
        rp = self.Rx(-oma, rp)
        rp = self.Rz(chia, rp)
        rbp = np.zeros((3,3,self.num_data))
        for k in range(3):
            for m in range(3):
                rbp[k,m,:]= (rp[k,:,:]*rbw[:,m,:]).sum(0)
        if self.num_data == 1:
            return rbp.reshape((3,3))
        else:
            return rbp








if __name__ =="__main__":
    JD = np.array([2457364.06375,2457364.06375])
    nt = nutation2000b(JD)
    C = nt.getNulMat()
    D = nt.getprecsssionMatrix()
    print nt