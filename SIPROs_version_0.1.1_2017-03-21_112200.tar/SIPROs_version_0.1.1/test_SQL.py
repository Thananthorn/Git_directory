import MySQLdb

# Open database connection
db = MySQLdb.connect("localhost","root","P@ssw0rdgistda" , "CUF_information" )

# prepare a cursor object using cursor() method
cursor = db.cursor()
#cursor.execute("CREATE table CUF_DATA (ID int(2) NOT NULL auto_increment , Revolution text(7) , spectralMode text(5) , PRIMARY KEY (ID));")

# execute SQL query using execute() method.

db.query("""INSERT INTO CUF_DATA (Revolution , spectralMode) value ("42135" , " MS  ")""")
db.query("""INSERT INTO CUF_DATA (Revolution , spectralMode) value ("42135" , " PAN ")""")


cursor.execute("SELECT * FROM CUF_DATA")
# Fetch a single row using fetchone() method.

for row in cursor.fetchall():
    print "| %s | %s | %s |"%(row[0] , row[1] ,row[2]) 

# disconnect from server
db.close()