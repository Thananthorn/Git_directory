"""/------------------------------------------------------------------------------------------------------------------------------------------------------------------------ 
This script have 4 library
1. sys or know as System-specific parameters and function. This module provides access to some variables used or maintained by 
   the interpreter and to functions that interact strongly with the interpreter.
2. numpy it is library about calculate and numerical methods for engineering or science methods it import bypass in script as [np] .
3. os or know as Miscellaneous operating system interfaces. This module provides a portable way of using operating system dependent functionality.
4. traceback is module provides a standard interface to extract. I use this for check error of function or script.
----------------------------------------------------------------------------------------------------------------------------------------------------------------------/"""

import os
import sys
import traceback 
import numpy as np

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
"""/------------------------------------------------------------------------------------------------------------------------------------------------------------------------
comparecufandcpf function is methods to get CPF file from CPF directory for use in product process and extract gerald 
to make this function work you have to give 3 thing to it.
A. [Image_date] This valiable is date of satellite take image value.
B. [cpf_file_keep_directory] This valiable is path where you keep CPF files.
C. [cpf_index_directory] This valiable is path to keep index files create by function.

[validity_name] = globals valiable use for create mutivaliable from loop.
[validity_name_list] = list to get index filename.

Use for loop to read path of CPF files in cpf_file_keep_directory and create index file by use validity date in CPF file for save CPF 
full path and CPF filename.

[cpf_file_count] = count of index files.
[date_value] = [Image_date]

Use for loop to check condition in length of [cpf_file_count].

Set condition.
If count != (cpf_file_count - 1)  mean not last index files.
Set condition by use [date_value].
If [date_value] more than or equal validity_name[i] and less than validity_name[i + 1].
use value from index filename : validity_name[i].txt {full path of CPF file and CPF file name}.

If count = (cpf_file_count - 1) mean last index file.
Set condition by use [date_value].
If [date_value] more than or equal validity_name[i].
use value from index filename : validity_name[i].txt {full path of CPF file and CPF file name}.

At last this function will return 2 thing.
A. [Pre_calibration_parameter_file] = full path of CPF file.
B. [calibration_parameter_filename] = CPF filename.
------------------------------------------------------------------------------------------------------------------------------------------------------------------------/"""
def comparecufandcpf(Image_date , cpf_file_keep_directory , cpf_index_directory):
	cpf_directory = cpf_file_keep_directory
	cpf_create_index_directory = cpf_index_directory

	validity_name = globals()
	validity_name_list = []

	for cpf_root , cpf_directory , cpf_filename in os.walk(cpf_directory , topdown=False):
		for filename in cpf_filename :
			cpf_path = os.path.abspath(os.path.join(cpf_root , filename))
			validity_start = os.path.basename(cpf_path)
			validity_name["validity_%s" % filename] = cpf_create_index_directory + "/" + validity_start[24:-11] + ".txt"
			validity_file = open(validity_name["validity_%s" % filename] , "w")
			validity_file.write(str(cpf_path))
			validity_file.write("\n" + str(validity_start))
			validity_file.close()
			validity_name_list.append(validity_start[24:-11])
			validity_name_list.sort()

	cpf_file_count = len(validity_name_list)
	date_value = int(Image_date)

	for i in range(0, cpf_file_count):
		if i != (cpf_file_count - 1) :
			if (date_value >= int(validity_name_list[i])) and (date_value < int(validity_name_list[(i + 1)])):
				index_filename = cpf_create_index_directory + "/" + validity_name_list[i] + ".txt"
				index_file = open(index_filename , "r")
				read_value_list = []
				for j in range (2):
					pre_read_value = index_file.readline()
					read_value = pre_read_value.strip("\n")
					read_value_list.append(read_value)
				index_file.close()
				Pre_calibration_parameter_file = read_value_list[0]
				calibration_parameter_filename = read_value_list[1]
 				print "date_value : %s\n" % date_value , "use cpf : %s\n" % Pre_calibration_parameter_file, "cpf name : %s" % calibration_parameter_filename

		elif i == (cpf_file_count - 1) :
			if (date_value >= int(validity_name_list[i])) :
				index_filename = cpf_create_index_directory + "/" + validity_name_list[i] + ".txt"
				index_file = open(index_filename , "r")
				read_value_list = []
				for j in range (2):
					pre_read_value = index_file.readline()
					read_value = pre_read_value.strip("\n")
					read_value_list.append(read_value)
				index_file.close()
				Pre_calibration_parameter_file = read_value_list[0]
				calibration_parameter_filename = read_value_list[1]
 				print "date_value : %s\n" % date_value , "use cpf : %s\n" % Pre_calibration_parameter_file, "cpf name : %s" % calibration_parameter_filename

	return Pre_calibration_parameter_file , calibration_parameter_filename
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
if __name__ == '__main__':
	Image_date = "20161213"
	cpf_file_keep_directory = "C:/Worker/Support-Worker/Sipros_system/CPF_PROCESSING/CPF_FILE"
	cpf_index_directory = "C:/Worker/Support-Worker/Sipros_system/CPF_PROCESSING/CPF_INDEX"
	try:
		comparecufandcpf(Image_date , cpf_file_keep_directory , cpf_index_directory)
	except:
		print traceback.format_exc()
