"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

 """

import platform

if platform.system() == "Windows":
    from osgeo import gdal, osr, ogr
else:
    import gdal

import numpy as np
import xml.etree.ElementTree as ET
import locationutil as util
import dutil
import cv2
import determine_pixel_shift as dps
import utmLatlon
import os
from commomTools import readDataBand, findSamplesPoints, remapImageBandGridMethod
from systemConstants import LV1_2ProductionConstants as lv1constants





def buildMSImageUsingCubicInterpolation(out_file_name, in_file_name, lines, current_date, utc_gps, dut1,dem,
                                        dem_interpolation_method, gain, dark_curr, start_sample=1,im_width = 6000,im_height = 6000):

    process_box = lv1constants.MS_SAMPLE_PROCESS_BOX_SIZE
    step = lv1constants.MS_SAMPLE_GRID_STEP
    offsetm = lv1constants.LOADOFFSET
    block_size = im_width



    lines[0] = lines[0] - 1
    lines[1] = lines[1] - 1
    lines[2] = lines[2] - 1
    lines[3] = lines[3] - 1
    end_sample =start_sample + im_width-1
    if (end_sample > lv1constants.MS_MAX_WIDTH) or (start_sample<1) :
        print "The intended sample is beyond the scope of the recorded GER file."
    samples = np.arange(start_sample, start_sample + im_width)

    posB1 = np.loadtxt(in_file_name + "B1.pos")
    posB2 = np.loadtxt(in_file_name + "B2.pos")
    posB3f = np.loadtxt(in_file_name + "B3.pos")
    posB4 = np.loadtxt(in_file_name + "B4.pos")
    sat_pos = [posB1,posB2, posB3f, posB4]

    timeB1 = np.loadtxt(in_file_name + "B1.tim")
    timeB2 = np.loadtxt(in_file_name + "B2.tim")
    timeB3f = np.loadtxt(in_file_name + "B3.tim")
    timeB4 = np.loadtxt(in_file_name + "B4.tim")

    sat_time = [timeB1, timeB2, timeB3f, timeB4]

    attB1 = np.loadtxt(in_file_name + "B1.att")
    attB2 = np.loadtxt(in_file_name + "B2.att")
    attB3f = np.loadtxt(in_file_name + "B3.att")
    attB4 = np.loadtxt(in_file_name + "B4.att")
    sat_att = [attB1, attB2, attB3f, attB4]

    band1 = gdal.Open(in_file_name + "B1.tif")
    band2 = gdal.Open(in_file_name + "B2.tif")
    band3 = gdal.Open(in_file_name + "B3.tif")
    band4 = gdal.Open(in_file_name + "B4.tif")
    data_height = band1.RasterYSize


    # Find the shift function using the middle line
    mid_line = im_height/2
    mid_sample = start_sample + im_width/2
    # Building the transformation polynomial





    # find approprite line offset
    # consider only the first and last lines.

    print "finding the corresponding pixels among image bands"

    max_width = im_width

    offset_min1 = max(-offsetm,0-lines[0])
    offset_max1 = min(offsetm,data_height-lines[0]-im_height)

    offset_min2 = max(-offsetm, 0 - lines[1])
    offset_max2 = min(offsetm, data_height - lines[1] - im_height)

    offset_min3 = max(-offsetm, 0 - lines[3])
    offset_max3 = min(offsetm, data_height - lines[2] - im_height)

    offset_min4 = max(-offsetm, 0 - lines[3])
    offset_max4 = min(offsetm, data_height - lines[3] - im_height)

    gain_number = np.loadtxt(in_file_name + "B1.gain")
    databand1 = readDataBand(band1, 0, lines[0]  + offset_min1, max_width, offset_max1 - offset_min1 + im_height,
                             gain[0], dark_curr[0], gain_number, im_type="MS")
    # band1.ReadAsArray(0, lines[0] -1 + offset_min1, max_width, offset_max1 - offset_min1 + im_height)
    gain_number = np.loadtxt(in_file_name + "B2.gain")
    databand2 = readDataBand(band2, 0, lines[1]  + offset_min2, max_width, offset_max2 - offset_min2 + im_height,
                             gain[1], dark_curr[1], gain_number,
                             im_type="MS")  # band2.ReadAsArray(0, lines[1] -1 + offset_min2, max_width, offset_max2 - offset_min2 + im_height)
    gain_number = np.loadtxt(in_file_name + "B3.gain")
    databand3 = readDataBand(band3, 0, lines[2] , max_width, im_height,
                             gain[2], dark_curr[2], gain_number,
                             im_type="MS")  # band3.ReadAsArray(0, lines[2] -1, max_width, im_height)
    gain_number = np.loadtxt(in_file_name + "B4.gain")
    databand4 = readDataBand(band4, 0, lines[3]  + offset_min4, max_width, offset_max4 - offset_min4 + im_height,
                             gain[3], dark_curr[3], gain_number, im_type="MS")
    image_data = [databand1, databand2, databand3, databand4]
    offset_mins = [offset_min1, offset_min2, offset_min3, offset_min4]
    print "Find the initial shift at the middle of an image (%d,%d)" % (mid_sample, mid_line)

    print "Find the corresponding points between bands!!"
    all_file_exist = True
    for band in [1,2,3,4]:
        all_file_exist &= os.path.isfile(in_file_name + "x_b%d_LINE_%d.txt" % (band,lines[2]+1))
        all_file_exist &= os.path.isfile(in_file_name + "y_b%d_LINE_%d.txt" % (band, lines[2] + 1))
    if not all_file_exist :

        x1, x2, x3, x4, y1, y2, y3, y4 = findSamplesPoints(in_file_name, step, lines,sat_pos, sat_time, sat_att,
                                                           image_data,offset_mins, current_date,  utc_gps, dut1,
                                                           dem, dem_interpolation_method, im_width, im_height,
                                                           precision_error = lv1constants.MS_PRECISION,
                                                           max_percision_error = lv1constants.MS_MAX_PRECISION,
                                                           process_box = process_box, im_register= False)
        np.savetxt(in_file_name + "x_b1_LINE_%d.txt" % (lines[2]+1), x1)
        np.savetxt(in_file_name + "x_b2_LINE_%d.txt" % (lines[2]+1), x2)
        np.savetxt(in_file_name + "x_b3_LINE_%d.txt" % (lines[2]+1), x3)
        np.savetxt(in_file_name + "x_b4_LINE_%d.txt" % (lines[2]+1), x4)

        np.savetxt(in_file_name + "y_b1_LINE_%d.txt" % (lines[2]+1), y1)
        np.savetxt(in_file_name + "y_b2_LINE_%d.txt" % (lines[2]+1), y2)
        np.savetxt(in_file_name + "y_b3_LINE_%d.txt" % (lines[2]+1), y3)
        np.savetxt(in_file_name + "y_b4_LINE_%d.txt" % (lines[2]+1), y4)
    else:
        x1 = np.loadtxt(in_file_name + "x_b1_LINE_%d.txt" % (lines[2] + 1))
        x2 = np.loadtxt(in_file_name + "x_b2_LINE_%d.txt" % (lines[2] + 1))
        x3 = np.loadtxt(in_file_name + "x_b3_LINE_%d.txt" % (lines[2] + 1))
        x4 = np.loadtxt(in_file_name + "x_b4_LINE_%d.txt" % (lines[2] + 1))

        y1 = np.loadtxt(in_file_name + "y_b1_LINE_%d.txt" % (lines[2] + 1))
        y2 = np.loadtxt(in_file_name + "y_b2_LINE_%d.txt" % (lines[2] + 1))
        y3 = np.loadtxt(in_file_name + "y_b3_LINE_%d.txt" % (lines[2] + 1))
        y4 = np.loadtxt(in_file_name + "y_b4_LINE_%d.txt" % (lines[2] + 1))
    szx = im_width/step
    szy = im_height / step
    x1t = np.zeros((szy, szx))
    x2t = np.zeros((szy, szx))
    x3t = np.zeros((szy, szx))
    x4t = np.zeros((szy, szx))

    y1t = np.zeros((szy, szx))
    y2t = np.zeros((szy, szx))
    y3t = np.zeros((szy, szx))
    y4t = np.zeros((szy, szx))
    process_box2 = process_box/step
    for col in range(0, im_width, process_box):
        for row in range(0, im_height, process_box):
            rowmax = row + process_box
            colmax = col + process_box
            idx = np.nonzero((x3>=col)*(x3<colmax)*(y3>=row)*(y3<rowmax))
            row2= row/step
            rowmax2  = rowmax/step
            col2 = col/step
            colmax2 = colmax/step
            x1t[row2:rowmax2, col2:colmax2] = x1[idx].reshape((process_box2, process_box2))
            y1t[row2:rowmax2, col2 :colmax2] = y1[idx].reshape((process_box2, process_box2))

            x2t[row2:rowmax2, col2 :colmax2] = x2[idx].reshape((process_box2, process_box2))
            y2t[row2:rowmax2, col2 :colmax2] = y2[idx].reshape((process_box2, process_box2))

            x3t[row2:rowmax2, col2 :colmax2] = x3[idx].reshape((process_box2, process_box2))
            y3t[row2:rowmax2, col2 :colmax2] = y3[idx].reshape((process_box2, process_box2))

            x4t[row2:rowmax2, col2 :colmax2] = x4[idx].reshape((process_box2, process_box2))
            y4t[row2:rowmax2, col2 :colmax2] = y4[idx].reshape((process_box2, process_box2))

    x1 = x1t.flatten()
    x2 = x2t.flatten()
    x3 = x3t.flatten()
    x4 = x4t.flatten()

    y1 = y1t.flatten()
    y2 = y2t.flatten()
    y3 = y3t.flatten()
    y4 = y4t.flatten()


    mask = np.ones((im_height, im_width),'uint8')
    gtiffDriver = gdal.GetDriverByName('GTiff')
    dst_ds = gtiffDriver.Create(out_file_name, im_width, im_height, 4, gdal.GDT_Byte)
    ms_b1 = dst_ds.GetRasterBand(3)
    ms_b2 = dst_ds.GetRasterBand(2)
    ms_b3 = dst_ds.GetRasterBand(1)
    ms_b4 = dst_ds.GetRasterBand(4)
    u1 = np.arange(start_sample-1, im_width).astype('float32')
    v1 = np.arange(0, im_height).astype('float32')
    u,v = np.meshgrid(u1, v1)
    #u1 = u.flatten()
    #v1 = v.flatten()
    sard_time = np.loadtxt(in_file_name + "B3sadr_times.txt")
    idx = np.nonzero(timeB3f > sard_time[-1])[0]
    if len(idx) > 0:
        line3_max = min(im_height, idx[0]-lines[2])
    else:
        line3_max = im_height



    for band in [1, 2, 3, 4]:


        if band == 1:

            id1 = np.nonzero(timeB1 > sard_time[-1])[0]
            b1h = databand1.shape[0]+offset_min1
            if len(id1) > 0:
                line1_max = min(b1h, id1[0] - lines[0])
            else:
                line1_max = b1h

            idok = np.nonzero((y1<line1_max) * (y3<line3_max))[0]

            xmap,ymap,mask1 = remapImageBandGridMethod(x1[idok], y1[idok], x3[idok], y3[idok], 0, 0, block_size,
                                                       im_width, im_height, offset_min1,
                                                       max_error=lv1constants.REMAP_MAX_ERROR)
            #mask1 = (xmap>0)*(ymap>0)*(xmap<im_width)*(ymap<im_height)
            mask *= mask1
            #databand1 = 1.0*(databand1 < 1.0) + 255.0*(databand1>254.8) + databand1*(databand1 > 1) * (databand1 < 254.8)
            out = cv2.remap(databand1, xmap, ymap, cv2.INTER_CUBIC,  borderMode=cv2.BORDER_CONSTANT,borderValue=0)
            out = lv1constants.MIN_DN * (out < lv1constants.MIN_DN) +\
                  lv1constants.MAX_DN * (out >= lv1constants.MAX_DN) +\
                  out * (out >= lv1constants.MIN_DN)*(out < lv1constants.MAX_DN)
            out = np.round(out).astype('uint8')
            ms_b1.WriteArray(out)
        elif band == 2:

            id2 = np.nonzero(timeB2 > sard_time[-1])[0]
            b2h = databand2.shape[0] + offset_min2
            if len(id2) > 0:
                line2_max = min(b2h, id2[0] - lines[1])
            else:
                line2_max = b2h

            idok = np.nonzero((y2 < line2_max) * (y3 < line3_max))[0]
            xmap, ymap,mask2 = remapImageBandGridMethod(x2[idok], y2[idok], x3[idok], y3[idok], 0, 0, block_size,
                                                        im_width, im_height, offset_min2,
                                                        max_error = lv1constants.REMAP_MAX_ERROR)
            # mask2 = (xmap > 0) * (ymap > 0) * (xmap < im_width) * (ymap < im_height)
            mask *= mask2
            #databand2 = 1.0 * (databand2 < 1.0) + 255.0 * (databand2 > 254.8) + databand2 * (databand2 > 1) * (
            #databand2 <= 254.8)
            out = cv2.remap(databand2, xmap, ymap, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
            out = lv1constants.MIN_DN * (out < lv1constants.MIN_DN) +\
                  lv1constants.MAX_DN * (out >= lv1constants.MAX_DN) +\
                  out * (out >= lv1constants.MIN_DN)*(out < lv1constants.MAX_DN)
            out = np.round(out).astype('uint8')
            ms_b2.WriteArray(out)
        elif band == 3:
            out = databand3[0:im_height, 0:im_width]
            out = lv1constants.MIN_DN * (out < lv1constants.MIN_DN) +\
                  lv1constants.MAX_DN * (out >= lv1constants.MAX_DN) +\
                  out * (out >= lv1constants.MIN_DN)*(out < lv1constants.MAX_DN)
            out = np.round(out).astype('uint8')
            ms_b3.WriteArray(out)
        elif band == 4:

            id4 = np.nonzero(timeB4 > sard_time[-1])[0]
            b4h = databand4.shape[0] + offset_min4
            if len(id4) > 0:
                line4_max = min(b4h, id4[0] - lines[3])
            else:
                line4_max = b4h

            idok = np.nonzero((y2 < line4_max) * (y3 < line3_max))[0]
            xmap, ymap,mask4 = remapImageBandGridMethod(x4[idok], y4[idok], x3[idok], y3[idok], 0, 0, block_size,
                                                        im_width, im_height, offset_min4,
                                                        max_error=lv1constants.REMAP_MAX_ERROR)
            #databand4= 1.0 * (databand4 < 1.0) + 255.0 * (databand4 > 254.8) + databand4 * (databand4 > 1) * (
            #databand4 < 254.8)
            out = cv2.remap(databand4, xmap, ymap, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
            out = lv1constants.MIN_DN * (out < lv1constants.MIN_DN) +\
                  lv1constants.MAX_DN * (out >= lv1constants.MAX_DN) +\
                  out * (out >= lv1constants.MIN_DN)*(out < lv1constants.MAX_DN)
            out = np.round(out).astype('uint8')
            # mask4 = (xmap > 0) * (ymap > 0) * (xmap < im_width) * (ymap < im_height)
            mask *= mask4
            ms_b4.WriteArray(out)
    dst_ds = None
    dst_ds = gdal.Open(out_file_name, gdal.GA_Update)
    for band in [1,2,3,4]:
        ms  = dst_ds.GetRasterBand(band)
        data = ms.ReadAsArray()
        data = data*(mask>0)
        ms.WriteArray(data)




def buildPANImageUsingCubicInterpolation(out_file_name, in_file_name, beg_line, filter2D, gain, dark_curr,
                                         start_sample = 1, im_width = 12000, im_height = 12000):
    max_width = lv1constants.PAN_MAX_WIDTH

    band1 = gdal.Open(in_file_name + ".tif")
    beg_line -= 1
    start_sample -= 1

    gtiffDriver = gdal.GetDriverByName('GTiff')
    dst_ds = gtiffDriver.Create(out_file_name, im_width, im_height, 1, gdal.GDT_Byte)
    pan_b1 = dst_ds.GetRasterBand(1)
    ger_height = band1.RasterYSize

    # load as a block of 1000x1000 overlapped by 100
    gain_number = np.loadtxt(in_file_name +".gain")

    for k in range(0, im_height, lv1constants.PAN_PROCESS_BOX_SIZE):
        for m in range(0, im_width, lv1constants.PAN_PROCESS_BOX_SIZE):
            print "Building block (%d,%d)......" % (k, m)
            y_min = max(0, beg_line + k - lv1constants.PAN_OVERLAP_SIZE)
            x_min = max(0, m - lv1constants.PAN_OVERLAP_SIZE + start_sample)

            x_off_l = start_sample + m - x_min
            y_off_l = beg_line + k - y_min
            x_max = min(max_width, m + lv1constants.PAN_PROCESS_BOX_SIZE + lv1constants.PAN_OVERLAP_SIZE
                        + start_sample)
            y_max = min(ger_height,min(beg_line + im_height + 20, beg_line + k + 1000 + lv1constants.PAN_OVERLAP_SIZE))
            x_off_h = x_max - (m + lv1constants.PAN_PROCESS_BOX_SIZE)+(start_sample-1)
            y_off_h = y_max - (beg_line + lv1constants.PAN_PROCESS_BOX_SIZE + k)
            load_width = x_max - x_min
            load_height = y_max - y_min
            one_block = readDataBand(band1,x_min, y_min, load_width, load_height, gain, dark_curr, gain_number,
                                     im_type= "PAN" )#band1.ReadAsArray(x_min, y_min, load_width, load_height)
            #one_block = np.round((one_block > 0) * (one_block < 255) * one_block + 255 * (one_block >= 255))
            #one_block = one_block.astype('uint8')
            if lv1constants.DENCONVOLUTION:
                summ = cv2.GaussianBlur(one_block.astype('uint8'), lv1constants.PAN_GAUSSIAN_SIZE,
                                        lv1constants.PAN_GAUSSIAN_SIGMA)  # cv2.filter2D(org_image,cv2.CV_32F,kernel, borderType=cv2.BORDER_REFLECT)
                edges = cv2.Canny(summ.astype('uint8'), lv1constants.PAN_CANNY_TH1, lv1constants.PAN_CANNY_TH2,
                                  L2gradient=False)
                edges = cv2.filter2D(edges, cv2.CV_8U, lv1constants.PAN_EDGE_KERNEL)
                summ = cv2.filter2D(one_block, cv2.CV_32F, lv1constants.PAN_SUM_KERNEL, borderType=cv2.BORDER_REFLECT)
                gradient = np.abs(one_block - summ) * (edges > 0)  # np.sqrt(sumsq - (summ) ** 2) #np.abs(gradient) #
                # gradient = cv2.filter2D(gradient,cv2.CV_32F, np.ones((3, 3), 'float32') /9.0, borderType=cv2.BORDER_REFLECT)
                gradient[0, :] = 0
                gradient[1, :] = 0
                gradient[-1, :] = 0
                gradient[-2, :] = 0
                gradient[:, 0] = 0
                gradient[:, 1] = 0
                gradient[:, -1] = 0
                gradient[:, -2] = 0
                my_filter_im = np.zeros_like(one_block).astype('float32')
                idx, idy = np.nonzero(gradient < lv1constants.PAN_TH1)
                my_filter_im[idx, idy] = one_block[idx, idy]
                idx, idy = np.nonzero((gradient >= lv1constants.PAN_TH1) * (gradient < lv1constants.PAN_TH2))
                tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[3], borderType=cv2.BORDER_REFLECT)
                my_filter_im[idx, idy] = tem[idx, idy]
                idx, idy = np.nonzero((gradient >= lv1constants.PAN_TH2) * (gradient < lv1constants.PAN_TH3))
                tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[4], borderType=cv2.BORDER_REFLECT)
                my_filter_im[idx, idy] = tem[idx, idy]
                idx, idy = np.nonzero((gradient >= lv1constants.PAN_TH3) * (gradient < lv1constants.PAN_TH4))
                tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[5], borderType=cv2.BORDER_REFLECT)
                my_filter_im[idx, idy] = tem[idx, idy]
                idx, idy = np.nonzero((gradient >= lv1constants.PAN_TH4))
                tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[6], borderType=cv2.BORDER_REFLECT)
                my_filter_im[idx, idy] = tem[idx, idy]
                filtered_im = np.round((my_filter_im > lv1constants.MIN_DN) * (my_filter_im < lv1constants.MAX_DN) * my_filter_im
                                       + lv1constants.MAX_DN * (my_filter_im >= lv1constants.MAX_DN))
            else:
                filtered_im = np.round(
                    (one_block > 0) * (one_block < 255) * one_block+ 255 * (one_block >= 255))

            #filtered_im = cv2.filter2D(one_block, cv2.CV_8UC1, filter2D)
            used_ar = filtered_im[y_off_l:y_off_l + lv1constants.PAN_PROCESS_BOX_SIZE,
                      x_off_l:x_off_l + lv1constants.PAN_PROCESS_BOX_SIZE].astype('uint8')

            pan_b1.WriteArray(used_ar, m, k)




if __name__ == "__main__":
    # cpf_file =  "/media/professor/Data and Backup/LEVEL0/CPF file/CPF_20110106_Delta_UT/THEOS_1_20110104_000000_20110106_000000.CPF"
    # cpf_file = r"D:\level1A_development\GER\THEOS_1_20150915_000000_20150917_000000.CPF"
    # gp,dp = readGainsAndDarkCurrent(cpf_file,"PAN", 6)
    # g1, d1 = readGainsAndDarkCurrent(cpf_file,1,5)
    # g2, d2 = readGainsAndDarkCurrent(cpf_file,2,5)
    # g3, d3 = readGainsAndDarkCurrent(cpf_file,3,5)
    # g4, d4 = readGainsAndDarkCurrent(cpf_file,4,4)
    # g4 = np.ones(g4.shape)
    # d4 = np.zeros(d4.shape)
    # g1 = np.ones(g4.shape)
    # d1 = np.zeros(d4.shape)
    # g2 = np.ones(g4.shape)
    # d2 = np.zeros(d4.shape)
    # g3 = np.ones(g4.shape)
    # d3 = np.zeros(d4.shape)
    # import matplotlib.pyplot as plt
    # plt.plot(d4)
    # plt.show()
    file_name = r"D:\level1A_development\GER\TS1_2015308_37179_004_"
    # buildRMImage(file_name,7299,7363,7428,7493,g1,g2,g3,g4,d1,d2,d3,d4)
    # gains =[g1,g2,g3,g4]
    # dark_curr = [d1,d2,d3,d4]
    out_file = file_name + "out.tif"
    # buildPANImageUsingCubicInterpolation(out_file ,file_name,43221,gp,dp,[2015,1,1],-16.0)
    buildMSImageUsingCubicInterpolation(out_file, file_name, [5379, 5441, 5503, 5565], [2015, 11, 4], -17.0, -0.200)
