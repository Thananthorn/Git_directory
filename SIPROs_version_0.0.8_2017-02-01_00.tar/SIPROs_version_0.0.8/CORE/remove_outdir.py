import os , shutil , sys


out_directory = r"C:/Worker/Support-Worker/Producting_system/Level_1A"
for root , directory , filename in os.walk(out_directory , topdown=False):
	for name in filename : 
		remove_name = os.path.join(root , name)
		if remove_name.endswith(".zip"):
			pass
			# print remove_name
		elif not remove_name.endswith(".zip"):
			print "Delete " + remove_name
			os.remove(remove_name)

	for dirname in directory :
		remove_dir = os.path.join(root , dirname)
		if os.listdir(remove_dir) != []:
			pass

		elif os.listdir(remove_dir) == []:
			os.rmdir(remove_dir)
			print "Delete " + remove_dir
