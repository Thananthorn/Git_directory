"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""


import CompleteLevel1A as level1asystem
import CompleteLevel2A as level2asystem
import digitalElevationModel as demservice


# SYSTEM CONSTANTS
class demDirectory:
    # The absolute directories to all DEM Databses.
    # Fail to add correct directories may result in high positioning error.

    # #Open this if Sipros centos server.
    # SRTM30 = ""
    # SRTM90 = "/home/sipros/Application_1A_2A/Sipros_System/DEM/SRTM_90"
    # GLOBE = "/home/sipros/Application_1A_2A/Sipros_System/DEM/GLOBE"
    # THEOS = "/home/sipros/Application_1A_2A/Sipros_System/DEM/THEOS_DEM"

    # Open this if windows
    SRTM30 = ""
    SRTM90 = r"C:\Worker\Support-Worker\Sipros_system\DEM\SRTM_90"
    GLOBE = r"C:\Worker\Support-Worker\Sipros_system\DEM\GLOBE"
    THEOS = r"C:\Worker\Support-Worker\Sipros_system\DEM\THEOS_DEM"


class processingLevel:
    LEVEL1A = "1A"
    LEVEL2A = "2A"



class sensorType:
    PAN ="PAN"
    MS = "MS"



# SCENE INFORMATION TO USED
class sceneInfo:
    # Open this case for windows.
    ger_dir = r"C:\Worker\Support-Worker\Sipros_system\GERALD\THEOS_1_LEVEL0_1_111040095_40095_PAN_PB_TOP_1_19_2016-05-27_06-22-20"
    cpf_file = r"C:\Worker\Support-Worker\Sipros_system\CPF_PROCESSING\CPF_FILE\THEOS_1_20160517_000000_20160519_000002.CPF"

    # Open this if Sipros centos server.
    # ger_dir = r"D:\Data2APanSharpen\CASE2\THEOS_1_LEVEL0_1_111042934_42934_MS_PB_TOP_2_16_2016-12-13_05-36-25"
    # cpf_file = r"D:\Data2APanSharpen\CASE2\THEOS_1_20161206_000000_20161208_000000.CPF"

    begin_lines = [25599]
    start_sample = 1
    im_width = 12000
    im_height = 12000
    info_dir ="C:/Worker/Support-Worker/Sipros_system/EXTRACTION_FILES/info_40095_019"
    target_dir = "C:/Worker/Support-Worker/Sipros_system/PRODUCT_FILES/Level2A_40095_019"
    rev_num = str(400095)
    grid_id = "168-292"
    line_shifted = 0



# PROCESSING LEVEL AND DATA TYPE
class processSetup:
    processing_level = processingLevel.LEVEL2A
    # Choose Between LEVEL2A & LEVEL1A
    sensor = sensorType.PAN
    # Choose Between PAN & MS
    dem_interpolation = demservice.digitalElevationModel.CUBIC
    # Choose between NEAREST, LINEAR, CUBIC, KRIGING and RBF (KRIGING & RBF ARE VERY SLOW)
    dem_type = demservice.THEOS_DEM
    # Choose between THEOS_DEM, GLOBE, SRTM90 & SRTM30 (SRTM30 may be very slow)
    
    # Open this if windows.
    apf_file = r"C:\Worker\Support-Worker\Sipros_system\APF\THEOS_nominal.APF"

    # Open this if sipros centos server.
    # apf_file = r"D:\level1A_development\THEOS_nominal.APF"
    # LOCATION OF APF FILE


def callProcessingSystem(scene_info, process_setup):  # main call thread of the main process
    ger_directory = scene_info.ger_dir
    cpf_file = scene_info.cpf_file
    apf_file = process_setup.apf_file
    begin_lines = scene_info.begin_lines
    dem_type = process_setup.dem_type
    info_directory = scene_info.info_dir
    destination_directory = scene_info.target_dir
    rev_num = scene_info.rev_num
    grid_ref = scene_info.grid_id
    dem_interpolation_method = process_setup.dem_interpolation
    line_shifted = scene_info.line_shifted
    start_sample = scene_info.start_sample
    im_width = scene_info.im_width
    im_height = scene_info.im_height
    dem_dir = demDirectory

    if processSetup.processing_level == processingLevel.LEVEL1A:
        level1asystem.buildLevel1AImage(processSetup.sensor, ger_directory, cpf_file, apf_file, begin_lines, dem_type,
                                        info_directory, destination_directory, rev_num, grid_ref,dem_dir,
                                        dem_interpolation=dem_interpolation_method, line_shifted=line_shifted,
                                        start_sample=start_sample, im_width=im_width, im_height=im_height,
                                        force_run=False)
    elif processSetup.processing_level == processingLevel.LEVEL2A:
        level2asystem.buildLevel2AImage(processSetup.sensor, ger_directory, cpf_file, apf_file, begin_lines, dem_type,
                                        info_directory, destination_directory, rev_num, grid_ref,dem_dir,
                                        dem_interpolation=dem_interpolation_method, line_shift=line_shifted,
                                        start_sample=start_sample, im_width=im_width, im_height=im_height,
                                        force_run=False)


if __name__ == "__main__":
    scene_info = sceneInfo
    process_setup = processSetup
    callProcessingSystem(scene_info, process_setup)
