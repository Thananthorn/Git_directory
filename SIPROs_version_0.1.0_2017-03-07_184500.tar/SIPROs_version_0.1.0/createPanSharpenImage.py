"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

 """

import platform

if platform.system() == "Windows":
    from osgeo import gdal
else:
    import gdal
import numpy as np

import cv2
import determine_pixel_shift as dps
import utm
from osgeo import osr, ogr

import utmLatlon
import psutil
import os
import scipy.interpolate as inplt
import scipy.signal as signal
from commomTools import remapImageBandGridMethod, readDataBand, findSamplesPointsMS2PAN,\
    findLV2RemapFuncitionPANWithInterpolation, makingDEMData
from systemConstants import LV1_2ProductionConstants, pansharpenMethods
import scipy.signal as sg


def broveyPanSharpen(ms,pan):
    ms_out = np.zeros_like(ms,'uint8')
    height, width = pan.shape
    step = 3000
    for k in range(0,height, step):
        for m in range(0, width, step):
            ms_part = ms[k:k+step,m:m+step,:].astype('float32')
            pan_part = pan[k:k+step,m:m+step].astype('float32')
            gray = ms_part[:, :, 0] * LV1_2ProductionConstants.g1
            gray += ms_part[:, :, 1] * LV1_2ProductionConstants.g2
            gray += ms_part[:, :, 2] * LV1_2ProductionConstants.g3
            gray += ms_part[:, :, 3] * LV1_2ProductionConstants.g4
            out = np.zeros_like(ms_part)
            for b in range(4):
                out[:,:,b] = ms_part[:,:,b]*(pan_part/gray)
            out = 1*(out<1) + 255*(out>255) + out*(out>=1)*(out<=255)
            out = np.round(out).astype('uint8')
            ms_out[k:k+step,m:m+step,:] = out
    return ms_out

def gramSchmidth(ms, pan):

    height, width = pan.shape

    num_pixels = height * width
    ms = ms.reshape((num_pixels, 4))
    imout = np.zeros_like(ms)
    pan = pan.reshape((num_pixels))
    gains = np.array([LV1_2ProductionConstants.g1,LV1_2ProductionConstants.g2,
                      LV1_2ProductionConstants.g3, LV1_2ProductionConstants.g4])
    v0 = np.dot(ms, gains).flatten()
    mv = ms.mean(0)
    v0_mean = v0.mean()
    vp_mean = pan.mean()
    v0 -= v0_mean
    pan-= vp_mean
    pan = pan * v0.std() / pan.std()

    bot = (v0 * v0).mean()
    step = 3000*3000
    a_j = []
    for b in range(4):
        top = 0
        for k in range(0, num_pixels, step):
            kstp = min(num_pixels, k + step)
            ms_data = ms[k:kstp, b].astype('float64')
            ms_data -= mv[b]
            top += ms_data * v0[k:kstp]
        top = top/float(num_pixels)
        a = top / bot
        a_j.append(a)
    for b in range(4):
        for k in range(0, num_pixels, step):
            kstp = min(num_pixels, k + step)
            ms_data = ms[k:kstp, b].astype('float64')
            ms_data -= mv[b]
            ms_data -= a_j[b] * v0[k:kstp]
            ms_data += a_j[b] * pan[k:kstp]
            ms_data += mv[b]
            ms_data = 1 * (ms_data < 1) + 255 * (ms_data > 255) + ms_data * (ms_data >= 1) * (ms_data <= 255)
            imout[k:kstp, b] = np.round(ms_data).astype('uint8')


    return imout.reshape((height, width, 4))


def highpassPansharpen(ms, pan):
    kernel = np.array([0.0002,0.0003,0.0003,0.0003,0.0004,0.0004,0.0004,0.0005,0.0005,0.0005,0.0005,0.0005,0.0005,0.0005,0.0004,0.0004,0.0004,0.0003,0.0003,0.0003,0.0002,0.0003,0.0003,0.0004,0.0005,0.0005,0.0006,0.0007,0.0008,0.0008,0.0009,0.0009,0.0009,0.0008,0.0008,0.0007,0.0006,0.0005,0.0005,0.0004,0.0003,0.0003,0.0004,0.0004,0.0005,0.0006,0.0007,0.0009,0.0010,0.0011,0.0012,0.0013,0.0014,0.0013,0.0012,0.0011,0.0010,0.0009,0.0007,0.0006,0.0005,0.0004,0.0004,0.0004,0.0005,0.0006,0.0007,0.0009,0.0011,0.0013,0.0014,0.0016,0.0017,0.0018,0.0017,0.0016,0.0014,0.0013,0.0011,0.0009,0.0007,0.0006,0.0005,0.0004,0.0005,0.0006,0.0008,0.0009,0.0013,0.0017,0.0021,0.0024,0.0027,0.0030,0.0033,0.0030,0.0027,0.0024,0.0021,0.0017,0.0013,0.0009,0.0008,0.0006,0.0005,0.0006,0.0008,0.0010,0.0011,0.0017,0.0023,0.0029,0.0034,0.0038,0.0043,0.0047,0.0043,0.0038,0.0034,0.0029,0.0023,0.0017,0.0011,0.0010,0.0008,0.0006,0.0007,0.0009,0.0011,0.0014,0.0021,0.0029,0.0037,0.0044,0.0050,0.0056,0.0062,0.0056,0.0050,0.0044,0.0037,0.0029,0.0021,0.0014,0.0011,0.0009,0.0007,0.0007,0.0010,0.0013,0.0015,0.0025,0.0034,0.0043,0.0052,0.0060,0.0067,0.0075,0.0067,0.0060,0.0052,0.0043,0.0034,0.0025,0.0015,0.0013,0.0010,0.0007,0.0008,0.0011,0.0014,0.0017,0.0027,0.0038,0.0049,0.0059,0.0068,0.0077,0.0086,0.0077,0.0068,0.0059,0.0049,0.0038,0.0027,0.0017,0.0014,0.0011,0.0008,0.0008,0.0011,0.0015,0.0018,0.0030,0.0042,0.0055,0.0066,0.0076,0.0086,0.0096,0.0086,0.0076,0.0066,0.0055,0.0042,0.0030,0.0018,0.0015,0.0011,0.0008,0.0009,0.0012,0.0016,0.0019,0.0033,0.0046,0.0060,0.0073,0.0084,0.0095,0.0107,0.0095,0.0084,0.0073,0.0060,0.0046,0.0033,0.0019,0.0016,0.0012,0.0009,0.0008,0.0011,0.0015,0.0018,0.0030,0.0042,0.0055,0.0066,0.0076,0.0086,0.0096,0.0086,0.0076,0.0066,0.0055,0.0042,0.0030,0.0018,0.0015,0.0011,0.0008,0.0008,0.0011,0.0014,0.0017,0.0027,0.0038,0.0049,0.0059,0.0068,0.0077,0.0086,0.0077,0.0068,0.0059,0.0049,0.0038,0.0027,0.0017,0.0014,0.0011,0.0008,0.0007,0.0010,0.0013,0.0015,0.0025,0.0034,0.0043,0.0052,0.0060,0.0067,0.0075,0.0067,0.0060,0.0052,0.0043,0.0034,0.0025,0.0015,0.0013,0.0010,0.0007,0.0007,0.0009,0.0011,0.0014,0.0021,0.0029,0.0037,0.0044,0.0050,0.0056,0.0062,0.0056,0.0050,0.0044,0.0037,0.0029,0.0021,0.0014,0.0011,0.0009,0.0007,0.0006,0.0008,0.0010,0.0011,0.0017,0.0023,0.0029,0.0034,0.0038,0.0043,0.0047,0.0043,0.0038,0.0034,0.0029,0.0023,0.0017,0.0011,0.0010,0.0008,0.0006,0.0005,0.0006,0.0008,0.0009,0.0013,0.0017,0.0021,0.0024,0.0027,0.0030,0.0033,0.0030,0.0027,0.0024,0.0021,0.0017,0.0013,0.0009,0.0008,0.0006,0.0005,0.0004,0.0005,0.0006,0.0007,0.0009,0.0011,0.0013,0.0014,0.0016,0.0017,0.0018,0.0017,0.0016,0.0014,0.0013,0.0011,0.0009,0.0007,0.0006,0.0005,0.0004,0.0004,0.0004,0.0005,0.0006,0.0007,0.0009,0.0010,0.0011,0.0012,0.0013,0.0014,0.0013,0.0012,0.0011,0.0010,0.0009,0.0007,0.0006,0.0005,0.0004,0.0004,0.0003,0.0003,0.0004,0.0005,0.0005,0.0006,0.0007,0.0008,0.0008,0.0009,0.0009,0.0009,0.0008,0.0008,0.0007,0.0006,0.0005,0.0005,0.0004,0.0003,0.0003,0.0002,0.0003,0.0003,0.0003,0.0004,0.0004,0.0004,0.0005,0.0005,0.0005,0.0005,0.0005,0.0005,0.0005,0.0004,0.0004,0.0004,0.0003,0.0003,0.0003,0.000])
    kernel = kernel.reshape((21, 21))
    ms_out = np.zeros_like(ms, 'uint8')
    height, width = pan.shape
    step = 3000
    margin = 100
    for k in range(0, height, step):
        for m in range(0, width, step):
            str_row = max(0, k-margin)
            str_col = max(0, m-margin)
            stp_row = min(height, k + step + margin)
            stp_col = min(width, m + step + margin)
            k0 = margin*(str_row > 0)
            m0 = margin * (str_col > 0)
            k1 = k0 + step
            m1 = m0 + step
            ms_part = ms[str_row:stp_row, str_col:stp_col, :].astype('float64').copy()
            pan_part = pan[str_row:stp_row, str_col:stp_col].astype('float64').copy()
            pan_low =  sg.convolve2d(pan_part, kernel,mode="same",boundary="wrap")
            pan_high = pan_part - pan_low
            k_fac =  ms_part[:, :, 0]/ pan_low
            ms_part[:, :, 0] += k_fac*pan_high

            k_fac = ms_part[:, :, 1] / pan_low
            ms_part[:, :, 1] += k_fac * pan_high

            k_fac = ms_part[:, :, 2] / pan_low
            ms_part[:, :, 2] += k_fac * pan_high

            k_fac = ms_part[:, :, 3] / pan_low
            ms_part[:, :, 3] += k_fac * pan_high

            ms_part = 1 * (ms_part < 1) + 255 * (ms_part > 255) + ms_part * (ms_part >= 1) * (ms_part <= 255)
            ms_part = (np.round(ms_part)).astype('uint8')
            ms_out[k:k+step,m:m+step,:] = ms_part[k0:k1,m0:m1,:]

    return  ms_out



def pcaPanSharpen(ms,pan):

    height, width = pan.shape
    step = 3000 * 3000
    num_pixels = height * width
    ms = ms.reshape((num_pixels, 4))
    pan = pan.reshape(num_pixels)
    mv = 0

    for k in range(0,num_pixels,step):
        kstp = min(num_pixels, k+step)
        mstemp = ms[k:kstp, :].astype('float64')
        mv += mstemp.sum(0)

    mv = mv/float(num_pixels)
    ms_cov = np.zeros((4,4),'float64')
    for k in range(0,num_pixels,step):
        kstp = min(num_pixels, k+step)
        mstemp = ms[k:kstp, :].astype('float64') - mv.reshape((1,4))
        ms_cov += np.dot(mstemp.T, mstemp)

    ms_cov = ms_cov /float(num_pixels)
    v, W = np.linalg.eigh(ms_cov)
    vord = np.argsort(v)
    vord = vord[::-1]
    W2 = np.zeros_like(W)
    for b in range(4):
        W2[:, b] = W[:, vord[b]]

    vpm = pan.mean()
    vpstd = pan.std()

    vm1 = 0
    v1std = 0
    for k in range(0,num_pixels,step):
        kstp = min(num_pixels, k+step)
        mstemp = ms[k:kstp,:].astype('float64')  - mv.reshape((1,4))
        vtemp = np.dot(W2, mstemp.T)
        vm1 += vtemp[0,:].sum()
        v1std += (vtemp[0,:]**2).sum()
    vm1 = vm1 / float(num_pixels)
    v1std = np.sqrt((v1std/ float(num_pixels))-vm1**2)

    sign = 0
    for k in range(0, num_pixels, step):
        kstp = min(num_pixels, k + step)
        vp = pan[k:kstp]
        vp = ((vp - vpm) / vpstd) * v1std + vm1
        kstp = min(num_pixels, k + step)
        mstemp = ms[k:kstp, :].astype('float64') - mv.reshape((1, 4))
        vtemp = np.dot(W2, mstemp.T)
        v1 = vtemp[0,:]
        sign += (v1*vp).sum()
    if sign > 0:
        sign = 1
    else:
        sign = -1

    for k in range(0,num_pixels,step):
        kstp = min(num_pixels, k+step)
        mstemp = ms[k:kstp,:].astype('float64')  - mv.reshape((1,4))
        vtemp = np.dot(W2, mstemp.T)
        vp = pan[k:kstp]
        vp = sign*((vp - vpm) / vpstd) * v1std + vm1
        vtemp[0, :] = vp
        mstemp = np.dot(W2.T, vtemp).T
        mstemp = mstemp + mv.reshape((1, 4))
        mstemp = 1 * (mstemp < 1) + 255 * (mstemp > 255) + mstemp * (mstemp >= 1) * (mstemp <= 255)
        ms[k:kstp, :] = np.round(mstemp)
    ms_out = ms.reshape((height, width, 4)).astype('uint8')
    return ms_out



def utmToLatLon(x, y, zone, isnorth):
    dsc = osr.SpatialReference()
    dsc.ImportFromEPSG(4326)
    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if isnorth:
        src.SetUTM(zone, 1)
    else:
        src.SetUTM(zone, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(x, y)
    point.Transform(coordTransform)
    lon = point.GetX()
    lat = point.GetY()
    return lat, lon


def findImageMapInfo(in_file_name, start_sample, end_sample, line, im_height, current_date, utc_gps, dut1, dem,
                     dem_interpolation_method):
    # Get All 4 Tie points
    latc, lonc, heightc = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name,
                                                                 np.array([(end_sample + start_sample) / 2]),
                                                                 np.array([line + im_height / 2]), current_date,
                                                                 utc_gps, dut1, dem, dem_interpolation_method)

    xc, yc, zonec, zoneletterc = utm.from_latlon(latc, lonc)

    dsc = osr.SpatialReference()
    dsc.SetWellKnownGeogCS("WGS84")
    if latc >= 0:
        dsc.SetUTM(zonec, 1)
        isnorth = True
    else:
        dsc.SetUTM(zonec, 0)
        isnorth = False
    latul, lonul, heightul = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([start_sample]),
                                                                    [line], current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method)

    xul, yul, zoneul, zoneletter = utm.from_latlon(latul, lonul)

    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latul >= 0:
        src.SetUTM(zoneul, 1)
    else:
        src.SetUTM(zoneul, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xul, yul)
    point.Transform(coordTransform)
    xul = point.GetX()
    yul = point.GetY()
    print "original image upper left UTM:", xul, yul, "Lat, Lon", latul, lonul

    latur, lonur, heightur = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([end_sample]),
                                                                    [line], current_date, utc_gps, dut1, dem,
                                                                    dem_interpolation_method)
    xur, yur, zoneur, zoneletter = utm.from_latlon(latur, lonur)
    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latur >= 0:
        src.SetUTM(zoneur, 1)
    else:
        src.SetUTM(zoneur, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xur, yur)
    point.Transform(coordTransform)
    xur = point.GetX()
    yur = point.GetY()

    print "original image upper right UTM:", xur, yur, "Lat, Lon", latur, lonur
    latll, lonll, heightll = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([start_sample]),
                                                                    [line + im_height], current_date, utc_gps, dut1,
                                                                    dem,
                                                                    dem_interpolation_method)
    xll, yll, zonell, zoneletter = utm.from_latlon(latll, lonll)

    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latll >= 0:
        src.SetUTM(zonell, 1)
    else:
        src.SetUTM(zonell, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xll, yll)
    point.Transform(coordTransform)
    xll = point.GetX()
    yll = point.GetY()
    print "original image lower left UTM:", xll, yll, "Lat, Lon", latll, lonll

    latlr, lonlr, heightlr = dps.findInterSectionPointArrayUsingDEM("PAN", in_file_name, np.array([end_sample]),
                                                                    [line + im_height], current_date, utc_gps, dut1,
                                                                    dem,
                                                                    dem_interpolation_method)
    xlr, ylr, zonelr, zoneletter_c = utm.from_latlon(latlr, lonlr)
    src = osr.SpatialReference()
    src.SetWellKnownGeogCS("WGS84")
    if latlr >= 0:
        src.SetUTM(zonelr, 1)
    else:
        src.SetUTM(zonelr, 0)

    coordTransform = osr.CoordinateTransformation(src, dsc)
    point = ogr.Geometry(ogr.wkbPoint)
    point.AddPoint(xlr, ylr)
    point.Transform(coordTransform)
    xlr = point.GetX()
    ylr = point.GetY()

    print "original image lower right UTM:", xlr, ylr, "Lat, Lon", latlr, lonlr
    print "original image center UTM:", xc, yc

    # determine the mapping function.
    if LV1_2ProductionConstants.DESCENDING:
        num_lines = np.ceil((yul - ylr) / 2.0 + 1)
        num_samples = np.ceil((xur - xll) / 2.0 + 1)
        lv_width = int(np.ceil(num_samples))
        lv_height = int(np.ceil(num_lines))
        x2_up_left = xll
        y2_up_left = yul
        dx2 = 2.0
        dy2 = -2.0
    else:
        num_lines = np.ceil((yll - yur) / 2.0 + 1)
        num_samples = np.ceil((xul - xlr) / 2.0 + 1)
        lv_width = int(np.ceil(num_samples))
        lv_height = int(np.ceil(num_lines))
        x2_up_left = xlr
        y2_up_left = yll
        dx2 = 2.0
        dy2 = -2.0

    print "The level 2A image has a size of %d x %d  pixels" % (lv_width, lv_height)

    lv2_geotrans = [x2_up_left, y2_up_left, dx2, dy2, zonec]
    map_geo_trans = [x2_up_left, y2_up_left, dx2, dy2, zonec, zoneletter_c]

    if LV1_2ProductionConstants.DESCENDING:
        lat_topleft, lon_topleft = utmToLatLon(xll, yul, zonec, isnorth)  # utm.to_latlon(xllc,yul, zonec,zoneletterc )
        lat_botright, lon_botright = utmToLatLon(xur, ylr, zonec,
                                                 isnorth)  # utm.to_latlon(xur, ylr, zonec, zoneletterc )
        if zonec == 60:
            if lat_botright < 0:
                lat_botright = lat_botright + 360
        elif zonec == 1:
            if lat_topleft > 0:
                lat_botright = lat_topleft - 360
        latgrid, longrid, hgrid = dem.getValuesFromRetangularArea(lat_topleft, lon_topleft, lat_botright, lon_botright)
        hmin = hgrid.min()
        hmax = hgrid.max()
    else:
        lat_topleft, lon_topleft = utmToLatLon(xlr, yll, zonec, isnorth)  # utm.to_latlon(xllc,yul, zonec,zoneletterc )
        lat_botright, lon_botright = utmToLatLon(xul, yur, zonec,
                                                 isnorth)  # utm.to_latlon(xur, ylr, zonec, zoneletterc )
        if zonec == 60:
            if lat_botright < 0:
                lat_botright = lat_botright + 360
        elif zonec == 1:
            if lat_topleft > 0:
                lat_botright = lat_topleft - 360
        latgrid, longrid, hgrid = dem.getValuesFromRetangularArea(lat_topleft, lon_topleft, lat_botright, lon_botright)
        hmin = hgrid.min()
        hmax = hgrid.max()
    print "The Minimum and maximum altitudes of the scene are %f and %f meters, respectively." % (hmin, hmax)

    return xul,yul, latul, lonul, xur, yur, latur, lonur, xll, yll, latll, lonll, xlr, ylr, latlr, lonlr, xc, yc\
        ,latc, lonc, zonec, heightll, heightul, heightll, heightlr, heightc, zonec, zoneletter_c, x2_up_left\
        , y2_up_left, hmin, hmax

def findBeginLineMS(pansharpen_info_dir, pan_line, ms_in_file_name,h0, current_date, utc_gps, dut1,
                    latul, lonul):
    begin_lines_ms_files = pansharpen_info_dir + "\\begin_lines_%d.txt" % pan_line
    if not os.path.isfile(begin_lines_ms_files):
        ms_lines = []
        samples_zero_ms = []
        aline = np.arange(6000) + 1
        print "Find the beginning line....."
        for band in [1, 2, 3, 4]:
            print "Band:%d" % (band)
            ms_im = gdal.Open(ms_in_file_name + "B%d.tif" % band)
            raw_height = ms_im.RasterYSize
            raw_width = ms_im.RasterXSize
            dis = []

            for line in range(0, raw_height, 1000):
                latms, lonms, h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline, [line],
                                                                              h0,current_date, utc_gps, dut1, band)
                dist1 = np.sqrt((latms - latul) ** 2 + (lonms - lonul) ** 2)
                dist1 = dist1.min()
                dis.append(dist1)
            dis = np.array(dis)
            best_k = np.nonzero(dis == dis.min())[0][0]
            dis = []
            km1 = max(0, best_k - 1) * 1000
            kp1 = min((best_k + 1) * 1000, raw_height)
            print "     The best line is between %d and %d" % (km1, kp1)
            for line in range(km1, kp1, 100):
                latms, lonms, h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline, [line],
                                                                              h0,
                                                                              current_date, utc_gps, dut1, band)
                dist1 = np.sqrt((latms - latul) ** 2 + (lonms - lonul) ** 2)
                dist1 = dist1.min()
                dis.append(dist1)
            dis = np.array(dis)
            best_k = np.nonzero(dis == dis.min())[0][0]
            kp1 = km1 + min((best_k + 1) * 100, raw_height)
            km1 = km1 + max(0, best_k - 1) * 100
            print "     The best line is between %d and %d" % (km1, kp1)
            dis = []
            for line in range(km1, kp1, 10):
                latms, lonms, h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline, [line],
                                                                              h0,
                                                                              current_date, utc_gps, dut1, band)
                dist1 = np.sqrt((latms - latul) ** 2 + (lonms - lonul) ** 2)
                dist1 = dist1.min()
                dis.append(dist1)
            dis = np.array(dis)
            best_k = np.nonzero(dis == dis.min())[0][0]

            kp1 = km1 + min((best_k + 1) * 10, raw_height)
            km1 = km1 + max(0, best_k - 1) * 10
            print "     The best line is between %d and %d" % (km1, kp1)
            dis = []
            for line in range(km1, kp1):
                latms, lonms, h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline, [line],
                                                                              h0,
                                                                              current_date, utc_gps, dut1, band)
                dist1 = np.sqrt((latms - latul) ** 2 + (lonms - lonul) ** 2)
                dist1 = dist1.min()
                dis.append(dist1)
            dis = np.array(dis)
            best_k = np.nonzero(dis == dis.min())[0][0]
            best_line = best_k + km1
            latms, lonms, h = dps.findInterSectionPointArrayGivenAltitude("MS", ms_in_file_name, aline, [best_line],
                                                                          h0,
                                                                          current_date, utc_gps, dut1, band)
            dist1 = np.sqrt((latms - latul) ** 2 + (lonms - lonul) ** 2)
            opt_samples = np.nonzero(dist1 == dist1.min())[0][0]

            print "best line:%d for band %d at sample %d" % (best_k + km1 - 5, band, opt_samples)
            ms_lines.append(best_k + km1 - 5)
            samples_zero_ms.append(opt_samples)

        data_line_sample = np.zeros((4, 2))
        data_line_sample[:, 0] = np.array(ms_lines)
        data_line_sample[:, 1] = np.array(samples_zero_ms)
        np.savetxt(begin_lines_ms_files, data_line_sample)
    else:
        data_line_sample = np.loadtxt(begin_lines_ms_files)
        ms_lines = []
        samples_zero_ms = []
        for k in range(4):
            ms_lines.append(int(data_line_sample[k, 0]))
            samples_zero_ms.append(int(data_line_sample[k, 1]))
    return ms_lines, samples_zero_ms

def findKeyPoints(ref, fim):


    print "Fine Tuning using SIFT-based image-to-image registration"
    print "Find keys points between images"
    size_width = 1000
    margins = 100
    sf = cv2.SIFT()
    FLANN_INDEX_KDTREE = 0
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    search_params = dict(checks=50)  # or pass empty dictionary
    flann = cv2.FlannBasedMatcher(index_params, search_params)

    data_h, data_w = ref.shape
    maching_pairs = []
    distances = []
    for k in range(0, data_h, size_width):
        for m in range(0, data_w, size_width):
            str_row = max(0, k - margins)
            str_col = max(0, m - margins)
            stp_row = min(data_h, k + size_width + margins)
            stp_col = min(data_w, m + size_width+ margins)
            print "working on (%d, %d) -> (%d,%d) " % (str_row, str_col, stp_row, stp_col)
            data_k = ref[str_row:stp_row, str_col:stp_col]
            data_k = (data_k > 0) * (data_k < 255) * data_k + 255 * (data_k >= 255)
            data_k = np.round(data_k).astype('uint8')
            keys_ref, des_ref = sf.detectAndCompute(data_k, None)
            data_k = fim[str_row:stp_row, str_col:stp_col]
            data_k = (data_k > 0) * (data_k < 255) * data_k + 255 * (data_k >= 255)
            data_k = np.round(data_k).astype('uint8')
            keys_fim, des_fim = sf.detectAndCompute(data_k, None)
            matches = flann.knnMatch(des_ref, des_fim, k=2)
            scores = np.zeros(len(matches))
            cnt = 0
            for (m0, m1) in matches:
                scores[cnt] = m1.distance / m0.distance
                cnt += 1
            if scores.max() > 2:
                good_points = np.nonzero(scores > 2)[0]
                num_good_points = len(good_points)
                for pnt in good_points:
                    mbest = matches[pnt][0]
                    p_ref = keys_ref[mbest.queryIdx].pt
                    p_fim = keys_fim[mbest.trainIdx].pt
                    refx = p_ref[0] + str_col
                    refy = p_ref[1] + str_row
                    imx = p_fim[0] + str_col
                    imy = p_fim[1] + str_row
                    distance = np.sqrt((refx-imx)**2 + (refy-imy)**2)
                    if (refx>= m) & (refx < m+size_width) & (refy >= k) & (refy < k + size_width) & (
                                imx >= m) & (imx < m+size_width) & (imy >= k) & (imy < k + size_width):
                        maching_pairs.append([[refx, refy], [imx, imy]])
                        distances.append(distance)
    print "There are %d matching pairs." %(len(maching_pairs))

    distances = np.array(distances)
    print "Maximum distance: %f, average distance: %f, std: %f." %(distances.max(), distances.mean(), distances.std())
    maching_pairs = np.array(maching_pairs)
    ref_points = maching_pairs[:, 0, :]
    im_points = maching_pairs[:, 1, :]


    return ref_points, im_points ,distances

def remapFunction(xms,yms,pan_points, ms_points):
    dis = (pan_points-ms_points)**2
    dis = dis.sum(1)
    dis = np.sqrt(dis)
    dissort = np.sort(dis)
    num_points = dis.size
    idx = np.nonzero((dis>dissort[num_points/10]) * (dis < dissort[-num_points/10]))[0]
    pan_points = pan_points[idx]
    ms_points = ms_points[idx]


    num_points = pan_points.shape[0]
    A = np.zeros((num_points,6))
    x = ms_points[:,0]
    y = ms_points[:,1]
    xp = pan_points[:,0]
    yp = pan_points[:,1]

    A[:,0] = 1.0
    A[:, 1] = x
    A[:, 2] = y
    A[:, 3] = x*y
    A[:, 4] = x**2
    A[:, 5] = y**2

    coefx = np.linalg.lstsq(A,xp)[0]
    coefy = np.linalg.lstsq(A,yp)[0]

    num_points = xms.size
    A = np.zeros((num_points, 6))
    xms2 =xms.flatten()
    yms2 = yms.flatten()
    A[:, 0] = 1.0
    A[:, 1] = xms2
    A[:, 2] = yms2
    A[:, 3] = xms2 * yms2
    A[:, 4] = xms2 ** 2
    A[:, 5] = yms2 ** 2
    xpan = np.dot(A,coefx)
    ypan = np.dot(A,coefy)
    xpan = xpan.reshape(xms.shape)
    ypan = ypan.reshape(yms.shape)

    return xpan, ypan

def findMsPanCorrespondingPoints(pansharpen_info_dir , pan_line, ms_in_file_name, pan_in_file_name, step, samples_zero_ms,
                                 ms_lines, sat_pos, sat_time, sat_att, current_date, utc_gps, dut1, dem,
                                 dem_interpolation_method, im_width, im_height):
    all_files_exists = True
    for band in ['1', '2', '3', '4', 'p']:
        file_x = pansharpen_info_dir + "\\x" + band + "_Line_%d.txt" % pan_line
        file_y = pansharpen_info_dir + "\\y" + band + "_Line_%d.txt" % pan_line
        all_files_exists = all_files_exists & os.path.isfile(file_x)
        all_files_exists = all_files_exists & os.path.isfile(file_y)

    if not all_files_exists:

        x1, x2, x3, x4, xp, y1, y2, y3, y4, yp = findSamplesPointsMS2PAN(ms_in_file_name, pan_in_file_name, step,
                                                                         samples_zero_ms,
                                                                         ms_lines, pan_line, sat_pos, sat_time, sat_att,
                                                                         current_date,
                                                                         utc_gps, dut1, dem, dem_interpolation_method,
                                                                         im_width, im_height, im_register=False)
        np.savetxt(pansharpen_info_dir + "\\x1_Line_%d.txt" % pan_line, x1)
        np.savetxt(pansharpen_info_dir + "\\x2_Line_%d.txt" % pan_line, x2)
        np.savetxt(pansharpen_info_dir + "\\x3_Line_%d.txt" % pan_line, x3)
        np.savetxt(pansharpen_info_dir + "\\x4_Line_%d.txt" % pan_line, x4)
        np.savetxt(pansharpen_info_dir + "\\xp_Line_%d.txt" % pan_line, xp)
        np.savetxt(pansharpen_info_dir + "\\y1_Line_%d.txt" % pan_line, y1)
        np.savetxt(pansharpen_info_dir + "\\y2_Line_%d.txt" % pan_line, y2)
        np.savetxt(pansharpen_info_dir + "\\y3_Line_%d.txt" % pan_line, y3)
        np.savetxt(pansharpen_info_dir + "\\y4_Line_%d.txt" % pan_line, y4)
        np.savetxt(pansharpen_info_dir + "\\yp_Line_%d.txt" % pan_line, yp)
    else:
        x1 = np.loadtxt(pansharpen_info_dir + "\\x1_Line_%d.txt" % pan_line)
        x2 = np.loadtxt(pansharpen_info_dir + "\\x2_Line_%d.txt" % pan_line)
        x3 = np.loadtxt(pansharpen_info_dir + "\\x3_Line_%d.txt" % pan_line)
        x4 = np.loadtxt(pansharpen_info_dir + "\\x4_Line_%d.txt" % pan_line)
        xp = np.loadtxt(pansharpen_info_dir + "\\xp_Line_%d.txt" % pan_line)

        y1 = np.loadtxt(pansharpen_info_dir + "\\y1_Line_%d.txt" % pan_line)
        y2 = np.loadtxt(pansharpen_info_dir + "\\y2_Line_%d.txt" % pan_line)
        y3 = np.loadtxt(pansharpen_info_dir + "\\y3_Line_%d.txt" % pan_line)
        y4 = np.loadtxt(pansharpen_info_dir + "\\y4_Line_%d.txt" % pan_line)
        yp = np.loadtxt(pansharpen_info_dir + "\\yp_Line_%d.txt" % pan_line)
    return x1, x2, x3, x4, xp, y1, y2, y3, y4, yp


def findAdjustRemapPanPoints(pansharpen_info_dir, pan_in_file_name, start_sample, pan_line, im_width, im_height, gains, darkcurrs,
                             sard_time, image_data, ms_lines, offset_min1, offset_min2, offset_min3,
                             offset_min4, x1,y1,x2,y2,x3,y3,x4,y4,xp,yp, block_size, timeB1, timeB2, timeB3, timeB4):
    ref_map_file = pansharpen_info_dir + "\\ref_Line_%d.txt" % pan_line
    im_map_file = pansharpen_info_dir + "\\im_Line_%d.txt" % pan_line
    pan_im = gdal.Open(pan_in_file_name + ".tif")
    b1 = pan_im.GetRasterBand(1)
    gain_number = np.loadtxt(pan_in_file_name + ".gain")
    panData = readDataBand(b1, start_sample, pan_line, im_width, im_height, gains[-1], darkcurrs[-1],
                           gain_number, im_type="PAN")
    all_remap_files_exist = (os.path.isfile(ref_map_file) & os.path.isfile(im_map_file))
    if not all_remap_files_exist:
        gray_version = np.zeros((im_height, im_width), 'float32')
        for band in [1, 2, 3, 4]:
            if band == 1:

                id1 = np.nonzero(timeB1 > sard_time[-1])[0]
                b1h = image_data[0].shape[0] + offset_min1
                if len(id1) > 0:
                    line1_max = min(b1h, id1[0] - ms_lines[0])
                else:
                    line1_max = b1h

                idok = np.nonzero((y1 < line1_max))[0]

                xmap, ymap, mask1 = remapImageBandGridMethod(x1[idok], y1[idok], xp[idok], yp[idok], 0, 0, block_size,
                                                             im_width, im_height, offset_min1,
                                                             max_error=LV1_2ProductionConstants.REMAP_MAX_ERROR)

                out = cv2.remap(image_data[0], xmap, ymap, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                borderValue=0)
                gray_version = LV1_2ProductionConstants.g1 * out


            elif band == 2:
                id2 = np.nonzero(timeB2 > sard_time[-1])[0]
                b2h = image_data[1].shape[0] + offset_min2
                if len(id2) > 0:
                    line2_max = min(b2h, id2[0] - ms_lines[1])
                else:
                    line2_max = b2h

                idok = np.nonzero((y2 < line2_max))[0]
                xmap, ymap, mask2 = remapImageBandGridMethod(x2[idok], y2[idok], xp[idok], yp[idok], 0, 0, block_size,
                                                             im_width, im_height, offset_min2,
                                                             max_error=LV1_2ProductionConstants.REMAP_MAX_ERROR)
                out = cv2.remap(image_data[1], xmap, ymap, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                borderValue=0)
                gray_version += LV1_2ProductionConstants.g2 * out

            elif band == 3:
                id3 = np.nonzero(timeB3 > sard_time[-1])[0]
                b3h = image_data[2].shape[0] + offset_min3
                if len(id3) > 0:
                    line3_max = min(b3h, id3[0] - ms_lines[2])
                else:
                    line3_max = b3h

                idok = np.nonzero((y3 < line3_max))[0]
                xmap, ymap, mask2 = remapImageBandGridMethod(x3[idok], y3[idok], xp[idok], yp[idok], 0, 0, block_size,
                                                             im_width, im_height, offset_min3,
                                                             max_error=LV1_2ProductionConstants.REMAP_MAX_ERROR)
                out = cv2.remap(image_data[2], xmap, ymap, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                borderValue=0)
                gray_version += LV1_2ProductionConstants.g3 * out



            elif band == 4:

                id4 = np.nonzero(timeB4 > sard_time[-1])[0]
                b4h = image_data[3].shape[0] + offset_min4
                if len(id4) > 0:
                    line4_max = min(b4h, id4[0] - ms_lines[3])
                else:
                    line4_max = b4h

                idok = np.nonzero((y3 < line4_max))[0]
                xmap, ymap, mask4 = remapImageBandGridMethod(x4[idok], y4[idok], xp[idok], yp[idok], 0, 0, block_size,
                                                             im_width, im_height, offset_min4,
                                                             max_error=LV1_2ProductionConstants.REMAP_MAX_ERROR)
                out = cv2.remap(image_data[3], xmap, ymap, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                borderValue=0)
                gray_version += LV1_2ProductionConstants.g4 * out
        MIN_DN = LV1_2ProductionConstants.MIN_DN
        MAX_DN = LV1_2ProductionConstants.MAX_DN

        gray_version = MIN_DN * (gray_version < MIN_DN) + \
                       MAX_DN * (gray_version >= MAX_DN) + \
                       gray_version * (gray_version >= MIN_DN) * (gray_version < MAX_DN)

        ref_points, im_points, dis = findKeyPoints(panData, gray_version)
        gray_version = None
        np.savetxt(ref_map_file, ref_points)
        np.savetxt(im_map_file, im_points)
    else:
        im_points = np.loadtxt(im_map_file)
        ref_points = np.loadtxt(ref_map_file)
    xp2, yp2 = remapFunction(xp, yp, ref_points, im_points)
    return xp2, yp2

def buildRemapMSImage(image_data, ms_lines, offset_min1, offset_min2, offset_min3, offset_min4, x1, y1, x2, y2,
                      x3, y3, x4, y4, xp2, yp2, timeB1, timeB2, timeB3, timeB4, sard_time, im_height,
                      im_width):
    ms_remap_image = np.zeros((im_height, im_width, 4), 'uint8')
    block_size = im_width
    MIN_DN = LV1_2ProductionConstants.MIN_DN
    MAX_DN = LV1_2ProductionConstants.MAX_DN
    for band in [1, 2, 3, 4]:
        if band == 1:

            id1 = np.nonzero(timeB1 > sard_time[-1])[0]
            b1h = image_data[0].shape[0] + offset_min1
            if len(id1) > 0:
                line1_max = min(b1h, id1[0] - ms_lines[0])
            else:
                line1_max = b1h

            idok = np.nonzero((y1 < line1_max))[0]

            xmap, ymap, mask1 = remapImageBandGridMethod(x1[idok], y1[idok], xp2[idok], yp2[idok], 0, 0, block_size,
                                                         im_width, im_height, offset_min1,
                                                         max_error=LV1_2ProductionConstants.REMAP_MAX_ERROR)

            out = cv2.remap(image_data[0], xmap, ymap, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)

            out = MIN_DN * (out < MIN_DN) + \
                  MAX_DN * (out >= MAX_DN) + \
                  out * (out >= MIN_DN) * (out < MAX_DN)
            out = np.round(out).astype('uint8')
            ms_remap_image[:, :, 0] = out

        elif band == 2:
            id2 = np.nonzero(timeB2 > sard_time[-1])[0]
            b2h = image_data[1].shape[0] + offset_min2
            if len(id2) > 0:
                line2_max = min(b2h, id2[0] - ms_lines[1])
            else:
                line2_max = b2h

            idok = np.nonzero((y2 < line2_max))[0]
            xmap, ymap, mask2 = remapImageBandGridMethod(x2[idok], y2[idok], xp2[idok], yp2[idok], 0, 0, block_size,
                                                         im_width, im_height, offset_min2,
                                                         max_error=LV1_2ProductionConstants.REMAP_MAX_ERROR)
            out = cv2.remap(image_data[1], xmap, ymap, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)

            out = MIN_DN * (out < MIN_DN) + \
                  MAX_DN * (out >= MAX_DN) + \
                  out * (out >= MIN_DN) * (out < MAX_DN)
            out = np.round(out).astype('uint8')
            ms_remap_image[:, :, 1] = out

        elif band == 3:
            id3 = np.nonzero(timeB3 > sard_time[-1])[0]
            b3h = image_data[2].shape[0] + offset_min3
            if len(id3) > 0:
                line3_max = min(b3h, id3[0] - ms_lines[2])
            else:
                line3_max = b3h

            idok = np.nonzero((y3 < line3_max))[0]
            xmap, ymap, mask2 = remapImageBandGridMethod(x3[idok], y3[idok], xp2[idok], yp2[idok], 0, 0, block_size,
                                                         im_width, im_height, offset_min3,
                                                         max_error=LV1_2ProductionConstants.REMAP_MAX_ERROR)
            out = cv2.remap(image_data[2], xmap, ymap, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)

            out = MIN_DN * (out < MIN_DN) + \
                  MAX_DN * (out >= MAX_DN) + \
                  out * (out >= MIN_DN) * (out < MAX_DN)
            out = np.round(out).astype('uint8')
            ms_remap_image[:, :, 2] = out


        elif band == 4:

            id4 = np.nonzero(timeB4 > sard_time[-1])[0]
            b4h = image_data[3].shape[0] + offset_min4
            if len(id4) > 0:
                line4_max = min(b4h, id4[0] - ms_lines[3])
            else:
                line4_max = b4h

            idok = np.nonzero((y3 < line4_max))[0]
            xmap, ymap, mask4 = remapImageBandGridMethod(x4[idok], y4[idok], xp2[idok], yp2[idok], 0, 0, block_size,
                                                         im_width, im_height, offset_min4,
                                                         max_error=LV1_2ProductionConstants.REMAP_MAX_ERROR)
            out = cv2.remap(image_data[3], xmap, ymap, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)

            out = MIN_DN * (out < MIN_DN) + \
                  MAX_DN * (out >= MAX_DN) + \
                  out * (out >= MIN_DN) * (out < MAX_DN)
            out = np.round(out).astype('uint8')
            ms_remap_image[:, :, 3] = out
    return ms_remap_image

def buildLV1PanSharpenImage(pansharpen_method, pan_in_file_name, start_sample, pan_line, im_width,
                            im_height, gains, darkcurrs,ms_data, filter2D):
    in_im = gdal.Open(pan_in_file_name + ".tif")
    max_width = in_im.RasterXSize
    band1 = in_im.GetRasterBand(1)
    ger_height = in_im.RasterYSize
    pan_data = np.zeros((im_height, im_width), 'float32')
    print "Perform image filtering...",
    gain_numbers = np.loadtxt(pan_in_file_name + ".gain").astype('int')

    for k in range(0, im_height, LV1_2ProductionConstants.PAN_PROCESS_BOX_SIZE):
        for m in range(0, im_width, LV1_2ProductionConstants.PAN_PROCESS_BOX_SIZE):
            # print "Building block (%d,%d)......" % (k, m)
            y_min = max(0, pan_line + k - LV1_2ProductionConstants.PAN_OVERLAP_SIZE)
            x_min = max(0, m - LV1_2ProductionConstants.PAN_OVERLAP_SIZE + start_sample)
            x_off_l = start_sample + m - x_min
            y_off_l = pan_line + k - y_min
            x_max = min(max_width, m + LV1_2ProductionConstants.PAN_OVERLAP_SIZE +
                        LV1_2ProductionConstants.PAN_PROCESS_BOX_SIZE + start_sample)
            y_max = min(ger_height, min(pan_line + im_height + 20, pan_line + k +
                                        LV1_2ProductionConstants.PAN_OVERLAP_SIZE +
                                        LV1_2ProductionConstants.PAN_PROCESS_BOX_SIZE))
            load_width = x_max - x_min
            load_height = y_max - y_min
            one_block = readDataBand(band1, x_min, y_min, load_width, load_height, gains[-1], darkcurrs[-1],
                                     gain_numbers, im_type="PAN")

            if LV1_2ProductionConstants.DENCONVOLUTION:
                summ = cv2.GaussianBlur(one_block.astype('uint8'), LV1_2ProductionConstants.PAN_GAUSSIAN_SIZE,
                                        LV1_2ProductionConstants.PAN_GAUSSIAN_SIGMA)
                edges = cv2.Canny(summ.astype('uint8'), LV1_2ProductionConstants.PAN_CANNY_TH1,
                                  LV1_2ProductionConstants.PAN_CANNY_TH2, L2gradient=False)
                edges = cv2.filter2D(edges, cv2.CV_8U, LV1_2ProductionConstants.PAN_EDGE_KERNEL)

                kernel = LV1_2ProductionConstants.PAN_SUM_KERNEL
                summ = signal.convolve2d(one_block, kernel, mode='same', fillvalue=0.0)
                gradient = np.abs(one_block - summ) * (edges > 0)

                gradient[0, :] = 0
                gradient[1, :] = 0
                gradient[-1, :] = 0
                gradient[-2, :] = 0
                gradient[:, 0] = 0
                gradient[:, 1] = 0
                gradient[:, -1] = 0
                gradient[:, -2] = 0
                my_filter_im = np.zeros_like(one_block).astype('float32')
                idx, idy = np.nonzero(gradient < LV1_2ProductionConstants.PAN_TH1)
                my_filter_im[idx, idy] = one_block[idx, idy]
                idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH1) * (
                    gradient < LV1_2ProductionConstants.PAN_TH2))
                tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[3], borderType=cv2.BORDER_REFLECT)
                my_filter_im[idx, idy] = tem[idx, idy]
                idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH2) * (
                    gradient < LV1_2ProductionConstants.PAN_TH3))
                tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[4], borderType=cv2.BORDER_REFLECT)
                my_filter_im[idx, idy] = tem[idx, idy]
                idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH3) * (
                    gradient < LV1_2ProductionConstants.PAN_TH4))
                tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[5], borderType=cv2.BORDER_REFLECT)
                my_filter_im[idx, idy] = tem[idx, idy]
                idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH4))
                tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[6], borderType=cv2.BORDER_REFLECT)
                my_filter_im[idx, idy] = tem[idx, idy]
                filtered_im = my_filter_im.copy()
            else:
                filtered_im = one_block
            used_ar = filtered_im[y_off_l:y_off_l + LV1_2ProductionConstants.PAN_PROCESS_BOX_SIZE,
                      x_off_l:x_off_l + LV1_2ProductionConstants.PAN_PROCESS_BOX_SIZE].astype('float32')
            rw, cl = used_ar.shape
            pan_data[k:k + rw, m:m + cl] = used_ar

    if pansharpen_method == pansharpenMethods.BROVEY:
        pansharp_data = broveyPanSharpen(ms_data, pan_data)
    elif pansharpen_method == pansharpenMethods.PCA:
        pansharp_data = pcaPanSharpen(ms_data, pan_data)
    elif pansharpen_method == pansharpenMethods.GRAM_SCHEMIDTH:
        pansharp_data = gramSchmidth(ms_data, pan_data)
    elif pansharpen_method == pansharpenMethods.HIGHPASS_MODULATION:
        pansharp_data = highpassPansharpen(ms_data, pan_data)
    return pansharp_data

def findLV1ToLv2Samples(pan_in_file_name, pan_line,hmin, hmax, current_date, utc_gps, dut1,
                        x2_up_left, y2_up_left, dx2, dy2, zonec, start_sample, im_width,
                        im_height):
    all_file_exist = os.path.isfile(pan_in_file_name + "ger_pair_line%d.txt" % pan_line) and \
                     os.path.isfile(pan_in_file_name + "lv2_pair_min_altitude_line%d.txt" % pan_line) and \
                     os.path.isfile(pan_in_file_name + "lv2_pair_max_altitude_line%d.txt" % pan_line)

    step_sample = LV1_2ProductionConstants.LV1ToLV2_SAMPLE_GRID_SIZE
    step_line = LV1_2ProductionConstants.LV1ToLV2_SAMPLE_GRID_SIZE
    x_sampels = np.hstack((np.arange(0, im_width, step_sample), np.array([im_width - 1])))
    y_sampels = np.hstack((np.arange(0, im_height, step_line), np.array([im_height - 1])))
    num_pairs = len(x_sampels) * len(y_sampels)
    if all_file_exist:
        print "Attempt to load files containing Level 2A and GER pixel paris..."
        ger_pairs = np.loadtxt(pan_in_file_name + "ger_pair_line%d.txt" % (pan_line))
        lv2_pairs_min = np.loadtxt(pan_in_file_name + "lv2_pair_min_altitude_line%d.txt" % (pan_line))
        lv2_pairs_max = np.loadtxt(pan_in_file_name + "lv2_pair_max_altitude_line%d.txt" % (pan_line))
        if (ger_pairs.shape[0] != num_pairs) or (lv2_pairs_max.shape[0] != num_pairs) or (
            lv2_pairs_min.shape[0] != num_pairs):
            all_file_exist = False
    else:
        ger_pairs = []
        lv2_pairs_max = []
        lv2_pairs_min = []
    if not all_file_exist:
        ger_pairs = np.zeros((num_pairs, 2))
        lv2_pairs_min = np.zeros((num_pairs, 2))
        lv2_pairs_max = np.zeros((num_pairs, 2))
        print "The matching pair files have not been created."
        print "Generating the matching pair database."
        cnt = 0
        for s_line in y_sampels:
            print "find matching pairs of line %d" % s_line
            s_samples = x_sampels + start_sample
            lata_min, lona_min, ha = dps.findInterSectionPointArrayGivenAltitude("PAN", pan_in_file_name, s_samples,
                                                                                 [pan_line + s_line], hmin,
                                                                                 current_date, utc_gps, dut1)
            lata_max, lona_max, ha = dps.findInterSectionPointArrayGivenAltitude("PAN", pan_in_file_name, s_samples,
                                                                                 [pan_line + s_line], hmax,
                                                                                 current_date, utc_gps, dut1)

            num_s = s_samples.shape[0]
            x, y, z, zl = utmLatlon.from_latlon(lata_min, lona_min, zonec)
            cols = (x - x2_up_left) / dx2
            rows = (y - y2_up_left) / dy2
            str = cnt * num_s
            stp = str + num_s
            lv2_pairs_min[str:stp, 0] = cols
            lv2_pairs_min[str:stp, 1] = rows

            x, y, z, zl = utmLatlon.from_latlon(lata_max, lona_max, zonec)
            cols = (x - x2_up_left) / dx2
            rows = (y - y2_up_left) / dy2

            lv2_pairs_max[str:stp, 0] = cols
            lv2_pairs_max[str:stp, 1] = rows

            ger_pairs[str:stp, 0] = s_samples - 1
            ger_pairs[str:stp, 1] = s_line
            cnt += 1
        if LV1_2ProductionConstants.SAVED_LV1ToLV2_SAMPLE:
            print "completed...saving to files."
            np.savetxt(pan_in_file_name + "ger_pair_line%d.txt" % (pan_line), ger_pairs)
            np.savetxt(pan_in_file_name + "lv2_pair_min_altitude_line%d.txt" % (pan_line), lv2_pairs_min)
            np.savetxt(pan_in_file_name + "lv2_pair_max_altitude_line%d.txt" % (pan_line), lv2_pairs_max)
    return ger_pairs, lv2_pairs_min, lv2_pairs_max

def buildPanSharpenImageUsingCubicInterpolation(product_level, out_file_name,  pan_in_file_name, ms_in_file_name,
                                                pansharpen_info_dir, beg_line_pan, current_date, utc_gps, dut1,
                                                dem, dem_interpolation_method, gains, darkcurrs, pansharpen_method,
                                                filter2D, start_sample=1, im_width=12000, im_height=12000,
                                                ms_width_max =6000, ms_height_max = 6000):



    pan_line = beg_line_pan
    #ms_lines = beg_line_ms
    end_sample =start_sample + im_width-1
    if (end_sample >12000) or (start_sample<1) :
        print "The intended sample is beyond the scope of the recorded GER file."
    start_sample = start_sample-1
    # compute pan scene information
    sat_times = np.loadtxt(pan_in_file_name + ".tim")
    line_max = len(sat_times)
    im_height = min(line_max - pan_line, im_height)

    #cv2.imwrite(pansharpen_info_dir +"\\pan1.tif", panData.astype('uint8'))
    xul, yul, latul, lonul, xur, yur, latur, lonur, xll, yll, latll, lonll, xlr, ylr, latlr,\
    lonlr, xc, yc , latc, lonc, zonec, heightll, heightul, heightll, heightlr, heightc, zonec, \
    zoneletter_c, x2_up_left, y2_up_left, hmin, hmax = findImageMapInfo(pan_in_file_name, start_sample, end_sample, pan_line,
                                                            im_height, current_date, utc_gps, dut1, dem,
                                                            dem_interpolation_method)


    if LV1_2ProductionConstants.DESCENDING:
        num_lines = np.ceil((yul - ylr) / 2.0 + 1)
        num_samples = np.ceil((xur - xll) / 2.0 + 1)
        lv_width = int(np.ceil(num_samples))
        lv_height = int(np.ceil(num_lines))
        x2_up_left = xll
        y2_up_left = yul
        dx2 = 2.0
        dy2 = -2.
    else:
        num_lines = np.ceil((yll - yur) / 2.0 + 1)
        num_samples = np.ceil((xul - xlr) / 2.0 + 1)
        lv_width = int(np.ceil(num_samples))
        lv_height = int(np.ceil(num_lines))
        x2_up_left = xlr
        y2_up_left = yll
        dx2 = 2.0
        dy2 = -2.0
    lv2_geotrans = [x2_up_left, y2_up_left, dx2, dy2, zonec]
    map_geo_trans = [x2_up_left, y2_up_left, dx2, dy2, zonec, zoneletter_c]


    if not os.path.isfile(out_file_name):

        ms_lines,samples_zero_ms= findBeginLineMS(pansharpen_info_dir, pan_line, ms_in_file_name, heightul, current_date,
                                                  utc_gps, dut1, latul, lonul)
        print ms_lines
        step = 50
        posB1 = np.loadtxt(ms_in_file_name + "B1.pos")
        posB2 = np.loadtxt(ms_in_file_name + "B2.pos")
        posB3 = np.loadtxt(ms_in_file_name + "B3.pos")
        posB4 = np.loadtxt(ms_in_file_name + "B4.pos")
        pos_pan = np.loadtxt(pan_in_file_name + ".pos")
        sat_pos = [posB1, posB2, posB3, posB4, pos_pan]

        timeB1 = np.loadtxt(ms_in_file_name + "B1.tim")
        timeB2 = np.loadtxt(ms_in_file_name + "B2.tim")
        timeB3 = np.loadtxt(ms_in_file_name + "B3.tim")
        timeB4 = np.loadtxt(ms_in_file_name + "B4.tim")
        time_pan = np.loadtxt(pan_in_file_name + ".tim")

        sat_time = [timeB1, timeB2, timeB3, timeB4, time_pan]

        attB1 = np.loadtxt(ms_in_file_name + "B1.att")
        attB2 = np.loadtxt(ms_in_file_name + "B2.att")
        attB3 = np.loadtxt(ms_in_file_name + "B3.att")
        attB4 = np.loadtxt(ms_in_file_name + "B4.att")
        att_pan = np.loadtxt(pan_in_file_name + ".att")
        sat_att = [attB1, attB2, attB3, attB4, att_pan ]





        x1, x2, x3, x4, xp, y1, y2, y3, y4, yp = findMsPanCorrespondingPoints(pansharpen_info_dir , pan_line, ms_in_file_name, pan_in_file_name, step, samples_zero_ms,
                                     ms_lines, sat_pos, sat_time, sat_att, current_date, utc_gps, dut1, dem,
                                     dem_interpolation_method, im_width, im_height)

        print "Load MS Image Data"
        min_line = min(x1.min(), x2.min(), x3.min(), x4.min())
        max_line = max(x1.max(), x2.max(), x3.max(), x4.max())
        if min_line >= 0:
            min_line = 0
        else:
            min_line = int(np.floor(min_line))
        max_line = int(np.ceil(max_line))
        offset_min1 = min_line
        offset_min2 = min_line
        offset_min3 = min_line
        offset_min4 = min_line
        image_data = []
        gain_number = np.loadtxt(ms_in_file_name + "B1.gain")
        for band in [1, 2, 3, 4]:
            im = gdal.Open(ms_in_file_name + "B%d.tif" % band)
            b1 = im.GetRasterBand(1)
            databand =readDataBand(b1, 0,  int(ms_lines[band - 1] + min_line), int(ms_width_max),
                                     int(max_line - min_line), gains[band-1], darkcurrs[band-1],
                                     gain_number,  im_type= "MS")
            image_data.append(databand)


        sard_time = np.loadtxt(ms_in_file_name + "B3sadr_times.txt")
        block_size = im_width
        xp2, yp2 = findAdjustRemapPanPoints(pansharpen_info_dir, pan_in_file_name, start_sample, pan_line, im_width, im_height, gains, darkcurrs,
                                 sard_time, image_data, ms_lines, offset_min1, offset_min2, offset_min3,
                                 offset_min4, x1,y1,x2,y2,x3,y3,x4,y4,xp,yp, block_size, timeB1, timeB2, timeB3, timeB4)

        ms_remap_image = buildRemapMSImage(image_data, ms_lines, offset_min1, offset_min2, offset_min3, offset_min4, x1, y1, x2, y2,
                          x3, y3, x4, y4, xp2, yp2, timeB1, timeB2, timeB3, timeB4, sard_time, im_height,
                          im_width)

        pansharp_im = buildLV1PanSharpenImage(pansharpen_method, pan_in_file_name, start_sample, pan_line,
                                              im_width, im_height, gains, darkcurrs,ms_remap_image,filter2D)

        avg_dem = 0.0

        if product_level == "1A":
            gtiff_driver = gdal.GetDriverByName('GTiff')
            imout = gtiff_driver.Create(out_file_name,im_width, im_height, 4, gdal.GDT_Byte)
            for b in range(4):
                if b == 0:
                    imband = imout.GetRasterBand(3)
                elif b == 2:
                    imband = imout.GetRasterBand(1)
                else:
                    imband = imout.GetRasterBand(b+1)
                imband.WriteArray(pansharp_im[:,:,b])
        elif product_level == "2A":
            tempfile = pansharpen_info_dir + "\\level1.tif"
            gtiff_driver = gdal.GetDriverByName('GTiff')
            imout = gtiff_driver.Create(tempfile , im_width, im_height, 4, gdal.GDT_Byte)
            for b in range(4):
                imband = imout.GetRasterBand(b + 1)
                imband.WriteArray(pansharp_im[:, :, b])
            pansharp_im = None
            image_data = None
            imout = None
            ger_pairs, lv2_pairs_min, lv2_pairs_max = findLV1ToLv2Samples(pan_in_file_name, pan_line, hmin, hmax,
                                                                          current_date, utc_gps, dut1, x2_up_left,
                                                                          y2_up_left, dx2, dy2, zonec, start_sample,
                                                                          im_width, im_height)

            dem_file_name = pan_in_file_name + "DEM_%d.tif" % pan_line
            if not os.path.isfile(dem_file_name):
                print "DEM file do not exist. Interpolate DEM for the LV2 Scene"
                makingDEMData(dem_file_name, lv_width, lv_height, map_geo_trans, dem,
                              dem_interpolation_method=dem_interpolation_method)
            else:
                print "DEM File Exist. LOAD DEM FILE."



            dem_ds_im = gdal.Open(dem_file_name)
            dem_ds = dem_ds_im.GetRasterBand(1)
            band_map_info = findLV2RemapFuncitionPANWithInterpolation(pan_in_file_name, pan_line, ger_pairs, lv2_pairs_min,
                                                                      lv2_pairs_max,
                                                                      lv2_geotrans, dem_ds, hmin, hmax, current_date, utc_gps,
                                                                      dut1, lv_width, lv_height, im_width, im_height,
                                                                      lv2_step_size=LV1_2ProductionConstants.LV2ToLV1_SAMPLE_GRID_SIZE)


            dst_ds = gtiff_driver.Create(out_file_name, lv_width, lv_height, 4, gdal.GDT_Byte)

            imout = gdal.Open(tempfile)

            for band in [1, 2, 3, 4]:
                out_data = np.zeros((lv_height, lv_width), 'uint8')
                mask_data = np.zeros((lv_height, lv_width), 'uint8')
                MIN_DN = LV1_2ProductionConstants.MIN_DN
                MAX_DN = LV1_2ProductionConstants.MAX_DN
                lv1_band = imout.GetRasterBand(band)
                databand = lv1_band.ReadAsArray()
                if band == 1:
                    dst_band = dst_ds.GetRasterBand(3)
                elif band == 3:
                    dst_band = dst_ds.GetRasterBand(1)
                else:
                    dst_band = dst_ds.GetRasterBand(band)


                for line, sample, line_max, samp_max, x_file_name, y_file_name in band_map_info:

                    if (x_file_name is not None) and (y_file_name is not None):

                        X = np.load(x_file_name)
                        Y = np.load(y_file_name)
                        Xmin = int(X.min())
                        Xmax = int(np.ceil(X.max()))
                        Ymin = int(Y.min())
                        Ymax = int(np.ceil(Y.max()))
                        strx = int(max(Xmin, 0))
                        stpx = min(Xmax + 1, im_width)
                        stry = max(Ymin, 0)
                        stpy = min(Ymax + 1, im_height)
                        temp = np.zeros_like(X)
                        if (strx < stpx) & (stry < stpy):
                            original = databand[stry:stpy, strx:stpx]
                            remap_out = cv2.remap(original, X - strx, Y - stry, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                                  borderValue=0)
                            temp[(X >= X.min()) * (X <= X.max()) * (Y >= Y.min()) * (Y <= Y.max())] = remap_out.flatten()

                            # band3.WriteArray(sample, line, ms_band_data)
                            mk = (X > 0) * (X < im_width) * (Y > 0) * (Y < im_height)
                            temp = MIN_DN * (temp < MIN_DN) + MAX_DN * (temp > MAX_DN) + temp * (temp >= MIN_DN) * (temp <= MAX_DN)
                            temp = np.round(temp).astype('uint8')
                            # temp = temp * mk

                            out_data[line:line + line_max, sample:sample + samp_max] = temp * mk
                            mask_data[line:line + line_max, sample:sample + samp_max] = mk
                        if band == 4:
                            os.remove(x_file_name)
                            os.remove(y_file_name)
                    else:
                        mask_data[line:line + line_max, sample:sample + samp_max] *= 0
                dst_band.WriteArray(out_data, 0, 0)
            imout = None
            os.remove(tempfile)


            num_nonzero_pixels = 0.0
            block_num_lines = 1000
            block_num_pixels = 1000
            for line in range(0, lv_height, block_num_lines):
                for sample in range(0, lv_width, block_num_pixels):
                    line_max = min((lv_height - line), block_num_lines)
                    samp_max = min(lv_width - sample, block_num_pixels)
                    h = dem_ds.ReadAsArray(sample, line, samp_max, line_max)
                    data = out_data[line:(line + line_max), sample:(sample + samp_max)]
                    mask = (data != 0).astype('float32')
                    avg_dem += (h * mask).sum()
                    num_nonzero_pixels += mask.sum()
            avg_dem /= num_nonzero_pixels
    else:
        dem_file_name = pan_in_file_name + "DEM_%d.tif" % pan_line
        if not os.path.isfile(dem_file_name):
            print "DEM file do not exist. Interpolate DEM for the LV2 Scene"
            makingDEMData(dem_file_name, lv_width, lv_height, map_geo_trans, dem,
                          dem_interpolation_method=dem_interpolation_method)
        else:
            print "DEM File Exist. LOAD DEM FILE."

        dem_ds_im = gdal.Open(dem_file_name)
        dem_ds = dem_ds_im.GetRasterBand(1)
        num_nonzero_pixels = 0.0
        block_num_lines = 1000
        block_num_pixels = 1000
        avg_dem = 0.0
        dst_ds = gdal.Open(out_file_name, gdal.GA_Update)
        band1 = dst_ds.GetRasterBand(1)
        out_data = band1.ReadAsArray()
        for line in range(0, lv_height, block_num_lines):
            for sample in range(0, lv_width, block_num_pixels):
                line_max = min((lv_height - line), block_num_lines)
                samp_max = min(lv_width - sample, block_num_pixels)
                h = dem_ds.ReadAsArray(sample, line, samp_max, line_max)
                data = out_data[line:(line + line_max), sample:(sample + samp_max)]
                mask = (data != 0).astype('float32')
                avg_dem += (h * mask).sum()
                num_nonzero_pixels += mask.sum()
        avg_dem /= num_nonzero_pixels


    cl1 = np.round((xul-x2_up_left)/dx2)+1
    rw1 = np.round((yul-y2_up_left)/dy2)+1
    x1  = x2_up_left + dx2*cl1
    y1 = y2_up_left + dy2*rw1
    lat1,lon1 = utm.to_latlon(x1,y1,zonec,zoneletter_c)
    #lat1 = lat1[0]
    #lon1 = lon1[0]

    cl2 = np.round((xur-x2_up_left)/dx2)+1
    rw2 = np.round((yur-y2_up_left)/dy2)+1
    x2  = x2_up_left + dx2*cl2
    y2 = y2_up_left + dy2*rw2
    lat2,lon2 = utm.to_latlon(x2,y2,zonec,zoneletter_c)
    #lat2 = lat2[0]
    #lon2 = lon2[0]

    cl3 = np.round((xll-x2_up_left)/dx2)+1
    rw3 = np.round((yll-y2_up_left)/dy2)+1
    x3  = x2_up_left + dx2*cl3
    y3 = y2_up_left + dy2*rw3
    lat3,lon3 = utm.to_latlon(x3,y3,zonec,zoneletter_c)
    #lat3 = lat3[0]
    #lon3 = lon3[0]

    cl4 = np.round((xlr-x2_up_left)/dx2)+1
    rw4 = np.round((ylr-y2_up_left)/dy2)+1
    x4  = x2_up_left + dx2*cl4
    y4 = y2_up_left + dy2*rw4
    lat4,lon4 = utm.to_latlon(x4,y4,zonec,zoneletter_c)
    #lat4 = lat4[0]
    #lon4 = lon4[0]

    cl5 = np.round((xc-x2_up_left)/dx2)+1
    rw5 = np.round((yc-y2_up_left)/dy2)+1
    x5  = x2_up_left + dx2*cl5
    y5 = y2_up_left + dy2*rw5
    lat5,lon5 = utm.to_latlon(x5,y5,zonec,zoneletter_c)
    #lat5 = lat5[0]
    #lon5 = lon5[0]
    print "Upper left vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw1,cl1)
    print "FRAME_X: %e, FRAME_COL: %e"%(x1,y1)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon1,lat1)
    print ".........................................................."

    print "Upper right vertex......................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw2,cl2)
    print "FRAME_X: %e, FRAME_COL: %e"%(x2,y2)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon2,lat2)
    print ".........................................................."

    print "Lower left vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw3,cl3)
    print "FRAME_X: %e, FRAME_COL: %e"%(x3,y3)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon3,lat3)
    print ".........................................................."

    print "Lower right vertex........................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw4,cl4)
    print "FRAME_X: %e, FRAME_COL: %e"%(x4,y4)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon4,lat4)
    print ".........................................................."

    print "Scene center.............................................."
    print "FRAME_ROW: %d, FRAME_COL: %d"%(rw5,cl5)
    print "FRAME_X: %e, FRAME_COL: %e"%(x5,y5)
    print "FRAME_LON: %3.6f, FRAME_LAT: %3.6f"%(lon5,lat5)
    print ".........................................................."



    if product_level == "2A":
        srs = osr.SpatialReference()
        srs.SetWellKnownGeogCS("WGS84")
        if (lat5 >= 0):
            srs.SetUTM(zonec, 1)
        else:
            srs.SetUTM(zonec, 0)
        dst_ds.SetProjection(srs.ExportToWkt())
        dst_ds.SetGeoTransform([x2_up_left, 2.0, 0, y2_up_left, 0, -2.0])
    map_info = [x2_up_left, y2_up_left, 2.0, 2.0, avg_dem, zonec, (lat5 >= 0)]
    upleft =  [[cl1,rw1],[x1,y1],[lon1,lat1]]
    upright = [[cl2,rw2],[x2,y2],[lon2,lat2]]
    midpoint =[[cl5,rw5],[x5,y5],[lon5,lat5]]
    lowleft = [[cl3,rw3],[x3,y3],[lon3,lat3]]
    lowright= [[cl4,rw4],[x4,y4],[lon4,lat4]]
    return upleft, upright, midpoint, lowleft, lowright, map_info



