"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import lxml.etree as et
import datetime
import numpy as np
import re
import os
import shutil
import makePDFfile
from systemConstants import LV1_2ProductionConstants as LV1AConstants
import time

def dimap_create(save_loaction,rev_num,sensor_mode,grid_ref,lines_list,full_path,CPF_path,angle_list,start_sample,
                 im_width,im_height,band_bad_lines, band_degraded_lines,  line_shifted = 0,job_time = None):
    xml_save_location = save_loaction + "/METADATA.DIM"

    process_level = "1A"
    # rev_num = "32823"
    # sensor_mode = "MS"
    # grid_ref = "0257-0310"
    if sensor_mode == "MS":
        start_line_B1 = lines_list[0]
        start_line_B2 = lines_list[1]
        start_line_B3 = lines_list[2]
        start_line_B4 = lines_list[3]
        b1_offset = start_line_B1-start_line_B3
        b2_offset = start_line_B2-start_line_B3
        b4_offset = start_line_B4-start_line_B3
    elif sensor_mode == "PAN" :
        start_line = lines_list[0]



    upleft,upright,midpoint,lowleft,lowright, view_angles, sat_angles, sat_altitude, sun_angles, orientation = angle_list
    sensor_mode = sensor_mode.upper()
    ger_file_list = []
    for filename in os.listdir(full_path) :
        base,ext = os.path.splitext(filename)
        #print base, ext
        if ext.lower() == ".adb":
            ger_file = base +ext
            ger_file_list.append(ger_file)
    if sensor_mode == "MS" :
        if len(ger_file_list) > 0 :
            ger_name = ger_file_list[2].replace(".adb","")
        GER_extract_path = full_path+"/"+ger_name
    elif sensor_mode == "PAN":
        if len(ger_file_list) > 0 :
            ger_name = ger_file_list[0].replace(".adb","")
        GER_extract_path = full_path+"/"+ger_name

    print GER_extract_path

    ############### find igps time ###############
    print "collecting IGPST"
    sofr = open(GER_extract_path+".sofr",'rb')
    while 1:
        line = sofr.readline()
        if not line.find("IGPSTYear") == -1:
            year = line.split(":")[1].strip()
        elif not line.find("IGPSTDay") == -1:
            doy = line.split(":")[1].strip()
        elif not line.find("IGPSTHour") == -1:
            hour = line.split(":")[1].strip()
        elif not line.find("IGPSTMinute") == -1:
            minute = line.split(":")[1].strip()
        elif not line.find("IGPSTSec") == -1:
            sec = line.split(":")[1].strip()
            break
    date =  datetime.date(int(year), 1, 1) + datetime.timedelta(int(doy) - 1)
    year = date.strftime('%Y')
    month = date.strftime('%m')
    day = date.strftime('%d')
    IGPS_time = hour.zfill(2) + ":" +minute.zfill(2) + ":" + "%.6f"%float(sec)
    # print IGPS_time


    ############### find line time ###############
    print "collecting Line dating"
    def actual_time(tim):
        t1 = tim
        hour1 = int(np.floor(t1/3600.0))
        t1 -= hour1*3600.0
        minute1 = int(np.floor(t1)/60.0)
        second1 = t1 - minute1*60.0
        micsec1 = second1-int(np.floor(second1))
        micsec1 = int(micsec1*1e6)
        second1 = int(second1)
        return [hour1,minute1,second1,micsec1]
    tim_file = np.loadtxt(GER_extract_path+".tim")

    prod_time = time.time()

    if sensor_mode == "MS":
        cen_time = actual_time(tim_file[start_line_B3+2999-1])
        beg_time = actual_time(tim_file[start_line_B3-1])
        end_time = actual_time(tim_file[start_line_B3+5999-1])
    elif sensor_mode == "PAN" :
        cen_time = actual_time(tim_file[start_line+5999-1])
        beg_time = actual_time(tim_file[start_line-1])
        end_time = actual_time(tim_file[start_line+1999-1])
    # print "SCENE T1 M " + year +"/"+ month +"/"+ day +" "+ str(time[0])+":"+str(time[1])+":"+str(time[2])+"."+ str(time[3])[0]
    tim_file = None


    ############### find LCNT,filename,Comp_Ratio ###############
    print "collecting others information"
    sgr_file = open(GER_extract_path+".sgr",'r')
    sgr_line = sgr_file.readlines()
    for i in range(len(sgr_line)-1):
        if not sgr_line[i].find("Beg_LineCount") == -1:
            Line_counter = sgr_line[i].split(":")[1].strip()
        if not sgr_line[i].find("File_Name") == -1:
            filename_num = sgr_line[i].split(":")[1].strip()
        if not sgr_line[i].find("Comp_Ratio") == -1:
            comp_Ratio = sgr_line[i].split(":")[1].strip()
        if not sgr_line[i].find("Beg_Format") == -1:
            file_beg_sfsc = int(sgr_line[i].split(":")[1].strip())
    # print Line_counter,filename_num,comp_Ratio,file_beg_sfsc



    ############### find satellite position information and kept in array ###############
    print "collecting satellite position"
    sadr_time = []
    sadr_pos = []
    sadr_att = []
    sadr_vel = []
    sadr_file = open(GER_extract_path+".sadr",'r')
    sadr_read = sadr_file.read()
    sadr_lines = re.findall(r"\[[0-99999]*\][^\[]*",sadr_read)
    for sadr_line in sadr_lines:
        sadr_line_split = sadr_line.splitlines()
        for i in sadr_line_split:
            if not i.find("Date") == -1:
                sadr_tim =i.split(":")[1].strip()
                sadr_tim = sadr_tim[0:4] +"-"+ sadr_tim[4:6] +"-"+ sadr_tim[6:8] +" "+ sadr_tim[8:10] +":"+ sadr_tim[10:12] +":"+ "%.6f"%float(sadr_tim[12:len(sadr_tim)])
            if not i.find("Attitude_Q1") == -1:
                q1 = i.split(":")[1].strip()
            if not i.find("Attitude_Q2") == -1:
                q2 = i.split(":")[1].strip()
            if not i.find("Attitude_Q3") == -1:
                q3 = i.split(":")[1].strip()
            if not i.find("Attitude_Q4") == -1:
                q4 = i.split(":")[1].strip()
            if not i.find("Position_Px") == -1:
                px = i.split(":")[1].strip()
            if not i.find("Position_Py") == -1:
                py = i.split(":")[1].strip()
            if not i.find("Position_Pz") == -1:
                pz = i.split(":")[1].strip()
            if not i.find("Velocity_Vx") == -1:
                vx = i.split(":")[1].strip()
            if not i.find("Velocity_Vy") == -1:
                vy = i.split(":")[1].strip()
            if not i.find("Velocity_Vz") == -1:
                vz = i.split(":")[1].strip()
        sadr_time.append(sadr_tim)
        sadr_att.append([q1,q2,q3,q4])
        sadr_pos.append([px,py,pz])
        sadr_vel.append([vx,vy,vz])



    ############### find gain number used in adb file 4 bands ###############
    print "collecting gain information for each band"
    if sensor_mode == "MS":

        adb_file_b1 = open(GER_extract_path[:-2]+"B1.adb",'r')
        adb_cnt = 0
        while adb_cnt<100:
            this_line = adb_file_b1.readline()
            if not this_line.find("gain") == -1:
                gain_num_b1 = this_line[this_line.find("gain")+6:this_line.find("gain")+8]
                gain_num_b1 = int(gain_num_b1)+1
                if sensor_mode == "PAN":
                    gain_num_b1 = this_line[this_line.find("gain")+8:this_line.find("gain")+10]
                    gain_num_b1 = int(gain_num_b1)+1
                break
            adb_cnt+=1

        adb_file_b2 = open(GER_extract_path[:-2]+"B2.adb",'r')
        adb_cnt = 0
        while adb_cnt<100:
            this_line = adb_file_b2.readline()
            if not this_line.find("gain") == -1:
                gain_num_b2 = this_line[this_line.find("gain")+6:this_line.find("gain")+8]
                gain_num_b2 = int(gain_num_b2)+1
                break
            adb_cnt+=1

        adb_file_b3 = open(GER_extract_path[:-2]+"B3.adb",'r')
        adb_cnt = 0
        while adb_cnt<100:
            this_line = adb_file_b3.readline()
            if not this_line.find("gain") == -1:
                gain_num_b3 = this_line[this_line.find("gain")+6:this_line.find("gain")+8]
                gain_num_b3 = int(gain_num_b3)+1
                break
            adb_cnt+=1

        adb_file_b4 = open(GER_extract_path[:-2]+"B4.adb",'r')
        adb_cnt = 0
        while adb_cnt<100:
            this_line = adb_file_b4.readline()
            if not this_line.find("gain") == -1:
                gain_num_b4 = this_line[this_line.find("gain")+6:this_line.find("gain")+8]
                gain_num_b4 = int(gain_num_b4)+1
                break
            adb_cnt+=1

        gain_num =[gain_num_b1,gain_num_b2,gain_num_b3,gain_num_b4]

    if sensor_mode == "PAN":
        adb_file = open(GER_extract_path+".adb",'r')
        adb_cnt = 0
        while adb_cnt<100:
            this_line = adb_file.readline()
            if not this_line.find("gain") == -1:
                if sensor_mode == "PAN":
                    gain_num = this_line[this_line.find("gain")+8:this_line.find("gain")+10]
                    gain_num = int(gain_num)+1
                break
            adb_cnt+=1





    ############### find infomation in CPF file ###############
    print "collecting information from CPF file"
    cpf_tree = et.parse(CPF_path)

    DatationParameters = cpf_tree.find(".//DatationParameters")
    DatationParameters_list = []
    for i in DatationParameters:
        DatationParameters_list.append(i.text.strip())
    ut1_utc = "%1.17e"%float(DatationParameters_list[0])
    utc_gpst = "%1.17e"%((-1)*float(DatationParameters_list[1]))

    valid_time = cpf_tree.find(".//ValidityStartPeriod")
    valid_time_list= []
    for i in valid_time:
        valid_time_list.append(i.text)
    valid_date = valid_time_list[0][0:4]+"-"+valid_time_list[0][4:6]+"-"+valid_time_list[0][6:8]
    valid_time = valid_time_list[1][0:2]+":"+valid_time_list[1][2:4]+":"+valid_time_list[1][4:6]+".000000"
    CPF_valid_time = valid_date+" "+valid_time

    rotAngle = cpf_tree.find(".//RotationRLOsToRPIP")
    rotAngle_list = []
    for i in rotAngle:
        rotAngle_list.append(i.text.strip())
    # print rotAngle_list
    if sensor_mode == "MS":
        roll,pitch,yaw = rotAngle_list[3],rotAngle_list[4],rotAngle_list[5]
    if sensor_mode == "PAN":
        roll,pitch,yaw = rotAngle_list[0],rotAngle_list[1],rotAngle_list[2]

    if sensor_mode == "MS":
        gain_info_allband = []
        band_tag = ["B1","B2","B3","B4"]
        for band_n in range(4):
            Gain_info = cpf_tree.find(".//"+band_tag[band_n]+"//G"+str(gain_num[band_n]))
            gain_info_list = []
            for i in Gain_info:
                gain_info_list.append(i.text)
            gain_info_list[2] = 1/np.float32(gain_info_list[2].split(","))
            gain_info_list[3] = np.float32(gain_info_list[3].split(","))*gain_info_list[2]
            gain_info_allband.append(gain_info_list)
    if sensor_mode == "PAN":
        gain_info_allband = []
        Gain_info = cpf_tree.find(".//PAN//G"+str(gain_num))
        gain_info_list = []
        for i in Gain_info:
            gain_info_list.append(i.text)
        gain_info_list[2] = 1/np.float32(gain_info_list[2].split(","))
        gain_info_list[3] = np.float32(gain_info_list[3].split(","))*gain_info_list[2]
        gain_info_allband.append(gain_info_list)

            # print gain_info_list[0],gain_info_list[1],len(gain_info_list[2].split(","))
    # print gain_info_allband[0][0],gain_info_allband[0][2][0:10],gain_info_allband[0][3][0:10]












    ################################## DIMAP Creaste Start #####################################################
    print "Creating DIMAP..."

    Dimap_Document = et.Element("Dimap_Document")
    Metadata_Id = et.SubElement(Dimap_Document,"Metadata_Id")
    Metadat_Format = et.SubElement(Metadata_Id,"Metadata_Format",version="1.1")
    Metadat_Format.text = "DIMAP"
    Metadata_Profile = et.SubElement(Metadata_Id,"Metadata_Profile")
    Metadata_Profile.text = "THEOS1_1A_SCENE"







    Dataset_Id = et.SubElement(Dimap_Document,"Dataset_Id")
    DATASET_NAME = et.SubElement(Dataset_Id,"DATASET_NAME")
    if sensor_mode == "MS":
        DATASET_NAME.text = "SCENE T1 M %4d//%02d//%02d" %(int(year), int(month), int(day))  \
                            + " %02d:%02d:%02.1f" % (cen_time[0], cen_time[1], cen_time[2] + cen_time[3]/1000000.0)\
                            + " " + grid_ref + " " + str(line_shifted)#
    if sensor_mode == "PAN":
        DATASET_NAME.text = "SCENE T1 P %4d//%02d//%02d" %(int(year), int(month), int(day))  \
                            + " %02d:%02d:%02.1f" % (cen_time[0], cen_time[1], cen_time[2] + cen_time[3]/1000000.0)\
                            + " " + grid_ref + " " + str(line_shifted)#
                            #+ year +"/"+ month +"/"+ day +" "+ str(cen_time[0])+":"+str(cen_time[1])+":"+str(cen_time[2])+"."+ str(cen_time[3])[0] + " " + grid_ref + " "+str(line_shifted)
    DATASET_QL_FORMAT = et.SubElement(Dataset_Id, "DATASET_QL_FORMAT", version="6.b")
    DATASET_QL_FORMAT.text = "JPEG"
    DATASET_QL_PATH = et.SubElement(Dataset_Id, "DATASET_QL_PATH",href="PREVIEW.JPG")
    DATASET_TN_FORMAT = et.SubElement(Dataset_Id, "DATASET_TN_FORMAT", version="6.b")
    DATASET_TN_FORMAT.text = "JPEG"
    DATASET_TN_PATH = et.SubElement(Dataset_Id, "DATASET_TN_PATH",href="ICON.JPG")
    COPYRIGHT = et.SubElement(Dataset_Id, "COPYRIGHT")
    prod_time = time.time()
    prod_asct = time.gmtime(prod_time)
    prod_y = prod_asct.tm_year - 2000
    COPYRIGHT.text = "(c) GISTDA - "+str(prod_y)








    Dataset_Frame = et.SubElement(Dimap_Document,"Dataset_Frame")
    Vertex = et.SubElement(Dataset_Frame,"Vertex")

    FRAME_LON = et.SubElement(Vertex,"FRAME_LON")
    FRAME_LON.text = " %3.6f" % (upleft[1][0])
    FRAME_LAT = et.SubElement(Vertex,"FRAME_LAT")
    FRAME_LAT.text = " %3.6f" % (upleft[0][0])
    FRAME_ROW = et.SubElement(Vertex,"FRAME_ROW")
    FRAME_ROW.text = "1"
    FRAME_COL = et.SubElement(Vertex,"FRAME_COL")
    FRAME_COL.text = "1"

    Vertex = et.SubElement(Dataset_Frame,"Vertex")
    FRAME_LON = et.SubElement(Vertex,"FRAME_LON")
    FRAME_LON.text = " %3.6f" % (upright[1][0])
    FRAME_LAT = et.SubElement(Vertex,"FRAME_LAT")
    FRAME_LAT.text = " %3.6f" % (upright[0][0])
    FRAME_ROW = et.SubElement(Vertex,"FRAME_ROW")
    FRAME_ROW.text = "1"
    FRAME_COL = et.SubElement(Vertex,"FRAME_COL")
    if sensor_mode == "MS":
        FRAME_COL.text = str(min(6000,im_width))
    if sensor_mode == "PAN":
        FRAME_COL.text = str(min(12000,im_width))

    Vertex = et.SubElement(Dataset_Frame,"Vertex")
    FRAME_LON = et.SubElement(Vertex,"FRAME_LON")
    FRAME_LON.text = " %3.6f" % (lowleft[1][0])
    FRAME_LAT = et.SubElement(Vertex,"FRAME_LAT")
    FRAME_LAT.text = " %3.6f" % (lowleft[0][0])
    FRAME_ROW = et.SubElement(Vertex,"FRAME_ROW")
    if sensor_mode == "MS":
        FRAME_ROW.text = str(min(6000,im_height))
    if sensor_mode == "PAN":
        FRAME_ROW.text = str(min(12000,im_height))
    FRAME_COL = et.SubElement(Vertex,"FRAME_COL")
    FRAME_COL.text = "1"

    Vertex = et.SubElement(Dataset_Frame,"Vertex")
    FRAME_LON = et.SubElement(Vertex,"FRAME_LON")
    FRAME_LON.text = str(lowright[1][0])
    FRAME_LAT = et.SubElement(Vertex,"FRAME_LAT")
    FRAME_LAT.text = str(lowright[0][0])
    FRAME_ROW = et.SubElement(Vertex,"FRAME_ROW")
    if sensor_mode == "MS":
        FRAME_ROW.text = str(min(6000,im_height))
    if sensor_mode == "PAN":
        FRAME_ROW.text = str(min(12000,im_height))
    FRAME_COL = et.SubElement(Vertex,"FRAME_COL")
    if sensor_mode == "MS":
        FRAME_COL.text = str(min(6000,im_width))
    if sensor_mode == "PAN":
        FRAME_COL.text = str(min(12000,im_width))

    Vertex = et.SubElement(Dataset_Frame,"Scene_Center")
    FRAME_LON = et.SubElement(Vertex,"FRAME_LON")
    FRAME_LON.text = " %3.6f" % (midpoint[1][0])
    FRAME_LAT = et.SubElement(Vertex,"FRAME_LAT")
    FRAME_LAT.text = " %3.6f" % (midpoint[0][0])
    FRAME_ROW = et.SubElement(Vertex,"FRAME_ROW")
    if sensor_mode == "MS":
        FRAME_ROW.text = str(min(6000/2,im_height/2))
    if sensor_mode == "PAN":
        FRAME_ROW.text = str(min(12000/2,im_height/2))
    FRAME_COL = et.SubElement(Vertex,"FRAME_COL")
    if sensor_mode == "MS":
        FRAME_COL.text = str(min(6000/2,im_width/2))
    if sensor_mode == "PAN":
        FRAME_COL.text = str(min(12000/2,im_width/2))
    SCENE_ORIENTATION = et.SubElement(Dataset_Frame,"SCENE_ORIENTATION")
    SCENE_ORIENTATION.text = " %1.16e" % (orientation[0])









    Dataset_Sources = et.SubElement(Dimap_Document,"Dataset_Sources")
    Source_Information = et.SubElement(Dataset_Sources,"Source_Information")
    SOURCE_TYPE = et.SubElement(Source_Information,"SOURCE_TYPE")
    SOURCE_TYPE.text = "SCENE"
    SOURCE_ID = et.SubElement(Source_Information,"SOURCE_ID")
    if sensor_mode == "MS":
        SOURCE_ID.text = "SCENE T1 M %4d//%02d//%02d" %(int(year), int(month), int(day))  \
                            + " %02d:%02d:%02.1f" % (cen_time[0], cen_time[1], cen_time[2] + cen_time[3]/1000000.0)\
                            + " " + grid_ref + " " + str(line_shifted)#" + year +"/"+ month +"/"+ day +" "+ str(cen_time[0])+":"+str(cen_time[1])+":"+str(cen_time[2])+"."+ str(cen_time[3])[0] + " " + grid_ref + " "+str(line_shifted)
    if sensor_mode == "PAN":
        SOURCE_ID.text = "SCENE T1 P %4d//%02d//%02d" %(int(year), int(month), int(day))  \
                            + " %02d:%02d:%02.1f" % (cen_time[0], cen_time[1], cen_time[2] + cen_time[3]/1000000.0)\
                            + " " + grid_ref + " " + str(line_shifted)#" + year +"/"+ month +"/"+ day +" "+ str(cen_time[0])+":"+str(cen_time[1])+":"+str(cen_time[2])+"."+ str(cen_time[3])[0] + " " + grid_ref + " "+str(line_shifted)
    SOURCE_DESCRIPTION = et.SubElement(Source_Information,"SOURCE_DESCRIPTION")
    SOURCE_DESCRIPTION.text = "Raw Level Data Format"
    Scene_Source = et.SubElement(Source_Information,"Scene_Source")
    GRID_REFERENCE = et.SubElement(Scene_Source,"GRID_REFERENCE")
    GRID_REFERENCE.text = grid_ref
    SHIFT_VALUE = et.SubElement(Scene_Source,"SHIFT_VALUE")
    SHIFT_VALUE.text = str(line_shifted)
    IMAGING_DATE = et.SubElement(Scene_Source,"IMAGING_DATE")
    IMAGING_DATE.text = year +"-"+ month +"-"+ day
    IMAGING_TIME = et.SubElement(Scene_Source,"IMAGING_TIME")
    IMAGING_TIME.text = str(cen_time[0])+":"+str(cen_time[1])+":"+str(cen_time[2])+"."+ str(cen_time[3])
    MISSION = et.SubElement(Scene_Source,"MISSION")
    MISSION.text = "THEOS"
    MISSION_INDEX = et.SubElement(Scene_Source,"MISSION_INDEX")
    MISSION_INDEX.text = "1"
    INSTRUMENT = et.SubElement(Scene_Source,"INSTRUMENT")
    INSTRUMENT.text = "TOP"
    INSTRUMENT_INDEX = et.SubElement(Scene_Source,"INSTRUMENT_INDEX")
    IMAGING_MODE = et.SubElement(Scene_Source,"IMAGING_MODE")
    if sensor_mode == "MS":
        INSTRUMENT_INDEX.text = "2"
        IMAGING_MODE.text = "MS"
    if sensor_mode == "PAN":
        INSTRUMENT_INDEX.text = "1"
        IMAGING_MODE.text = "PAN"
    SCENE_PROCESSING_LEVEL = et.SubElement(Scene_Source,"SCENE_PROCESSING_LEVEL")
    SCENE_PROCESSING_LEVEL.text = "0"
    VIEWING_ANGLE_ALONG_TRACK = et.SubElement(Scene_Source,"VIEWING_ANGLE_ALONG_TRACK")
    VIEWING_ANGLE_ALONG_TRACK.text = " %3.6f" % (view_angles[0])
    VIEWING_ANGLE_ACROSS_TRACK = et.SubElement(Scene_Source,"VIEWING_ANGLE_ACROSS_TRACK")
    VIEWING_ANGLE_ACROSS_TRACK.text =" %3.6f" % (view_angles[1])
    SATELLITE_INCIDENCE_ANGLE = et.SubElement(Scene_Source,"SATELLITE_INCIDENCE_ANGLE")
    SATELLITE_INCIDENCE_ANGLE.text = " %3.6f" % (sat_angles[0])
    SATELLITE_AZIMUTH_ANGLE = et.SubElement(Scene_Source,"SATELLITE_AZIMUTH_ANGLE")
    SATELLITE_AZIMUTH_ANGLE.text = " %3.6f" % (sat_angles[1][0])
    SUN_AZIMUTH = et.SubElement(Scene_Source,"SUN_AZIMUTH")
    SUN_AZIMUTH.text = " %3.6f" % (sun_angles[0][0])
    SUN_ELEVATION = et.SubElement(Scene_Source,"SUN_ELEVATION")
    SUN_ELEVATION.text = " %3.6f" % (sun_angles[1][0])
    REVOLUTION_NUMBER = et.SubElement(Scene_Source,"REVOLUTION_NUMBER")
    REVOLUTION_NUMBER.text = rev_num
    THEORETICAL_RESOLUTION = et.SubElement(Scene_Source,"THEORETICAL_RESOLUTION",UNIT="METERS")
    if sensor_mode == "MS":
        THEORETICAL_RESOLUTION.text = "15"
    if sensor_mode == "PAN":
        THEORETICAL_RESOLUTION.text = "2"







    Coordinate_Reference_System = et.SubElement(Dimap_Document,"Coordinate_Reference_System")
    GEO_TABLES = et.SubElement(Coordinate_Reference_System,"GEO_TABLES",version="5.2")
    GEO_TABLES.text = "EPSG"
    Horizontal_CS = et.SubElement(Coordinate_Reference_System,"Horizontal_CS")
    HORIZONTAL_CS_TYPE = et.SubElement(Horizontal_CS,"HORIZONTAL_CS_TYPE")
    HORIZONTAL_CS_TYPE.text = "GEOGRAPHIC"
    HORIZONTAL_CS_CODE = et.SubElement(Horizontal_CS,"HORIZONTAL_CS_CODE")
    HORIZONTAL_CS_CODE.text = "epsg:4326"
    HORIZONTAL_CS_NAME = et.SubElement(Horizontal_CS,"HORIZONTAL_CS_NAME")
    HORIZONTAL_CS_NAME.text = "WGS 84"








    Raster_CS = et.SubElement(Dimap_Document,"Raster_CS")
    RASTER_CS_TYPE = et.SubElement(Raster_CS,"RASTER_CS_TYPE")
    if process_level == "1A":
        RASTER_CS_TYPE.text = "POINT"
    if process_level == "2A":
        RASTER_CS_TYPE.text = "CELL"
    PIXEL_ORIGIN = et.SubElement(Raster_CS,"PIXEL_ORIGIN")
    PIXEL_ORIGIN.text = str(start_sample)










    Geoposition = et.SubElement(Dimap_Document, "Geoposition")
    Geoposition_Points = et.SubElement(Geoposition,"Geoposition_Points")

    Tie_Point = et.SubElement(Geoposition_Points,"Tie_Point")
    TIE_POINT_CRS_X = et.SubElement(Tie_Point,"TIE_POINT_CRS_X")
    TIE_POINT_CRS_X.text = " %3.6f" % (upright[1][0])
    TIE_POINT_CRS_Y = et.SubElement(Tie_Point,"TIE_POINT_CRS_Y")
    TIE_POINT_CRS_Y.text = " %3.6f" %(upright[0][0])
    TIE_POINT_DATA_X = et.SubElement(Tie_Point,"TIE_POINT_DATA_X")
    TIE_POINT_DATA_X.text = " 1.0000000000000000e+00"
    TIE_POINT_DATA_Y = et.SubElement(Tie_Point,"TIE_POINT_DATA_Y")
    TIE_POINT_DATA_Y.text = " 1.0000000000000000e+00"

    Tie_Point = et.SubElement(Geoposition_Points,"Tie_Point")
    TIE_POINT_CRS_X = et.SubElement(Tie_Point,"TIE_POINT_CRS_X")
    TIE_POINT_CRS_X.text = " %3.6f" %(upleft[1][0])
    TIE_POINT_CRS_Y = et.SubElement(Tie_Point,"TIE_POINT_CRS_Y")
    TIE_POINT_CRS_Y.text = " %3.6f" %(upleft[0][0])
    TIE_POINT_DATA_X = et.SubElement(Tie_Point,"TIE_POINT_DATA_X")
    if sensor_mode == "MS":
        TIE_POINT_DATA_X.text = " 6.0000000000000000e+03"
    if sensor_mode == "PAN":
        TIE_POINT_DATA_X.text = " 1.2000000000000000e+04"
    TIE_POINT_DATA_Y = et.SubElement(Tie_Point,"TIE_POINT_DATA_Y")
    TIE_POINT_DATA_Y.text = " 1.0000000000000000e+00"

    Tie_Point = et.SubElement(Geoposition_Points,"Tie_Point")
    TIE_POINT_CRS_X = et.SubElement(Tie_Point,"TIE_POINT_CRS_X")
    TIE_POINT_CRS_X.text = " %3.6f" % (lowleft[1][0])
    TIE_POINT_CRS_Y = et.SubElement(Tie_Point,"TIE_POINT_CRS_Y")
    TIE_POINT_CRS_Y.text = " %3.6f" % (lowleft[0][0])
    TIE_POINT_DATA_X = et.SubElement(Tie_Point,"TIE_POINT_DATA_X")
    TIE_POINT_DATA_X.text = " 1.0000000000000000e+00"
    TIE_POINT_DATA_Y = et.SubElement(Tie_Point,"TIE_POINT_DATA_Y")
    if sensor_mode == "MS":
        TIE_POINT_DATA_Y.text = " 6.0000000000000000e+03"
    if sensor_mode == "PAN":
        TIE_POINT_DATA_Y.text = " 1.2000000000000000e+04"

    Tie_Point = et.SubElement(Geoposition_Points,"Tie_Point")
    TIE_POINT_CRS_X = et.SubElement(Tie_Point,"TIE_POINT_CRS_X")
    TIE_POINT_CRS_X.text = " %3.6f" % (lowright[1][0])
    TIE_POINT_CRS_Y = et.SubElement(Tie_Point,"TIE_POINT_CRS_Y")
    TIE_POINT_CRS_Y.text = " %3.6f" % (lowright[0][0])
    TIE_POINT_DATA_X = et.SubElement(Tie_Point,"TIE_POINT_DATA_X")
    if sensor_mode == "MS":
        TIE_POINT_DATA_X.text = " 6.0000000000000000e+03"
    if sensor_mode == "PAN":
        TIE_POINT_DATA_X.text = " 1.2000000000000000e+04"
    TIE_POINT_DATA_Y = et.SubElement(Tie_Point,"TIE_POINT_DATA_Y")
    if sensor_mode == "MS":
        TIE_POINT_DATA_Y.text = " 6.0000000000000000e+03"
    if sensor_mode == "PAN":
        TIE_POINT_DATA_Y.text = " 1.2000000000000000e+04"







    if job_time == None:
        job_time = prod_time
    job_asct = time.gmtime(job_time)
    job_y = job_asct.tm_year-2000
    job_mon = job_asct.tm_mon
    job_d = job_asct.tm_mday
    job_h  = job_asct.tm_hour
    job_min = job_asct.tm_min
    job_sec = job_asct.tm_sec
    job_milsec = int((job_time%1)*1000)

    prod_asct = time.gmtime(prod_time)
    prod_y = prod_asct.tm_year-2000
    prod_mon = prod_asct.tm_mon
    prod_d = prod_asct.tm_mday
    prod_h  = prod_asct.tm_hour
    prod_min = prod_asct.tm_min
    prod_sec = prod_asct.tm_sec
    prod_milsec = int((prod_time%1)*1000)



    Production = et.SubElement(Dimap_Document, "Production")
    JOB_ID = et.SubElement(Production,"JOB_ID")
    JOB_ID.text = "TH_CAT_%02d%02d%02d"%(job_y, job_mon, job_d) + "%02d%02d%02d%03d"%(job_h,job_min,job_sec,job_milsec)+"_1"
    PRODUCT_INFO = et.SubElement(Production,"PRODUCT_INFO")
    if process_level == "1A":
        PRODUCT_INFO.text = "THEOS1 SCENE level 1A"
    if process_level == "2A":
        PRODUCT_INFO.text = "THEOS1 SCENE level 2A"
    PRODUCT_TYPE = et.SubElement(Production,"PRODUCT_TYPE")
    PRODUCT_TYPE.text = "THEOS1 SCENE"
    DATASET_PRODUCER_NAME = et.SubElement(Production,"DATASET_PRODUCER_NAME")
    DATASET_PRODUCER_NAME.text = "GISTDA"
    DATASET_PRODUCER_URL = et.SubElement(Production,"DATASET_PRODUCER_URL",href="http://www.gistda.or.th")
    DATASET_PRODUCTION_DATE = et.SubElement(Production,"DATASET_PRODUCTION_DATE")
    DATASET_PRODUCTION_DATE.text = "%04d-%02d-%02d %02d:%02d:%02.6f"%(prod_y,prod_mon,prod_d,prod_h,prod_min,prod_sec)
    Production_Facility = et.SubElement(Production,"Production_Facility")
    SOFTWARE_NAME = et.SubElement(Production_Facility,"SOFTWARE_NAME")
    SOFTWARE_NAME.text = "THEOS-IGS"
    SOFTWARE_VERSION = et.SubElement(Production_Facility,"SOFTWARE_VERSION")
    SOFTWARE_VERSION.text = "SIRROS_V01"
    PROCESSING_CENTER = et.SubElement(Production_Facility,"PROCESSING_CENTER")
    PROCESSING_CENTER.text = "THEOS-IGS"




    Raster_Dimensions = et.SubElement(Dimap_Document,"Raster_Dimensions")
    NCOLS = et.SubElement(Raster_Dimensions,"NCOLS")
    NROWS = et.SubElement(Raster_Dimensions,"NROWS")
    NBANDS = et.SubElement(Raster_Dimensions,"NBANDS")
    if sensor_mode == "MS":
        NCOLS.text = str(min(6000,im_width))
        NROWS.text = str(min(6000,im_height))
        NBANDS.text = "4"
    if sensor_mode == "PAN":
        NCOLS.text = str(min(12000,im_width))
        NROWS.text = str(min(12000,im_height))
        NBANDS.text = "1"





    Raster_Encoding =  et.SubElement(Dimap_Document,"Raster_Encoding")
    NBITS = et.SubElement(Raster_Encoding,"NBITS")
    NBITS.text = "8"
    DATA_TYPE = et.SubElement(Raster_Encoding,"DATA_TYPE")
    DATA_TYPE.text = "UNSIGNED"
    BYTEORDER = et.SubElement(Raster_Encoding,"BYTEORDER")
    BYTEORDER.text = "I"
    BANDS_LAYOUT = et.SubElement(Raster_Encoding,"BANDS_LAYOUT")
    BANDS_LAYOUT.text = "BSQ"




    Data_Processing = et.SubElement(Dimap_Document,"Data_Processing")
    PROCESSING_LEVEL = et.SubElement(Data_Processing,"PROCESSING_LEVEL")
    if process_level == "1A":
        PROCESSING_LEVEL.text = "1A"
    if process_level == "2A":
        PROCESSING_LEVEL.text = "2A"
    if sensor_mode == "MS":
        GEOMETRIC_PROCESSING = et.SubElement(Data_Processing,"GEOMETRIC_PROCESSING")
        GEOMETRIC_PROCESSING.text = "SYSTEM"
        RADIOMETRIC_PROCESSING = et.SubElement(Data_Processing,"RADIOMETRIC_PROCESSING")
        RADIOMETRIC_PROCESSING.text = "SYSTEM"
        Processing_Options = et.SubElement(Data_Processing,"Processing_Options")
        Correction_Algorithm = et.SubElement(Processing_Options,"Correction_Algorithm")
        ALGORITHM_TYPE = et.SubElement(Correction_Algorithm,"ALGORITHM_TYPE")
        ALGORITHM_TYPE.text = "ENHANCEMENT"
        ALGORITHM_NAME = et.SubElement(Correction_Algorithm,"ALGORITHM_NAME")
        ALGORITHM_NAME.text = "MS bands registration"
        ALGORITHM_ACTIVATION = et.SubElement(Correction_Algorithm,"ALGORITHM_ACTIVATION")
        ALGORITHM_ACTIVATION.text = "Y"
        ALGORITHM_TYPE = et.SubElement(Correction_Algorithm,"ALGORITHM_TYPE")
        ALGORITHM_TYPE.text = "RESAMPLING"
        ALGORITHM_NAME = et.SubElement(Correction_Algorithm,"ALGORITHM_NAME")
        ALGORITHM_NAME.text = "Bicubic resampling"
        ALGORITHM_ACTIVATION = et.SubElement(Correction_Algorithm,"ALGORITHM_ACTIVATION")
        ALGORITHM_ACTIVATION.text = "Y"
        ALGORITHM_TYPE = et.SubElement(Correction_Algorithm,"ALGORITHM_TYPE")
        ALGORITHM_TYPE.text = "ENHANCEMENT"
        ALGORITHM_NAME = et.SubElement(Correction_Algorithm,"ALGORITHM_NAME")
        ALGORITHM_NAME.text = "Denoising and Deconvolution"
        ALGORITHM_ACTIVATION = et.SubElement(Correction_Algorithm,"ALGORITHM_ACTIVATION")
        ALGORITHM_ACTIVATION.text = "Y"
    if sensor_mode == "PAN":
        GEOMETRIC_PROCESSING = et.SubElement(Data_Processing,"GEOMETRIC_PROCESSING")
        GEOMETRIC_PROCESSING.text = "RAW"
        RADIOMETRIC_PROCESSING = et.SubElement(Data_Processing,"RADIOMETRIC_PROCESSING")
        RADIOMETRIC_PROCESSING.text = "SYSTEM"
        Processing_Options = et.SubElement(Data_Processing,"Processing_Options")
        Correction_Algorithm = et.SubElement(Processing_Options,"Correction_Algorithm")
        ALGORITHM_TYPE = et.SubElement(Correction_Algorithm,"ALGORITHM_TYPE")
        ALGORITHM_TYPE.text = "ENHANCEMENT"
        ALGORITHM_NAME = et.SubElement(Correction_Algorithm,"ALGORITHM_NAME")
        ALGORITHM_NAME.text = "Denoising and Deconvolution"
        ALGORITHM_ACTIVATION = et.SubElement(Correction_Algorithm,"ALGORITHM_ACTIVATION")
        ALGORITHM_ACTIVATION.text = "Y"






    Data_Access =  et.SubElement(Dimap_Document,"Data_Access")
    DATA_FILE_ORGANISATION = et.SubElement(Data_Access,"DATA_FILE_ORGANISATION")
    DATA_FILE_ORGANISATION.text = "BAND_COMPOSITE"
    DATA_FILE_FORMAT = et.SubElement(Data_Access,"DATA_FILE_FORMAT",version="1.0")
    DATA_FILE_FORMAT.text = "GEOTIFF"
    Data_File = et.SubElement(Data_Access,"Data_File")
    DATA_FILE_PATH = et.SubElement(Data_File,"DATA_FILE_PATH",href="IMAGERY.TIF")





    Image_Display =  et.SubElement(Dimap_Document,"Image_Display")
    if sensor_mode == "MS":
        Band_Display_Order = et.SubElement(Image_Display,"Band_Display_Order")
        RED_CHANNEL = et.SubElement(Band_Display_Order,"RED_CHANNEL")
        RED_CHANNEL.text = "3"
        GREEN_CHANNEL = et.SubElement(Band_Display_Order,"GREEN_CHANNEL")
        GREEN_CHANNEL.text = "2"
        BLUE_CHANNEL = et.SubElement(Band_Display_Order,"BLUE_CHANNEL")
        BLUE_CHANNEL.text = "1"
    if sensor_mode == "PAN":
        Band_Display_Order = et.SubElement(Image_Display,"Band_Display_Order")
        RED_CHANNEL = et.SubElement(Band_Display_Order,"RED_CHANNEL")
        RED_CHANNEL.text = "1"
        GREEN_CHANNEL = et.SubElement(Band_Display_Order,"GREEN_CHANNEL")
        GREEN_CHANNEL.text = "1"
        BLUE_CHANNEL = et.SubElement(Band_Display_Order,"BLUE_CHANNEL")
        BLUE_CHANNEL.text = "1"
    Special_Value = et.SubElement(Image_Display,"Special_Value")
    SPECIAL_VALUE_INDEX = et.SubElement(Special_Value,"SPECIAL_VALUE_INDEX")
    SPECIAL_VALUE_INDEX.text = "255"
    SPECIAL_VALUE_TEXT = et.SubElement(Special_Value,"SPECIAL_VALUE_TEXT")
    SPECIAL_VALUE_TEXT.text = "SATURATED"
    Special_Value_Color = et.SubElement(Special_Value,"Special_Value_Color")
    RED_LEVEL = et.SubElement(Special_Value_Color,"RED_LEVEL")
    RED_LEVEL.text = "1"
    GREEN_LEVEL = et.SubElement(Special_Value_Color,"GREEN_LEVEL")
    GREEN_LEVEL.text = "1"
    BLUE_LEVEL = et.SubElement(Special_Value_Color,"BLUE_LEVEL")
    BLUE_LEVEL.text = "1"
    Special_Value = et.SubElement(Image_Display,"Special_Value")
    SPECIAL_VALUE_INDEX = et.SubElement(Special_Value,"SPECIAL_VALUE_INDEX")
    SPECIAL_VALUE_INDEX.text = "0"
    SPECIAL_VALUE_TEXT = et.SubElement(Special_Value,"SPECIAL_VALUE_TEXT")
    SPECIAL_VALUE_TEXT.text = "NODATA"
    Special_Value_Color = et.SubElement(Special_Value,"Special_Value_Color")
    RED_LEVEL = et.SubElement(Special_Value_Color,"RED_LEVEL")
    RED_LEVEL.text = "0"
    GREEN_LEVEL = et.SubElement(Special_Value_Color,"GREEN_LEVEL")
    GREEN_LEVEL.text = "0"
    BLUE_LEVEL = et.SubElement(Special_Value_Color,"BLUE_LEVEL")
    BLUE_LEVEL.text = "0"





    Data_Strip =  et.SubElement(Dimap_Document,"Data_Strip")
    Data_Strip_Identification = et.SubElement(Data_Strip,"Data_Strip_Identification")
    DATA_STRIP_ID = et.SubElement(Data_Strip_Identification,"DATA_STRIP_ID")
    if sensor_mode == "MS":
        file_id = "TS1_"+str(year)+str(doy)+"_"+rev_num+"_%03d"%int(filename_num)
        DATA_STRIP_ID.text = file_id+"_MS"
    if sensor_mode == "PAN":
        file_id = "TS1_"+str(year)+str(doy)+"_"+rev_num+"_%03d"%int(filename_num)
        DATA_STRIP_ID.text = file_id+"_PAN"
    LCNT = et.SubElement(Data_Strip_Identification,"LCNT")
    LCNT.text = Line_counter
    IGPST = et.SubElement(Data_Strip_Identification,"IGPST")
    IGPST.text = year + "-" + month + "-" + day + " " + IGPS_time
    FILE_NAME = et.SubElement(Data_Strip_Identification,"FILE_NAME")
    FILE_NAME.text = filename_num
    COMPRESSION_RATIO = et.SubElement(Data_Strip_Identification,"COMPRESSION_RATIO")
    COMPRESSION_RATIO.text = comp_Ratio
    Frame_Counters = et.SubElement(Data_Strip,"Frame_Counters")
    if sensor_mode == "MS":
        Band_Counters =  et.SubElement(Frame_Counters,"Band_Counters")
        BAND_INDEX =  et.SubElement(Band_Counters,"BAND_INDEX")
        BAND_INDEX.text = "1"
        BAND_OFFSET =  et.SubElement(Band_Counters,"BAND_OFFSET")
        BAND_OFFSET.text = str(b1_offset)
        SFSC_BEGIN =  et.SubElement(Band_Counters,"SFSC_BEGIN")
        b1_beg_sfsc = int(file_beg_sfsc+((start_line_B3+b1_offset)/8))
        SFSC_BEGIN.text = str(b1_beg_sfsc)
        SFSC_END = et.SubElement(Band_Counters,"SFSC_END")
        SFSC_END.text = str(b1_beg_sfsc+min(6000,im_height)/8)
        DSR_BEGIN =  et.SubElement(Band_Counters,"DSR_BEGIN")
        DSR_BEGIN.text = str(start_line_B3+b1_offset)
        DSR_END =  et.SubElement(Band_Counters,"DSR_END")
        DSR_END.text = str(start_line_B3+b1_offset+min(6000,im_height)-1)

        Band_Counters =  et.SubElement(Frame_Counters,"Band_Counters")
        BAND_INDEX =  et.SubElement(Band_Counters,"BAND_INDEX")
        BAND_INDEX.text = "2"
        BAND_OFFSET =  et.SubElement(Band_Counters,"BAND_OFFSET")
        BAND_OFFSET.text = str(b2_offset)
        SFSC_BEGIN =  et.SubElement(Band_Counters,"SFSC_BEGIN")
        b2_beg_sfsc = int(file_beg_sfsc+((start_line_B3+b2_offset)/8))
        SFSC_BEGIN.text = str(b2_beg_sfsc)
        SFSC_END = et.SubElement(Band_Counters,"SFSC_END")
        SFSC_END.text = str(b2_beg_sfsc+min(6000,im_height)/8)
        DSR_BEGIN =  et.SubElement(Band_Counters,"DSR_BEGIN")
        DSR_BEGIN.text = str(start_line_B3+b2_offset)
        DSR_END =  et.SubElement(Band_Counters,"DSR_END")
        DSR_END.text = str(start_line_B3+b2_offset+min(6000,im_height)-1)

        Band_Counters =  et.SubElement(Frame_Counters,"Band_Counters")
        BAND_INDEX =  et.SubElement(Band_Counters,"BAND_INDEX")
        BAND_INDEX.text = "3"
        BAND_OFFSET =  et.SubElement(Band_Counters,"BAND_OFFSET")
        BAND_OFFSET.text = "0"
        SFSC_BEGIN =  et.SubElement(Band_Counters,"SFSC_BEGIN")
        b3_beg_sfsc = int(file_beg_sfsc+((start_line_B3)/8))
        SFSC_BEGIN.text = str(b3_beg_sfsc)
        SFSC_END = et.SubElement(Band_Counters,"SFSC_END")
        SFSC_END.text = str(b3_beg_sfsc+min(6000,im_height)/8)
        DSR_BEGIN =  et.SubElement(Band_Counters,"DSR_BEGIN")
        DSR_BEGIN.text = str(start_line_B3)
        DSR_END =  et.SubElement(Band_Counters,"DSR_END")
        DSR_END.text = str(start_line_B3+min(6000,im_height)-1)

        Band_Counters =  et.SubElement(Frame_Counters,"Band_Counters")
        BAND_INDEX =  et.SubElement(Band_Counters,"BAND_INDEX")
        BAND_INDEX.text = "4"
        BAND_OFFSET =  et.SubElement(Band_Counters,"BAND_OFFSET")
        BAND_OFFSET.text = str(b4_offset)
        SFSC_BEGIN =  et.SubElement(Band_Counters,"SFSC_BEGIN")
        b4_beg_sfsc = int(file_beg_sfsc+((start_line_B3+b4_offset)/8))
        SFSC_BEGIN.text = str(b4_beg_sfsc)
        SFSC_END = et.SubElement(Band_Counters,"SFSC_END")
        SFSC_END.text = str(b4_beg_sfsc+min(6000,im_height)/8)
        if sensor_mode == "PAN":
            SFSC_END.text = str(b4_beg_sfsc+min(6000,im_height)/8)
        DSR_BEGIN =  et.SubElement(Band_Counters,"DSR_BEGIN")
        DSR_BEGIN.text = str(start_line_B3+b4_offset)
        DSR_END =  et.SubElement(Band_Counters,"DSR_END")
        DSR_END.text = str(start_line_B3+b4_offset+min(6000,im_height)-1)
        if sensor_mode == "PAN":
            DSR_END.text = str(start_line_B3+b4_offset+12000-1)
    if sensor_mode == "PAN":
        Band_Counters =  et.SubElement(Frame_Counters,"Band_Counters")
        BAND_INDEX =  et.SubElement(Band_Counters,"BAND_INDEX")
        BAND_INDEX.text = "1"
        BAND_OFFSET =  et.SubElement(Band_Counters,"BAND_OFFSET")
        BAND_OFFSET.text = "0"
        SFSC_BEGIN =  et.SubElement(Band_Counters,"SFSC_BEGIN")
        b4_beg_sfsc = int(file_beg_sfsc+((start_line)/8))
        SFSC_BEGIN.text = str(b4_beg_sfsc)
        SFSC_END = et.SubElement(Band_Counters,"SFSC_END")
        SFSC_END.text = str(b4_beg_sfsc+min(12000,im_height)/8)
        DSR_BEGIN =  et.SubElement(Band_Counters,"DSR_BEGIN")
        DSR_BEGIN.text = str(start_line)
        DSR_END =  et.SubElement(Band_Counters,"DSR_END")
        DSR_END.text = str(start_line+min(12000,im_height)-1)

    Time_Stamp =  et.SubElement(Data_Strip,"Time_Stamp")
    REFERENCE_BAND = et.SubElement(Time_Stamp,"REFERENCE_BAND")
    REFERENCE_BAND.text = "3"
    REFERENCE_TIME = et.SubElement(Time_Stamp,"REFERENCE_TIME")
    REFERENCE_TIME.text = year + "-" + month + "-" + day + " " +str(beg_time[0])+":"+str(beg_time[1])+":"+str(beg_time[2])+"."+ str(beg_time[3])
    REFERENCE_LINE= et.SubElement(Time_Stamp,"REFERENCE_LINE")
    REFERENCE_LINE.text ="1"
    LINE_PERIOD= et.SubElement(Time_Stamp,"LINE_PERIOD")
    if sensor_mode == "MS":
        LINE_PERIOD.text = "2.1602000000000001e-03"
    if sensor_mode == "PAN":
        LINE_PERIOD.text = "3.0860000000000002e-04"

    Ephemeris =  et.SubElement(Data_Strip,"Ephemeris")
    SATELLITE_ALTITUDE =  et.SubElement(Ephemeris,"SATELLITE_ALTITUDE")
    SATELLITE_ALTITUDE.text = " %1.16e" % (sat_altitude)
    Raw_Ephemeris = et.SubElement(Ephemeris,"Raw_Ephemeris")
    Point_List = et.SubElement(Raw_Ephemeris,"Point_List")
    cnt = 0
    while cnt<len(sadr_time):
        Point = et.SubElement(Point_List,"Point")
        TIME =  et.SubElement(Point,"TIME")
        TIME.text = sadr_time[cnt]
        Location =  et.SubElement(Point,"Location")
        X_pos =  et.SubElement(Location,"X")
        X_pos.text = "%1.17e"%float(sadr_pos[cnt][0])
        Y_pos =  et.SubElement(Location,"Y")
        Y_pos.text = "%1.17e"%float(sadr_pos[cnt][1])
        Z_pos =  et.SubElement(Location,"Z")
        Z_pos.text = "%1.17e"%float(sadr_pos[cnt][2])
        Velocity =  et.SubElement(Point,"Velocity")
        X_vel =  et.SubElement(Velocity,"X")
        X_vel.text = "%1.17e"%float(sadr_vel[cnt][0])
        Y_vel =  et.SubElement(Velocity,"Y")
        Y_vel.text = "%1.17e"%float(sadr_vel[cnt][1])
        Z_vel =  et.SubElement(Velocity,"Z")
        Z_vel.text = "%1.17e"%float(sadr_vel[cnt][2])
        cnt+=1





    Attitudes =  et.SubElement(Data_Strip,"Attitudes")
    Raw_Attitudes =  et.SubElement(Attitudes,"Raw_Attitudes")
    UT1_UTC =  et.SubElement(Raw_Attitudes,"UT1_UTC")
    UT1_UTC.text = ut1_utc
    UTC_GPST =  et.SubElement(Raw_Attitudes,"UTC_GPST")
    UTC_GPST.text = utc_gpst
    U_dimap =  et.SubElement(Raw_Attitudes,"U")
    U_dimap.text = "7.272205e-7"
    V_dimap = et.SubElement(Raw_Attitudes, "V")
    V_dimap.text = "9.647792E-7"
    Quaternion_List =  et.SubElement(Raw_Attitudes,"Quaternion_List")
    cnt = 0
    while cnt<len(sadr_time):
        Quaternion =  et.SubElement(Quaternion_List,"Quaternion")
        TIME =  et.SubElement(Quaternion,"TIME")
        TIME.text = sadr_time[cnt]
        Q0 =  et.SubElement(Quaternion,"Q0")
        Q0.text = "%1.17e"%float(sadr_att[cnt][0])
        Q1 =  et.SubElement(Quaternion,"Q1")
        Q1.text = "%1.17e"%float(sadr_att[cnt][1])
        Q2 =  et.SubElement(Quaternion,"Q2")
        Q2.text = "%1.17e"%float(sadr_att[cnt][2])
        Q3 =  et.SubElement(Quaternion,"Q3")
        Q3.text = "%1.17e"%float(sadr_att[cnt][3])
        cnt+=1




    Sensor_Config = et.SubElement(Data_Strip,"Sensor_Configuration")
    Look_Angles_List = et.SubElement(Sensor_Config,"Instrument_Look_Angles_List")
    if sensor_mode == "MS":
        ccdLOS_band_list = [[".//C_ccdLOS_B1_X_List",".//C_ccdLOS_B1_Y_List"],\
                            [".//C_ccdLOS_B2_X_List",".//C_ccdLOS_B2_Y_List"],\
                            [".//C_ccdLOS_B3_X_List",".//C_ccdLOS_B3_Y_List"],\
                            [".//C_ccdLOS_B4_X_List",".//C_ccdLOS_B4_Y_List"]]
        band_cnt = 1
        for band in ccdLOS_band_list:
            Look_Angles = et.SubElement(Look_Angles_List,"Instrument_Look_Angles")
            Valid_Time = et.SubElement(Look_Angles,"VALIDITY_DATE")
            Valid_Time.text = CPF_valid_time
            Band_Index = et.SubElement(Look_Angles,"BAND_INDEX")
            Band_Index.text = str(band_cnt)
            Poly_Look_Angles = et.SubElement(Look_Angles,"Polynomial_Look_Angles")


            XLOS_List = ["XLOS0","XLOS1","XLOS2","XLOS3"]
            YLOS_List = ["YLOS0","YLOS1","YLOS2","YLOS3"]

            ccd_x = cpf_tree.find(band[0])
            for num in range(4):
                XLOS = et.SubElement(Poly_Look_Angles,XLOS_List[num])
                XLOS.text = "%1.17e"%float(ccd_x[num].text)

            ccd_y = cpf_tree.find(band[1])
            for num in range(4):
                YLOS = et.SubElement(Poly_Look_Angles,YLOS_List[num])
                YLOS.text = ccd_y[num].text
            band_cnt+=1
    if sensor_mode == "PAN":
        ccdLOS_band_list = [[".//C_ccdLOS_PAN_X_List",".//C_ccdLOS_PAN_Y_List"]]

        for band in ccdLOS_band_list:
            Look_Angles = et.SubElement(Look_Angles_List,"Instrument_Look_Angles")
            Valid_Time = et.SubElement(Look_Angles,"VALIDIDTY_TIME")
            Valid_Time.text = CPF_valid_time
            Band_Index = et.SubElement(Look_Angles,"BAND_INDEX")
            Band_Index.text = "1"
            Poly_Look_Angles = et.SubElement(Look_Angles,"Polynomial_Look_Angles")
            XLOS_List = ["XLOS0","XLOS1","XLOS2","XLOS3"]
            YLOS_List = ["YLOS0","YLOS1","YLOS2","YLOS3"]
            ccd_x = cpf_tree.find(band[0])
            for num in range(4):
                XLOS = et.SubElement(Poly_Look_Angles,XLOS_List[num])
                XLOS.text = ccd_x[num].text
            ccd_y = cpf_tree.find(band[1])
            for num in range(4):
                YLOS = et.SubElement(Poly_Look_Angles,YLOS_List[num])
                YLOS.text = ccd_y[num].text
    Instrument_Biases = et.SubElement(Sensor_Config,"Instrument_Biases")
    YAW =  et.SubElement(Instrument_Biases,"YAW")
    YAW.text = yaw
    PITCH =  et.SubElement(Instrument_Biases,"PITCH")
    PITCH.text = pitch
    ROLL =  et.SubElement(Instrument_Biases,"ROLL")
    ROLL.text = roll






    Sensor_Calibration = et.SubElement(Data_Strip,"Sensor_Calibration")
    Calibration = et.SubElement(Sensor_Calibration,"Calibration")
    CALIBRATION_TYPE = et.SubElement(Calibration,"CALIBRATION_TYPE")
    CALIBRATION_TYPE.text = "NOMINAL"
    CALIBRATION_VALIDITY = et.SubElement(Calibration,"CALIBRATION_VALIDITY")
    CALIBRATION_VALIDITY.text = CPF_valid_time
    CALIBRATION_FILENAME = et.SubElement(Calibration,"CALIBRATION_FILENAME")
    # CALIBRATION_FILENAME.text = CPF_path.split("\\")[len(CPF_path.split("\\"))-1]
    CALIBRATION_FILENAME.text = os.path.basename(CPF_path)
    if sensor_mode == "MS":
        for band_num in range(4):
            Band_Parameters = et.SubElement(Calibration,"Band_Parameters")
            BAND_INDEX = et.SubElement(Band_Parameters,"BAND_INDEX")
            BAND_INDEX.text = str(band_num+1)
            Gain_Section_List = et.SubElement(Band_Parameters,"Gain_Section_List")
            Gain_Section = et.SubElement(Gain_Section_List,"Gain_Section")
            LINE_NUMBER = et.SubElement(Gain_Section,"LINE_NUMBER")
            LINE_NUMBER.text = "1"
            GAIN_NUMBER = et.SubElement(Gain_Section,"GAIN_NUMBER")
            GAIN_NUMBER.text = str(gain_num[band_num])
            PHYSICAL_BIAS = et.SubElement(Gain_Section,"PHYSICAL_BIAS")
            PHYSICAL_BIAS.text = " "+gain_info_allband[band_num][1].strip()
            PHYSICAL_GAIN = et.SubElement(Gain_Section,"PHYSICAL_GAIN")
            PHYSICAL_GAIN.text = " "+gain_info_allband[band_num][0].strip()
            PHYSICAL_UNIT = et.SubElement(Gain_Section,"PHYSICAL_UNIT")
            PHYSICAL_UNIT.text = "equivalent radiance (W.m-2.Sr-1.um-1)"
            Pixel_Parameters = et.SubElement(Gain_Section,"Pixel_Parameters")
            Cells = et.SubElement(Pixel_Parameters,"Cells")
            for i in range(len(gain_info_allband[band_num][2])):
                Cell = et.SubElement(Cells,"Cell")
                G = et.SubElement(Cell,"G")
                G.text = str(gain_info_allband[band_num][2][i])
                DC = et.SubElement(Cell,"DC")
                DC.text = str(gain_info_allband[band_num][3][i])
            if LV1AConstants.DESCENDING:
                if (band_bad_lines[band_num] is not None) or (band_degraded_lines[band_num] is not None):
                    make_bad_line_tree = False

                    band_bad_line_array = band_bad_lines[band_num]
                    if band_bad_line_array is not None:
                        print band_bad_line_array
                        num_bad_lines = np.array(band_bad_line_array).size
                        for bln in range(num_bad_lines):
                            num_line_in_image  =  band_bad_line_array[bln] -  lines_list[band_num] +1
                            if (num_line_in_image >= 1)  and (num_line_in_image < im_height):
                                if not make_bad_line_tree:
                                    bad_line_list = et.SubElement(Band_Parameters, "Bad_Line_List")
                                    make_bad_line_tree = True
                                bad_line = et.SubElement(bad_line_list,"Bad_line")
                                bl_idx = et.SubElement(bad_line,"BL_INDEX")
                                bl_idx.text = str(num_line_in_image)
                                bl_status = et.SubElement(bad_line, "BL_STATUS")
                                bl_status.text = "LOST"
                    degraded_line_array = band_degraded_lines[band_num]
                    if (not isinstance(degraded_line_array, np.ndarray)) & (degraded_line_array is not None) :
                        degraded_line_array = np.array(degraded_line_array)

                    if degraded_line_array is not None:
                        try:
                            num_bad_lines = degraded_line_array.shape[0]
                        except:
                            print degraded_line_array
                        for bln in range(num_bad_lines):
                            num_line_in_image  =  degraded_line_array[bln,0] -  lines_list[band_num] +1
                            if (num_line_in_image >= 1)  and (num_line_in_image < im_height):
                                if not make_bad_line_tree:
                                    bad_line_list = et.SubElement(Band_Parameters, "Bad_Line_List")
                                    make_bad_line_tree = True
                                bad_line = et.SubElement(bad_line_list,"Bad_line")
                                bl_idx = et.SubElement(bad_line,"BL_INDEX")
                                bl_idx.text = str(num_line_in_image)
                                bl_status = et.SubElement(bad_line, "BL_STATUS")
                                bl_status.text = "DEGRADED"
                                bl_portion = et.SubElement(bad_line, "BL_Portions")
                                bl_portion2 = et.SubElement(bl_portion, "BL_Portion")
                                pix_min = et.SubElement(bl_portion2, "PIX_MIN")
                                pix_min.text = str(degraded_line_array[bln,1])
                                pix_max = et.SubElement(bl_portion2, "PIX_MAX")
                                pix_max.text = str(degraded_line_array[bln, 2])





    if sensor_mode == "PAN":
        band_num = 0
        Band_Parameters = et.SubElement(Calibration,"Band_Parameters")
        BAND_INDEX = et.SubElement(Band_Parameters,"BAND_INDEX")
        BAND_INDEX.text = str(band_num+1)
        Gain_Section_List = et.SubElement(Band_Parameters,"Gain_Section_List")
        Gain_Section = et.SubElement(Gain_Section_List,"Gain_Section")
        LINE_NUMBER = et.SubElement(Gain_Section,"LINE_NUMBER")
        LINE_NUMBER.text = "1"
        GAIN_NUMBER = et.SubElement(Gain_Section,"GAIN_NUMBER")
        GAIN_NUMBER.text = str(gain_num)
        PHYSICAL_BIAS = et.SubElement(Gain_Section,"PHYSICAL_BIAS")
        PHYSICAL_BIAS.text = " "+gain_info_allband[band_num][1].strip()
        PHYSICAL_GAIN = et.SubElement(Gain_Section,"PHYSICAL_GAIN")
        PHYSICAL_GAIN.text = " "+gain_info_allband[band_num][0].strip()
        PHYSICAL_UNIT = et.SubElement(Gain_Section,"PHYSICAL_UNIT")
        PHYSICAL_UNIT.text = "equivalent radiance (W.m-2.Sr-1.um-1)"
        Pixel_Parameters = et.SubElement(Gain_Section,"Pixel_Parameters")
        Cells = et.SubElement(Pixel_Parameters,"Cells")
        for i in range(len(gain_info_allband[band_num][2])):
            Cell = et.SubElement(Cells,"Cell")
            G = et.SubElement(Cell,"G")
            G.text = str(gain_info_allband[band_num][2][i])
            DC = et.SubElement(Cell,"DC")
            DC.text = str(gain_info_allband[band_num][3][i])
        band_num = 0
        if LV1AConstants.DESCENDING:
            if (band_bad_lines[band_num] is not None) or (band_degraded_lines[band_num] is not None):

                band_bad_line_array = band_bad_lines[band_num]
                if band_bad_line_array is not None:
                    print band_bad_line_array
                    if (not isinstance(band_bad_line_array,np.ndarray)):
                        band_bad_line_array = np.array(band_bad_line_array)
                    num_bad_lines = band_bad_line_array.size
                    make_bad_line_tree = False
                    for bln in range(num_bad_lines):
                        num_line_in_image = band_bad_line_array[bln] - lines_list[band_num] + 1
                        if (num_line_in_image >= 1) and (num_line_in_image < im_height):
                            if not make_bad_line_tree:
                                bad_line_list = et.SubElement(Band_Parameters, "Bad_Line_List")
                                make_bad_line_tree = True
                            bad_line = et.SubElement(bad_line_list, "Bad_line")
                            bl_idx = et.SubElement(bad_line, "BL_INDEX")
                            bl_idx.text = str(num_line_in_image)
                            bl_status = et.SubElement(bad_line, "BL_STATUS")
                            bl_status.text = "LOST"
                degraded_line_array = band_degraded_lines[band_num]
                if degraded_line_array is not None:
                    if degraded_line_array.ndim == 1 :
                        degraded_line_array = degraded_line_array.reshape((1,3))
                    num_bad_lines = degraded_line_array.shape[0]
                    for bln in range(num_bad_lines):
                        num_line_in_image = degraded_line_array[bln, 0] - lines_list[band_num] + 1
                        if (num_line_in_image >= 1) and (num_line_in_image < im_height):
                            if not make_bad_line_tree:
                                bad_line_list = et.SubElement(Band_Parameters, "Bad_Line_List")
                                make_bad_line_tree = True
                            bad_line = et.SubElement(bad_line_list, "Bad_line")
                            bl_idx = et.SubElement(bad_line, "BL_INDEX")
                            bl_idx.text = str(num_line_in_image)
                            bl_status = et.SubElement(bad_line, "BL_STATUS")
                            bl_status.text = "DEGRADED"
                            bl_portion = et.SubElement(bad_line, "BL_Portions")
                            bl_portion2 = et.SubElement(bl_portion, "BL_Portion")
                            pix_min = et.SubElement(bl_portion2, "PIX_MIN")
                            pix_min.text = str(degraded_line_array[bln, 1])
                            pix_max = et.SubElement(bl_portion2, "PIX_MAX")
                            pix_max.text = str(degraded_line_array[bln, 2])





    pretty_print = et.tostring(Dimap_Document, pretty_print=True)

    # print pretty_print

    save_xml = open(xml_save_location,'w')
    save_xml.write('<?xml version="1.0" encoding="UTF-8" ?>\n')
    save_xml.write('<?xml-stylesheet href="STYLE.XSL" type="text/xsl" ?>\n')
    save_xml.write(et.tostring(Dimap_Document, pretty_print=True))
    save_xml.close()


    ######################### insert new line for each group for better looking ##############################
    dim_read = open(xml_save_location, 'r')
    liness= dim_read.readlines()
    dim_read.close()
    dim_write = open(xml_save_location,'w')
    for i in range(len(liness)):
        if "<Metadata_Id>" in liness[i]:
            dim_write.write("\n"+liness[i])
        elif "<Dataset_Id>" in liness[i]:
            dim_write.write("\n"+liness[i])
        elif "<Dataset_Frame>" in liness[i]:
            dim_write.write("\n"+liness[i])
        elif "<Dataset_Sources>" in liness[i]:
            dim_write.write("\n"+liness[i])
        elif "<Coordinate_Reference_System>" in liness[i]:
            dim_write.write("\n"+liness[i])
        elif "<Raster_CS>" in liness[i]:
            dim_write.write("\n"+liness[i])
        elif "<Geoposition>" in liness[i]:
            dim_write.write("\n"+liness[i])
        elif "<Production>" in liness[i]:
            dim_write.write("\n"+liness[i])
        elif "<Raster_Dimensions>" in liness[i]:
            dim_write.write("\n"+liness[i])
        elif "<Raster_Encoding>" in liness[i]:
            dim_write.write("\n"+liness[i])
        elif "<Data_Processing>" in liness[i]:
            dim_write.write("\n"+liness[i])
        elif "<Data_Access>" in liness[i]:
            dim_write.write("\n"+liness[i])
        elif "<Image_Display>" in liness[i]:
            dim_write.write("\n"+liness[i])
        elif "<Data_Strip>" in liness[i]:
            dim_write.write("\n"+liness[i])
        else:
            dim_write.write(liness[i])

    dim_write.close()

    print "DIMAP Created Sucessfully!! at", xml_save_location

    if os.path.exists("./STYLE.XSL"):
        shutil.copy("./STYLE.XSL",save_loaction)
    makePDFfile.make_pdf_file(xml_save_location,save_loaction)
