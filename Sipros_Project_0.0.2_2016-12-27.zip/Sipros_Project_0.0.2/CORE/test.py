# A = 02
# # 0915151454.460
# # B = A.strip("\n")
# # C = float(B)
# # D = str(B)
# E = "%s"%str(A)
# # \n%s:%s:%s 
# F = E.split("/")


# print "A : %s"%A , type(A)
# # print "B : %s"%B , type(B)
# # print "C : %s"%C , type(C)
# # print "D : %d"%int(D) , type(D)
# print "E : %s"%E , type(E)
# print "F : %s"%F , type(F)

# G = "031546"
# H = G[2:4]
# print H

# Begin Reception : 20161003 032235.271 
# End Reception : 20161003 032733.483
# OrbitCycle : 26
# RevolutionNumber : 041920
# Mission : THEOS
# Satellite ID: 1
# Passrank : 1
# PassID : 111041920
# Segment count : 8
# Segment info
# FileName : 2
# Gerald name : THEOS_1_LEVEL0_1_111041920_041920_MS_PB_TOP_2_2_2016-10-03_03-15-44
# Segment rank : 3
# Instrument : TOP2
# Transmission mode : PB
# Segment quality : 20
# Begin segment viewing date : 20161003
# Begin segment viewing time : 031544
# End segment viewing date : 20161003
# End segment viewing time : 031708
# Compression ratio : 3.75
# SpectralMode : MS
# Band offset : -127, -64, 0, 64
# Reference Band : B3
# Along track viewing angle : 11.8885760189
# Across track viewing angle : 1.7542739473
# ABS Gain : 2.41858
# Scene info
# Scene rank : 4
# Grid reference : 266-277
# Technical quality : EEEE
# Cloud cover : AAAAAAAA
# Snow cover : 00000000
# Center scene viewing date : 20161003
# Center scene viewing time :031614
# Begin scene viewing date : 20161003
# Begin scene viewing time : 031607
# End scene viewing date : 20161003
# End scene viewing time : 031620
# Coupling mode : YES
# Orientation angle : 10.8286562427
# Incidence angle : 13.6011767743
# Sun elevation : 45.63
# Sun azimuth : 150.65
# Latitude NW : 36.9108333333
# Longitude NW : -107.721666667
# Latitude NE : 36.7455555556
# Longitude NE : -108.777222222
# Latitude SW : 36.1552777778
# Longitude SW : -107.491666667
# Latitude SE : 35.9922222222
# Longitude SE : -108.5375
# Center scene latitude : 36.4530555556
# Center scene longitude : 36.1313888889
# Begin line : [10934, 10997, 11061, 11125]

A = 123
B = [A]
print B , type(B)
