import cv2

from osgeo import gdal

import numpy as np


imf = r"D:\Data2APanSharpen\Level 2A - SIPROS\ProminentLine\GERALD\THEOS_1_LEVEL0_1_111041472_41472_MS_PB_TOP_2_16_2016-09-01_05-11-01\level1a\cmp4.tif"
im = gdal.Open(imf)
b2 = im.GetRasterBand(2)
b3 = im.GetRasterBand(1)
d2 = b2.ReadAsArray()
d3 = b3.ReadAsArray()
height, width = d2.shape
rmse_min = 1e100
for dx in range(-3, 4):
    for dy in range(-3, 4):
        xmin = max(0, dx)
        xmax = min(width + dx, width)
        ymin = max(0, dy)
        ymax = min(height + dy, height)
        d2o = d2[ymin:ymax, xmin:xmax]

        xmin = max(0, -dx)
        xmax = min(width - dx, width)
        ymin = max(0, -dy)
        ymax = min(height - dy, height)
        d3o = d3[ymin:ymax, xmin:xmax]
        err = d2o.astype('float32') - d3o.astype('float32')
        rmse = np.sqrt((err ** 2).mean())
        if rmse < rmse_min:
            rmse_min = rmse
            dx_best = dx
            dy_best = dy

print "dx:%d ,dy: %d at rmse = %f" % (dx_best, dy_best, rmse_min)
dx = dx_best
dy = dy_best
xmin = max(0, dx)
xmax = min(width + dx, width)
ymin = max(0, dy)
ymax = min(height + dy, height)
d2o = d2[ymin:ymax, xmin:xmax]

xmin = max(0, -dx)
xmax = min(width - dx, width)
ymin = max(0, -dy)
ymax = min(height - dy, height)
d3o = d3[ymin:ymax, xmin:xmax]

h, w = d3o.shape
out = np.zeros((h, w, 3), 'uint8')
out[: , : , 1] = d2o
out[: , : , 2] = d3o
cv2.imwrite(r"D:\Data2APanSharpen\Level 2A - SIPROS\ProminentLine\GERALD\THEOS_1_LEVEL0_1_111041472_41472_MS_PB_TOP_2_16_2016-09-01_05-11-01\level1a\cmp4new.tif", out)

