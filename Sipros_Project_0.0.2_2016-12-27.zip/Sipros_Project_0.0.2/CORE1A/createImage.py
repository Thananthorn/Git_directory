__author__ = 'professor'
import cv2
import os
import platform

import psutil

import determine_pixel_shift as dps
import digitalElevationModel as demserice
import dutil
import locationutil as util
import numpy as np
import scipy.interpolate as inplt
import utmLatlon
import xml.etree.ElementTree as ET


if platform.system() == "Windows":
    from osgeo import gdal
else:
    import gdal

def readGainsAndDarkCurrent(cpf_file, band, gain_number):
    tree = ET.parse(cpf_file)
    root = tree.getroot()
    if band == "PAN":
        gains_txt = root.findall("./RadiometricParameters/PAN/G%d/DetectorRelativeGains" % (gain_number))[0].text
        darkCurrent_txt = root.findall("./RadiometricParameters/PAN/G%d/DarkCurrents" % (gain_number))[0].text
    else:
        gains_txt = root.findall("./RadiometricParameters/B%d/G%d/DetectorRelativeGains" % (band, gain_number))[0].text
        darkCurrent_txt = root.findall("./RadiometricParameters/B%d/G%d/DarkCurrents" % (band, gain_number))[0].text
    # print gains_txt
    gains_txt = gains_txt.split(",")

    darkCurrent_txt = darkCurrent_txt.split(",")
    gains = []
    darkCurrents = []
    for it in range(len(gains_txt)):
        gains.append(float(gains_txt[it]))
        darkCurrents.append(float(darkCurrent_txt[it]))
    gains = np.array(gains)
    darkCurrents = np.array(darkCurrents)
    return gains, darkCurrents


def buildRMImage(file_name, line1B1, line1B2, line1B3, line1B4, g1, g2, g3, g4, d1, d2, d3, d4):
    file_band1 = file_name + "B1.tif"
    band1 = gdal.Open(file_band1)
    file_band2 = file_name + "B2.tif"
    band2 = gdal.Open(file_band2)
    file_band3 = file_name + "B3.tif"
    band3 = gdal.Open(file_band3)
    file_band4 = file_name + "B4.tif"
    band4 = gdal.Open(file_band4)
    out_file_name = file_name + "_ms.tif"
    gtiffDriver = gdal.GetDriverByName('GTiff')
    dst_ds = gtiffDriver.Create(out_file_name, 6000, 6000, 4, gdal.GDT_Byte)
    ms_b1 = dst_ds.GetRasterBand(1)
    ms_b2 = dst_ds.GetRasterBand(2)
    ms_b3 = dst_ds.GetRasterBand(3)
    ms_b4 = dst_ds.GetRasterBand(4)
    print "Saving Image"
    for line in range(6000):
        print "save line %d" % line
        lb1 = band1.ReadAsArray(0, line1B1 + line, 6000, 1).astype('float32')
        lb2 = band2.ReadAsArray(0, line1B2 + line, 6000, 1).astype('float32')
        lb3 = band3.ReadAsArray(0, line1B3 + line, 6000, 1).astype('float32')
        lb4 = band4.ReadAsArray(0, line1B4 + line, 6000, 1).astype('float32')
        lb1 = np.round((lb1 - d1) / g1)
        if lb1.min() < 0:
            print "find b1 less than zero"
        if lb1.max() > 255:
            print "find b1 greater than 255= %f" % lb1.max()
        lb1 = lb1 * (lb1 < 255.0) + 255.0 * (lb1 >= 255)
        lb1 = lb1.astype('uint8').reshape((1, 6000))
        lb1[0, 6:] = lb1[0, :-6]
        lb2 = np.round((lb2 - d2) / g2)
        if lb2.min() < 0:
            print "find b2 less than zero"
        if lb2.max() > 255:
            print "find b2 greater than 255= %f" % lb2.max()
        lb2 = lb2 * (lb2 < 255.0) + 255.0 * (lb2 >= 255)
        lb2 = lb2.astype('uint8').reshape((1, 6000))
        lb2[0, 4:] = lb2[0, :-4]
        lb3 = np.round((lb3 - d3) / g3)
        if lb3.min() < 0:
            print "find b3 less than zero"
        if lb3.max() > 255:
            print "find b3 greater than 255= %f" % lb3.max()
        lb3 = lb3 * (lb3 < 255.0) + 255.0 * (lb3 >= 255)
        lb3 = lb3.astype('uint8').reshape((1, 6000))
        lb4 = np.round((lb4 - d4) / g4)
        if lb4.min() < 0:
            print "find b4 less than zero"
        if lb4.max() > 255:
            print "find b4 greater than 255= %f" % lb4.max()
        lb4 = lb4 * (lb4 < 255.0) + 255.0 * (lb4 >= 255)
        lb4 = lb4.astype('uint8').reshape((1, 6000))
        lb4[0, :-5] = lb1[0, 5:]
        ms_b1.WriteArray(lb1, 0, line)
        ms_b2.WriteArray(lb2, 0, line)
        ms_b3.WriteArray(lb3, 0, line)
        ms_b4.WriteArray(lb4, 0, line)
    dst_ds = None

def readDataBand(gdalband , sample, line, width, height, gain, dark_curr, gain_numbers, im_type):

    pixels = np.arange(sample, sample + width).reshape((1, width))
    y_min = line
    im_data = gdalband.ReadAsArray(sample, line, width, height)

    if im_type == "PAN":
        nlines = gain_numbers.shape[0]
        glo = gain_numbers[:, 0].reshape((nlines, 1))
        gle = gain_numbers[:, 1].reshape((nlines, 1))
        gro = gain_numbers[:, 2].reshape((nlines, 1))
        gre = gain_numbers[:, 3].reshape((nlines, 1))
        gns = glo[y_min:(y_min + height), :] * (pixels < 6000) * (pixels % 2 == 0) + \
              gle[y_min:(y_min + height), :] * (pixels < 6000) * (pixels % 2 == 1) + \
              gro[y_min:(y_min + height), :] * (pixels >= 6000) * (pixels % 2 == 0) + \
              gre[y_min:(y_min + height), :] * (pixels >= 6000) * (pixels % 2 == 1)
    elif im_type == "MS":
        nlines = gain_numbers.shape[0]
        g = gain_numbers.reshape((nlines, 1))
        gns = np.repeat(g[y_min:(y_min + height), :], width, 1)
    pix_gain = np.zeros_like(im_data, 'float32')
    pix_drk = np.zeros_like(im_data, 'float32')
    for idg in range(len(gain)):
        pix_gain = pix_gain + (gns == (idg)) * gain[idg][pixels]
        pix_drk = pix_drk + (gns == (idg)) * dark_curr[idg][pixels]
    # print gain[2][pixels], pix_gain, pix_gain.min(), pix_gain.max()
    # print np.nonzero(pix_gain == 0.0)
    # pix_gain = gain[gns]
    # pix_drk = dark_cur[gns]
    im_data = im_data.astype('float32')
    im_data = (im_data - pix_drk) / pix_gain
    im_data = im_data.astype('float32')
    return im_data

def computeJDtime(date, time, utc_gps):
    t1 = time
    hour1 = int(np.floor(t1 / 3600.0))
    t1 -= hour1 * 3600.0
    minute1 = int(np.floor(t1) / 60.0)
    second1 = t1 - minute1 * 60.0
    micsec1 = second1 - int(np.floor(second1))
    micsec1 = int(micsec1 * 1e6)
    second1 = int(second1)
    tt1 = dutil.datetime(date[0], date[1], date[2], hour1, minute1, second1, micsec1)
    JD1 = tt1.to_jd() + utc_gps / (24 * 60. * 60.)
    return JD1


def determine_shift(lat1, lon1, lat3, lon3, im_width):
    distances13 = (lat1.reshape((im_width, 1)) - lat3.reshape((1, im_width))) ** 2
    distances13 += (lon1.reshape((im_width, 1)) - lon3.reshape((1, im_width))) ** 2
    distances13 = np.sqrt(distances13)
    distances13_min = distances13.min(1).reshape((im_width, 1))
    distances13_min = np.repeat(distances13_min, im_width, 1)
    [a, b] = np.nonzero(distances13 == distances13_min)
    return b


def determine_shift_subpixel(lat1, lon1, lat3, lon3, im_width):
    distances13 = (lat1.reshape((im_width, 1)) - lat3.reshape((1, im_width))) ** 2
    distances13 += (lon1.reshape((im_width, 1)) - lon3.reshape((1, im_width))) ** 2
    distances13 = np.sqrt(distances13)
    distances13_min = distances13.min(1).reshape((im_width, 1))
    distances13_min = np.repeat(distances13_min, im_width, 1)
    [a, b] = np.nonzero(distances13 == distances13_min)
    idx = 0
    bout = []
    for b0 in b:
        if (b0 > 0) and (b0 < im_width - 1):
            bn2 = max(0, b0 - 2)
            bn1 = max(0, b0 - 1)
            bp1 = min(im_width - 1, b0 + 1)
            bp2 = min(im_width - 1, b0 + 2)
            distances13x = distances13[idx, :]
            A = np.array([[bn2 ** 2, bn2, 1], [bn1 ** 2, bn1, 1], [b0 ** 2, b0, 1], [bp1 ** 2, bp1, 1],
                          [bp2 ** 2, bp2, 1]]).astype('float64')
            bv = np.array(
                [distances13x[bn2], distances13x[bn1], distances13x[b0], distances13x[bp1], distances13x[bp2]])
            par = np.linalg.lstsq(A, bv)[0]
            b_best = -par[1] / (2.0 * par[0])
        else:
            b_best = None
        bout.append(b_best)
        idx += 1
    bout = np.array(bout)
    return bout


def buildMSImageFromGerFile(out_file_name, in_file_name, lines, gains, dark_currents, current_date, utc_gps):
    im_height = 6000
    im_width = 6000
    samples = np.arange(im_width)
    posB1 = np.loadtxt(in_file_name + "B1.pos")
    posB2 = np.loadtxt(in_file_name + "B2.pos")
    posB3 = np.loadtxt(in_file_name + "B3.pos")
    posB4 = np.loadtxt(in_file_name + "B4.pos")

    timeB1 = np.loadtxt(in_file_name + "B1.tim")
    timeB2 = np.loadtxt(in_file_name + "B2.tim")
    timeB3 = np.loadtxt(in_file_name + "B3.tim")
    timeB4 = np.loadtxt(in_file_name + "B4.tim")

    attB1 = np.loadtxt(in_file_name + "B1.att")
    attB2 = np.loadtxt(in_file_name + "B2.att")
    attB3 = np.loadtxt(in_file_name + "B3.att")
    attB4 = np.loadtxt(in_file_name + "B4.att")

    band1 = gdal.Open(in_file_name + "B1.tif")
    band2 = gdal.Open(in_file_name + "B2.tif")
    band3 = gdal.Open(in_file_name + "B3.tif")
    band4 = gdal.Open(in_file_name + "B4.tif")


    # out_im = np.zeros((im_height,im_height,4),'uint8')
    out_line0 = np.zeros((1, im_width), 'uint8')
    posB1 = posB1[lines[0]:lines[0] + im_height]
    posB2 = posB2[lines[1]:lines[1] + im_height]
    posB3 = posB3[lines[2]:lines[2] + im_height]
    posB4 = posB4[lines[3]:lines[3] + im_height]

    timeB1 = timeB1[lines[0]:lines[0] + im_height]
    timeB2 = timeB2[lines[1]:lines[1] + im_height]
    timeB3 = timeB3[lines[2]:lines[2] + im_height]
    timeB4 = timeB4[lines[3]:lines[3] + im_height]

    attB1 = attB1[lines[0]:lines[0] + im_height]
    attB2 = attB2[lines[1]:lines[1] + im_height]
    attB3 = attB3[lines[2]:lines[2] + im_height]
    attB4 = attB4[lines[3]:lines[3] + im_height]
    gtiffDriver = gdal.GetDriverByName('GTiff')
    dst_ds = gtiffDriver.Create(out_file_name, 6000, 6000, 4, gdal.GDT_Byte)
    ms_b1 = dst_ds.GetRasterBand(1)
    ms_b2 = dst_ds.GetRasterBand(2)
    ms_b3 = dst_ds.GetRasterBand(3)
    ms_b4 = dst_ds.GetRasterBand(4)

    for k in range(im_height):
        out_line0 = np.zeros((1, im_width), 'uint8')
        out_line1 = np.zeros((1, im_width), 'uint8')
        out_line2 = np.zeros((1, im_width), 'uint8')
        out_line3 = np.zeros((1, im_width), 'uint8')
        jd1 = computeJDtime(current_date, timeB1[k], utc_gps)
        jd2 = computeJDtime(current_date, timeB2[k], utc_gps)
        jd3 = computeJDtime(current_date, timeB3[k], utc_gps)
        jd4 = computeJDtime(current_date, timeB4[k], utc_gps)
        uecef1 = util.computeUECEF(jd1, samples, attB1[k], 1)
        uecef2 = util.computeUECEF(jd2, samples, attB2[k], 2)
        uecef3 = util.computeUECEF(jd3, samples, attB3[k], 3)
        uecef4 = util.computeUECEF(jd4, samples, attB4[k], 4)
        earth_post1 = util.findEarthSurfacePosition(uecef1, posB1[k])
        earth_post2 = util.findEarthSurfacePosition(uecef2, posB2[k])
        earth_post3 = util.findEarthSurfacePosition(uecef3, posB3[k])
        earth_post4 = util.findEarthSurfacePosition(uecef4, posB4[k])
        lat1, lon1, height1 = util.itrf2latlon(earth_post1)
        lat2, lon2, height2 = util.itrf2latlon(earth_post2)
        lat3, lon3, height3 = util.itrf2latlon(earth_post3)
        lat4, lon4, height4 = util.itrf2latlon(earth_post4)
        one_lineB3 = band3.ReadAsArray(0, lines[2] + k - 1, im_width, 1)
        one_lineB3 = np.round((one_lineB3 - dark_currents[2]) / gains[2])
        one_lineB3 = one_lineB3 * (one_lineB3 < 255.0) + 255.0 * (one_lineB3 >= 255)

        out_line2[0, :] = one_lineB3[0]
        print "===========================\n creating Line %d:" % k

        b = determine_shift(lat1, lon1, lat3, lon3, im_width)
        one_lineB1 = band1.ReadAsArray(0, lines[0] + k - 1, im_width, 1)
        one_lineB1 = np.round((one_lineB1 - dark_currents[0]) / gains[0])
        one_lineB1 = one_lineB1 * (one_lineB1 < 255.0) + 255.0 * (one_lineB1 >= 255)


        # out_im[k,b,0] = one_lineB1
        out_line0[0, b] = one_lineB1
        print "   shift band1 pixel 1:%d" % b[0]
        print "   shift band1 pixel 3000:%d" % (b[3000] - 3000)

        b = determine_shift(lat2, lon2, lat3, lon3, im_width)
        one_lineB2 = band2.ReadAsArray(0, lines[1] + k - 1, im_width, 1)
        one_lineB2 = np.round((one_lineB2 - dark_currents[1]) / gains[1])
        one_lineB2 = one_lineB2 * (one_lineB2 < 255.0) + 255.0 * (one_lineB2 >= 255)
        # out_im[k,b,1] = one_lineB2
        out_line1[0, b] = one_lineB2
        print "   shift band2 :%d" % b[0]
        print "   shift band2 pixel 3000:%d" % (b[3000] - 3000)

        b = determine_shift(lat4, lon4, lat3, lon3, im_width)
        one_lineB4 = band4.ReadAsArray(0, lines[3] + k - 1, im_width, 1)
        one_lineB4 = np.round((one_lineB4 - dark_currents[3]) / gains[3])
        one_lineB4 = one_lineB4 * (one_lineB4 < 255.0) + 255.0 * (one_lineB4 >= 255)
        # out_im[k,b,3] = one_lineB4
        out_line3[0, b] = one_lineB4
        print "   shift band4 :%d" % (-im_width + b[-1])
        print "   shift band1 pixel 3000:%d" % (b[3000] - 3000)
        ms_b1.WriteArray(out_line0, 0, k)
        ms_b2.WriteArray(out_line1, 0, k)
        ms_b3.WriteArray(out_line2, 0, k)
        ms_b4.WriteArray(out_line3, 0, k)
    dst_ds = None




    # distances1 = np.zeros((im_width,im_width))
    # distances2 = np.zeros((im_width,im_width))
    # distances3 = np.zeros((im_width,im_width))
    # distances4 = np.zeros((im_width,im_width))
    # x31 = earth_post3[0].reshape(im_width,1)
    # x32 = earth_post3[1].reshape(im_width,1)
    # x33 = earth_post3[2].reshape(im_width,1)
    #
    # x11 = earth_post1[0].reshape(1,im_width)
    # x12 = earth_post1[1].reshape(1,im_width)
    # x13 = earth_post1[2].reshape(1,im_width)
    # distances1 = np.sqrt((x11-x31)**2+(x12-x32)**2 +(x13-x33)**2)
    # min_d1 = distances1.min(1)
    #
    # x21 = earth_post2[0].reshape(1,im_width)
    # x22 = earth_post2[1].reshape(1,im_width)
    # x23 = earth_post2[2].reshape(1,im_width)
    # distances2 = np.sqrt((x21-x31)**2+(x22-x32)**2 +(x23-x33)**2)
    #
    # x41 = earth_post4[0].reshape(1,im_width)
    # x42 = earth_post4[1].reshape(1,im_width)
    # x43 = earth_post4[2].reshape(1,im_width)
    # distances4 = np.sqrt((x41-x31)**2+(x42-x32)**2 +(x43-x33)**2)



    # use band3 for positioning'


def findPixelShifting(lat, lon, lat_ref, lon_ref, im_width):
    distances = (lat.reshape((im_width, 1)) - lat_ref.reshape((1, im_width))) ** 2
    distances += (lon.reshape((im_width, 1)) - lon_ref.reshape((1, im_width))) ** 2
    distances = np.sqrt(distances)
    distances_min = distances.min(0).reshape((1, im_width))
    distances_min = np.repeat(distances_min, im_width, 0)
    [a, b] = np.nonzero(distances == distances_min)
    idx = 0
    asub = []

    for a0 in a:
        an2 = max(0, a0 - 2)
        an1 = max(0, a0 - 1)
        ap1 = min(im_width - 1, a0 + 1)
        ap2 = min(im_width - 1, a0 + 2)
        distancesx = distances[:, idx].flatten()
        A = np.array(
            [[an2 ** 2, an2, 1], [an1 ** 2, an1, 1], [a0 ** 2, a0, 1], [ap1 ** 2, ap1, 1], [ap2 ** 2, ap2, 1]]).astype(
            'float64')
        bv = np.array([distancesx[an2], distancesx[an1], distancesx[a0], distancesx[ap1], distancesx[ap2]])
        par = np.linalg.lstsq(A, bv)[0]
        b_best = -par[1] / (2.0 * par[0])
        asub.append(b_best)
        idx += 1
    a_sub = np.array(asub)
    a_sub = a_sub * (a_sub <= im_width - 1) * (a_sub >= 0) + (im_width - 1) * (a_sub > im_width)
    return a_sub


def w(x):
    a = -0.5
    a3 = a + 2.0
    a2 = -a - 3.0
    b3 = a
    b2 = -5.0 * a
    b1 = 8 * a
    b0 = -4 * a
    absx = np.abs(x)
    absx3 = absx ** 3
    absx2 = absx ** 2
    y1 = a3 * absx3 ** 3 + a2 * absx2 + 1.0
    y2 = b3 * absx3 + b2 * absx2 + b1 * absx + b0
    y = y1 * (absx <= 1.0) + y2 * (absx > 1) * (absx < 2.0)
    return y


def cubicInterpolationV1(data, pixel_map, im_width):
    data = data.astype('float32')
    a = np.floor(pixel_map).astype('int32')
    ap1 = a + 1
    ap1 = ap1 * (ap1 < im_width) + (a - (ap1 - im_width) - 1) * (ap1 >= im_width)
    ap1 = ap1 * (ap1 >= 0) + (-ap1) * (ap1 < 0)
    ap2 = a + 2
    ap2 = ap2 * (ap2 < im_width) + (a - (ap2 - im_width) - 1) * (ap2 >= im_width)
    ap2 = ap2 * (ap2 >= 0) + (-ap2) * (ap2 < 0)
    an1 = a - 1
    an1 = an1 * (an1 >= 0) + (-an1) * (an1 < 0)
    an1 = an1 * (an1 < im_width) + (a - (an1 - im_width) - 1) * (an1 >= im_width)
    w0 = w(pixel_map - a)
    wp1 = w(a + 1 - pixel_map)
    wp2 = w(a + 2 - pixel_map)
    wn1 = w(pixel_map - a + 1)
    imout = w0 * data[0, a] + wp1 * data[0, ap1] + wp2 * data[0, ap2] + wn1 * data[0, an1]
    imout = imout * (imout > 0) * (imout <= 255) + 255 * (imout > 255)
    imout = imout.astype('uint8')
    imout = imout.reshape((1, im_width))
    return imout


def cubicInterpolation(data, pixel_map, im_width):
    data = data.astype('float32')
    pixel_map2 = pixel_map.copy()
    pixel_map = pixel_map * (pixel_map > 0) * (pixel_map <= im_width - 1) + (im_width - 1) * (pixel_map > im_width)
    a = np.floor(pixel_map).astype('int32')
    ap1 = a + 1
    ap1 = ap1 * (ap1 < im_width) + (a - (ap1 - im_width) - 1) * (ap1 >= im_width)
    ap1 = ap1 * (ap1 >= 0) + (-ap1) * (ap1 < 0)
    ap2 = a + 2
    ap2 = ap2 * (ap2 < im_width) + (a - (ap2 - im_width) - 1) * (ap2 >= im_width)
    ap2 = ap2 * (ap2 >= 0) + (-ap2) * (ap2 < 0)
    an1 = a - 1
    an1 = an1 * (an1 >= 0) + (-an1) * (an1 < 0)
    an1 = an1 * (an1 < im_width) + (a - (an1 - im_width) - 1) * (an1 >= im_width)
    # print a.shape
    # print a.max()
    # print a.min()
    term1 = 2.0 * data[a]
    term2 = -1 * data[an1] + data[ap1]
    term3 = 2.0 * data[an1] - 5.0 * data[a] + 4.0 * data[ap1] - 1.0 * data[ap2]
    term4 = -1.0 * data[an1] + 3.0 * data[a] - 3.0 * data[ap1] + 1.0 * data[ap2]
    t = pixel_map - a
    imout = term1 + t * term2 + t * t * term3 + t * t * t * term4
    imout = imout / 2.0
    imout = imout * (imout > 0) * (imout <= 255) + 255 * (imout > 255)
    imout = imout.astype('uint8') * (pixel_map2 > 0) * (pixel_map2 <= im_width - 1)
    # imout = imout.reshape((1,im_width))
    return imout

def findSamplesPoints(in_file_name, step, lines, sat_pos, sat_time, sat_att, image_data, offset_mins, current_date,
                      utc_gps, dut1, dem, dem_interpolation_method, im_width, im_height, precision_error=1.0,
                      max_percision_error=5.0, process_box=500):

    # process_box = 500
    pos1, pos2, pos3, pos4 = sat_pos
    time1, time2, time3, time4 = sat_time
    att1, att2, att3, att4 = sat_att
    num_data_line = len(sat_time)

    x1 = []
    y1 = []
    x2 = []
    y2 = []
    x3 = []
    y3 = []
    x4 = []
    y4 = []

    for block_line in range(0, im_height, process_box) :
        for block_sample in range(0, im_width, process_box):
            # block_line = 3500
            # block_sample = 5500
            mid_sample = block_sample + process_box / 2
            mid_line = block_line + process_box / 2

            print "Find the initial shift at the middle of an image (%d,%d)" % (mid_sample, mid_line)
            lat3a, lon3a, h3a = dps.findInterSectionPointArrayUsingDEMPreloaded("MS", in_file_name, np.array([mid_sample]),
                                                                                [mid_line + lines[2]], pos3, time3, att3,
                                                                                current_date, utc_gps, dut1, dem,
                                                                                dem_interpolation_method, band=3)

            x3a, y3a, zn3, zt3 = utmLatlon.from_latlon(lat3a, lon3a)
            dx_init = np.zeros((4,))  # [45, 22, 0, -23]
            dy_init = np.zeros((4,))  # [29, 28, 0, -29]
            for band in [1, 2, 4]:
                err_min = 1e100
                best_solution_found = False
                dx = 0
                dy = 0
                while not best_solution_found:
                    err_min = 1e100

                    for tx in [-1, 0, 1]:
                        for ty in [-1, 0, 1]:
                            latb, lonb, hb = util.computeViewLatLongArrayWithHeight(band, np.array([dx]) + tx + mid_sample,
                                                                                    np.array([dy]) + ty + mid_line, h3a,
                                                                                    lines[band - 1],
                                                                                    sat_pos[band - 1],
                                                                                    sat_att[band - 1],
                                                                                    sat_time[band - 1],
                                                                                    current_date[0], current_date[1],
                                                                                    current_date[2], utc_gps, dut1)
                            xb, yb, zn, zt = utmLatlon.from_latlon(latb, lonb, zn3)
                            error = np.sqrt((xb - x3a) ** 2 + (yb - y3a) ** 2)[0]
                            if error < err_min:
                                err_min = error
                                dx_temp = tx
                                dy_temp = ty

                    if (dx_temp == 0) and (dy_temp == 0):
                        best_solution_found = True

                        dx_init[band - 1] = dx
                        dy_init[band - 1] = dy
                    else:
                        dx += dx_temp
                        dy += dy_temp

                print "The initial dislacement for Band %d is (%d,%d)" % (band, dx_init[band - 1], dy_init[band - 1])
            bline = block_line
            bsample = block_sample
            # block_width = im_width
            max_block_height = process_box
            max_block_width = process_box
            block_height = min((im_height - bline), max_block_height)
            block_width = min(im_width - bsample, max_block_width)
            line_str = block_line
            line_stp = line_str + block_height
            sample_str = block_sample
            sample_stp = sample_str + block_width
            samples2 = np.arange(sample_str + step / 2, sample_stp, step)



            for line in range(line_str + step / 2 , line_stp, step):
                # print "working on Sample:%d and Line: %d" % (line
                # print "Estimating locations."


                lat3a, lon3a, h3a = dps.findInterSectionPointArrayUsingDEMPreloaded("MS", in_file_name, samples2,
                                                                                        [line + lines[2]], pos3, time3,
                                                                                        att3, current_date,
                                                                                        utc_gps, dut1, dem,
                                                                                        dem_interpolation_method,
                                                                                        band=3)
                x3a, y3a, zn3, zt3 = utmLatlon.from_latlon(lat3a, lon3a, zn3)
                # x3.append(samples2)
                # y3.append(line*np.ones_like(samples2))
                sard_times = np.loadtxt(in_file_name + "B%dsadr_times.txt" % 3)
                sard_last_time = sard_times[-1]
                valid_pixels = np.ones_like(samples2)
                for band in [1, 2, 4]:
                    sx_in = (samples2 + dx_init[band - 1]).astype('float64')
                    sy_in = (np.array(line + dy_init[band - 1]) * np.ones_like(samples2)).astype('float64')
                    err_sx = np.ones_like(sx_in) * 2.0
                    err_sy = np.ones_like(sx_in) * 2.0
                    num_fail = 0

                    for it in range(200):
                        idx = np.nonzero((err_sx > precision_error) + (err_sy > precision_error))[0]
                        if len(idx) == 0 :  # and (not brute_force):
                            brute_force = False
                            # print "Save best location!!"
                            if band == 1:
                                sx1 = sx_in.copy()  # x1.append(sx)
                                sy1 = sy_in.copy()  # y1.append(sy)
                            elif band == 2:
                                sx2 = sx_in.copy()  # x2.append(sx)
                                sy2 = sy_in.copy()  # y2.append(sy)
                            elif band == 4:
                                sx4 = sx_in.copy()  # x4.append(sx)
                                sy4 = sy_in.copy()  # sy4.append(sy)
                            break

                        sx = sx_in[idx]
                        sy = sy_in[idx]
                        hb = h3a[idx]
                        lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy,
                                                                              hb, lines[band - 1], sat_pos[band - 1],
                                                                              sat_att[band - 1], sat_time[band - 1],
                                                                              current_date[0], current_date[1],
                                                                              current_date[2], utc_gps, dut1)
                        xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon, zn3)
                        errx = xb - x3a[idx]
                        erry = yb - y3a[idx]

                        errx_max = np.abs(errx).max()
                        erry_max = np.abs(erry).max()


                        lat1, lon1, ht = util.computeViewLatLongArrayWithHeight(band, sx + 1.0, sy,
                                                                                hb, lines[band - 1], sat_pos[band - 1],
                                                                                sat_att[band - 1], sat_time[band - 1],
                                                                                current_date[0], current_date[1],
                                                                                current_date[2], utc_gps, dut1)
                        lat2, lon2, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy + 1.0,
                                                                                hb, lines[band - 1], sat_pos[band - 1],
                                                                                sat_att[band - 1], sat_time[band - 1],
                                                                                current_date[0], current_date[1],
                                                                                current_date[2], utc_gps, dut1)
                        xb1, yb1, zn, zt = utmLatlon.from_latlon(lat1, lon1)
                        xb2, yb2, zn, zt = utmLatlon.from_latlon(lat2, lon2)
                        # errlat = xb - x3a
                        # errlon = yb - y3a
                        total_errors = np.sqrt(errx ** 2 + erry ** 2)
                        gx = 2.0 * errx * (xb1 - xb) + 2.0 * (erry) * (yb1 - yb)
                        gy = 2.0 * errx * (xb2 - xb) + 2.0 * (erry) * (yb2 - yb)
                        lamb = (0.1 / total_errors)
                        lamb = (lamb > 0.001) * 0.001 + (lamb <= 0.001) * lamb

                        lamb = (lamb < 1e-7) * 1e-7 + (lamb >= 1e-7) * lamb


                        itx = 0
                        it_max = 100
                        new_total_error = total_errors.copy()
                        while np.any(new_total_error >= total_errors) and (itx < it_max):
                            sxt = sx - lamb * gx
                            syt = sy - lamb * gy

                            lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sxt, syt,
                                                                                  hb, lines[band - 1], sat_pos[band - 1],
                                                                                  sat_att[band - 1], sat_time[band - 1],
                                                                                  current_date[0], current_date[1],
                                                                                  current_date[2], utc_gps, dut1)

                            try:
                                xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon, zn3)
                                errold_x = errx.copy()
                                errold_y = erry.copy()
                                errx = xb - x3a[idx]
                                erry = yb - y3a[idx]

                                old_total_error = new_total_error.copy()
                                new_total_error = np.sqrt(errx ** 2 + erry ** 2)
                                lamb = (lamb / 2.0) * (new_total_error >= total_errors) + \
                                       (lamb / 2.0) * (new_total_error < total_errors) * (
                                       new_total_error < old_total_error) + \
                                       (lamb) * (new_total_error < total_errors) * (new_total_error >= old_total_error)

                                errx = errx * (new_total_error >= total_errors) + \
                                       errx * (new_total_error < total_errors) * (new_total_error < old_total_error) + \
                                       errold_x * (new_total_error < total_errors) * (
                                       new_total_error >= old_total_error)

                                erry = erry * (new_total_error >= total_errors) + \
                                       erry * (new_total_error < total_errors) * (new_total_error < old_total_error) + \
                                       errold_y * (new_total_error < total_errors) * (
                                       new_total_error >= old_total_error)

                                itx += 1
                            except :
                                lamb = lamb / 10.0
                                sxt = sx - lamb * gx
                                syt = sy - lamb * gy
                                itx += 1

                        sx = sx - (lamb * 2) * gx
                        sy = sy - (lamb * 2) * gy
                        sx_in[idx] = sx
                        sy_in[idx] = sy
                        err_sx[idx] = errx
                        err_sy[idx] = erry


                        if itx == it_max:
                            # print "[%d] cannot improve the performance any future!" % (band),
                            # print "..... error x: %f, error y: %f." % ( errxm, errym)
                            # print "Exiting the solution searching"
                            # print "Try to randomly move around. "
                            sx_bestold = sx.copy()
                            sy_bestold = sy.copy()
                            if num_fail < 5:
                                sx = sx_bestold + 2.0 * (np.random.rand(sx.shape[0]) - 0.5)  # samples2 + dx_init[band - 1]
                                sy = sy_bestold + 2.0 * (np.random.rand(sx.shape[0]) - 0.5)  # np.array(line + dy_init[band - 1]) * np.ones_like(samples2)
                                num_fail += 1
                            else:
                                print "Warning: There are saving %d pixels from Band %d with positioning error more than " \
                                      "%f meters." % (sx.shape[0], band, precision_error)

                                id_max = np.nonzero((err_sx > max_percision_error) + (err_sy > max_percision_error))[0]


                                valid_pixels[id_max] = 0
                                if band == 1:
                                    sx1 = sx_in.copy()  # x1.append(sx)
                                    sy1 = sy_in.copy()  # y1.append(sy)
                                elif band == 2:
                                    sx2 = sx_in.copy()  # x2.append(sx)
                                    sy2 = sy_in.copy()  # y2.append(sy)
                                elif band == 4:
                                    sx4 = sx_in.copy()  # x4.append(sx)
                                    sy4 = sy_in.copy()  # sy4.append(sy)
                                break

                if (sat_time[band - 1][line + lines[band - 1]] > sard_last_time) or (sat_time[2][line + lines[2]] > sard_last_time):
                    print "perform image to image registration"
                    num_sample_points = len(sx)
                    bandheight = image_data[band - 1].shape[0]
                    lineb = lines[band - 1]
                    max_lineb = bandheight + offset_mins[band - 1]
                    for k in range(num_sample_points):
                        sx3 = samples2[k]
                        sy3 = line
                        sxb = sx[k]
                        syb = sy[k]
                        if (sx3 > 20) & (sx3 < im_width - 20) & (sy3 > 20) & (sy3 < im_height - 20):
                            if  (sxb > 25) & (sxb < im_width - 25) & (syb > 25) & (syb < max_lineb - 25):
                                im3 = image_data[2][sy3 - 20:sy3 + 21, sx3 - 20:sx3 + 21]
                                xg, yg = np.meshgrid(sxb + np.arange(-20, 21), syb + np.arange(-20, 21) - offset_mins[band - 1])
                                xg = xg.astype('float32')
                                yg = yg.astype('float32')
                                itc_max = 10
                                itc = 0
                                c_done = False
                                dx = 0
                                dy = 0
                                grad_old = 1e300
                                while (itc < itc_max) & (not c_done):
                                    imb = cv2.remap(image_data[band - 1], xg + dx + 1, yg + dy, cv2.INTER_CUBIC)
                                    coor0 = np.corrcoef([im3.flatten(), imb.flatten()])[0, 1]
                                    imb = cv2.remap(image_data[band - 1], xg + dx + 2, yg + dy , cv2.INTER_CUBIC)
                                    coorr = np.corrcoef([im3.flatten(), imb.flatten()])[0, 1]
                                    imb = cv2.remap(image_data[band - 1], xg + dx + 1, yg + dy + 1, cv2.INTER_CUBIC)
                                    coord = np.corrcoef([im3.flatten(), imb.flatten()])[0, 1]
                                    gr = coorr - coor0
                                    gd = coord - coor0
                                    grad = np.sqrt(gr ** 2 + gd ** 2)
                                    if grad < grad_old:
                                        grad_old = grad
                                        itc += 1
                                        itg = 0
                                        itgmax = 10
                                        lamb = 1.0
                                        while (itg < itgmax):
                                            dxp = dx + lamb * gr
                                            dyp = dy + lamb * gd
                                            imb = cv2.remap(image_data[band - 1], xg + dxp + 1, yg + dyp, cv2.INTER_CUBIC)
                                            coorp = np.corrcoef([im3.flatten(), imb.flatten()])[0, 1]
                                            if coorp > coor0:
                                                dx = dxp
                                                dy = dyp
                                                itg = itgmax
                                            else:
                                                lamb /= 2.0
                                                itg += 1
                                    else:
                                        c_done = True
                                sx[k] += dx
                                sy[k] += dy




                if (sx1 is not None) & (sy1 is not None) & (sx2 is not None) & (sy2 is not None) & (sx4 is not None) & (sy4 is not None):

                    id_ready = np.nonzero(valid_pixels)[0]
                    id_max = np.nonzero(valid_pixels == 0)[0]
                    if np.any(sx1) is None:
                        print sx1
                    if len(id_max) > 0 :
                        print "Warning: We need to remove %d pixels due to the maximum error is more than the " \
                              "maximum limit of %f meters" % (id_max.shape[0], max_percision_error)
                        if valid_pixels.sum() > 0 :
                            x1.append(sx1[id_ready])
                            x2.append(sx2[id_ready])
                            x3.append(samples2[id_ready])
                            x4.append(sx4[id_ready])

                            y1.append(sy1[id_ready])
                            y2.append(sy2[id_ready])
                            y3.append(line * np.ones_like(samples2[id_ready]))
                            y4.append(sy4[id_ready])
                    else:
                        x1.append(sx1)
                        x2.append(sx2)
                        x3.append(samples2)
                        x4.append(sx4)

                        y1.append(sy1)
                        y2.append(sy2)
                        y3.append(line * np.ones_like(samples2))
                        y4.append(sy4)
    num_items = 0
    for item in x1:
        num_items += len(item)
    x1out = np.zeros((num_items,))
    x2out = np.zeros((num_items,))
    x3out = np.zeros((num_items,))
    x4out = np.zeros((num_items,))

    y1out = np.zeros((num_items,))
    y2out = np.zeros((num_items,))
    y3out = np.zeros((num_items,))
    y4out = np.zeros((num_items,))

    num_list = len(x1)
    str = 0
    for list_id in range(num_list):
        stp = str + len(x1[list_id])
        x1out[str:stp] = x1[list_id]
        x2out[str:stp] = x2[list_id]
        x3out[str:stp] = x3[list_id]
        x4out[str:stp] = x4[list_id]

        y1out[str:stp] = y1[list_id]
        y2out[str:stp] = y2[list_id]
        y3out[str:stp] = y3[list_id]
        y4out[str:stp] = y4[list_id]
        str = stp



    # x1 = np.array(x1).flatten()
    # x2 = np.array(x2).flatten()
    # x3 = np.array(x3).flatten()
    # x4 = np.array(x4).flatten()
    # y1 = np.array(y1).flatten()
    # y2 = np.array(y2).flatten()
    # y3 = np.array(y3).flatten()
    # y4 = np.array(y4).flatten()
    return x1out, x2out, x3out, x4out, y1out, y2out, y3out, y4out

def remapImageBandGridMethod(xb, yb, x3, y3, line_str, sample_str, block_size, im_width, im_height, offset_min,
                             max_error=0.1):


    # fx = inplt.RectBivariateSpline(U2, V2, X2, bbox=[sample_str, im_width, 0, im_height])
    # fy = inplt.RectBivariateSpline(U2, V2, Y2, bbox=[sample_str, im_width, 0, im_height])

    end_line = min(line_str + block_size, im_height)
    end_sample = min(sample_str + block_size, im_width)
    print "working on line:%d to %d and sample: %d to %d" % (line_str, end_line, sample_str, end_sample)
    block_height = end_line - line_str
    block_width = end_sample - sample_str
    out_x = np.zeros((block_height, block_width), 'float32')
    out_y = np.zeros((block_height, block_width), 'float32')
    mask = np.ones((block_height, block_width), 'uint8')
    idx = np.nonzero((x3 >= sample_str) * (x3 < end_sample) * (y3 >= line_str) * (y3 < end_line))[0]
    u = x3[idx]
    v = y3[idx]
    num_samples = u.size
    mid_sample = np.median(u)
    mid_line = np.median(v)
    ut = (u - mid_sample).astype('float64')
    vt = (v - mid_line).astype('float64')
    AA = np.zeros((num_samples, 12), 'float64')
    AA[:, 0] = 1.0
    AA[:, 1] = ut
    AA[:, 2] = vt
    AA[:, 3] = ut * vt
    AA[:, 4] = ut ** 2
    AA[:, 5] = vt ** 2
    AA[:, 6] = ut * vt * vt
    AA[:, 7] = vt * ut * ut
    AA[:, 8] = ut ** 3
    AA[:, 9] = vt ** 3
    AA[:, 10] = vt * ut ** 3
    AA[:, 11] = ut * vt ** 3
    x1 = xb[idx]
    y1 = yb[idx]
    b = x1 - mid_sample
    par_x1 = np.linalg.lstsq(AA, b)[0]
    errx1 = (np.abs(np.dot(AA, par_x1) - b).max())
    print "max error column: %f" % errx1

    b = y1 - mid_line
    par_y1 = np.linalg.lstsq(AA, b)[0]
    erry1 = (np.abs(np.dot(AA, par_y1) - b).max())
    print "max error row: %f" % erry1
    if ((errx1 > max_error) or (erry1 > max_error)) and (block_size > 500):
        new_block_size = max(block_size / 2, 500)
        for sub_line in range(line_str, end_line, new_block_size):
            for sub_sample in range(sample_str, end_sample, new_block_size):

                lstr = sub_line - line_str
                sstr = sub_sample - sample_str
                sub_block_line_end = min(sub_line + new_block_size, end_line)
                sub_block_sample_end = min(sub_sample + new_block_size, end_sample)
                sub_out_x, sub_out_y, sub_mask = remapImageBandGridMethod(xb, yb, x3, y3, sub_line, sub_sample,
                                                                 new_block_size, im_width, im_height, offset_min,
                                                                 max_error)

                # sub_out_x, sub_out_y, sub_mask = remapImageBandGridMethod( xb, yb, x3, y3, sub_line, sub_sample,
                #                                                  new_block_size, im_width,im_height, offset_min,
                #                                                  block_offset, max_error)
                sub_block_line_end -= line_str
                sub_block_sample_end -= sample_str
                print lstr, sstr, sub_block_line_end, sub_block_sample_end
                w = sub_block_sample_end - sstr
                h = sub_block_line_end - lstr
                out_x[lstr:sub_block_line_end, sstr: sub_block_sample_end] = sub_out_x[:h, :w]
                out_y[lstr:sub_block_line_end, sstr: sub_block_sample_end] = sub_out_y[:h, :w]
                mask[lstr:sub_block_line_end, sstr: sub_block_sample_end] = sub_mask[:h, :w]
    else:
        bline = line_str
        bsample = sample_str
        V, U = np.mgrid[bline:bline + block_height, bsample:bsample + block_width]

        sub_mask = np.ones_like(U, "uint8")
        mskh, mskw = sub_mask.shape
        u1d = U.flatten()
        v1d = V.flatten()
        num_pairs = u1d.size
        A = np.zeros((num_pairs, 12))
        ut = (u1d - mid_sample).astype('float64')
        vt = (v1d - mid_line).astype('float64')
        A[:, 0] = 1.0
        A[:, 1] = ut
        A[:, 2] = vt
        A[:, 3] = ut * vt
        A[:, 4] = ut ** 2
        A[:, 5] = vt ** 2
        A[:, 6] = ut * vt * vt
        A[:, 7] = vt * ut * ut
        A[:, 8] = ut ** 3
        A[:, 9] = vt ** 3
        A[:, 10] = vt * ut ** 3
        A[:, 11] = ut * vt ** 3
        sub_mask = sub_mask.flatten()

        x = np.dot(A, par_x1) + mid_sample + 1
        y = np.dot(A, par_y1) + mid_line - offset_min
        x = x.astype('float32')
        y = y.astype('float32')
        out_x = x.reshape(U.shape)
        out_y = y.reshape(U.shape)
        idx = np.nonzero((x < 0))[0]
        sub_mask[idx] = 0
        idx = np.nonzero((x > im_width - 1))[0]
        sub_mask[idx] = 0
        # mask[y > im_height-1, x > im_width-1] = 0

        sub_mask = sub_mask.reshape(U.shape)
        out_x = out_x
        out_y = out_y
        mask = sub_mask




    return out_x, out_y, mask



# def findSamplesPoints(in_file_name, step, lines,sat_pos, sat_time, sat_att, image_data,offset_mins, current_date,
#                       utc_gps, dut1, dem_directory, im_width, im_height):
#
#     mid_sample = im_width/2
#     mid_line = im_height/2
#     pos1, pos2, pos3, pos4 = sat_pos
#     time1,time2,time3,time4 = sat_time
#     att1, att2, att3, att4 = sat_att
#
#     print "Find the initial shift at the middle of an image (%d,%d)" % (mid_sample, mid_line)
#     lat3a, lon3a, h3a = dps.findInterSectionPointArrayUsingKrigingPreloaded("MS", in_file_name,
#                                                                             np.array([mid_sample]),
#                                                                             [mid_line + lines[2]], pos3, time3,
#                                                                             att3, current_date,
#                                                                             utc_gps, dut1, dem_directory,
#                                                                             band=3)
#     dx_init = [0, 0, 0, 0]
#     dy_init = [0, 0, 0, 0]
#     for band in [1, 2, 4]:
#         err_min = 1e100
#         for dx in range(-10, 10):
#             for dy in range(-10, 10):
#
#                 latb, lonb, hb = util.computeViewLatLongArrayWithHeight(band, np.array([dx]) + mid_sample,
#                                                                         np.array([dy]) + mid_line, h3a,
#                                                                         lines[band - 1],
#                                                                         sat_pos[band - 1],
#                                                                         sat_att[band - 1],
#                                                                         sat_time[band - 1],
#                                                                         current_date[0], current_date[1],
#                                                                         current_date[2], utc_gps, dut1)
#                 error = np.sqrt((latb - lat3a) ** 2 + (lonb - lon3a) ** 2)[0]
#                 # print error
#                 if error < err_min:
#                     err_min = error
#                     dx_init[band - 1] = dx
#                     dy_init[band - 1] = dy
#         print "The initial dislacement for Band %d is (%d,%d)" % (band, dx_init[band - 1], dy_init[band - 1])
#     bline = 0
#     bsample = 0
#     block_width = im_width
#     max_block_height = im_height
#     max_block_width = im_width
#     block_height = min((im_height - bline), max_block_height)
#     block_width = min(im_width - bsample, max_block_width)
#     line_str = 0
#     line_stp = block_height
#     sample_str = 0
#     sample_stp = block_width
#     samples2 = np.arange(sample_str, sample_stp, step)
#
#     x1 = []
#     y1 = []
#     x2 = []
#     y2 = []
#     x3 = []
#     y3 = []
#     x4 = []
#     y4 = []
#
#     v = np.arange(line_str + step/2, line_stp, step)
#     u = samples2.copy()
#     #num_u = u.shape[0]
#     #num_v = v.shape[0]
#     #line_str = 5880
#     for line in range(line_str + step/2, line_stp, step):
#         #line = 5425
#         print "working on line: %d" % line
#         print "Estimating locations."
#         lat3a, lon3a, h3a = dps.findInterSectionPointArrayUsingKrigingPreloaded("MS", in_file_name, samples2,
#                                                                                 [line + lines[2]], pos3, time3,
#                                                                                 att3, current_date,
#                                                                                 utc_gps, dut1, dem_directory, band=3)
#         x3a, y3a, zn3, zt3 = utmLatlon.from_latlon(lat3a, lon3a)
#
#         # lat3a1, lon3a1, h3a1 = dps.findInterSectionPointArrayUsingKrigingPreloaded("MS", in_file_name, samples2,
#         #                                                                         [line + lines[2]+10], pos3, time3,
#         #                                                                         att3, current_date,
#         #                                                                         utc_gps, dut1, dem_directory, band=3)
#         # x3a1, y3a1, zn31, zt31 = utmLatlon.from_latlon(lat3a1, lon3a1)
#         # print (x3a1-x3a).max(),(y3a1-y3a).max()
#         # print (x3a1 - x3a).min(), (y3a1 - y3a).min()
#         # band =1
#         # sx = samples2 + dx_init[band- 1]
#         # sy = np.array(line + dy_init[band - 1]) * np.ones_like(samples2)
#         # lat1, lon1, ht1 = util.computeViewLatLongArrayWithHeight(band, sx, sy,
#         #                                                       h3a, lines[band - 1], sat_pos[band - 1],
#         #                                                       sat_att[band - 1], sat_time[band - 1],
#         #                                                       current_date[0], current_date[1],
#         #                                                       current_date[2], utc_gps, dut1)
#         # xb1, yb1, zn1, zt1 = utmLatlon.from_latlon(lat1, lon1)
#         #
#         # lat2, lon2, ht2 = util.computeViewLatLongArrayWithHeight(band, sx, sy+10,
#         #                                                          h3a, lines[band - 1], sat_pos[band - 1],
#         #                                                          sat_att[band - 1], sat_time[band - 1],
#         #                                                          current_date[0], current_date[1],
#         #                                                          current_date[2], utc_gps, dut1)
#         # xb2, yb2, zn2, zt2 = utmLatlon.from_latlon(lat2, lon2)
#         # print (xb1 - xb2).max(), (yb1 - yb2).max()
#         # print (xb1 - xb2).min(), (yb1 - yb2).min()
#         #x3.append(samples2)
#         #y3.append(line*np.ones_like(samples2))
#         sard_times = np.loadtxt(in_file_name + "B%dsadr_times.txt" % 3)
#         sard_last_time = sard_times[-1]
#         #sard_last_time = sat_time[0][-1]
#         for band in [1, 2, 4]:
#             print "Find the best pixels in Band %d."%band
#             sx = samples2 + dx_init[band - 1]
#             sy = np.array(line + dy_init[band - 1]) * np.ones_like(samples2)
#             #print "Band: %d has line max of %d"%(band,sy.max()+lines[band-1])
#             brute_force = False
#             max_iteration = 200
#             for it in range(max_iteration):
#                 lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy,
#                                                                       h3a, lines[band - 1], sat_pos[band - 1],
#                                                                       sat_att[band - 1], sat_time[band - 1],
#                                                                       current_date[0], current_date[1],
#                                                                       current_date[2], utc_gps, dut1)
#                 xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon)
#                 errx = xb - x3a
#                 erry = yb - y3a
#                 errx_max = np.abs(errx).max()
#                 erry_max = np.abs(erry).max()
#                 if ((errx_max < 0.5) and (erry_max < 0.5)) : #and (not brute_force):
#                     brute_force = False
#                     #print "Save best location!!"
#                     print "Sucessful."
#                     if band == 1:
#                         sx1 = sx #x1.append(sx)
#                         sy1 = sy #y1.append(sy)
#                         print sy.min(),sy.max()
#                     elif band == 2:
#                         sx2 = sx #x2.append(sx)
#                         sy2 = sy #y2.append(sy)
#                     elif band == 4:
#                         sx4 = sx #x4.append(sx)
#                         sy4 = sy #sy4.append(sy)
#                     break
#
#                 # print errx.min(), errx.max(), erry.min(), erry.max()
#
#                 lat1, lon1, ht = util.computeViewLatLongArrayWithHeight(band, sx + 1, sy,
#                                                                         h3a, lines[band - 1], sat_pos[band - 1],
#                                                                         sat_att[band - 1], sat_time[band - 1],
#                                                                         current_date[0], current_date[1],
#                                                                         current_date[2], utc_gps, dut1)
#                 lat2, lon2, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy + 1,
#                                                                         h3a, lines[band - 1], sat_pos[band - 1],
#                                                                         sat_att[band - 1], sat_time[band - 1],
#                                                                         current_date[0], current_date[1],
#                                                                         current_date[2], utc_gps, dut1)
#                 xb1, yb1, zn, zt = utmLatlon.from_latlon(lat1, lon1)
#                 xb2, yb2, zn, zt = utmLatlon.from_latlon(lat2, lon2)
#                 # errlat = xb - x3a
#                 # errlon = yb - y3a
#                 gx = 2.0 * errx * (xb1 - xb) + 2.0 * (erry) * (yb1 - yb)
#                 gy = 2.0 * errx * (xb2 - xb) + 2.0 * (erry) * (yb2 - yb)
#                 lamb = 0.001
#
#                 errxm = errx_max
#                 errym = erry_max
#                 itx = 0
#                 it_max = 50
#                 while ((errxm >= errx_max) or (errym >= erry_max)) and (itx < it_max):
#                     sxt = sx - lamb * gx
#                     syt = sy - lamb * gy
#
#                     lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sxt, syt,
#                                                                           h3a, lines[band - 1], sat_pos[band - 1],
#                                                                           sat_att[band - 1], sat_time[band - 1],
#                                                                           current_date[0], current_date[1],
#                                                                           current_date[2], utc_gps, dut1)
#                     xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon, zn3)
#                     errx = xb - x3a
#                     erry = yb - y3a
#                     errxm = np.abs(errx).max()
#                     errym = np.abs(erry).max()
#                     #print "lambda:%f, %f, %f"%(lamb,errxm,errym)
#                     lamb = lamb / 2.0
#                     itx += 1
#                 sx = sx - (lamb * 2) * gx
#                 sy = sy - (lamb * 2) * gy
#                 if itx == it_max:
#                     print "[%d] cannot improve the performance any future!" % (band),
#                     print " with lambda:%f, error x: %f, error y: %f." % (lamb, errxm, errym)
#                     print "Exiting the gradient search approach!"
#                     print "Using a brute force approach to find a new initial pixel."
#                     sx = samples2 + dx_init[band - 1]
#                     sy = np.array(line + dy_init[band - 1]) * np.ones_like(samples2)
#                     lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy,
#                                                                           h3a, lines[band - 1], sat_pos[band - 1],
#                                                                           sat_att[band - 1], sat_time[band - 1],
#                                                                           current_date[0], current_date[1],
#                                                                           current_date[2], utc_gps, dut1)
#                     xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon)
#                     errx = xb - x3a
#                     erry = yb - y3a
#                     err_min = errx ** 2 + erry ** 2
#                     sx_best = samples2 + dx_init[band - 1]
#                     sy_best =  np.array(line + dy_init[band - 1]) * np.ones_like(samples2)
#                     max_pix = int(np.ceil(max(errxm,errym)/5.0)+5)
#                     for dx in range(1,max_pix):
#                             for dy in range(1,max_pix):
#                                 sx = samples2 + dx_init[band - 1] + dx
#                                 sy = np.array(line + dy_init[band - 1]) * np.ones_like(samples2) + dy
#                                 lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy,
#                                                                                       h3a, lines[band - 1],
#                                                                                       sat_pos[band - 1],
#                                                                                       sat_att[band - 1],
#                                                                                       sat_time[band - 1],
#                                                                                       current_date[0], current_date[1],
#                                                                                       current_date[2], utc_gps, dut1)
#                                 xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon)
#                                 errx = xb - x3a
#                                 erry = yb - y3a
#                                 err = errx ** 2 + erry ** 2
#                                 sx_best = sx * (err < err_min) + sx_best * (err >= err_min)
#                                 sy_best = sy * (err < err_min) + sy_best * (err >= err_min)
#                                 err_min = err * (err < err_min) + err_min * (err >= err_min)
#
#                                 sx = samples2 + dx_init[band - 1] - dx
#                                 sy = np.array(line + dy_init[band - 1]) * np.ones_like(samples2) - dy
#                                 lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy,
#                                                                                       h3a, lines[band - 1],
#                                                                                       sat_pos[band - 1],
#                                                                                       sat_att[band - 1],
#                                                                                       sat_time[band - 1],
#                                                                                       current_date[0], current_date[1],
#                                                                                       current_date[2], utc_gps, dut1)
#                                 xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon)
#                                 errx = xb - x3a
#                                 erry = yb - y3a
#                                 err = errx ** 2 + erry ** 2
#                                 sx_best = sx * (err < err_min) + sx_best * (err >= err_min)
#                                 sy_best = sy * (err < err_min) + sy_best * (err >= err_min)
#                                 err_min = err * (err < err_min) + err_min * (err >= err_min)
#
#                     print "After brute force we achieved the maximum error of %f" % (np.sqrt(err_min.max()))
#                     sx = sx_best
#                     sy = sy_best
#                     print "Return back to the gradient search appoarch."
#
#             if it == max_iteration:
#                 print "[%d] The algorithm is terminated with error: %f m, %f m in x- and y-directions." %(band,
#                                                                                                           errx_max, erry_max)
#                 if band == 1:
#                     sx1 = sx  # x1.append(sx)
#                     sy1 = sy  # y1.append(sy)
#                     print sy.min(), sy.max()
#                 elif band == 2:
#                     sx2 = sx  # x2.append(sx)
#                     sy2 = sy  # y2.append(sy)
#                 elif band == 4:
#                     sx4 = sx  # x4.append(sx)
#                     sy4 = sy  # sy4.append(sy)
#
#         if (sat_time[band-1][line+lines[band-1]] > sard_last_time) or (sat_time[2][line+lines[2]] > sard_last_time):
#             print "The line(s) of interest is beyond the flight telemetry record. "
#             print "Perform image to image registration to check for more precide solution."
#             num_sample_points = len(sx)
#             bandheight = image_data[band -1].shape[0]
#             lineb = lines[band - 1]
#             max_lineb = bandheight + offset_mins[band-1]
#             for k in range(num_sample_points):
#                 sx3 = samples2[k]
#                 sy3 = line
#                 sxb = sx[k]
#                 syb = sy[k]
#                 if (sx3> 20) & (sx3 < im_width-20) & (sy3 > 20) & (sy3 < im_height - 20):
#                     if  (sxb> 25) & (sxb < im_width-25) & (syb > 25) & (syb < max_lineb - 25):
#                         im3 = image_data[2][sy3-20:sy3+21,sx3-20:sx3+21]
#                         xg,yg =np.meshgrid(sxb+np.arange(-20,21), syb+np.arange(-20,21) -offset_mins[band-1] )
#                         xg = xg.astype('float32')
#                         yg = yg.astype('float32')
#                         itc_max = 10
#                         itc = 0
#                         c_done = False
#                         dx = 0
#                         dy = 0
#                         grad_old = 1e300
#                         while (itc < itc_max) & (not c_done):
#                             imb = cv2.remap(image_data[band-1],xg + dx+1, yg + dy, cv2.INTER_CUBIC)
#                             coor0 = np.corrcoef([im3.flatten(),imb.flatten()])[0,1]
#                             imb = cv2.remap(image_data[band - 1], xg + dx + 2, yg + dy , cv2.INTER_CUBIC)
#                             coorr = np.corrcoef([im3.flatten(), imb.flatten()])[0, 1]
#                             imb = cv2.remap(image_data[band - 1], xg + dx+1, yg+dy+1, cv2.INTER_CUBIC)
#                             coord = np.corrcoef([im3.flatten(), imb.flatten()])[0, 1]
#                             gr = coorr - coor0
#                             gd = coord - coor0
#                             grad = np.sqrt(gr**2 +gd**2)
#                             if grad < grad_old:
#                                 grad_old = grad
#                                 itc += 1
#                                 itg = 0
#                                 itgmax = 10
#                                 lamb = 1.0
#                                 while (itg <itgmax):
#                                     dxp = dx + lamb * gr
#                                     dyp = dy + lamb * gd
#                                     imb = cv2.remap(image_data[band - 1], xg + dxp + 1, yg + dyp, cv2.INTER_CUBIC)
#                                     coorp = np.corrcoef([im3.flatten(), imb.flatten()])[0, 1]
#                                     if coorp > coor0:
#                                         dx = dxp
#                                         dy = dyp
#                                         itg = itgmax
#                                     else:
#                                         lamb /= 2.0
#                                         itg += 1
#                             else:
#                                 c_done = True
#                         sx[k] += dx
#                         sy[k] += dy
#
#
#
#
#         if (sx1 is not None) & (sy1 is not None) & (sx2 is not None) & (sy2 is not None) & (sx4 is not None) &  (sy4 is not None):
#             x1.append(sx1)
#             x2.append(sx2)
#             x3.append(samples2)
#             x4.append(sx4)
#
#             y1.append(sy1)
#             y2.append(sy2)
#             y3.append(line*np.ones_like(samples2))
#             y4.append(sy4)
#     x1 = np.array(x1).flatten()
#     x2 = np.array(x2).flatten()
#     x3 = np.array(x3).flatten()
#     x4 = np.array(x4).flatten()
#     y1 = np.array(y1).flatten()
#     y2 = np.array(y2).flatten()
#     y3 = np.array(y3).flatten()
#     y4 = np.array(y4).flatten()
#     return x1, x2, x3, x4, y1, y2, y3, y4

def remapImageBand(data, xb, yb, x3, y3, line_str, sample_str, block_size, im_width, im_height, offset_min, block_offset,
                   max_error=0.1):

    end_line = min(line_str + block_size, im_height)
    end_sample = min(sample_str + block_size, im_width)
    print "working on line:%d to %d and sample: %d to %d" % (line_str, end_line, sample_str, end_sample)
    block_height = end_line - line_str
    block_width = end_sample - sample_str

    out = np.zeros((block_width, block_height), 'uint8')
    mask = np.ones((block_width, block_height), 'uint8')
    idx = np.nonzero((x3 >= sample_str) * (x3 < end_sample) * (y3 >= line_str) * (y3 < end_line))[0]
    u = x3[idx]
    v = y3[idx]
    num_samples = u.size
    mid_sample = np.median(u)
    mid_line = np.median(v)
    ut = (u - mid_sample).astype('float64')
    vt = (v - mid_line).astype('float64')
    AA = np.zeros((num_samples, 12), 'float64')
    AA[:, 0] = 1.0
    AA[:, 1] = ut
    AA[:, 2] = vt
    AA[:, 3] = ut * vt
    AA[:, 4] = ut ** 2
    AA[:, 5] = vt ** 2
    AA[:, 6] = ut * vt * vt
    AA[:, 7] = vt * ut * ut
    AA[:, 8] = ut ** 3
    AA[:, 9] = vt ** 3
    AA[:, 10] = vt * ut ** 3
    AA[:, 11] = ut * vt ** 3
    x1 = xb[idx]
    y1 = yb[idx]

    # print np.abs(b-out).max()
    par_x1 = np.linalg.lstsq(AA, b)[0]
    errx1 = (np.abs(np.dot(AA, par_x1) - b).max())
    print "max error column: %f" % errx1

    b = y1 - mid_line
    par_y1 = np.linalg.lstsq(AA, b)[0]
    erry1 = (np.abs(np.dot(AA, par_y1) - b).max())
    minblocksize = 1000
    print "max error row: %f" % erry1
    if ((errx1 > max_error) or (erry1 > max_error)) and (block_size > minblocksize):
        new_block_size = max(block_size / 2, minblocksize)
        for sub_line in range(line_str, end_line, new_block_size):
            for sub_sample in range(sample_str, end_sample, new_block_size):

                lstr = sub_line - line_str
                sstr = sub_sample - sample_str
                sub_block_line_end = min(sub_line + new_block_size, end_line)
                sub_block_sample_end = min(sub_sample + new_block_size, end_sample)
                sub_out, sub_mask = remapImageBand(data, xb, yb, x3, y3, sub_line, sub_sample, new_block_size, im_width,
                                                   im_height, offset_min, block_offset, max_error)
                sub_block_line_end -= line_str
                sub_block_sample_end -= sample_str
                print lstr, sstr, sub_block_line_end, sub_block_sample_end
                w = sub_block_sample_end - sstr
                h = sub_block_line_end - lstr
                out[lstr:sub_block_line_end, sstr: sub_block_sample_end] = sub_out[:h, :w]
                mask[lstr:sub_block_line_end, sstr: sub_block_sample_end] = sub_mask[:h, :w]
    else:
        bline = line_str
        bsample = sample_str
        if (bline == 0) & (bsample == 0):
            V, U = np.mgrid[0:block_height, 0:block_width]
            # sub_mask = mask[0:block_height, 0:block_width]
        elif (bline == 0) & (bsample > 0):
            V, U = np.mgrid[0:block_height, bsample - block_offset:bsample + block_width]
            # sub_mask = mask[0:block_height, bsample - block_offset:bsample + block_width]
        elif (bline > 0) & (bsample == 0):
            V, U = np.mgrid[bline - block_offset:bline + block_height, 0:block_width]
            # sub_mask = mask[bline - block_offset:bline + block_height, 0:block_width]
        else:
            V, U = np.mgrid[bline - block_offset:bline + block_height,
                   bsample - block_offset:bsample + block_width]
            # sub_mask = mask[bline - block_offset:bline + block_height,
            #           bsample - block_offset:bsample + block_width]
        sub_mask = np.ones_like(U, "uint8")
        mskh, mskw = sub_mask.shape
        u1d = U.flatten()
        v1d = V.flatten()
        num_pairs = u1d.size
        A = np.zeros((num_pairs, 12))
        ut = (u1d - mid_sample).astype('float64')
        vt = (v1d - mid_line).astype('float64')
        A[:, 0] = 1.0
        A[:, 1] = ut
        A[:, 2] = vt
        A[:, 3] = ut * vt
        A[:, 4] = ut ** 2
        A[:, 5] = vt ** 2
        A[:, 6] = ut * vt * vt
        A[:, 7] = vt * ut * ut
        A[:, 8] = ut ** 3
        A[:, 9] = vt ** 3
        A[:, 10] = vt * ut ** 3
        A[:, 11] = ut * vt ** 3
        sub_mask = sub_mask.flatten()

        x = np.dot(A, par_x1) + mid_sample + 1
        y = np.dot(A, par_y1) + mid_line - offset_min
        x = x.astype('float32')
        y = y.astype('float32')
        remap_im = cv2.remap(data, x, y, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                             borderValue=0)
        idx = np.nonzero((x < 0))[0]
        sub_mask[idx] = 0
        idx = np.nonzero((x > im_width - 1))[0]
        sub_mask[idx] = 0
        # mask[y > im_height-1, x > im_width-1] = 0
        remap_im = remap_im.reshape(U.shape)
        sub_mask = sub_mask.reshape(U.shape)
        if (bline == 0) & (bsample == 0):
            outimage = remap_im
            mask = sub_mask
        elif (bline == 0):
            outimage = remap_im[:, block_offset:]
            mask = sub_mask[:, block_offset:]
        elif (bsample == 0):
            outimage = remap_im[block_offset:, :]
            mask = sub_mask[block_offset:, :]
        else:
            outimage = remap_im[block_offset:, block_offset:]
            mask = sub_mask[block_offset:, block_offset:]

        # mask = sub_mask.reshape((mskh, mskw))

        out = outimage

    return out, mask


def buildMSImageUsingCubicInterpolation(out_file_name, in_file_name, lines, current_date, utc_gps, dut1, dem,
                                        dem_interpolation_method, gain, dark_curr, start_sample=1, im_width=6000, im_height=6000):

    # im_width = 6000
    lines[0] = lines[0] - 1
    lines[1] = lines[1] - 1
    lines[2] = lines[2] - 1
    lines[3] = lines[3] - 1
    end_sample = start_sample + im_width - 1
    if (end_sample > 6000) or (start_sample < 1) :
        print "The intended sample is beyond the scope of the recorded GER file."
    samples = np.arange(start_sample, start_sample + im_width)

    posB1 = np.loadtxt(in_file_name + "B1.pos")
    posB2 = np.loadtxt(in_file_name + "B2.pos")
    posB3f = np.loadtxt(in_file_name + "B3.pos")
    posB4 = np.loadtxt(in_file_name + "B4.pos")
    sat_pos = [posB1, posB2, posB3f, posB4]

    timeB1 = np.loadtxt(in_file_name + "B1.tim")
    timeB2 = np.loadtxt(in_file_name + "B2.tim")
    timeB3f = np.loadtxt(in_file_name + "B3.tim")
    timeB4 = np.loadtxt(in_file_name + "B4.tim")

    sat_time = [timeB1, timeB2, timeB3f, timeB4]

    attB1 = np.loadtxt(in_file_name + "B1.att")
    attB2 = np.loadtxt(in_file_name + "B2.att")
    attB3f = np.loadtxt(in_file_name + "B3.att")
    attB4 = np.loadtxt(in_file_name + "B4.att")
    sat_att = [attB1, attB2, attB3f, attB4]

    band1 = gdal.Open(in_file_name + "B1.tif")
    band2 = gdal.Open(in_file_name + "B2.tif")
    band3 = gdal.Open(in_file_name + "B3.tif")
    band4 = gdal.Open(in_file_name + "B4.tif")
    data_height = band1.RasterYSize


    # out_im = np.zeros((im_height,im_height,4),'uint8')



    # Find the shift function using the middle line
    mid_line = im_height / 2
    mid_sample = start_sample + im_width / 2
    # Building the transformation polynomial
    if data_height - (lines[2] + im_height) < 1000:
        print "The produced image is very close to the end of the scene. Increase the box size to 2000."
        process_box = 2000
    else:
        process_box = 500


    step = 10

    # find approprite line offset
    # consider only the first and last lines.

    print "finding the corresponding pixels among image bands"
    block_size = 1000
    block_offset = step
    max_block_width = block_size + block_offset
    max_block_height = block_size + block_offset
    max_width = 6000
    min_line = min(lines)
    max_line = max(lines)
    offsetm = 100
    offset_min1 = max(-offsetm, 0 - lines[0])
    offset_max1 = min(offsetm, data_height - lines[0] - im_height)

    offset_min2 = max(-offsetm, 0 - lines[1])
    offset_max2 = min(offsetm, data_height - lines[1] - im_height)

    offset_min3 = max(-offsetm, 0 - lines[3])
    offset_max3 = min(offsetm, data_height - lines[2] - im_height)

    offset_min4 = max(-offsetm, 0 - lines[3])
    offset_max4 = min(offsetm, data_height - lines[3] - im_height)

    gain_number = np.loadtxt(in_file_name + "B1.gain")
    databand1 = readDataBand(band1, 0, lines[0] + offset_min1, max_width, offset_max1 - offset_min1 + im_height,
                             gain[0], dark_curr[0], gain_number, im_type="MS")
    # band1.ReadAsArray(0, lines[0] -1 + offset_min1, max_width, offset_max1 - offset_min1 + im_height)
    gain_number = np.loadtxt(in_file_name + "B2.gain")
    databand2 = readDataBand(band2, 0, lines[1] + offset_min2, max_width, offset_max2 - offset_min2 + im_height,
                             gain[1], dark_curr[1], gain_number,
                             im_type="MS")  # band2.ReadAsArray(0, lines[1] -1 + offset_min2, max_width, offset_max2 - offset_min2 + im_height)
    gain_number = np.loadtxt(in_file_name + "B3.gain")
    databand3 = readDataBand(band3, 0, lines[2] , max_width, im_height,
                             gain[2], dark_curr[2], gain_number,
                             im_type="MS")  # band3.ReadAsArray(0, lines[2] -1, max_width, im_height)
    gain_number = np.loadtxt(in_file_name + "B4.gain")
    databand4 = readDataBand(band4, 0, lines[3] + offset_min4, max_width, offset_max4 - offset_min4 + im_height,
                             gain[3], dark_curr[3], gain_number, im_type="MS")
    image_data = [databand1, databand2, databand3, databand4]
    offset_mins = [offset_min1, offset_min2, offset_min3, offset_min4]
    print "Find the initial shift at the middle of an image (%d,%d)" % (mid_sample, mid_line)

    mask = np.ones((im_height, im_width), "uint8")
    print "Find the corresponding points between bands!!"
    all_file_exist = True
    for band in [1, 2, 3, 4]:
        all_file_exist &= os.path.isfile(in_file_name + "x_b%d_LINE_%d.txt" % (band, lines[2] + 1))
        all_file_exist &= os.path.isfile(in_file_name + "y_b%d_LINE_%d.txt" % (band, lines[2] + 1))
    if not all_file_exist :

        x1, x2, x3, x4, y1, y2, y3, y4 = findSamplesPoints(in_file_name, step, lines, sat_pos, sat_time, sat_att,
                                                           image_data, offset_mins, current_date, utc_gps, dut1,
                                                           dem, dem_interpolation_method, im_width, im_height,
                                                           precision_error=1.0, max_percision_error=5.0,
                                                           process_box=process_box)
        np.savetxt(in_file_name + "x_b1_LINE_%d.txt" % (lines[2] + 1), x1)
        np.savetxt(in_file_name + "x_b2_LINE_%d.txt" % (lines[2] + 1), x2)
        np.savetxt(in_file_name + "x_b3_LINE_%d.txt" % (lines[2] + 1), x3)
        np.savetxt(in_file_name + "x_b4_LINE_%d.txt" % (lines[2] + 1), x4)

        np.savetxt(in_file_name + "y_b1_LINE_%d.txt" % (lines[2] + 1), y1)
        np.savetxt(in_file_name + "y_b2_LINE_%d.txt" % (lines[2] + 1), y2)
        np.savetxt(in_file_name + "y_b3_LINE_%d.txt" % (lines[2] + 1), y3)
        np.savetxt(in_file_name + "y_b4_LINE_%d.txt" % (lines[2] + 1), y4)
    else:
        x1 = np.loadtxt(in_file_name + "x_b1_LINE_%d.txt" % (lines[2] + 1))
        x2 = np.loadtxt(in_file_name + "x_b2_LINE_%d.txt" % (lines[2] + 1))
        x3 = np.loadtxt(in_file_name + "x_b3_LINE_%d.txt" % (lines[2] + 1))
        x4 = np.loadtxt(in_file_name + "x_b4_LINE_%d.txt" % (lines[2] + 1))

        y1 = np.loadtxt(in_file_name + "y_b1_LINE_%d.txt" % (lines[2] + 1))
        y2 = np.loadtxt(in_file_name + "y_b2_LINE_%d.txt" % (lines[2] + 1))
        y3 = np.loadtxt(in_file_name + "y_b3_LINE_%d.txt" % (lines[2] + 1))
        y4 = np.loadtxt(in_file_name + "y_b4_LINE_%d.txt" % (lines[2] + 1))

    mask = np.ones((im_height, im_width), 'uint8')
    gtiffDriver = gdal.GetDriverByName('GTiff')
    dst_ds = gtiffDriver.Create(out_file_name, im_width, im_height, 4, gdal.GDT_Byte)
    ms_b1 = dst_ds.GetRasterBand(3)
    ms_b2 = dst_ds.GetRasterBand(2)
    ms_b3 = dst_ds.GetRasterBand(1)
    ms_b4 = dst_ds.GetRasterBand(4)
    u1 = np.arange(start_sample - 1, im_width).astype('float32')
    v1 = np.arange(0, im_height).astype('float32')
    u, v = np.meshgrid(u1, v1)
    # u1 = u.flatten()
    # v1 = v.flatten()

    for band in [1, 2, 3, 4]:
        block_size = 6000
        block_offset = 50
        if band == 1:
            # fx  = inplt.SmoothBivariateSpline(y3,x3,x1,bbox= [0,im_width,0,im_height])
            # xmap = fx(v1,u1)
            # xmap = xmap.reshape(u.shape).astype('float32')
            # fy = inplt.SmoothBivariateSpline(y3,x3,y1,bbox= [0,im_width,0,im_height])
            # ymap = fy(v1, u1) - offset_min1
            # ymap = ymap.reshape(u.shape).astype('float32')
            xmap, ymap, mask1 = remapImageBandGridMethod(x1, y1, x3, y3, 0, 0, block_size, im_width, im_height, offset_min1,
                                                      max_error=0.1)
            # mask1 = (xmap>0)*(ymap>0)*(xmap<im_width)*(ymap<im_height)
            mask *= mask1
            out = cv2.remap(databand1, xmap, ymap, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
            out = 1 * (out < 1) + 255 * (out >= 255) + out * (out >= 1) * (out < 255)
            out = np.round(out).astype('uint8')
            ms_b1.WriteArray(out)
        elif band == 2:
            # fx = inplt.SmoothBivariateSpline(y3, x3, x2, bbox=[0, im_width, 0, im_height])
            # xmap = fx(v1, u1)
            # xmap = xmap.reshape(u.shape).astype('float32')
            # fy = inplt.SmoothBivariateSpline(y3, x3, y2, bbox=[0, im_width, 0, im_height])
            # ymap = fy(v1, u1) - offset_min2
            # ymap = ymap.reshape(u.shape).astype('float32')
            xmap, ymap, mask2 = remapImageBandGridMethod(x2, y2, x3, y3, 0, 0, block_size, im_width, im_height, offset_min2,
                                                      max_error=0.1)
            # mask2 = (xmap > 0) * (ymap > 0) * (xmap < im_width) * (ymap < im_height)
            mask *= mask2
            out = cv2.remap(databand2, xmap, ymap, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
            out = 1 * (out < 1) + 255 * (out >= 255) + out * (out >= 1) * (out < 255)
            out = np.round(out).astype('uint8')
            ms_b2.WriteArray(out)
        elif band == 3:
            out = databand3[0:im_height, 0:im_width]
            out = 1 * (out < 1) + 255 * (out >= 255) + out * (out >= 1) * (out < 255)
            out = np.round(out).astype('uint8')
            ms_b3.WriteArray(out)
        elif band == 4:
            # fx = inplt.SmoothBivariateSpline(y3, x3, x4, bbox=[0, im_width, 0, im_height])
            # xmap = fx(v1, u1)
            # xmap = xmap.reshape(u.shape).astype('float32')
            # fy = inplt.SmoothBivariateSpline(y3, x3, y4, bbox=[0, im_width, 0, im_height])
            # ymap = fy(v1, u1) - offset_min4
            # ymap = ymap.reshape(u.shape).astype('float32')
            xmap, ymap, mask4 = remapImageBandGridMethod(x4, y4, x3, y3, 0, 0, block_size, im_width, im_height, offset_min4,
                                                      max_error=0.1)
            out = cv2.remap(databand4, xmap, ymap, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
            out = 1 * (out < 1) + 255 * (out >= 255) + out * (out >= 1) * (out < 255)
            out = np.round(out).astype('uint8')
            # mask4 = (xmap > 0) * (ymap > 0) * (xmap < im_width) * (ymap < im_height)
            mask *= mask4
            ms_b4.WriteArray(out)
    dst_ds = None
    dst_ds = gdal.Open(out_file_name, gdal.GA_Update)
    for band in [1, 2, 3, 4]:
        ms = dst_ds.GetRasterBand(band)
        data = ms.ReadAsArray()
        data = data * (mask > 0)
        ms.WriteArray(data)





def buildPANImageUsingCubicInterpolation(out_file_name, in_file_name, beg_line, filter2D, gain, dark_curr,
                                         start_sample=1, im_width=12000, im_height=12000):
    max_width = 12000

    band1 = gdal.Open(in_file_name + ".tif")
    beg_line -= 1
    start_sample -= 1

    gtiffDriver = gdal.GetDriverByName('GTiff')
    dst_ds = gtiffDriver.Create(out_file_name, im_width, im_height, 1, gdal.GDT_Byte)
    pan_b1 = dst_ds.GetRasterBand(1)
    ger_height = band1.RasterYSize

    # load as a block of 1000x1000 overlapped by 100
    gain_number = np.loadtxt(in_file_name + ".gain")

    for k in range(0, im_height, 1000):
        for m in range(0, im_width, 1000):
            print "Building block (%d,%d)......" % (k, m)
            y_min = max(0, beg_line + k - 100)
            x_min = max(0, m - 100 + start_sample)

            x_off_l = start_sample + m - x_min
            y_off_l = beg_line + k - y_min
            x_max = min(max_width, m + 1000 + 100 + start_sample)
            y_max = min(ger_height, min(beg_line + im_height + 20, beg_line + k + 1000 + 100))
            x_off_h = x_max - (m + 1000) + (start_sample - 1)
            y_off_h = y_max - (beg_line + 1000 + k)
            load_width = x_max - x_min
            load_height = y_max - y_min
            one_block = readDataBand(band1, x_min, y_min, load_width, load_height, gain, dark_curr, gain_number,
                                     im_type="PAN")  # band1.ReadAsArray(x_min, y_min, load_width, load_height)
            # one_block = np.round((one_block > 0) * (one_block < 255) * one_block + 255 * (one_block >= 255))
            # one_block = one_block.astype('uint8')
            summ = cv2.GaussianBlur(one_block.astype('uint8'), (3, 3), 3.3)  # cv2.filter2D(org_image,cv2.CV_32F,kernel, borderType=cv2.BORDER_REFLECT)
            edges = cv2.Canny(summ.astype('uint8'), 4, 8, L2gradient=False)
            edges = cv2.filter2D(edges, cv2.CV_8U, np.ones((7, 7)))
            summ = cv2.filter2D(one_block, cv2.CV_32F, np.ones((3, 3), 'float32') / 9.0, borderType=cv2.BORDER_REFLECT)
            gradient = np.abs(one_block - summ) * (edges > 0)  # np.sqrt(sumsq - (summ) ** 2) #np.abs(gradient) #
            # gradient = cv2.filter2D(gradient,cv2.CV_32F, np.ones((3, 3), 'float32') /9.0, borderType=cv2.BORDER_REFLECT)
            gradient[0, :] = 0
            gradient[1, :] = 0
            gradient[-1, :] = 0
            gradient[-2, :] = 0
            gradient[:, 0] = 0
            gradient[:, 1] = 0
            gradient[:, -1] = 0
            gradient[:, -2] = 0
            my_filter_im = np.zeros_like(one_block).astype('float32')
            idx, idy = np.nonzero(gradient < 0.75)
            my_filter_im[idx, idy] = one_block[idx, idy]
            idx, idy = np.nonzero((gradient >= 0.75) * (gradient < 1.25))
            tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[3], borderType=cv2.BORDER_REFLECT)
            my_filter_im[idx, idy] = tem[idx, idy]
            idx, idy = np.nonzero((gradient >= 1.25) * (gradient < 1.75))
            tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[4], borderType=cv2.BORDER_REFLECT)
            my_filter_im[idx, idy] = tem[idx, idy]
            idx, idy = np.nonzero((gradient >= 1.75) * (gradient < 2.25))
            tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[5], borderType=cv2.BORDER_REFLECT)
            my_filter_im[idx, idy] = tem[idx, idy]
            idx, idy = np.nonzero((gradient >= 2.25))
            tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[6], borderType=cv2.BORDER_REFLECT)
            my_filter_im[idx, idy] = tem[idx, idy]
            filtered_im = np.round((my_filter_im > 0) * (my_filter_im < 255) * my_filter_im + 255 * (my_filter_im >= 255))

            # filtered_im = cv2.filter2D(one_block, cv2.CV_8UC1, filter2D)
            used_ar = filtered_im[y_off_l:y_off_l + 1000, x_off_l:x_off_l + 1000].astype('uint8')
            # used_ar = one_block[y_off_l:y_off_l + 1000, x_off_l:x_off_l + 1000]
            # one_line = np.round((one_line-dark_currents)/gains)
            # out_line = one_line*(one_line <255.0) + 255.0*(one_line>=255)
            # outPAN = one_line.astype('uint8')
            pan_b1.WriteArray(used_ar, m, k)




if __name__ == "__main__":
    # cpf_file =  "/media/professor/Data and Backup/LEVEL0/CPF file/CPF_20110106_Delta_UT/THEOS_1_20110104_000000_20110106_000000.CPF"
    # cpf_file = r"D:\level1A_development\GER\THEOS_1_20150915_000000_20150917_000000.CPF"
    # gp,dp = readGainsAndDarkCurrent(cpf_file,"PAN", 6)
    # g1, d1 = readGainsAndDarkCurrent(cpf_file,1,5)
    # g2, d2 = readGainsAndDarkCurrent(cpf_file,2,5)
    # g3, d3 = readGainsAndDarkCurrent(cpf_file,3,5)
    # g4, d4 = readGainsAndDarkCurrent(cpf_file,4,4)
    # g4 = np.ones(g4.shape)
    # d4 = np.zeros(d4.shape)
    # g1 = np.ones(g4.shape)
    # d1 = np.zeros(d4.shape)
    # g2 = np.ones(g4.shape)
    # d2 = np.zeros(d4.shape)
    # g3 = np.ones(g4.shape)
    # d3 = np.zeros(d4.shape)
    # import matplotlib.pyplot as plt
    # plt.plot(d4)
    # plt.show()
    file_name = r"D:\level1A_development\GER\TS1_2015308_37179_004_"
    # buildRMImage(file_name,7299,7363,7428,7493,g1,g2,g3,g4,d1,d2,d3,d4)
    # gains =[g1,g2,g3,g4]
    # dark_curr = [d1,d2,d3,d4]
    out_file = file_name + "out.tif"
    # buildPANImageUsingCubicInterpolation(out_file ,file_name,43221,gp,dp,[2015,1,1],-16.0)
    buildMSImageUsingCubicInterpolation(out_file, file_name, [5379, 5441, 5503, 5565], [2015, 11, 4], -17.0, -0.200)
