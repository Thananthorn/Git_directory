import cv2

from osgeo import gdal

import numpy as np


new_file = r"D:\Data2APanSharpen\Level 2A - SIPROS\ProminentLine\GERALD\THEOS_1_LEVEL0_1_111041472_41472_MS_PB_TOP_2_16_2016-09-01_05-11-01\level1a\IMAGERY.tif"
old_file = r"D:\Data2APanSharpen\Level 2A - SIPROS\ProminentLine\1A\MS 1A\Old Product\TH_CAT_160909062614982_1\IMAGERY_MS1A_Old.tif"
out_file_name = r"D:\Data2APanSharpen\Level 2A - SIPROS\ProminentLine\GERALD\THEOS_1_LEVEL0_1_111041472_41472_MS_PB_TOP_2_16_2016-09-01_05-11-01\level1a\diff_band"
rgb_im_new = r"D:\Data2APanSharpen\Level 2A - SIPROS\ProminentLine\GERALD\THEOS_1_LEVEL0_1_111041472_41472_MS_PB_TOP_2_16_2016-09-01_05-11-01\level1a\new_rgb.tif"
rgb_im_old = r"D:\Data2APanSharpen\Level 2A - SIPROS\ProminentLine\GERALD\THEOS_1_LEVEL0_1_111041472_41472_MS_PB_TOP_2_16_2016-09-01_05-11-01\level1a\old_rgb.tif"
new_im = gdal.Open(new_file)
old_im = gdal.Open(old_file)
n_bands = new_im.RasterCount
drv = gdal.GetDriverByName("GTiff")
rgbnew = drv.Create(rgb_im_new, new_im.RasterXSize, new_im.RasterYSize, 3, gdal.GDT_Byte)
rgbold = drv.Create(rgb_im_old, new_im.RasterXSize, new_im.RasterYSize, 3, gdal.GDT_Byte)
for band in range(n_bands):
    new_band = new_im.GetRasterBand(band + 1)
    old_band = old_im.GetRasterBand(band + 1)
    new_data = new_band.ReadAsArray()
    old_data = old_band.ReadAsArray()
    if band < 3 :
        bandk = rgbnew.GetRasterBand(band + 1)
        bandk.WriteArray(new_data)
        bandk = rgbold.GetRasterBand(band + 1)
        bandk.WriteArray(old_data)
    new_data = new_data[900:1028 , 660:(660 + 128)]
    old_data = old_data[900:1028 , 660:(660 + 128)]
    NEW_DATA = np.fft.fft2(new_data)
    OLD_DATA = np.fft.fft2(old_data)
    NEW_DATA = np.fft.fftshift(NEW_DATA)
    OLD_DATA = np.fft.fftshift(OLD_DATA)
    FT = OLD_DATA / NEW_DATA
    ft = np.fft.ifft2(FT)
    ft = np.fft.ifftshift(ft)
    print np.real(ft[63:66, 63:66])
    print ft.sum()


    # diff = new_data.astype('float32')-old_data.astype('float32')
    # diff = np.abs(diff)
    #
    # diff_max = diff.max()
    # print band+1, diff_max, diff.mean(), diff.min(), np.nonzero(diff==diff_max)
    # if diff_max > 0 :
    #     diff = diff*(255.0/diff_max)
    # diff = diff.astype('uint8')
    # out_file =out_file_name+"%d.tif"%(band+1)
    # out_im = drv.Create(out_file,new_im.RasterXSize,new_im.RasterYSize,1,gdal.GDT_Byte)
    # out_band1  = out_im.GetRasterBand(1)
    # #out_band2 = out_im.GetRasterBand(3)
    # out_band1.WriteArray(diff)
    # #out_band2.WriteArray(old_data)
