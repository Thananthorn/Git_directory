import cv2

from osgeo import gdal

import numpy as np


if __name__ == "__main__":
    pan = r"D:\Data2APanSharpen\THEOS_37541\GERAL_PAN\THEOS_1_LEVEL0_1_111037541_37541_PAN_PB_TOP_1_13_2015-11-29_07-39-24\pan_output21946\IMAGERY.tif"
    ms = r"D:\Data2APanSharpen\THEOS_37541\GERAL_PAN\THEOS_1_LEVEL0_1_111037541_37541_PAN_PB_TOP_1_13_2015-11-29_07-39-24\pansharp_output21946\IMAGERYPANSHARPEN.tif"
    imout = r"D:\Data2APanSharpen\THEOS_37541\GERAL_PAN\THEOS_1_LEVEL0_1_111037541_37541_PAN_PB_TOP_1_13_2015-11-29_07-39-24\pansharp_output21946\PanVsMSBand"
    panim = gdal.Open(pan)
    msim = gdal.Open(ms)
    pan_band = panim.GetRasterBand(1)
    pan_data = pan_band.ReadAsArray()
    gtiffdrv = gdal.GetDriverByName("GTiff")
    width = panim.RasterXSize
    height = panim.RasterYSize
    for band in range(4):
        ms_band = msim.GetRasterBand(band + 1)
        ms_data = ms_band.ReadAsArray()
        cv2.imwrite(imout + "%d_raw.tif" % (band + 1), ms_data)
        im = gtiffdrv.Create(imout + "%d.tif" % (band + 1), width, height, 3, gdal.GDT_Byte)
        band1 = im.GetRasterBand(1)
        band1.WriteArray(pan_data)
        band2 = im.GetRasterBand(2)
        band2.WriteArray(ms_data)
        im = None
        msf = ms_data.astype('float32')
        panf = pan_data.astype('float32')
        msmean = msf.mean()
        panmean = panf.mean()
        msf = msf - msmean
        panf = panf - panmean
        denor = (msf * panf).mean()
        msstd = msf.std()
        panstd = panf.std()
        corr = denor / (msstd * panstd)
        print "correlation coefficient for band %d: %f." % (band + 1, corr)

