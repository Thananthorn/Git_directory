"""This script have 4 type of library
- type [0] as primary or core of python library in this script has 7 library.
    1. os or know as Miscellaneous operating system interfaces. This module provides a portable way of using operating system dependent functionality.
    2. shutil is High-level file operations functions are provided which support file copying and removal. For operations on individual files
    3. traceback is module provides a standard interface to extract. I use this for check error of function or script.
    4. zipfile is module for create file zip for keep some thing 
    5. time is module provides various time-related functions. Most of the functions defined in this module call platform C library 
       functions with the same name.
    6. sys or know as System-specific parameters and function. This module provides access to some variables used or maintained by 
       the interpreter and to functions that interact strongly with the interpreter.
    7. xml.dom is module for xml file operations.

- type [1] as teacher's library. He create them for use in this project.
    1. generalFileReader is name of script {generalFileReader.py} it import bypass in this script as [ gr ] it use in extraction gerald file.
    2. createImage2A is name of script {createImage2A.py} it import bypass in this script as [ createImage ] it use in create GEOtiff image file.
    3. locationutil is name of script {locationutil.py} it use in dem interpolation and find [lat , long] and  earth location etc.
    4. determine_pixel_shift is name of script {determine_pixel_shift.py} it use in calculate shift of pixel. This script is very 
       impotant we can set how to use CPU core to process in create product process look at valiable name [cpu_num] in this script.
    5. DIMAP1 is name of script {DIMAP1.py} it use in create DIMAP file process.

- type [2] as external library. It is standard library use for some process.
    1. numpy it is library about calculate and numerical methods for engineering or science methods it import bypass in script as [np] .
    2. cv2 it is opencv library it use about image processing methods.
    3. osgeo , gdal and osr it is geometry library or as name is Geospatial Data Abstraction Library use for geometry methods.
    4. PyQt4 it is Qt library. it is a C library use for some methods like dialog file , save file with dialog , etc.

- type [3] as mine library. I create it for use in this project.
    1. cpf_logic it is name of script {cpf_logic.py} it import bypass in this script as [CP] it is CPF file selector process. 
"""


import os
import shutil
import traceback
import zipfile
import time
import sys
from xml.dom import minidom


import generalFileReader as gr
import createImage2A as createImage
import locationutil
import determine_pixel_shift as dps
import DIMAP1
import digitalElevationModel as demservice

import numpy as np
import cv2
from osgeo import gdal
from osgeo import osr
from PyQt4.QtGui import QApplication , QFileDialog , QMessageBox

import cpf_logic as CP

pc = False
dem_directories = dict()

if pc:
    dem_directories[demservice.SRTM90_DEM] = "C:/Worker/Support-Worker/Sipros_system/dem/gls"
    dem_directories[demservice.GLOBE_DEM] = "C:/Worker/Support-Worker/Sipros_system/dem/globe"
    dem_directories[demservice.THEOS_DEM] = "C:/Worker/Support-Worker/Sipros_system/dem/old_system_dem"
else:
    dem_directories[demservice.SRTM90_DEM] = ""
    dem_directories[demservice.GLOBE_DEM] = "/home/asuna/worker/2016-12/LAB/DEM/globe"
    dem_directories[demservice.THEOS_DEM] = "/home/asuna/worker/2016-12/LAB/DEM/old_system_dem"

def MSDataExtraction(ms_ger_file_names, output_file_names, cpf_file_name, force_run=False):
    year, month, day, band_bad_lines, band_degraded_lines = gr.readGerMSFiles(ms_ger_file_names, output_file_names, cpf_file_name, force_run)
    return year, month, day, band_bad_lines, band_degraded_lines


def PANDataExtraction(pan_ger_file_names, output_file_names, cpf_file_name, force_run=False):
    year, month, day, band_bad_lines, band_degraded_lines = gr.readGerPANFiles(pan_ger_file_names, output_file_names, cpf_file_name, force_run)
    return year, month, day, band_bad_lines, band_degraded_lines


def find_ger_files(ger_dir):
    ger_file_list = []
    for filename in os.listdir(ger_dir):
        base, ext = os.path.splitext(filename)
        # print base, ext
        if ext.lower() == ".ger":
            ger_file = base + ext
            ger_file_list.append(ger_file)
            ger_file_list.sort()
    return ger_file_list

def createPreview(file_name, preview_file, icon_file, width, height):
    im = gdal.Open(file_name)
    imw = im.RasterXSize
    imh = im.RasterYSize
    scalex = float(imw) / float(width)
    scaley = float(imh) / float(height)
    scale = max(scalex , scaley)
    # steph = int(imh / height)
    # stepw = int(imw / width)
    scale_int = int(np.ceil(scale))

    realheight = int(np.ceil(float(imh) / scale_int))
    realwidht = int(np.ceil(float(imw) / scale_int))
    strx = width / 2 - realwidht / 2
    stpx = strx + realwidht
    stry = height / 2 - realheight / 2
    stpy = stry + realheight
    if im.RasterCount == 4:  # ms Images
        outim = np.zeros((realheight, realwidht, 3), 'uint8')
        preview_im = np.zeros((width, height, 3), 'uint8')

        b1 = im.GetRasterBand(3)
        b2 = im.GetRasterBand(2)
        b3 = im.GetRasterBand(1)
        for line in range(realheight):
            line_im = line * scale_int
            d1 = b1.ReadAsArray(0, line_im, imw, 1)
            d2 = b2.ReadAsArray(0, line_im, imw, 1)
            d3 = b3.ReadAsArray(0, line_im, imw, 1)
            outim[line, :, 0] = d1[0, ::scale_int]
            outim[line, :, 1] = d2[0, ::scale_int]
            outim[line, :, 2] = d3[0, ::scale_int]

        preview_im[stry:stpy, strx:stpx, :] = outim
    else:
        outim = np.zeros((realheight, realwidht), 'uint8')
        preview_im = np.zeros((width, height), 'uint8')
        b1 = im.GetRasterBand(1)
        for line in range(realheight):
            line_im = line * scale_int
            d1 = b1.ReadAsArray(0, line_im, imw, 1)
            outim[line, :] = d1[0, ::scale_int]
        preview_im[stry:stpy, strx:stpx] = outim
    cv2.imwrite(preview_file, preview_im)
    scale = min(width / 128, height / 128)
    icon = cv2.resize(preview_im, (width / scale, height / scale))
    cv2.imwrite(icon_file, icon)


def createLevel1A_MSImage(out_dir, ger_info_dir, ger_dir, cpf_file, band_lines, start_sample=1, im_width=6000, im_height=6000, force_run=False):
   
    """
    :param out_dir: output file directory
    :param ger_info_dir: the extracted files will be put in ger_info_dir
    :param ger_dir: director where .ger is located
    :param cpf_file: a .cpf file
    :param apf_file: a .apf file
    :param band_line: begining line
    :param start_sample: first sample of each line (default is 1.)
    :param im_width: Width of the MS image (default is 6000)
    :param im_height: Height of the MS image (default is 3000)
    :param force_run: True will force to extact all data.
                      False will extact only if file is too old or does not exist.
    :return:
        date = [year, month, day] when image was captured.
        utc_gps = UTC-GPS obtained from .cpf file.
        ut1_utc = UT1-UTC obtained from .cpf file.
        file_name: prefix of name of the files containing information extracted from the .ger file.
    """
    ms_ger_files = []
    ger_file_names = find_ger_files(ger_dir)
    for file_name in ger_file_names:
        ms_ger_files.append(ger_dir + "/" + file_name)
        ms_ger_files.sort()
        
    ms_ger_output_files = []
    for ger_file in ger_file_names:
        base, ext = os.path.splitext(ger_file)
        ms_ger_output_files.append(ger_info_dir + "/" + base)
        ms_ger_output_files.sort()

    date = MSDataExtraction(ms_ger_files, ms_ger_output_files, cpf_file, force_run)
    # date =[2015,1,2]
    file_name = ms_ger_output_files[0][:-2]
    utc_gps, ut1_utc = locationutil.readGainsAndDarkCurrent(cpf_file)
    out_file = out_dir + "/IMAGERY.tif"
    if (os.path.isfile(out_file) == False) or force_run:
#         createImage.buildMSImageUsingCubicInterpolation(out_file, file_name, band_lines, date, utc_gps, ut1_utc,dem_dir, start_sample, im_width, im_height)
        createImage.buildMSImageUsingCubicInterpolation(out_file, file_name, band_lines, date, utc_gps, ut1_utc, start_sample, im_width, im_height)
    scale = min(im_width / 1000, im_height / 1000)
    
    createPreview(out_file, out_dir + "/PREVIEW.JPG", out_dir + "/ICON.JPG", im_width / scale, im_height / scale)

    return date, utc_gps, ut1_utc, file_name

def createLevel2A_MSImage(out_dir, ger_info_dir, ger_dir, cpf_file, band_lines, dem, start_sample=1, im_width=6000, im_height=6000, dem_interp="kriging", force_run=False):
    
    """"
    :param out_dir: output file directory
    :param ger_info_dir: the extracted files will be put in ger_info_dir
    :param ger_dir: director contraining .ger files
    :param cpf_file: absolute location of a .cpf file
    :param dem: dem services
    :param band_lines: begining line for level 2A image [band1, band2, band3, band4]
    :param start_sample: staring samples default 1
    :param im_width: ger_file_image width default 12,0000
    :param im_height:ger_file_image heeight default 12,0000
    :param dem_interp: interpolation method for dem {"kriging", "linear", "cubic","nearest", "rbf"} defualt "kriging"
    :param force_run: force to extract all the files default is false
    :return:
        date: [year, month, day] when image was captured
        utc_gps: UTC-GPS obtained from .cpf file
        ut1_utc: UT1-UTC obtained from .cpf file
        file:_name=prefix of name of the files containing information extracted from the .ger file
        upleft: upper left corner of the scene in [row-col,utm lat-lon]
        upright: upper right corner of the scene in [row-col,utm lat-lon]
        midpoint: scene center in [row-col,utm lat-lon]
        lowleft: lower left corner of the scene in [row-col,utm lat-lon]
        lowright: lower right corner of the scene in [row-col,utm lat-lon]
        map_info: [x coordinate upper left corner in level 2A, y coordinate upper left corner in level 2A,
                  pixel resolution in x-direction,pixel resolution in y-direction, average elevation of the scene,
                  utm zone number, True if northern hemisphere]
    """
    ms_ger_files = []
    ger_file_names = find_ger_files(ger_dir)
    for file_name in ger_file_names:
        ms_ger_files.append(ger_dir + "/" + file_name)
        ms_ger_files.sort()
        
    ms_ger_output_files = []
    for ger_file in ger_file_names:
        base, ext = os.path.splitext(ger_file)
        ms_ger_output_files.append(ger_info_dir + "/" + base)
        ms_ger_output_files.sort()

    year, month, day, band_bad_lines, band_degraded_lines = MSDataExtraction(ms_ger_files, ms_ger_output_files, cpf_file, force_run)
    date = [year, month, day]
    file_name = ms_ger_output_files[0][:-2]
    utc_gps, ut1_utc = locationutil.readGainsAndDarkCurrent(cpf_file)
    out_file = out_dir + "/IMAGERY.tif"
    
    if (os.path.isfile(out_file) == False) or force_run:
        g1 = []
        g2 = []
        g3 = []
        g4 = []
        d1 = []
        d2 = []
        d3 = []
        d4 = []

        for gnumber in range(1, 11):
            g, d = gr.readGainsAndDarkCurrent(cpf_file, 1, gnumber)
            g1.append(g)
            d1.append(d)

            g, d = gr.readGainsAndDarkCurrent(cpf_file, 2, gnumber)
            g2.append(g)
            d2.append(d)

            g, d = gr.readGainsAndDarkCurrent(cpf_file, 3, gnumber)
            g3.append(g)
            d3.append(d)

            g, d = gr.readGainsAndDarkCurrent(cpf_file, 4, gnumber)
            g4.append(g)
            d4.append(d)
        gain = [g1, g2, g3, g4]
        darkcurrent = [d1, d2, d3, d4]
        
        upleft, upright, midpoint, lowleft, lowright, map_info = createImage.buildMS2AImageUsingCubicInterpolation(out_file, file_name, band_lines, date, utc_gps, ut1_utc, dem, gain, darkcurrent, start_sample, im_width, im_height, dem_interpolation_method=dem_interp)
    
    elif (os.path.isfile(out_file) == True):  # image file has been created.
        upleft, upright, midpoint, lowleft, lowright, map_info = createImage.computeMSImageCorners(out_file, file_name, band_lines, date, utc_gps, ut1_utc, dem, dem_interp, start_sample, im_width, im_height)
    
    scale = min(im_width / 1000, im_height / 1000)
    createPreview(out_file, out_dir + "/PREVIEW.JPG", out_dir + "/ICON.JPG", im_width / scale, im_height / scale)
    im = gdal.Open(out_file)
    proj = im.GetProjection()
    src = osr.SpatialReference()
    src.ImportFromWkt(proj)
    epsg = src.GetAttrValue("AUTHORITY", 1)
    map_info.append(epsg)
    width = im.RasterXSize
    height = im.RasterYSize
    map_info.append([width, height])

    return date, utc_gps, ut1_utc, file_name, upleft, upright, midpoint, lowleft, lowright, map_info

def createMSForPanSharpenImage(pansharpen_out_dir, pan_out_dir, ger_ms_info_dir, pansharpen_info_dir, ger_pan_info_dir, ger_ms_dir, ger_pan_dir, cpf_file, band_line_pan, start_sample=1, im_width=12000, im_height=12000, ms_width=6000, ms_height=6000, force_run=False):
    
    """
    :param out_dir: output file directory
    :param ger_info_dir: the extracted files will be put in ger_info_dir
    :param ger_dir: director where .ger is located
    :param cpf_file: a .cpf file
    :param apf_file: a .apf file
    :param band_line: begining line
    :param start_sample: first sample of each line (default is 1.)
    :param im_width: Width of the MS image (default is 6000)
    :param im_height: Height of the MS image (default is 3000)
    :param force_run: True will force to extact all data.
                      False will extact only if file is too old or does not exist.
    :return:
        date = [year, month, day] when image was captured.
        utc_gps = UTC-GPS obtained from .cpf file.
        ut1_utc = UT1-UTC obtained from .cpf file.
        file_name: prefix of name of the files containing information extracted from the .ger file.
    """
    
    ms_ger_files = []
    ger_file_names = find_ger_files(ger_ms_dir)
    for file_name in ger_file_names:
        ms_ger_files.append(ger_ms_dir + "/" + file_name)
        ms_ger_files.sort()
        
    ms_ger_output_files = []
    for ger_file in ger_file_names:
        base, ext = os.path.splitext(ger_file)
        ms_ger_output_files.append(ger_ms_info_dir + "/" + base)
        ms_ger_output_files.sort()

    date = MSDataExtraction(ms_ger_files, ms_ger_output_files, cpf_file, force_run)
    # date =[2015,1,2]
    ms_file_name = ms_ger_output_files[0][:-2]
    
    pan_ger_files = []
    ger_file_names = find_ger_files(ger_pan_dir)
    for file_name in ger_file_names:
        pan_ger_files.append(ger_pan_dir + "/" + file_name)
        pan_ger_files.sort()
        
    pan_ger_output_files = []
    for ger_file in ger_file_names:
        base, ext = os.path.splitext(ger_file)
        pan_ger_output_files.append(ger_pan_info_dir + "/" + base)
        pan_ger_output_files.sort()

    date = PANDataExtraction(pan_ger_files, pan_ger_output_files, cpf_file, force_run)
    # date = [2015,1,2]
    pan_file_name = pan_ger_output_files[0]
    utc_gps, ut1_utc = locationutil.readGainsAndDarkCurrent(cpf_file)
    out_file = pansharpen_out_dir + "/IMAGERYPANSHARPEN.tif"
    pan_out_file = pan_out_dir + "/IMAGERY.tif"

#     upleft, upright, midpoint, lowleft, lowright = createImage.buildMSForPanSharpenImageUsingCubicInterpolation(out_file, pan_out_file, pan_file_name,ms_file_name, pansharpen_info_dir,band_line_pan,date, utc_gps, ut1_utc, dem_dir, start_sample,im_width,im_height, ms_width, ms_height)
    upleft, upright, midpoint, lowleft, lowright = createImage.buildMSForPanSharpenImageUsingCubicInterpolation(out_file, pan_out_file, pan_file_name, ms_file_name, pansharpen_info_dir, band_line_pan, date, utc_gps, ut1_utc, start_sample, im_width, im_height, ms_width, ms_height)
    
    # if (os.path.isfile(out_file) == False) or force_run:
    #    upleft, upright, midpoint, lowleft, lowright =\
    #        createImage.buildMS2AImageUsingCubicInterpolation(out_file,  file_name, band_lines, date, utc_gps, ut1_utc,
    #                                                          dem_dir, start_sample, im_width, im_height)
    # elif (os.path.isfile(out_file) == True): # image file has been created.
    #     upleft, upright, midpoint, lowleft, lowright =\
    #         createImage.computeMSImageCorners(out_file,  file_name, band_lines, date, utc_gps, ut1_utc,
    #                                                          dem_dir, start_sample, im_width, im_height)
    # scale = min(im_width/1000,im_height/1000)
    # createPreview(out_file, out_dir + "\\PREVIEW.JPG", out_dir + "\\ICON.JPG", im_width/scale, im_height/scale)

    return date, utc_gps, ut1_utc, file_name, upleft, upright, midpoint, lowleft, lowright

def loadFilter(apf_file, band="PAN", id=9):
    
    """
    :param apf_file: The .apf file containing filter parameters
    :param band: spectral band. Default is "PAN"
    :param id: filter id. The defualt id is 9.
    :return: a 5x5 filter
    """
    doc = minidom.parse(apf_file)
    resplist = doc.getElementsByTagName("RestorationParametersList")[0]
    resparms = resplist.getElementsByTagName("RestorationParameters")
    for resp in resparms:
        apf_band = resp.getAttribute("band")
        if apf_band == band:
            filter_list = resp.getElementsByTagName("filter")
            for filter in filter_list:
                filter_id = int(filter.getAttribute("id"))
                if filter_id == id:
                    filterout = np.fromstring(filter.childNodes[0].data, dtype="float32", sep=",")
    filter2D = filterout.reshape((5, 5))
    return filter2D

def createLevel2A_PANImage(out_dir, ger_info_dir, ger_dir, cpf_file, apf_file, dem, band_line, start_sample=1, im_width=12000, im_height=12000, dem_interp="kriging", force_run="False"):
    
    """
    :param out_dir: output file directory
    :param ger_info_dir: the extracted files will be put in ger_info_dir
    :param ger_dir: director contraining .ger file
    :param cpf_file: absolute location of a .cpf file
    :param apf_file: absolute location of a .apf file
    :param dem: dem services
    :param band_line: begining line for level 2A image
    :param start_sample: staring samples default 1
    :param im_width: ger_file_image width default 12,0000
    :param im_height:ger_file_image heeight default 12,0000
    :param dem_interp: interpolation method for dem {"kriging", "linear", "cubic","nearest", "rbf"} defualt "kriging"
    :param force_run: force to extract all the files default is false
    :return:
        date: [year, month, day] when image was captured
        utc_gps: UTC-GPS obtained from .cpf file
        ut1_utc: UT1-UTC obtained from .cpf file
        file:_name=prefix of name of the files containing information extracted from the .ger file
        upleft: upper left corner of the scene in [row-col,utm lat-lon]
        upright: upper right corner of the scene in [row-col,utm lat-lon]
        midpoint: scene center in [row-col,utm lat-lon]
        lowleft: lower left corner of the scene in [row-col,utm lat-lon]
        lowright: lower right corner of the scene in [row-col,utm lat-lon]
        map_info: [x coordinate upper left corner in level 2A, y coordinate upper left corner in level 2A,
                  pixel resolution in x-direction,pixel resolution in y-direction, average elevation of the scene,
                  utm zone number, True if northern hemisphere]
    """
    
    pan_ger_files = []
    ger_file_names = find_ger_files(ger_dir)
    for file_name in ger_file_names:
        pan_ger_files.append(ger_dir + "/" + file_name)
        pan_ger_files.sort()
        
    pan_ger_output_files = []
    for ger_file in ger_file_names:
        base, ext = os.path.splitext(ger_file)
        pan_ger_output_files.append(ger_info_dir + "/" + base)
        pan_ger_output_files.sort()

    year, month, day, band_bad_lines, band_degraded_linees = PANDataExtraction(pan_ger_files, pan_ger_output_files, cpf_file, force_run)
    date = [year, month, day]
    file_name = pan_ger_output_files[0]
    utc_gps, ut1_utc = locationutil.readGainsAndDarkCurrent(cpf_file)
    out_file = out_dir + "/IMAGERY.tif"
    filter2D = []
    for id in range(1, 10):
        filter = loadFilter(apf_file, "PAN", id)
        filter2D.append(filter)

    if (force_run == True) or (os.path.isfile(out_file) == False):
        gain = []
        dark_cur = []
        for gnumber in range(1, 11):
            g, d = gr.readGainsAndDarkCurrent(cpf_file, "PAN", gnumber)
            gain.append(g)
            dark_cur.append(d)
        
        upleft, upright, midpoint, lowleft, lowright, map_info = createImage.buildPAN2AImageUsingCubicInterpolation(out_file, file_name, band_line, date, utc_gps, ut1_utc, dem, filter2D, gain, dark_cur, start_sample, im_width, im_height, dem_interpolation_method=dem_interp)
    elif (os.path.isfile(out_file) == True):  # image file has been created.
        upleft, upright, midpoint, lowleft, lowright, map_info = createImage.computePANImageCorners(out_file, file_name, band_line, date, utc_gps, ut1_utc, dem, dem_interp, filter2D, start_sample, im_width, im_height)
    
    im = gdal.Open(out_file)
    proj = im.GetProjection()
    src = osr.SpatialReference()
    src.ImportFromWkt(proj)
    epsg = src.GetAttrValue("AUTHORITY", 1)
    map_info.append(epsg)
    width = im.RasterXSize
    height = im.RasterYSize
    map_info.append([width, height])

    scale = min(im_width / 1000, im_height / 1000)
    createPreview(out_file, out_dir + "/PREVIEW.JPG", out_dir + "/ICON.JPG", im_width / scale, im_height / scale)

    return date, utc_gps, ut1_utc, file_name, upleft, upright, midpoint, lowleft, lowright, map_info

def computeDIMAPParameters(ger_info_prefix, dem_dir, image_type, line1, date, utc_gps, ut1_utc, start_sample, im_width, im_height):
    
    """
    :param ger_info_prefix: text containing all prefix to files extracted from .ger
    :param dem_dir: path to dem files
    :param image_type: "MS" for multispectral, "PAN" for panchromatic images
    :param line1: first line of Band 3 for multispectral image, and first line of panchromatic image
    :param date: [year, month, day] of capturing image
    :param utc_gps: UTC-GPS time
    :param ut1_utc: UT1-UTC time
    :return:
    upleft: latitude and longitude of pixel 1,1 in the image
    upright: latitude and longitude of pixel 1,width in the image
    lowleft = latitude and longitude of pixel height,1 in the image
    lowright = latitude and longitude of pixel height,width in the image
    midpoint = latitude and longitude of the center of the image
    view_angles = viewing angles along and across track.
    sat_angles = satellite incidence and azimuth angles
    sun_angles = sun azimuth and elevation angles
    orientation: orientation of the scene.
    """
    
    str_s = start_sample
    stp_s = start_sample + im_width - 1
    mid_s = start_sample + im_width / 2 - 1
    str_l = line1
    stp_l = line1 + im_height - 1
    mid_l = line1 + im_height / 2 - 1
    
    lat_upper_left, lon_upper_left, h_upper_left = dps.findInterSectionPoint(image_type, ger_info_prefix, str_s, str_l, date, utc_gps, ut1_utc, dem_dir)
    lat_upper_right, lon_upper_right, h_upper_right = dps.findInterSectionPoint(image_type, ger_info_prefix, stp_s, str_l, date, utc_gps, ut1_utc, dem_dir)
    lat_lower_left, lon_lower_left, h_lower_left = dps.findInterSectionPoint(image_type, ger_info_prefix, str_s, stp_l, date, utc_gps, ut1_utc, dem_dir)
    lat_lower_right, lon_lower_right, h_lower_right = dps.findInterSectionPoint(image_type, ger_info_prefix, stp_s, stp_l, date, utc_gps, ut1_utc, dem_dir)
    lat_mid, lon_mid, h_mid = dps.findInterSectionPoint(image_type, ger_info_prefix, mid_s, mid_l, date, utc_gps, ut1_utc, dem_dir)
    print "(%f,%f)=======(%f,%f)" % (lat_upper_left, lon_upper_left, lat_upper_right, lon_upper_right)
    print "====(%f,%f)====" % (lat_mid, lon_mid)
    print "(%f,%f)=======(%f,%f)" % (lat_lower_left, lon_lower_left, lat_lower_right, lon_lower_right)
    
    al, al_along, al_across, sat_incidence, sat_azimuth, sat_altitude = dps.findViewingAngles(image_type, ger_info_prefix, mid_l, mid_s, date, utc_gps, ut1_utc, lat_mid, lon_mid)
    print "VIEWING_ANGLE_ALONG_TRACK: %f, VIEWING_ANGLE_ACROSS_TRACK: %f" % (al_along, al_across)
    print "SATELLITE_INCIDENCE_ANGLE: %f, SATELLITE_AZIMUTH_ANGLE: %f, SATELLITE_ALTITUDE: %f" % (sat_incidence, sat_azimuth, sat_altitude)
    
    orientation = dps.findOrientationAngle(image_type, ger_info_prefix, mid_l, date, utc_gps, ut1_utc, dem_dir)
    print "SCENE_ORIENTATION: %f" % orientation
    
    sun_ev, sun_az = dps.findSunAngles(image_type, ger_info_prefix, mid_l, date, utc_gps, ut1_utc, lat_mid, lon_mid)
    print "SUN_AZIMUTH: %f,SUN_ELEVATION: %f" % (sun_az, sun_ev)

    # if image_type == "MS":
    #
    #     lat_upper_left, lon_upper_left, h_upper_left = dps.findInterSectionPoint(image_type, ger_info_prefix, str_s, line1,
    #                                                                              date, utc_gps, ut1_utc, dem_dir)
    #     lat_upper_right, lon_upper_right, h_upper_right = dps.findInterSectionPoint(image_type, ger_info_prefix, stp_s,
    #                                                                                 line1, date, utc_gps, ut1_utc,
    #                                                                                 dem_dir)
    #
    #     lat_lower_left, lon_lower_left, h_lower_left = dps.findInterSectionPoint(image_type, ger_info_prefix, str,
    #                                                                              line1 + im_height-1, date, utc_gps, ut1_utc,
    #                                                                              dem_dir)
    #     lat_lower_right, lon_lower_right, h_lower_right = dps.findInterSectionPoint(image_type, ger_info_prefix, stp,
    #                                                                                 line1 + im_height-1, date, utc_gps,
    #                                                                                 ut1_utc, dem_dir)
    #
    #     lat_mid, lon_mid, h_mid = dps.findInterSectionPoint(image_type, ger_info_prefix, str + im_width/2 -1, line1 + im_height/2-1, date,
    #                                                         utc_gps, ut1_utc, dem_dir)
    #     print "(%f,%f)=======(%f,%f)" % (lat_upper_left, lon_upper_left, lat_upper_right, lon_upper_right)
    #     print "====(%f,%f)====" % (lat_mid, lon_mid)
    #     print "(%f,%f)=======(%f,%f)" % (lat_lower_left, lon_lower_left, lat_lower_right, lon_lower_right)
    #     al, al_along, al_across, sat_incidence, sat_azimuth, sat_altitude = dps.findViewingAngles("MS", ger_info_prefix,
    #                                                                                               line1 + im_height/2-1, date,
    #                                                                                               utc_gps, ut1_utc,
    #                                                                                               lat_mid, lon_mid)
    #
    #     print "VIEWING_ANGLE_ALONG_TRACK: %f, VIEWING_ANGLE_ACROSS_TRACK: %f" % (al_along, al_across)
    #     print "SATELLITE_INCIDENCE_ANGLE: %f, SATELLITE_AZIMUTH_ANGLE: %f, SATELLITE_ALTITUDE: %f" % (
    #     sat_incidence, sat_azimuth, sat_altitude)
    #     orientation = dps.findOrientationAngle("MS", ger_info_prefix, line1, date, utc_gps, ut1_utc, dem_dir)
    #     print "SCENE_ORIENTATION: %f" % orientation
    #     sun_ev, sun_az = dps.findSunAngles("MS", ger_info_prefix, line1 + im_height/2-1, date, utc_gps, ut1_utc, lat_mid,
    #                                        lon_mid)
    #     print "SUN_AZIMUTH: %f,SUN_ELEVATION: %f" % (sun_az, sun_ev)
    # elif image_type == "PAN":
    #     lat_upper_left, lon_upper_left, h_upper_left = dps.findInterSectionPoint(image_type, ger_info_prefix, str, line1,
    #                                                                              date, utc_gps, ut1_utc, dem_dir)
    #     lat_upper_right, lon_upper_right, h_upper_right = dps.findInterSectionPoint(image_type, ger_info_prefix, stp,
    #                                                                                 line1, date, utc_gps, ut1_utc,
    #                                                                                 dem_dir)
    #
    #     lat_lower_left, lon_lower_left, h_lower_left = dps.findInterSectionPoint(image_type, ger_info_prefix, str,
    #                                                                              line1 + im_height-1, date, utc_gps, ut1_utc,
    #                                                                              dem_dir)
    #     lat_lower_right, lon_lower_right, h_lower_right = dps.findInterSectionPoint(image_type, ger_info_prefix, stp,
    #                                                                                 line1 + im_height-1 , date, utc_gps,
    #                                                                                 ut1_utc, dem_dir)
    #
    #     lat_mid, lon_mid, h_mid = dps.findInterSectionPoint(image_type, ger_info_prefix,str + im_width/2 -1, line1 + im_height/2-1, date,
    #                                                         utc_gps, ut1_utc, dem_dir)
    #     print "(%f,%f)=======(%f,%f)" % (lat_upper_left, lon_upper_left, lat_upper_right, lon_upper_right)
    #     print "====(%f,%f)====" % (lat_mid, lon_mid)
    #     print "(%f,%f)=======(%f,%f)" % (lat_lower_left, lon_lower_left, lat_lower_right, lon_lower_right)
    #     al, al_along, al_across, sat_incidence, sat_azimuth, sat_altitude = dps.findViewingAngles("PAN",
    #                                                                                               ger_info_prefix,
    #                                                                                               line1 + im_height/2-1, date,
    #                                                                                               utc_gps, ut1_utc,
    #                                                                                               lat_mid, lon_mid)
    #     print "VIEWING_ANGLE_ALONG_TRACK: %f, VIEWING_ANGLE_ACROSS_TRACK: %f" % (al_along, al_across)
    #     print "SATELLITE_INCIDENCE_ANGLE: %f, SATELLITE_AZIMUTH_ANGLE: %f, SATELLITE_ALTITUDE: %f" % (
    #     sat_incidence, sat_azimuth, sat_altitude)
    #     orientation = dps.findOrientationAngle("PAN", ger_info_prefix, line1, date, utc_gps, ut1_utc, dem_dir)
    #     print "SCENE_ORIENTATION: %f" % orientation
    #     sun_ev, sun_az = dps.findSunAngles("PAN", ger_info_prefix, line1 + im_height/2-1, date, utc_gps, ut1_utc, lat_mid,
    #                                        lon_mid)
    #     print "SUN_AZIMUTH: %f,SUN_ELEVATION: %f" % (sun_az, sun_ev)
    upleft = [lat_upper_left, lon_upper_left]
    upright = [lat_upper_right, lon_upper_right]
    lowleft = [lat_lower_left, lon_lower_left]
    lowright = [lat_lower_right, lon_lower_right]
    midpoint = [lat_mid, lon_mid]
    view_angles = [al_along, al_across]
    sat_angles = [sat_incidence, sat_azimuth]
    sun_angles = [sun_az, sun_ev]
    
    return upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles, orientation

def computeDIMAPParametersLevel2A(ger_info_prefix, dem, dem_interpolation_method, image_type, line1, date, utc_gps, ut1_utc, start_sample, im_width, im_height, midpoint):
    
    """
    :param ger_info_prefix: text containing all prefix to files extracted from .ger
    :param dem: dem service
    :param dem_interpolation_method: string indicate dem tyoe
    :param image_type: "MS" for multispectral, "PAN" for panchromatic images
    :param line1: first line of Band 3 for multispectral image, and first line of panchromatic image
    :param date: [year, month, day] of capturing image
    :param utc_gps: UTC-GPS time
    :param ut1_utc: UT1-UTC time
    :param midpoint = latitude and longitude of the center of the image
    :return:
    upleft: latitude and longitude of pixel 1,1 in the image
    upright: latitude and longitude of pixel 1,width in the image
    lowleft = latitude and longitude of pixel height,1 in the image
    lowright = latitude and longitude of pixel height,width in the image
    midpoint = latitude and longitude of the center of the image
    view_angles = viewing angles along and across track.
    sat_angles = satellite incidence and azimuth angles
    sun_angles = sun azimuth and elevation angles
    orientation: orientation of the scene.
    """

    mid_s = start_sample + im_width / 2 - 1
    mid_l = line1 + im_height / 2 - 1
    lat_mid = midpoint[2][1]
    lon_mid = midpoint[2][0]

    al, al_along, al_across, sat_incidence, sat_azimuth, sat_altitude = dps.findViewingAngles(image_type, ger_info_prefix, mid_l, mid_s, date, utc_gps, ut1_utc, lat_mid, lon_mid)
    print "VIEWING_ANGLE_ALONG_TRACK: %f, VIEWING_ANGLE_ACROSS_TRACK: %f" % (al_along, al_across)
    
    print "SATELLITE_INCIDENCE_ANGLE: %f, SATELLITE_AZIMUTH_ANGLE: %f, SATELLITE_ALTITUDE: %f" % (sat_incidence, sat_azimuth, sat_altitude)
    
    orientation = dps.findOrientationAngle(image_type, ger_info_prefix, mid_l, date, utc_gps, ut1_utc, dem, dem_interpolation_method)
    print "SCENE_ORIENTATION: %f" % orientation
    
    sun_ev, sun_az = dps.findSunAngles(image_type, ger_info_prefix, mid_l, date, utc_gps, ut1_utc, lat_mid, lon_mid)
    print "SUN_AZIMUTH: %f,SUN_ELEVATION: %f" % (sun_az, sun_ev)

    view_angles = [al_along, al_across]
    sat_angles = [sat_incidence, sat_azimuth]
    sun_angles = [sun_az, sun_ev]
    
    return view_angles, sat_angles, sat_altitude, sun_angles, orientation

def buildLevel1A_MS(ger_dir, cpf_file, band_lines, ger_info_dir, out_dir, dem_dir, start_sample=1, im_width=6000, im_height=6000, force_run=False):
    
    """
    :param ger_dir: sting  of the absolute Directory containing GER file
    :param cpf_file: string of the absolute cpf file name
    :param band_lines: [b1,b2,b3,b4] list of the scan lines corresponding to the first line of the ourput image
    :param ger_info_dir: string of the absolute path to the directory containing all extracted information
    :param out_dir: string of the absolute path to the directory containing all extracted tiff image and previews
    :param dem_dir: string of the absolute path to DEM data
    :param start_sample: Integer indicating the first sample of each line. Default value is 1
    :param im_width: width of the MS image. Default is 6000
    :param im_height: height of the MS image. Default is 60000
    :param force_run: True will force the program to re-extract and create all images again, False will extract file
                      only if the file does not exist.
    :return:
        upleft: lat,lon at pixel (1,1)
        upright: lat, lon at (1, im_width)
        midpoint: lat, lon at (im_height/2,im_width/2)
        lowleft: lat, lon at (im_height,1)
        lowright: lat, lon at (im_height,im_width)
        view_angles: viewing angles along and across track
        sat_angles: satellite incidence and azimuth angles
        sat_altitude: satellite altitude in meters
        sun_angles: sun elevation and azimuth angles
        orientation: scene orientation
    """
    
    print "Extracting GER file....."
    date, utc_gps, ut1_utc, ger_prefix = createLevel1A_MSImage(out_dir, ger_info_dir, ger_dir, cpf_file, band_lines, start_sample, im_width, im_height, force_run)
    print "file extraction completed."
    
    print "computing TILE points."
    upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles, orientation = computeDIMAPParameters(ger_prefix, dem_dir, "MS", band_lines[2], date, utc_gps, ut1_utc, start_sample, im_width, im_height)
    print "completed."
    
    print "Embedding TILE points into theimage file.."
    ms = gdal.Open(out_dir + "/IMAGERY.tif", gdal.GA_Update)
    proj = osr.SpatialReference()
    proj.SetWellKnownGeogCS("EPSG:4326")
    p11 = gdal.GCP()
    p11.GCPLine = 0.5
    p11.GCPPixel = 0.5
    p11.GCPX = upleft[1]
    p11.GCPY = upleft[0]
    p11.Id = '1'
    p1_6000 = gdal.GCP()
    p1_6000.GCPLine = 0.5
    p1_6000.GCPPixel = float(im_width) - 0.5
    p1_6000.GCPX = upright[1]
    p1_6000.GCPY = upright[0]
    p1_6000.Id = '2'

    p6000_1 = gdal.GCP()
    p6000_1.GCPLine = float(im_height) - 0.5
    p6000_1.GCPPixel = 0.5
    p6000_1.GCPX = lowleft[1]
    p6000_1.GCPY = lowleft[0]
    p6000_1.Id = '4'

    p6000_6000 = gdal.GCP()
    p6000_6000.GCPLine = float(im_height) - 0.5
    p6000_6000.GCPPixel = float(im_width) - 0.5
    p6000_6000.GCPX = lowright[1]
    p6000_6000.GCPY = lowright[0]
    p6000_6000.Id = '3'
    ms.SetGCPs([p11, p1_6000, p6000_1, p6000_6000], proj.ExportToWkt())
    import time
    t = time.gmtime()
    metadata = {'TIFFTAG_DATETIME': '%s  ' % time.strftime("%Y%m%d %H:%M:%S", t), 'TIFFTAG_IMAGEDESCRIPTION': 'PAN', 'AREA_OR_POINT': 'Point'}
    ms.SetMetadata(metadata)
    ms = None
    print "completed."
    
    return upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles, orientation

def buildLevel2A_MS(ger_dir, cpf_file, band_lines, ger_info_dir, out_dir, dem_type, dem_interp="kriging", start_sample=1, im_width=6000, im_height=6000, force_run=False):
    
    """
    :param ger_dir: sting  of the absolute Directory containing GER file
    :param cpf_file: string of the absolute cpf file name
    :param band_lines  the scan lines corresponding to the first line of the ourput image in
                format [band1,band2,band3,band4]
    :param ger_info_dir: string of the absolute path to the directory containing all extracted information
    :param out_dir: string of the absolute path to the directory containing all extracted tiff image and previews
    :param dem_type  string of digital elevation model database
    :param dem_interp: dem interpolation method {"kriging","nearest","linear","cubic","rbf"} [defualt: "kriging"]
    :param start_sample: starting sample in ger file [defualt: 1]
    :param im_width: the used area in width [default: 12,0000]
    :param im_height: the used area in height [default: 12,0000]
    :param force_run: True to force the system to re-extracting every files
    :return:
        upright: upper right corner of the scene in [row-col,utm lat-lon]
        midpoint: scene center in [row-col,utm lat-lon]
        lowleft: lower left corner of the scene in [row-col,utm lat-lon]
        lowright: lower right corner of the scene in [row-col,utm lat-lon]
        map_info: [x coordinate upper left corner in level 2A, y coordinate upper left corner in level 2A,
                  pixel resolution in x-direction,pixel resolution in y-direction, average elevation of the scene,
                  utm zone number, True if northern hemisphere]
        view_angles: viewing angles along and across track
        sat_angles: satellite incidence and azimuth angles
        sat_altitude: satellite altitude in meters
        sun_angles: sun elevation and azimuth angles
        orientation: scene orientation
    """
    
    ts = time.time()
    print "Extracting GER file....."
    if dem_type == demservice.SRTM90_DEM:
        dem = demservice.srtm90(dem_directories[dem_type])
    elif dem_type == demservice.GLOBE_DEM:
        dem = demservice.globedem(dem_directories[dem_type])
    elif dem_type == demservice.THEOS_DEM:
        dem = demservice.theosDEM(dem_directories[dem_type])
    
    date, utc_gps, ut1_utc, ger_prefix, upleft, upright, midpoint, lowleft, lowright, map_info = createLevel2A_MSImage(out_dir, ger_info_dir, ger_dir, cpf_file, band_lines, dem, dem_interp=dem_interp, start_sample=start_sample, im_width=im_width, im_height=im_height, force_run=force_run)
    print "file extraction completed."
    
    print "computing TILE points."
    view_angles, sat_angles, sat_altitude, sun_angles, orientation = computeDIMAPParametersLevel2A(ger_prefix, dem, dem_interp, "MS", band_lines[2], date, utc_gps, ut1_utc, start_sample, im_width, im_height, midpoint)
    print "completed."
    
    print "Embedding TILE points into theimage file.."
    ms = gdal.Open(out_dir + "/IMAGERY.tif", gdal.GA_Update)
    t = time.gmtime()
    metadata = {'TIFFTAG_DATETIME': '%s  ' % time.strftime("%Y%m%d %H:%M:%S", t), 'TIFFTAG_IMAGEDESCRIPTION': 'PAN', 'AREA_OR_POINT': 'Point'}
    ms.SetMetadata(metadata)
    ms = None
    print "completed."
    tp = time.time()
    print "Total processing time: %fs." % (tp - ts)
    
    return upleft, upright, midpoint, lowleft, lowright, map_info, view_angles, sat_angles, sat_altitude, sun_angles, orientation

def buildLevel2A_PAN(ger_dir, cpf_file, apf_file, band_line, ger_info_dir, out_dir, dem_type, dem_interp=demservice.digitalElevationModel.CUBIC, start_sample=1, im_width=12000, im_height=12000, force_run=False):
    
    """
    :param ger_dir: sting  of the absolute Directory containing GER file
    :param cpf_file: string of the absolute cpf file name
    :param apf_file: string of the absolute apf file name
    :param band_line:  the scan lines corresponding to the first line of the ourput image
    :param ger_info_dir: string of the absolute path to the directory containing all extracted information
    :param out_dir: string of the absolute path to the directory containing all extracted tiff image and previews
    :param dem_type:  string of the digital elevation model database
    :param dem_interp: dem interpolation method {"kriging","nearest","linear","cubic","rbf"} [defualt: "kriging"]
    :param start_sample: starting sample in ger file [defualt: 1]
    :param im_width: the used area in width [default: 12,0000]
    :param im_height: the used area in height [default: 12,0000]
    :param force_run: True to force the system to re-extracting every files
    :return:
        upright: upper right corner of the scene in [row-col,utm lat-lon]
        midpoint: scene center in [row-col,utm lat-lon]
        lowleft: lower left corner of the scene in [row-col,utm lat-lon]
        lowright: lower right corner of the scene in [row-col,utm lat-lon]
        map_info: [x coordinate upper left corner in level 2A, y coordinate upper left corner in level 2A,
                  pixel resolution in x-direction,pixel resolution in y-direction, average elevation of the scene,
                  utm zone number, True if northern hemisphere]
        view_angles: viewing angles along and across track
        sat_angles: satellite incidence and azimuth angles
        sat_altitude: satellite altitude in meters
        sun_angles: sun elevation and azimuth angles
        orientation: scene orientation
    """

    if dem_type == demservice.SRTM90_DEM:
        dem = demservice.srtm90(dem_directories[dem_type])
    elif dem_type == demservice.GLOBE_DEM:
        dem = demservice.globedem(dem_directories[dem_type])
    elif dem_type == demservice.THEOS_DEM:
        dem = demservice.theosDEM(dem_directories[dem_type])

    ts = time.time()
    print "GER file extracing......."
    date, utc_gps, ut1_utc, ger_prefix, upleft, upright, midpoint, lowleft, lowright, map_info = createLevel2A_PANImage(out_dir, ger_info_dir, ger_dir, cpf_file, apf_file, dem, band_line, dem_interp=dem_interp, start_sample=start_sample, im_width=im_width, im_height=im_height, force_run=force_run)
    print "Extraction completed."
    print "computing the TILE points"
    print "file extraction completed."
    
    print "computing TILE points."
    view_angles, sat_angles, sat_altitude, sun_angles, orientation = computeDIMAPParametersLevel2A(ger_prefix, dem, dem_interp, "PAN", band_line, date, utc_gps, ut1_utc, start_sample, im_width, im_height, midpoint)
    print "completed."
    
    print "Embedding TILE points into theimage file.."
    ms = gdal.Open(out_dir + "/IMAGERY.tif", gdal.GA_Update)
    t = time.gmtime()
    metadata = {'TIFFTAG_DATETIME': '%s  ' % time.strftime("%Y%m%d %H:%M:%S", t), 'TIFFTAG_IMAGEDESCRIPTION': 'PAN', 'AREA_OR_POINT': 'Point'}
    ms.SetMetadata(metadata)
    ms = None
    print "completed."
    tp = time.time()
    print "Total processing time: %fs." % (tp - ts)
    
    return upleft, upright, midpoint, lowleft, lowright, map_info, view_angles, sat_angles, sat_altitude, sun_angles, orientation

def build_PANSHARPEN(ger_ms_dir, ger_pan_dir, cpf_file, band_line_pan, pansharpen_info, ger_pan_info_dir, ger_ms_info_dir, pansharpen_out_dir, pan_out_dir, dem_dir, apf_file, start_sample=1, im_width=12000, im_height=12000, force_run=False):
    
    """
    :param ger_dir: sting  of the absolute Directory containing GER file
    :param cpf_file: string of the absolute cpf file name
    :param band_lines: [b1,b2,b3,b4] list of the scan lines corresponding to the first line of the ourput image
    :param ger_info_dir: string of the absolute path to the directory containing all extracted information
    :param out_dir: string of the absolute path to the directory containing all extracted tiff image and previews
    :param dem_dir: string of the absolute path to DEM data
    :param start_sample: Integer indicating the first sample of each line. Default value is 1
    :param im_width: width of the MS image. Default is 6000
    :param im_height: height of the MS image. Default is 60000
    :param force_run: True will force the program to re-extract and create all images again, False will extract file
                      only if the file does not exist.
    :return:
        upleft: lat,lon at pixel (1,1)
        upright: lat, lon at (1, im_width)
        midpoint: lat, lon at (im_height/2,im_width/2)
        lowleft: lat, lon at (im_height,1)
        lowright: lat, lon at (im_height,im_width)
        view_angles: viewing angles along and across track
        sat_angles: satellite incidence and azimuth angles
        sat_altitude: satellite altitude in meters
        sun_angles: sun elevation and azimuth angles
        orientation: scene orientation
    """
    
    ts = time.time()
    print "Building PAN Image......."
    print "Extracting GER file....."
    date, utc_gps, ut1_utc, ger_prefix, upleft, upright, midpoint, lowleft, lowright, map_info = createLevel2A_PANImage(pan_out_dir, ger_pan_info_dir, ger_pan_dir, cpf_file, apf_file, dem_dir, band_line_pan, start_sample, im_width, im_height, dem_interp="kriging", force_run=force_run)

    date, utc_gps, ut1_utc, ger_prefix, upleft, upright, midpoint, lowleft, lowright = createMSForPanSharpenImage(pansharpen_out_dir, pan_out_dir, ger_ms_info_dir, pansharpen_info, ger_pan_info_dir, ger_ms_dir, ger_pan_dir, cpf_file, band_line_pan, start_sample, im_width, im_height, force_run=force_run)

    # print "file extraction completed."
    # print "computing TILE points."
    # view_angles, sat_angles, sat_altitude, sun_angles, orientation = computeDIMAPParametersLevel2A(ger_prefix, dem_dir, "MS",
    #                                                                                        band_lines[2], date, utc_gps,
    #                                                                                        ut1_utc, start_sample,
    #                                                                                        im_width,im_height,midpoint )


    # t = time.gmtime()
    # metadata = {'TIFFTAG_DATETIME': '%s  ' % time.strftime("%Y%m%d %H:%M:%S", t), 'TIFFTAG_IMAGEDESCRIPTION': 'PAN',
    #             'AREA_OR_POINT': 'Point'}
    # ms.SetMetadata(metadata)
    # ms = None
    # print "completed."
    # tp = time.time()
    # print "Total processing time: %fs."%(tp-ts)
    # return upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles, orientation


def buildLevel2AImage(image_type, ger_directory, cpf_file, apf_file, begin_line, dem_type, info_directory, destination_directory, rev_num, grid_ref, dem_interpolation=demservice.digitalElevationModel.CUBIC, line_shift=0, start_sample=1, im_width=None, im_height=None, force_run=False):
    
    """
    :param image_type: "PAN" or "MS"
    :param ger_directory: directory containing ger files
    :param cpf_file: the cpf file associated with GER file
    :param apf_file: the advanced parameter files
    :param begin_line: the first line of the image
    :param dem_type: type of DEM used in the creation of LEVEL 2A product.
    :param info_directory: The directory that is used to stored all extracted data
    :param destination_directory: The output directory
    :param rev_num: revolution number
    :param grid_ref: the grid reference
    :param dem_interpolation: the interpolation method NEAREST, LINEAR, CUBIC, RBF, KRIGING
    :param line_shift: "The number of line shifted from the grid
    :param start_sample: The start sample. The default values i one
    :param im_width: Image width 6000 for MS and  12000 for PAN
    :param im_height: Image height6000 for MS and  12000 for PAN
    :param force_run: True to force the system to re-extracting all files.
    :return: None
    """
    
    job_time = time.time()
    if image_type == "PAN":
        if (im_width is None):
            im_width = 12000
        if (im_height is None):
            im_height = 12000

        upleft, upright, midpoint, lowleft, lowright, map_info, view_angles, sat_angles, sat_altitude, sun_angles, orientation = buildLevel2A_PAN(ger_directory, cpf_file, apf_file, begin_line, info_directory, destination_directory, dem_type, dem_interp=dem_interpolation, start_sample=start_sample, im_width=im_width, im_height=im_height, force_run=force_run)
        angle_list = [upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles, orientation, map_info]
        
        print "Create DIMAP file."
        DIMAP1.dimap_create(destination_directory, rev_num, "PAN", grid_ref, [begin_line], info_directory, cpf_file, angle_list, start_sample, im_width, im_height, line_shift, job_time)
        print "completed."
        
    elif image_type == "MS":
        if (im_width is None):
            im_width = 6000
        if (im_height is None):
            im_height = 6000
        upleft, upright, midpoint, lowleft, lowright, map_info, view_angles, sat_angles, sat_altitude, sun_angles, orientation = buildLevel2A_MS(ger_directory, cpf_file, begin_line, info_directory, destination_directory, dem_type, dem_interp=dem_interpolation, start_sample=start_sample, im_width=im_width, im_height=im_height, force_run=force_run)
        angle_list = [upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles, orientation, map_info]
        
        print "creating DIMAP"
        DIMAP1.dimap_create(destination_directory, rev_num, "MS", grid_ref, begin_line, info_directory, cpf_file, angle_list, start_sample, im_width, im_height, line_shift, job_time)
        print "completed."
    else:
        print "Invalid image type"
        exit(1)

def buildPanSharpen2A(pan_ger_directory, ms_ger_directory, cpf_file, apf_file, pan_begin_line, dem_directory, pan_info_directory, ms_info_directory, pansharpen_info_directory, destination_directory, pan_out_directory, rev_num, grid_ref, dem_interpolation="kriging", line_shift=0, start_sample=1, im_width=None, im_height=None, force_run=False):
    
    """
    :param pan_ger_directory:
    :param ms_ger_directory:
    :param cpf_file:
    :param apf_file:
    :param pan_begin_line:
    :param dem_directory:
    :param pan_info_directory:
    :param pansharpen_info_directory:
    :param destination_directory:
    :param rev_num:
    :param grid_ref:
    :param dem_interpolation:
    :param line_shift:
    :param start_sample:
    :param im_width:
    :param im_height:
    :param force_run:
    :return:
    """

    build_PANSHARPEN(ms_ger_directory, pan_ger_directory, cpf_file, pan_begin_line, pansharpen_info_directory, pan_info_directory, ms_info_directory, destination_directory, pan_out_directory, dem_directory, apf_file)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    if pc:
        apf_file = "C:/Worker/Support-Worker/Sipros_system/APF/THEOS_nominal.APF"  # APF File use in PAN process
        
        GERALD_keep = "//172.27.188.133/thaichote_gerald/GERALD"  # Path to keep Gerald directory in network drive.
        GERALD_local = "C:/Worker/Support-Worker/Sipros_system/GERALD"  # Path to keep Gerald directory in Local drive.
        
        GERALD_info = "C:/Worker/Support-Worker/Sipros_system/Extraction_files/Level2A"  # Path to keep directory of extract files from Gerald file.
        Product_keep = "C:/Worker/Support-Worker/Sipros_system/Product_files/Level_2A"  # Path to keep directory of product files from process.
        
        CPF_directory = "C:/Worker/Support-Worker/Sipros_system/CPF_PROCESSING/CPF_file"  # All CPF file keep in this directory.
        CPF_index = "C:/Worker/Support-Worker/Sipros_system/CPF_PROCESSING/CPF_index"  # Directory to keep index file who create by cpf_logic.
        
        Log_path = "C:/Worker/Support-Worker/Sipros_system/LOG"  # Directory to keep log file from product process.
        product_detail = "C:\Worker\Support-Worker\Sipros_system\Command_files"  # Directory to get command to process
        
    else :
        apf_file = "/home/asuna/worker/2016-12/LAB/APF/THEOS_nominal.APF"
        
        GERALD_keep = "/home/asuna/worker/2016-12/LAB/GERALD_SIM"  # Path to keep Gerald directory in network drive.
        GERALD_local = "/home/asuna/worker/2016-12/LAB/GERALD_Local"  # Path to keep Gerald directory in Local drive.
        
        GERALD_info = "/home/asuna/worker/2016-12/LAB/EXTRACTION/LEVEL2A"  # Path to keep directory of extract files from Gerald file.
        Product_keep = "/home/asuna/worker/2016-12/LAB/PRODUCT/LEVEL2A"  # Path to keep directory of product files from process.
        
        CPF_directory = "/home/asuna/worker/2016-12/LAB/CPF_PROCESS/CPF_FILE"  # All CPF file keep in this directory.
        CPF_index = "/home/asuna/worker/2016-12/LAB/CPF_PROCESS/CPF_INDEX"  # Directory to keep index file who create by cpf_logic.
        
        Log_path = "/home/asuna/worker/2016-12/LAB/LOG"  # Directory to keep log file from product process.
        product_detail = "/home/asuna/worker/2016-12/LAB/COMMAND"  # Directory to get command to process
        
    try :
        Browse_command_files_list = []
        Browse_command_file = QFileDialog.getOpenFileNames(None,"Browse command files" ,product_detail, "*.cmp")
        for command_filenames in Browse_command_file:
            command_filename = str(command_filenames)
            Browse_command_files_list.append(command_filename)
            
        count_command = len(Browse_command_files_list)
        
        for i in range(count_command):
            command_list = []
            open_command_file = open(Browse_command_files_list[i],"r")
            for j in range(64):
                get_pre_command = open_command_file.readline()
                pre_command = get_pre_command.strip("\n")
                command_value = str(pre_command)
                command_list.append(command_value)
            open_command_file.close()
            
            # Begin_reception_date = int(command_list[0])
            # Begin_reception_time = float(command_list[1])
            # End_reception_date = int(command_list[2])
            # End_reception_time = float(command_list[3])
            # Orbit_cycle = str(command_list[4])
            Revolution_number = str(command_list[5])
            # Mission = str(command_list[6])
            # Satellite = str(command_list[7])
            # Passrank = str(command_list[8])
            # PassID = str(command_list[9])
            # Segment_count = int(command_list[10])
            # Segment_info = str(command_list[11])
            FileName = str(command_list[12])
            Gerald_name = str(command_list[13])
            Segment_rank = int(command_list[14])
            # Instrument = str(command_list[15])  
            # Transmission_mode = str(command_list[16])
            # Segment_quality = str(command_list[17])
            # Begin_segment_viewing_date = int(command_list[18])
            # Begin_segment_viewing_time = float(command_list[19])
            # End_segment_viewing_date = int(command_list[20]) 
            # End_segment_viewing_time = float(command_list[21])
            # Compression_ratio = float(command_list[22])   
            SpectralMode = str(command_list[23])  
            band_offset_B1 = int(command_list[24])
            band_offset_B2 = int(command_list[25])
            band_offset_B3 = int(command_list[26])
            band_offset_B4 = int(command_list[27])
            # Reference_Band = str(command_list[28])
            # Along_track_viewing_angle = float(command_list[29])
            # Across_track_viewing_angle = float(command_list[30])
            # ABS_Gain = float(command_list[31])
            # scene_info = str(command_list[32])
            scene_count = int(command_list[33])
            scene_rank = int(command_list[34])
            Grid_ref = str(command_list[35])
            # Technical_quality = str(command_list[36])
            # Cloud_cover = str(command_list[37])
            # Snow_cover = str(command_list[38])
            Center_scene_viewing_date = str(command_list[39])
            Center_scene_viewing_time = str(command_list[40])
            # Begin_scene_viewing_date = int(command_list[41])
            # Begin_scene_viewing_time = float(command_list[42])
            # End_scene_viewing_date = int(command_list[43])
            # End_scene_viewing_time = float(command_list[44])
            # Coupling_mode = str(command_list[45])  
            # Orientation_angle = float(command_list[46])
            # Incidence_angle = float(command_list[47])
            # Sun_elevation = float(command_list[48])
            # Sun_azimuth = float(command_list[49])
            # Latitude_NW = float(command_list[50])
            # Longitude_NW = float(command_list[51])
            # Latitude_NE = float(command_list[52])
            # Longitude_NE = float(command_list[53])
            # Latitude_SW = float(command_list[54])
            # Longitude_SW = float(command_list[55])
            # Latitude_SE = float(command_list[56])
            # Longitude_SE = float(command_list[57])
            # Center_scene_latitude = float(command_list[58])
            # Center_scene_longitude = float(command_list[59])
            if SpectralMode == "MS":
                dsr_begin = [int(command_list[60]) , int(command_list[61]) , int(command_list[62]) , int(command_list[63])]
            elif SpectralMode == "PAN":
                dsr_begin = int(command_list[60])
            
            EXAMPLE = SpectralMode
    
            job_time = time.time()
            if EXAMPLE == "PAN":
                
                ger_keep = "%s/%s"%(GERALD_keep , Gerald_name)
                ger_dir = "%s/%s"%(GERALD_local , Gerald_name) # directory of ger file# directory of ger file
                Gerald_filelist = []
                for root , directory , files in os.walk(ger_keep , topdown = False):
                    for filename in files:
                        Gerald_filename = os.path.join(root , filename)
                        if Gerald_filename.endswith(".GER"):
                            Gerald_filelist.append(Gerald_filename)
                            Gerald_filelist.sort()
                        elif not Gerald_filename.endswith(".GER"):
                            error_value_gerald = str(traceback.format_exc())
                            print error_value_gerald
                            QMessageBox.warning(None ,"Warning", error_value_gerald)
                
                Gerald_file_pan = Gerald_filelist[0]
                if os.path.exists(Gerald_file_pan):
                    pass
                elif not os.path.exists(Gerald_file_pan):
                    sys.exit("Gerald file has not exist.")
                try :
                    if not os.path.exists(ger_dir):
                        os.mkdir(ger_dir)
                        print "create gerald local"
                        shutil.copy(Gerald_file_pan , ger_dir)
                        print "copy gerald from center dirve."
                    elif os.path.exists(ger_dir):
                        for local_root , local_directory , local_files in os.walk(ger_dir , topdown = False):
                            for local_filename in local_files:
                                Gerald_local_filename = os.path.join(local_root , local_filename)
                                if Gerald_local_filename.endswith(".GER"):
                                    pass
                                elif not Gerald_local_filename.endswith(".GER"):
                                    shutil.rmtree(ger_dir)
                                    print "Delete gerald local."
                                    os.mkdir(ger_dir)
                                    print "Recreate gerald local."
                                    shutil.copy(Gerald_file_pan , ger_dir)
                                    print "copy gerald from center dirve."
                except : 
                    QMessageBox.warning(None ,"Warning", str(traceback.format_exc()))
                    sys.exit(traceback.format_exc())
                
                cpf_file , cpf_name = CP.comparecufandcpf(Center_scene_viewing_date , CPF_directory , CPF_index)
                # absolute location of cpf file
        
                ger_info_dir = GERALD_info + "/" + Gerald_name# absolute directory containing all extracted information from ger files.
                if not os.path.exists(ger_info_dir):
                    os.mkdir(ger_info_dir)
                    print "Gerald info has create."
                elif os.path.exists(ger_info_dir):
                    print "Gerald info has already exist."
                    pass

                out_path = Product_keep + "/" + Gerald_name # absolute directory to keep product in
                if not os.path.exists(out_path):
                    os.mkdir(out_path)
                elif os.path.exists(out_path):
                    pass
                
                job_ID = time.gmtime(job_time)
                job_ID_year = job_ID.tm_year-2000
                job_ID_month = job_ID.tm_mon
                job_ID_day = job_ID.tm_mday
                job_ID_hour = job_ID.tm_hour
                job_ID_min = job_ID.tm_min
                job_ID_sec = job_ID.tm_sec
                job_ID_millisec = int((job_time%1)*1000)

                pan_out_name = "TH_CAT_%02d%02d%02d"%(job_ID_year , job_ID_month , job_ID_day) + "%02d%02d%02d%03d"%(job_ID_hour , job_ID_min , job_ID_sec , job_ID_millisec) + "_1_" + Center_scene_viewing_date + "_" + Center_scene_viewing_time

                out_dir = out_path + "/" + pan_out_name
                if not os.path.exists(out_dir):
                    os.mkdir(out_dir)
                    print "Product path has create."
                elif os.path.exists(out_dir):
                    shutil.rmtree(out_dir)
                    print "Delete old product path."
                    os.mkdir(out_dir)
                    print "Create new product path."
                
                if scene_rank != scene_count:
                    try:
                        bandline = dsr_begin  # begining line of PAN image    
                        start_sample = 1
                        start_time = time.clock()
                        # absolute directory containing dem files.                       
                        buildLevel2AImage(EXAMPLE, ger_dir, cpf_file, apf_file, begin_line=bandline, dem_type=demservice.THEOS_DEM, info_directory=ger_info_dir, destination_directory=out_dir, rev_num=Revolution_number, grid_ref=Grid_ref, dem_interpolation=demservice.digitalElevationModel.CUBIC, line_shift=0, start_sample=1)
                        end_time = float((time.clock() - start_time)/60)
                        
                        print "Create archive."
                        zip_out_dir = zipfile.ZipFile(out_dir   + ".zip" , "w")
                        print "adding %s"%out_dir
                        for ziproot , zipdirectory , zipfiles in os.walk(out_dir , topdown = False):
                            for zipname in zipfiles:
                                zipdir = os.path.join(ziproot , zipname)
                                zipfilename = os.path.join(zipname)
                                zip_out_dir.write(zipname)
                        zip_out_dir.close()
                        print "product completed."
                        
                        Log_pan_name = Log_path + "/" + pan_out_name + ".log"
                        Log_pan_file = open(Log_pan_name,"w")
                        Log_pan_file.write("Revolution : " +str(Revolution_number) + "\n")
                        Log_pan_file.write("Gerald directory name : " + str(Gerald_name) + "\n")
                        Log_pan_file.write("Spectral Mode : " + str(SpectralMode) + "\n")
                        Log_pan_file.write("FileName : " + str(FileName) + "\n")
                        Log_pan_file.write("CPF file : " + str(cpf_name) + "\n")
                        Log_pan_file.write("Process Level : 2A\n")
                        Log_pan_file.write("Begin line : " + str(bandline) + "\n")
                        Log_pan_file.write("Scene rank : " + str(scene_rank) + "\n")
                        Log_pan_file.write("Date : " + str(Center_scene_viewing_date) + "\n")
                        Log_pan_file.write("Time : " + str(Center_scene_viewing_time) + "\n")
                        Log_pan_file.write("Grid ref : " + str(Grid_ref) + "\n")
                        Log_pan_file.write("Status : completed.\n")
                        Log_pan_file.write("Time to use : " + str(end_time) + "mn")
                        Log_pan_file.close()
                    
                    except:
                        Log_pan_name = Log_path + "/" + pan_out_name + ".log"
                        Log_pan_file = open(Log_pan_name,"w")
                        Log_pan_file.write("Revolution : " +str(Revolution_number) + "\n")
                        Log_pan_file.write("Gerald directory name : " + str(Gerald_name) + "\n")
                        Log_pan_file.write("Spectral Mode : " + str(SpectralMode) + "\n")
                        Log_pan_file.write("FileName : " + str(FileName) + "\n")
                        Log_pan_file.write("CPF file : " + str(cpf_name) + "\n")
                        Log_pan_file.write("Process Level : 2A\n")
                        Log_pan_file.write("Begin line : " + str(bandline) + "\n")
                        Log_pan_file.write("Scene rank : " + str(scene_rank) + "\n")
                        Log_pan_file.write("Date : " + str(Center_scene_viewing_date) + "\n")
                        Log_pan_file.write("Time : " + str(Center_scene_viewing_time) + "\n")
                        Log_pan_file.write("Grid ref : " + str(Grid_ref) + "\n")
                        Log_pan_file.write("Status : uncompleted.\n")
                        Log_pan_file.write("Error value is : " + str(traceback.format_exc()))
                        Log_pan_file.close()
                        
                elif scene_rank == scene_count:
                    try:
                        Use_GDB_last_line_list = []
                        GDB_directory = ger_info_dir
                        for root_gdb , directory_gdb , file_gdb in os.walk(GDB_directory , topdown = False):
                            for filepath in file_gdb:
                                GDB_path = os.path.abspath(os.path.join(root_gdb , filepath))
                                if GDB_path.endswith(".gdb"):
                                    GDB_data_file = open(GDB_path , "r")
                                    GDB_data_list = GDB_data_file.readlines()
                                    GDB_data_file.close()
                                    
                                    Pre_GDB_Endline = GDB_data_list[len(GDB_data_list)-1]
                                    Pre_GDB_End_line_data = Pre_GDB_Endline.split( )
                                    count_Pre_GDB_End_line_data = len( Pre_GDB_End_line_data)
                                    GDB_last_line = int(Pre_GDB_End_line_data[count_Pre_GDB_End_line_data - 1])
                                    Use_GDB_last_line_list.append(GDB_last_line)
                                    
                        bandline = Use_GDB_last_line_list[0] - 11999  # begining line of PAN image
                        start_sample = 1
                        start_time = time.clock()
                        buildLevel2AImage(EXAMPLE, ger_dir, cpf_file, apf_file, begin_line=bandline, dem_type=demservice.THEOS_DEM, info_directory=ger_info_dir, destination_directory=out_dir, rev_num=Revolution_number, grid_ref=Grid_ref, dem_interpolation=demservice.digitalElevationModel.CUBIC, line_shift=0, start_sample=1)
                        end_time = float((time.clock() - start_time)/60)
                        
                        print "Create archive."
                        zip_out_dir = zipfile.ZipFile(out_dir   + ".zip" , "w")
                        print "adding %s"%out_dir
                        for ziproot , zipdirectory , zipfiles in os.walk(out_dir , topdown = False):
                            for zipname in zipfiles:
                                zipdir = os.path.join(ziproot , zipname)
                                zipfilename = os.path.join(zipname)
                                zip_out_dir.write(zipname)
                        zip_out_dir.close()
                        print "product completed."
                        
                        Log_pan_name = Log_path + "/" + pan_out_name + ".log"
                        Log_pan_file = open(Log_pan_name,"w")
                        Log_pan_file.write("Revolution : " +str(Revolution_number) + "\n")
                        Log_pan_file.write("Gerald directory name : " + str(Gerald_name) + "\n")
                        Log_pan_file.write("Spectral Mode : " + str(SpectralMode) + "\n")
                        Log_pan_file.write("FileName : " + str(FileName) + "\n")
                        Log_pan_file.write("CPF file : " + str(cpf_name) + "\n")
                        Log_pan_file.write("Process Level : 2A\n")
                        Log_pan_file.write("Begin line : " + str(bandline) + "\n")
                        Log_pan_file.write("Scene rank : " + str(scene_rank) + "\n")
                        Log_pan_file.write("Date : " + str(Center_scene_viewing_date) + "\n")
                        Log_pan_file.write("Time : " + str(Center_scene_viewing_time) + "\n")
                        Log_pan_file.write("Grid ref : " + str(Grid_ref) + "\n")
                        Log_pan_file.write("Status : completed.\n")
                        Log_pan_file.write("Time to use : " + str(end_time) + "mn")
                        Log_pan_file.close()
                    
                    except:
                        Log_pan_name = Log_path + "/" + pan_out_name + ".log"
                        Log_pan_file = open(Log_pan_name,"w")
                        Log_pan_file.write("Revolution : " +str(Revolution_number) + "\n")
                        Log_pan_file.write("Gerald directory name : " + str(Gerald_name) + "\n")
                        Log_pan_file.write("Spectral Mode : " + str(SpectralMode) + "\n")
                        Log_pan_file.write("FileName : " + str(FileName) + "\n")
                        Log_pan_file.write("CPF file : " + str(cpf_name) + "\n")
                        Log_pan_file.write("Process Level : 2A\n")
                        Log_pan_file.write("Begin line : " + str(bandline) + "\n")
                        Log_pan_file.write("Scene rank : " + str(scene_rank) + "\n")
                        Log_pan_file.write("Date : " + str(Center_scene_viewing_date) + "\n")
                        Log_pan_file.write("Time : " + str(Center_scene_viewing_time) + "\n")
                        Log_pan_file.write("Grid ref : " + str(Grid_ref) + "\n")
                        Log_pan_file.write("Status : uncompleted.\n")
                        Log_pan_file.write("Error value is : " + str(traceback.format_exc()))
                        Log_pan_file.close()
                        
            elif EXAMPLE == "MS":
                ger_keep = GERALD_keep + "/" + Gerald_name
                ger_dir = GERALD_local + "/" + Gerald_name
                Gerald_filelist = []
                for root , directory , files in os.walk(ger_keep , topdown = False):
                    for filename in files:
                        Gerald_filename = os.path.join(root , filename)
                        if Gerald_filename.endswith(".GER"):
                            Gerald_filelist.append(Gerald_filename)
                            Gerald_filelist.sort()
                        elif not Gerald_filename.endswith(".GER"):
                            error_value_gerald = str(traceback.format_exc())
                            print error_value_gerald
                            QMessageBox.warning(None ,"Warning", error_value_gerald)

                Gerald_file_B1 = Gerald_filelist[0]
                Gerald_file_B2 = Gerald_filelist[1]
                Gerald_file_B3 = Gerald_filelist[2]
                Gerald_file_B4 = Gerald_filelist[3]

                print "%s\n%s\n%s\n%s"%(Gerald_file_B1,Gerald_file_B2,Gerald_file_B3,Gerald_file_B4) 

                if (os.path.exists(Gerald_file_B1)) and (os.path.exists(Gerald_file_B2)) and (os.path.exists(Gerald_file_B3)) and (os.path.exists(Gerald_file_B4)):
                    pass
                elif not (os.path.exists(Gerald_file_B1) and os.path.exists(Gerald_file_B2) and os.path.exists(Gerald_file_B3) and os.path.exists(Gerald_file_B4)):
                    sys.exit("Gerald file has not exist.")
                try :
                    if not os.path.exists(ger_dir):
                        os.mkdir(ger_dir)
                        print "create gerald local"
                        shutil.copy(Gerald_file_B1 , ger_dir)
                        print "copy gerald band 1 from center dirve."
                        shutil.copy(Gerald_file_B2 , ger_dir)
                        print "copy gerald band 2 from center dirve."
                        shutil.copy(Gerald_file_B3 , ger_dir)
                        print "copy gerald band 3 from center dirve."
                        shutil.copy(Gerald_file_B4 , ger_dir)
                        print "copy gerald band 4 from center dirve."

                    elif os.path.exists(ger_dir):
                        for local_root , local_directory , local_files in os.walk(ger_dir , topdown = False):
                            for local_filename in local_files:
                                Gerald_local_filename = os.path.join(local_root , local_filename)
                                if Gerald_local_filename.endswith(".GER"):
                                    pass
                                elif not Gerald_local_filename.endswith(".GER"):
                                    shutil.rmtree(ger_dir)
                                    print "Delete gerald local."
                                    os.mkdir(ger_dir)
                                    print "Recreate gerald local."
                                    shutil.copy(Gerald_file_B1 , ger_dir)
                                    print "copy gerald band 1 from center dirve."
                                    shutil.copy(Gerald_file_B2 , ger_dir)
                                    print "copy gerald band 2 from center dirve."
                                    shutil.copy(Gerald_file_B3 , ger_dir)
                                    print "copy gerald band 3 from center dirve."
                                    shutil.copy(Gerald_file_B4 , ger_dir)
                                    print "copy gerald band 4 from center dirve."
                except : 
                    QMessageBox.warning(None ,"Warning", str(traceback.format_exc()))
                    sys.exit(traceback.format_exc())  # directory of ger file
                
                cpf_file , cpf_name = CP.comparecufandcpf(Center_scene_viewing_date , CPF_directory , CPF_index)
                
                ger_info_dir = GERALD_info + "/" + Gerald_name
                if not os.path.exists(ger_info_dir):
                    os.mkdir(ger_info_dir)
                    print "Gerald info has create."
                elif os.path.exists(ger_info_dir):
                    print "Gerald info has already exist."
                    pass    
                # absolute directory containing all extracted information from ger files.
                
                out_path = Product_keep + "/" + Gerald_name
                if not os.path.exists(out_path):
                    os.mkdir(out_path)
                elif os.path.exists(out_path):
                    pass

                out_path = Product_keep + "/" + Gerald_name
                if not os.path.exists(out_path):
                    os.mkdir(out_path)
                elif os.path.exists(out_path):
                    pass

                job_ID = time.gmtime(job_time)
                job_ID_year = job_ID.tm_year-2000
                job_ID_month = job_ID.tm_mon
                job_ID_day = job_ID.tm_mday
                job_ID_hour = job_ID.tm_hour
                job_ID_min = job_ID.tm_min
                job_ID_sec = job_ID.tm_sec
                job_ID_millisec = int((job_time%1)*1000)

                ms_out_name = "TH_CAT_%02d%02d%02d"%(job_ID_year , job_ID_month , job_ID_day) + "%02d%02d%02d%03d"%(job_ID_hour , job_ID_min , job_ID_sec , job_ID_millisec) + "_1_" + Center_scene_viewing_date + "_" + Center_scene_viewing_time

                # absolute director containing final image
                out_dir = out_path + "/" + ms_out_name
                if not os.path.exists(out_dir):
                    os.mkdir(out_dir)
                    print "Product path has create."
                elif os.path.exists(out_dir):
                    shutil.rmtree(out_dir)
                    print "Delete old product path."
                    os.mkdir(out_dir)
                    print "Create new product path."
                
                if scene_rank != scene_count:
                    try:
                        bandlines = dsr_begin  # begining line of MS image
                        start_sample = 1
                        start_time = time.clock()
                        buildLevel2AImage(EXAMPLE, ger_dir, cpf_file, apf_file, begin_line=bandlines, dem_type=demservice.THEOS_DEM, info_directory=ger_info_dir, destination_directory=out_dir, rev_num=Revolution_number, grid_ref=Grid_ref, dem_interpolation=demservice.digitalElevationModel.CUBIC, line_shift=0, start_sample=1)
                        end_time = float((time.clock() - start_time)/60.0)
                        
                        print "Create archive."
                        zip_out_dir = zipfile.ZipFile(out_dir   + ".zip" , "w")
                        print "adding %s"%out_dir
                        for ziproot , zipdirectory , zipfiles in os.walk(out_dir , topdown = False):
                            for zipname in zipfiles:
                                zipdir = os.path.join(ziproot , zipname)
                                zipfilename = os.path.join(zipname)
                                zip_out_dir.write(zipname)
                        zip_out_dir.close()
                        print "product completed."
                        
                        Log_ms_name = Log_path + "/" + ms_out_name + ".log"
                        Log_ms_file = open(Log_ms_name,"w")
                        Log_ms_file.write("Revolution : " +str(Revolution_number) + "\n")
                        Log_ms_file.write("Gerald directory name : " + str(Gerald_name) + "\n")
                        Log_ms_file.write("Spectral Mode : " + str(SpectralMode) + "\n")
                        Log_ms_file.write("FileName : " + str(FileName) + "\n")
                        Log_ms_file.write("CPF file : " + str(cpf_name) + "\n")
                        Log_ms_file.write("Process Level : 2A\n")
                        Log_ms_file.write("Begin line : " + str(bandlines) + "\n")
                        Log_ms_file.write("Scene rank : " + str(scene_rank) + "\n")
                        Log_ms_file.write("Date : " + str(Center_scene_viewing_date) + "\n")
                        Log_ms_file.write("Time : " + str(Center_scene_viewing_time) + "\n")
                        Log_ms_file.write("Grid ref : " + str(Grid_ref) + "\n")
                        Log_ms_file.write("Status : completed.\n")
                        Log_ms_file.write("Time to use : " + str(end_time) + "mn")
                        Log_ms_file.close()
                        
                    except :
                        Log_ms_name = Log_path + "/" + ms_out_name + ".log"
                        Log_ms_file = open(Log_ms_name,"w")
                        Log_ms_file.write("Revolution : " +str(Revolution_number) + "\n")
                        Log_ms_file.write("Gerald directory name : " + str(Gerald_name) + "\n")
                        Log_ms_file.write("Spectral Mode : " + str(SpectralMode) + "\n")
                        Log_ms_file.write("FileName : " + str(FileName) + "\n")
                        Log_ms_file.write("CPF file : " + str(cpf_name) + "\n")
                        Log_ms_file.write("Process Level : 2A\n")
                        Log_ms_file.write("Begin line : " + str(bandlines) + "\n")
                        Log_ms_file.write("Scene rank : " + str(scene_rank) + "\n")
                        Log_ms_file.write("Date : " + str(Center_scene_viewing_date) + "\n")
                        Log_ms_file.write("Time : " + str(Center_scene_viewing_time) + "\n")
                        Log_ms_file.write("Grid ref : " + str(Grid_ref) + "\n")
                        Log_ms_file.write("Status : uncompleted.\n")
                        Log_ms_file.write("Error value is : " + str(traceback.format_exc()))
                        Log_ms_file.close()
                        
                elif scene_rank == scene_count:
                    try:
                        Use_GDB_last_line_list = []
                        GDB_directory = ger_info_dir
                        for root_gdb , directory_gdb , file_gdb in os.walk(GDB_directory , topdown = False):
                            for filepath in file_gdb:
                                GDB_path = os.path.abspath(os.path.join(root_gdb , filepath))
                                if GDB_path.endswith("B4.gdb"):
                                    GDB_data_file = open(GDB_path , "r")
                                    GDB_data_list = GDB_data_file.readlines()
                                    GDB_data_file.close()
                                    
                                    Pre_GDB_Endline = GDB_data_list[len(GDB_data_list)-1]
                                    Pre_GDB_End_line_data = Pre_GDB_Endline.split( )
                                    count_Pre_GDB_End_line_data = len( Pre_GDB_End_line_data)
                                    GDB_last_line = int(Pre_GDB_End_line_data[count_Pre_GDB_End_line_data - 1])
                                    Use_GDB_last_line_list.append(GDB_last_line)
                                    
                        New_dsr_beginB4 = Use_GDB_last_line_list[0] - 5999
                        New_dsr_beginB3 = New_dsr_beginB4 - band_offset_B4
                        New_dsr_beginB2 = New_dsr_beginB3 + band_offset_B2
                        New_dsr_beginB1 = New_dsr_beginB3 + band_offset_B1
                        
                        bandlines = [New_dsr_beginB1 , New_dsr_beginB2 , New_dsr_beginB3 , New_dsr_beginB4]  # begining line of MS image
                        start_sample = 1
                        start_time = time.clock()
                        buildLevel2AImage(EXAMPLE, ger_dir, cpf_file, apf_file, begin_line=bandlines, dem_type=demservice.THEOS_DEM, info_directory=ger_info_dir, destination_directory=out_dir, rev_num=Revolution_number, grid_ref=Grid_ref, dem_interpolation=demservice.digitalElevationModel.CUBIC, line_shift=0, start_sample=1)
                        end_time = float((time.clock() - start_time)/60.0)
                        
                        print "Create archive."
                        zip_out_dir = zipfile.ZipFile(out_dir   + ".zip" , "w")
                        print "adding %s"%out_dir
                        for ziproot , zipdirectory , zipfiles in os.walk(out_dir , topdown = False):
                            for zipname in zipfiles:
                                zipdir = os.path.join(ziproot , zipname)
                                zipfilename = os.path.join(zipname)
                                zip_out_dir.write(zipname)
                        zip_out_dir.close()
                        print "product completed."
                        
                        Log_ms_name = Log_path + "/" + ms_out_name + ".log"
                        Log_ms_file = open(Log_ms_name,"w")
                        Log_ms_file.write("Revolution : " +str(Revolution_number) + "\n")
                        Log_ms_file.write("Gerald directory name : " + str(Gerald_name) + "\n")
                        Log_ms_file.write("Spectral Mode : " + str(SpectralMode) + "\n")
                        Log_ms_file.write("FileName : " + str(FileName) + "\n")
                        Log_ms_file.write("CPF file : " + str(cpf_name) + "\n")
                        Log_ms_file.write("Process Level : 2A\n")
                        Log_ms_file.write("Begin line : " + str(bandlines) + "\n")
                        Log_ms_file.write("Scene rank : " + str(scene_rank) + "\n")
                        Log_ms_file.write("Date : " + str(Center_scene_viewing_date) + "\n")
                        Log_ms_file.write("Time : " + str(Center_scene_viewing_time) + "\n")
                        Log_ms_file.write("Grid ref : " + str(Grid_ref) + "\n")
                        Log_ms_file.write("Status : completed.\n")
                        Log_ms_file.write("Time to use : " + str(end_time) + "mn")
                        Log_ms_file.close()
                    
                    except:
                        Log_ms_name = Log_path + "/" + ms_out_name + ".log"
                        Log_ms_file = open(Log_ms_name,"w")
                        Log_ms_file.write("Revolution : " +str(Revolution_number) + "\n")
                        Log_ms_file.write("Gerald directory name : " + str(Gerald_name) + "\n")
                        Log_ms_file.write("Spectral Mode : " + str(SpectralMode) + "\n")
                        Log_ms_file.write("FileName : " + str(FileName) + "\n")
                        Log_ms_file.write("CPF file : " + str(cpf_name) + "\n")
                        Log_ms_file.write("Process Level : 2A\n")
                        Log_ms_file.write("Begin line : " + str(bandlines) + "\n")
                        Log_ms_file.write("Scene rank : " + str(scene_rank) + "\n")
                        Log_ms_file.write("Date : " + str(Center_scene_viewing_date) + "\n")
                        Log_ms_file.write("Time : " + str(Center_scene_viewing_time) + "\n")
                        Log_ms_file.write("Grid ref : " + str(Grid_ref) + "\n")
                        Log_ms_file.write("Status : uncompleted.\n")
                        Log_ms_file.write("Error value is : " + str(traceback.format_exc()))
                        Log_ms_file.close()
    
    except IOError :
        QMessageBox.warning(None , "Warnig" , "Command abort by User.")
        
    except:
        error_value_process = str(traceback.format_exc())
        QMessageBox.warning(None ,"Warning", error_value_process)
        
    sys.exit("End Process.")
    
    # pansharp_info_dir = r"D:\Data2APanSharpen\THEOS_37541\GERAL_PAN\pansharpen_info"
    # pansharp_out_dir = r"D:\Data2APanSharpen\THEOS_37541\GERAL_PAN\pansharpen_out"
    #
    #
    # buildPanSharpen2A(ger_pan_dir,ger_ms_dir,cpf_file,apf_file,21946,dem_directory=dem_dir,pan_info_directory=pan_info_dir,
    #                   ms_info_directory=ms_info_dir,pansharpen_info_directory=pansharp_info_dir,destination_directory=pansharp_out_dir,
    #                   pan_out_directory=pansharp_info_dir,rev_num="37541",grid_ref="0139-0411",dem_interpolation="kriging",
    #                   line_shift=0,start_sample=1)

