""" MODULE images2gif

Provides a function (writeGif) to write animated gif from a series
of PIL images or numpy arrays.

This code is provided as is, and is free to use for all.

Almar Klein (June 2009)

- based on gifmaker (in the scripts folder of the source distribution of PIL)
- based on gif file structure as provided by wikipedia

"""

try:
    import PIL
    from PIL import Image, ImageChops
    from PIL.GifImagePlugin import getheader, getdata
except ImportError:
    PIL = None

try:
    import numpy as np
except ImportError:
    np = None    
import cv2

from osgeo import gdal

import matplotlib.animation as animation
import matplotlib.pyplot as plt


# getheader gives a 87a header and a color palette (two elements in a list).
# getdata()[0] gives the Image Descriptor up to (including) "LZW min code size".
# getdatas()[1:] is the image data itself in chuncks of 256 bytes (well
# technically the first byte says how many bytes follow, after which that
# amount (max 255) follows).
def intToBin(i):
    """ Integer to two bytes """
    # devide in two parts (bytes)
    i1 = i % 256
    i2 = int(i / 256)
    # make string (little endian)
    return chr(i1) + chr(i2)


def getheaderAnim(im):
    """ Animation header. To replace the getheader()[0] """
    bb = "GIF89a"
    bb += intToBin(im.size[0])
    bb += intToBin(im.size[1])
    bb += "\x87\x00\x00"
    return bb


def getAppExt(loops=0):
    """ Application extention. Part that secifies amount of loops. 
    if loops is 0, if goes on infinitely.
    """
    bb = "\x21\xFF\x0B"  # application extension
    bb += "NETSCAPE2.0"
    bb += "\x03\x01"
    if loops == 0:
        loops = 2 ** 16 - 1
    bb += intToBin(loops)
    bb += '\x00'  # end
    return bb


def getGraphicsControlExt(duration=0.1):
    """ Graphics Control Extension. A sort of header at the start of
    each image. Specifies transparancy and duration. """
    bb = '\x21\xF9\x04'
    bb += '\x08'  # no transparancy
    bb += intToBin(int(duration * 100))  # in 100th of seconds
    bb += '\x00'  # no transparant color
    bb += '\x00'  # end
    return bb


def _writeGifToFile(fp, images, durations, loops):
    """ Given a set of images writes the bytes to the specified stream.
    """
    
    # init
    frames = 0
    previous = None
    
    for im in images:
        
        if not previous:
            # first image
            
            # gather data
            # palette = getheader(im)[1]
            palette = im.palette.getdata()[1]
    # palettes.append(im.palette.getdata()[1])
            data = getdata(im)
            imdes, data = data[0], data[1:]            
            header = getheaderAnim(im)
            appext = getAppExt(loops)
            graphext = getGraphicsControlExt(durations[0])
            
            # write global header
            fp.write(header)
            fp.write(palette)
            fp.write(appext)
            
            # write image
            fp.write(graphext)
            fp.write(imdes)
            for d in data:
                fp.write(d)
            
        else:
            # gather info (compress difference)              
            data = getdata(im) 
            imdes, data = data[0], data[1:]       
            graphext = getGraphicsControlExt(durations[frames])
            
            # write image
            fp.write(graphext)
            fp.write(imdes)
            for d in data:
                fp.write(d)

#             # delta frame - does not seem to work
#             delta = ImageChops.subtract_modulo(im, previous)            
#             bbox = delta.getbbox()
#             
#             if bbox:
#                 
#                 # gather info (compress difference)              
#                 data = getdata(im.crop(bbox), offset = bbox[:2]) 
#                 imdes, data = data[0], data[1:]       
#                 graphext = getGraphicsControlExt(durations[frames])
#                 
#                 # write image
#                 fp.write(graphext)
#                 fp.write(imdes)
#                 for d in data:
#                     fp.write(d)
#                 
#             else:
#                 # FIXME: what should we do in this case?
#                 pass
        
        # prepare for next round
        previous = im.copy()        
        frames = frames + 1

    fp.write(";")  # end gif
    return frames


def writeGif(filename, images, duration=0.1, loops=0, dither=1):
    """ writeGif(filename, images, duration=0.1, loops=0, dither=1)
    Write an animated gif from the specified images. 
    images should be a list of numpy arrays of PIL images.
    Numpy images of type float should have pixels between 0 and 1.
    Numpy images of other types are expected to have values between 0 and 255.
    """
    
    if PIL is None:
        raise RuntimeError("Need PIL to write animated gif files.")
    
    images2 = []
    
    # convert to PIL
    for im in images:
        
        if isinstance(im, Image.Image):
            images2.append(im.convert('P', dither=dither))
            
        elif np and isinstance(im, np.ndarray):
            if im.dtype == np.uint8:
                pass
            elif im.dtype in [np.float32, np.float64]:
                im = (im * 255).astype(np.uint8)
            else:
                im = im.astype(np.uint8)
            # convert
            if len(im.shape) == 3 and im.shape[2] == 3:
                im = Image.fromarray(im, 'RGB').convert('P', dither=dither)
            elif len(im.shape) == 2:
                im = Image.fromarray(im, 'L').convert('P', dither=dither)
            else:
                raise ValueError("Array has invalid shape to be an image.")
            images2.append(im)
            
        else:
            raise ValueError("Unknown image type.")
    
    # check duration
    if hasattr(duration, '__len__'):
        if len(duration) == len(images2):
            durations = [d for d in duration]
        else:
            raise ValueError("len(duration) doesn't match amount of images.")
    else:
        durations = [duration for im in images2]
        
    
    # open file
    fp = open(filename, 'wb')
    
    # write
    try:
        n = _writeGifToFile(fp, images2, durations, loops)
        print n, 'frames written'
    finally:
        fp.close()
def build_gif(imgs, show_gif=True, save_gif=True, gif_file='animation.gif', title=''):

    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.set_axis_off()

    ims = map(lambda x: (ax.imshow(x), ax.set_title(title)), imgs)

    im_ani = animation.ArtistAnimation(fig, ims, interval=800, repeat_delay=0, blit=False)

    if save_gif:
        im_ani.save(gif_file, writer='imagemagick')

    if show_gif:
        plt.show()

    return
    
if __name__ == '__main__':
    org = r"D:\Data2APanSharpen\2016-05-27\Tested Images\revolution_39848_new\old_product\TH_CAT_160511081330552_1\IMAGERY.TIF"
    my = r"D:\Data2APanSharpen\2016-05-27\bridge error\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\GERALD\output\IMAGERY.tif"
    out = r"D:\Data2APanSharpen\2016-05-27\bridge error\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\GERALD\output\IMAGERYGIF"
    org_im = gdal.Open(org)
    my_im = gdal.Open(my)
    org_geo = org_im.GetGeoTransform()
    my_geo = my_im.GetGeoTransform()
    x_left = my_geo[0]
    y_left = my_geo[3]
    dx = (org_geo[0] - x_left) / my_geo[1]
    dy = (org_geo[3] - y_left) / my_geo[5]
    width = my_im.RasterXSize
    heigth = my_im.RasterYSize
    # im0 = np.zeros((heigth,width,3),'uint8')
    # im1 = np.zeros((heigth,width,3),'uint8')
    bandmy = [1, 2, 3]
    bandorg = [3, 2, 1]
    blocksize = 500
    for line in range(0, heigth, blocksize):
            for sample in range(0, width, blocksize):

                sub_h = min(blocksize, heigth - line)
                sub_w = min(blocksize, width - sample)
                im0 = np.zeros((sub_h, sub_w, 3), 'uint8')
                im1 = np.zeros((sub_h, sub_w, 3), 'uint8')
                for k in range(3):
                    myband = my_im.GetRasterBand(bandmy[k])
                    orgband = org_im.GetRasterBand(bandorg[k])
                    data_my = myband.ReadAsArray()
                    data_org = orgband.ReadAsArray()

                    x, y = np.meshgrid(np.arange(sub_w) - dx, np.arange(sub_h) - dy)
                    x = (x + sample).astype('float32')
                    y = (y + line).astype('float32')
                    im0[:, :, k] = data_my[line:line + sub_h, sample:sample + sub_w]
                    im1[:, :, k] = cv2.remap(data_org, x, y, cv2.INTER_CUBIC)
                im0 = cv2.resize(im0, (sub_w * 3, sub_h * 3))
                im1 = cv2.resize(im1, (sub_w * 3, sub_h * 3))
                im0 = cv2.cvtColor(im0, cv2.COLOR_BGR2RGB)
                im1 = cv2.cvtColor(im1, cv2.COLOR_BGR2RGB)

                if im0.max() > 0 :
                    imgs = [im0, im1]
                    build_gif(imgs, show_gif=True, save_gif=False, gif_file=out + "%d_%d.gif" % (sample, line))
    # for k in range(3):
    #     myband  = my_im.GetRasterBand(bandmy[k])
    #     orgband = org_im.GetRasterBand(bandorg[k])
    #     data_my = myband.ReadAsArray()
    #     data_org = orgband.ReadAsArray()
    #     for line in range(0,heigth,1000):
    #         for sample in range(0,width,1000):
    #             sub_h = min(1000,heigth-line)
    #             sub_w = min(1000,width-sample)
    #             x,y = np.meshgrid(np.arange(sub_w)-dx,np.arange(sub_h)-dy)
    #             x = (x+sample).astype('float32')
    #             y=  (y +line).astype('float32')
    #             im0[line:line+sub_h,sample:sample+sub_w,k]= data_my[line:line+sub_h,sample:sample+sub_w]
    #             im1[line:line+sub_h,sample:sample+sub_w,k]=  cv2.remap(data_org,x,y,cv2.INTER_CUBIC)
    # #im0 = cv2.cvtColor(im0,cv2.COLOR_BGR2
    # #im1 = cv2.cvtColor(im1,cv2.COLOR_BGR2RGB)
    # #imgs = [im0,im1]
    # #build_gif(imgs,show_gif=False,save_gif=True,gif_file=out)
    # temp1 = r"D:\2016-05-27\Tested Images\revvolution_39919_new\Newer\temp1.png"
    # temp2 = r"D:\2016-05-27\Tested Images\revvolution_39919_new\Newer\temp2.png"
    # cv2.imwrite(temp1,im0)
    # cv2.imwrite(temp2,im1)
    # im0 = PIL.Image.open(temp1)
    # im0.thumbnail((width,heigth), PIL.Image.ANTIALIAS)
    # im1 = PIL.Image.open(temp2)
    # im1.thumbnail((width,heigth), PIL.Image.ANTIALIAS)
    # images = [im0,im1]
    # writeGif(out,images, duration=0.5)
