__author__ = 'professor'
import cv2
import platform

import dutil
import locationutil as util
import numpy as np
import xml.etree.ElementTree as ET


if platform.system() == "Windows":
    from osgeo import gdal
else:
    import gdal


def readGainsAndDarkCurrent(cpf_file, band, gain_number):
    tree = ET.parse(cpf_file)
    root = tree.getroot()
    if band == "PAN":
        gains_txt = root.findall("./RadiometricParameters/PAN/G%d/DetectorRelativeGains" % (gain_number))[0].text
        darkCurrent_txt = root.findall("./RadiometricParameters/PAN/G%d/DarkCurrents" % (gain_number))[0].text
    else:
        gains_txt = root.findall("./RadiometricParameters/B%d/G%d/DetectorRelativeGains" % (band, gain_number))[0].text
        darkCurrent_txt = root.findall("./RadiometricParameters/B%d/G%d/DarkCurrents" % (band, gain_number))[0].text
    # print gains_txt
    gains_txt = gains_txt.split(",")

    darkCurrent_txt = darkCurrent_txt.split(",")
    gains = []
    darkCurrents = []
    for it in range(len(gains_txt)):
        gains.append(float(gains_txt[it]))
        darkCurrents.append(float(darkCurrent_txt[it]))
    gains = np.array(gains)
    darkCurrents = np.array(darkCurrents)
    return gains, darkCurrents


def buildRMImage(file_name, line1B1, line1B2, line1B3, line1B4, g1, g2, g3, g4, d1, d2, d3, d4):
    file_band1 = file_name + "B1.tif"
    band1 = gdal.Open(file_band1)
    file_band2 = file_name + "B2.tif"
    band2 = gdal.Open(file_band2)
    file_band3 = file_name + "B3.tif"
    band3 = gdal.Open(file_band3)
    file_band4 = file_name + "B4.tif"
    band4 = gdal.Open(file_band4)
    out_file_name = file_name + "_ms.tif"
    gtiffDriver = gdal.GetDriverByName('GTiff')
    dst_ds = gtiffDriver.Create(out_file_name, 6000, 6000, 4, gdal.GDT_Byte)
    ms_b1 = dst_ds.GetRasterBand(1)
    ms_b2 = dst_ds.GetRasterBand(2)
    ms_b3 = dst_ds.GetRasterBand(3)
    ms_b4 = dst_ds.GetRasterBand(4)
    print "Saving Image"
    for line in range(6000):
        print "save line %d" % line
        lb1 = band1.ReadAsArray(0, line1B1 + line, 6000, 1).astype('float32')
        lb2 = band2.ReadAsArray(0, line1B2 + line, 6000, 1).astype('float32')
        lb3 = band3.ReadAsArray(0, line1B3 + line, 6000, 1).astype('float32')
        lb4 = band4.ReadAsArray(0, line1B4 + line, 6000, 1).astype('float32')
        lb1 = np.round((lb1 - d1) / g1)
        if lb1.min() < 0:
            print "find b1 less than zero"
        if lb1.max() > 255:
            print "find b1 greater than 255= %f" % lb1.max()
        lb1 = lb1 * (lb1 < 255.0) + 255.0 * (lb1 >= 255)
        lb1 = lb1.astype('uint8').reshape((1, 6000))
        lb1[0, 6:] = lb1[0, :-6]
        lb2 = np.round((lb2 - d2) / g2)
        if lb2.min() < 0:
            print "find b2 less than zero"
        if lb2.max() > 255:
            print "find b2 greater than 255= %f" % lb2.max()
        lb2 = lb2 * (lb2 < 255.0) + 255.0 * (lb2 >= 255)
        lb2 = lb2.astype('uint8').reshape((1, 6000))
        lb2[0, 4:] = lb2[0, :-4]
        lb3 = np.round((lb3 - d3) / g3)
        if lb3.min() < 0:
            print "find b3 less than zero"
        if lb3.max() > 255:
            print "find b3 greater than 255= %f" % lb3.max()
        lb3 = lb3 * (lb3 < 255.0) + 255.0 * (lb3 >= 255)
        lb3 = lb3.astype('uint8').reshape((1, 6000))
        lb4 = np.round((lb4 - d4) / g4)
        if lb4.min() < 0:
            print "find b4 less than zero"
        if lb4.max() > 255:
            print "find b4 greater than 255= %f" % lb4.max()
        lb4 = lb4 * (lb4 < 255.0) + 255.0 * (lb4 >= 255)
        lb4 = lb4.astype('uint8').reshape((1, 6000))
        lb4[0, :-5] = lb1[0, 5:]
        ms_b1.WriteArray(lb1, 0, line)
        ms_b2.WriteArray(lb2, 0, line)
        ms_b3.WriteArray(lb3, 0, line)
        ms_b4.WriteArray(lb4, 0, line)
    dst_ds = None


def computeJDtime(date, time, utc_gps):
    t1 = time
    hour1 = int(np.floor(t1 / 3600.0))
    t1 -= hour1 * 3600.0
    minute1 = int(np.floor(t1) / 60.0)
    second1 = t1 - minute1 * 60.0
    micsec1 = second1 - int(np.floor(second1))
    micsec1 = int(micsec1 * 1e6)
    second1 = int(second1)
    tt1 = dutil.datetime(date[0], date[1], date[2], hour1, minute1, second1, micsec1)
    JD1 = tt1.to_jd() + utc_gps / (24 * 60. * 60.)
    return JD1


def determine_shift(lat1, lon1, lat3, lon3, im_width):
    distances13 = (lat1.reshape((im_width, 1)) - lat3.reshape((1, im_width))) ** 2
    distances13 += (lon1.reshape((im_width, 1)) - lon3.reshape((1, im_width))) ** 2
    distances13 = np.sqrt(distances13)
    distances13_min = distances13.min(1).reshape((im_width, 1))
    distances13_min = np.repeat(distances13_min, im_width, 1)
    [a, b] = np.nonzero(distances13 == distances13_min)
    return b


def determine_shift_subpixel(lat1, lon1, lat3, lon3, im_width):
    distances13 = (lat1.reshape((im_width, 1)) - lat3.reshape((1, im_width))) ** 2
    distances13 += (lon1.reshape((im_width, 1)) - lon3.reshape((1, im_width))) ** 2
    distances13 = np.sqrt(distances13)
    distances13_min = distances13.min(1).reshape((im_width, 1))
    distances13_min = np.repeat(distances13_min, im_width, 1)
    [a, b] = np.nonzero(distances13 == distances13_min)
    idx = 0
    bout = []
    for b0 in b:
        if (b0 > 0) and (b0 < im_width - 1):
            bn2 = max(0, b0 - 2)
            bn1 = max(0, b0 - 1)
            bp1 = min(im_width - 1, b0 + 1)
            bp2 = min(im_width - 1, b0 + 2)
            distances13x = distances13[idx, :]
            A = np.array([[bn2 ** 2, bn2, 1], [bn1 ** 2, bn1, 1], [b0 ** 2, b0, 1], [bp1 ** 2, bp1, 1],
                          [bp2 ** 2, bp2, 1]]).astype('float64')
            bv = np.array(
                [distances13x[bn2], distances13x[bn1], distances13x[b0], distances13x[bp1], distances13x[bp2]])
            par = np.linalg.lstsq(A, bv)[0]
            b_best = -par[1] / (2.0 * par[0])
        else:
            b_best = None
        bout.append(b_best)
        idx += 1
    bout = np.array(bout)
    return bout


def buildMSImageFromGerFile(out_file_name, in_file_name, lines, gains, dark_currents, current_date, utc_gps):
    im_height = 6000
    im_width = 6000
    samples = np.arange(im_width)
    posB1 = np.loadtxt(in_file_name + "B1.pos")
    posB2 = np.loadtxt(in_file_name + "B2.pos")
    posB3 = np.loadtxt(in_file_name + "B3.pos")
    posB4 = np.loadtxt(in_file_name + "B4.pos")

    timeB1 = np.loadtxt(in_file_name + "B1.tim")
    timeB2 = np.loadtxt(in_file_name + "B2.tim")
    timeB3 = np.loadtxt(in_file_name + "B3.tim")
    timeB4 = np.loadtxt(in_file_name + "B4.tim")

    attB1 = np.loadtxt(in_file_name + "B1.att")
    attB2 = np.loadtxt(in_file_name + "B2.att")
    attB3 = np.loadtxt(in_file_name + "B3.att")
    attB4 = np.loadtxt(in_file_name + "B4.att")

    band1 = gdal.Open(in_file_name + "B1.tif")
    band2 = gdal.Open(in_file_name + "B2.tif")
    band3 = gdal.Open(in_file_name + "B3.tif")
    band4 = gdal.Open(in_file_name + "B4.tif")


    # out_im = np.zeros((im_height,im_height,4),'uint8')
    out_line0 = np.zeros((1, im_width), 'uint8')
    posB1 = posB1[lines[0]:lines[0] + im_height]
    posB2 = posB2[lines[1]:lines[1] + im_height]
    posB3 = posB3[lines[2]:lines[2] + im_height]
    posB4 = posB4[lines[3]:lines[3] + im_height]

    timeB1 = timeB1[lines[0]:lines[0] + im_height]
    timeB2 = timeB2[lines[1]:lines[1] + im_height]
    timeB3 = timeB3[lines[2]:lines[2] + im_height]
    timeB4 = timeB4[lines[3]:lines[3] + im_height]

    attB1 = attB1[lines[0]:lines[0] + im_height]
    attB2 = attB2[lines[1]:lines[1] + im_height]
    attB3 = attB3[lines[2]:lines[2] + im_height]
    attB4 = attB4[lines[3]:lines[3] + im_height]
    gtiffDriver = gdal.GetDriverByName('GTiff')
    dst_ds = gtiffDriver.Create(out_file_name, 6000, 6000, 4, gdal.GDT_Byte)
    ms_b1 = dst_ds.GetRasterBand(1)
    ms_b2 = dst_ds.GetRasterBand(2)
    ms_b3 = dst_ds.GetRasterBand(3)
    ms_b4 = dst_ds.GetRasterBand(4)

    for k in range(im_height):
        out_line0 = np.zeros((1, im_width), 'uint8')
        out_line1 = np.zeros((1, im_width), 'uint8')
        out_line2 = np.zeros((1, im_width), 'uint8')
        out_line3 = np.zeros((1, im_width), 'uint8')
        jd1 = computeJDtime(current_date, timeB1[k], utc_gps)
        jd2 = computeJDtime(current_date, timeB2[k], utc_gps)
        jd3 = computeJDtime(current_date, timeB3[k], utc_gps)
        jd4 = computeJDtime(current_date, timeB4[k], utc_gps)
        uecef1 = util.computeUECEF(jd1, samples, attB1[k], 1)
        uecef2 = util.computeUECEF(jd2, samples, attB2[k], 2)
        uecef3 = util.computeUECEF(jd3, samples, attB3[k], 3)
        uecef4 = util.computeUECEF(jd4, samples, attB4[k], 4)
        earth_post1 = util.findEarthSurfacePosition(uecef1, posB1[k])
        earth_post2 = util.findEarthSurfacePosition(uecef2, posB2[k])
        earth_post3 = util.findEarthSurfacePosition(uecef3, posB3[k])
        earth_post4 = util.findEarthSurfacePosition(uecef4, posB4[k])
        lat1, lon1, height1 = util.itrf2latlon(earth_post1)
        lat2, lon2, height2 = util.itrf2latlon(earth_post2)
        lat3, lon3, height3 = util.itrf2latlon(earth_post3)
        lat4, lon4, height4 = util.itrf2latlon(earth_post4)
        one_lineB3 = band3.ReadAsArray(0, lines[2] + k - 1, im_width, 1)
        one_lineB3 = np.round((one_lineB3 - dark_currents[2]) / gains[2])
        one_lineB3 = one_lineB3 * (one_lineB3 < 255.0) + 255.0 * (one_lineB3 >= 255)

        out_line2[0, :] = one_lineB3[0]
        print "===========================\n creating Line %d:" % k

        b = determine_shift(lat1, lon1, lat3, lon3, im_width)
        one_lineB1 = band1.ReadAsArray(0, lines[0] + k - 1, im_width, 1)
        one_lineB1 = np.round((one_lineB1 - dark_currents[0]) / gains[0])
        one_lineB1 = one_lineB1 * (one_lineB1 < 255.0) + 255.0 * (one_lineB1 >= 255)


        # out_im[k,b,0] = one_lineB1
        out_line0[0, b] = one_lineB1
        print "   shift band1 pixel 1:%d" % b[0]
        print "   shift band1 pixel 3000:%d" % (b[3000] - 3000)

        b = determine_shift(lat2, lon2, lat3, lon3, im_width)
        one_lineB2 = band2.ReadAsArray(0, lines[1] + k - 1, im_width, 1)
        one_lineB2 = np.round((one_lineB2 - dark_currents[1]) / gains[1])
        one_lineB2 = one_lineB2 * (one_lineB2 < 255.0) + 255.0 * (one_lineB2 >= 255)
        # out_im[k,b,1] = one_lineB2
        out_line1[0, b] = one_lineB2
        print "   shift band2 :%d" % b[0]
        print "   shift band2 pixel 3000:%d" % (b[3000] - 3000)

        b = determine_shift(lat4, lon4, lat3, lon3, im_width)
        one_lineB4 = band4.ReadAsArray(0, lines[3] + k - 1, im_width, 1)
        one_lineB4 = np.round((one_lineB4 - dark_currents[3]) / gains[3])
        one_lineB4 = one_lineB4 * (one_lineB4 < 255.0) + 255.0 * (one_lineB4 >= 255)
        # out_im[k,b,3] = one_lineB4
        out_line3[0, b] = one_lineB4
        print "   shift band4 :%d" % (-im_width + b[-1])
        print "   shift band1 pixel 3000:%d" % (b[3000] - 3000)
        ms_b1.WriteArray(out_line0, 0, k)
        ms_b2.WriteArray(out_line1, 0, k)
        ms_b3.WriteArray(out_line2, 0, k)
        ms_b4.WriteArray(out_line3, 0, k)
    dst_ds = None




    # distances1 = np.zeros((im_width,im_width))
    # distances2 = np.zeros((im_width,im_width))
    # distances3 = np.zeros((im_width,im_width))
    # distances4 = np.zeros((im_width,im_width))
    # x31 = earth_post3[0].reshape(im_width,1)
    # x32 = earth_post3[1].reshape(im_width,1)
    # x33 = earth_post3[2].reshape(im_width,1)
    #
    # x11 = earth_post1[0].reshape(1,im_width)
    # x12 = earth_post1[1].reshape(1,im_width)
    # x13 = earth_post1[2].reshape(1,im_width)
    # distances1 = np.sqrt((x11-x31)**2+(x12-x32)**2 +(x13-x33)**2)
    # min_d1 = distances1.min(1)
    #
    # x21 = earth_post2[0].reshape(1,im_width)
    # x22 = earth_post2[1].reshape(1,im_width)
    # x23 = earth_post2[2].reshape(1,im_width)
    # distances2 = np.sqrt((x21-x31)**2+(x22-x32)**2 +(x23-x33)**2)
    #
    # x41 = earth_post4[0].reshape(1,im_width)
    # x42 = earth_post4[1].reshape(1,im_width)
    # x43 = earth_post4[2].reshape(1,im_width)
    # distances4 = np.sqrt((x41-x31)**2+(x42-x32)**2 +(x43-x33)**2)



    # use band3 for positioning'


def findPixelShifting(lat, lon, lat_ref, lon_ref, im_width):
    distances = (lat.reshape((im_width, 1)) - lat_ref.reshape((1, im_width))) ** 2
    distances += (lon.reshape((im_width, 1)) - lon_ref.reshape((1, im_width))) ** 2
    distances = np.sqrt(distances)
    distances_min = distances.min(0).reshape((1, im_width))
    distances_min = np.repeat(distances_min, im_width, 0)
    [a, b] = np.nonzero(distances == distances_min)
    idx = 0
    asub = []

    for a0 in a:
        an2 = max(0, a0 - 2)
        an1 = max(0, a0 - 1)
        ap1 = min(im_width - 1, a0 + 1)
        ap2 = min(im_width - 1, a0 + 2)
        distancesx = distances[:, idx].flatten()
        A = np.array(
            [[an2 ** 2, an2, 1], [an1 ** 2, an1, 1], [a0 ** 2, a0, 1], [ap1 ** 2, ap1, 1], [ap2 ** 2, ap2, 1]]).astype(
            'float64')
        bv = np.array([distancesx[an2], distancesx[an1], distancesx[a0], distancesx[ap1], distancesx[ap2]])
        par = np.linalg.lstsq(A, bv)[0]
        b_best = -par[1] / (2.0 * par[0])
        asub.append(b_best)
        idx += 1
    a_sub = np.array(asub)
    a_sub = a_sub * (a_sub <= im_width - 1) * (a_sub >= 0) + (im_width - 1) * (a_sub > im_width)
    return a_sub


def w(x):
    a = -0.5
    a3 = a + 2.0
    a2 = -a - 3.0
    b3 = a
    b2 = -5.0 * a
    b1 = 8 * a
    b0 = -4 * a
    absx = np.abs(x)
    absx3 = absx ** 3
    absx2 = absx ** 2
    y1 = a3 * absx3 ** 3 + a2 * absx2 + 1.0
    y2 = b3 * absx3 + b2 * absx2 + b1 * absx + b0
    y = y1 * (absx <= 1.0) + y2 * (absx > 1) * (absx < 2.0)
    return y


def cubicInterpolationV1(data, pixel_map, im_width):
    data = data.astype('float32')
    a = np.floor(pixel_map).astype('int32')
    ap1 = a + 1
    ap1 = ap1 * (ap1 < im_width) + (a - (ap1 - im_width) - 1) * (ap1 >= im_width)
    ap1 = ap1 * (ap1 >= 0) + (-ap1) * (ap1 < 0)
    ap2 = a + 2
    ap2 = ap2 * (ap2 < im_width) + (a - (ap2 - im_width) - 1) * (ap2 >= im_width)
    ap2 = ap2 * (ap2 >= 0) + (-ap2) * (ap2 < 0)
    an1 = a - 1
    an1 = an1 * (an1 >= 0) + (-an1) * (an1 < 0)
    an1 = an1 * (an1 < im_width) + (a - (an1 - im_width) - 1) * (an1 >= im_width)
    w0 = w(pixel_map - a)
    wp1 = w(a + 1 - pixel_map)
    wp2 = w(a + 2 - pixel_map)
    wn1 = w(pixel_map - a + 1)
    imout = w0 * data[0, a] + wp1 * data[0, ap1] + wp2 * data[0, ap2] + wn1 * data[0, an1]
    imout = imout * (imout > 0) * (imout <= 255) + 255 * (imout > 255)
    imout = imout.astype('uint8')
    imout = imout.reshape((1, im_width))
    return imout


def cubicInterpolation(data, pixel_map, im_width):
    data = data.astype('float32')
    pixel_map2 = pixel_map.copy()
    pixel_map = pixel_map * (pixel_map > 0) * (pixel_map <= im_width - 1) + (im_width - 1) * (pixel_map > im_width)
    a = np.floor(pixel_map).astype('int32')
    ap1 = a + 1
    ap1 = ap1 * (ap1 < im_width) + (a - (ap1 - im_width) - 1) * (ap1 >= im_width)
    ap1 = ap1 * (ap1 >= 0) + (-ap1) * (ap1 < 0)
    ap2 = a + 2
    ap2 = ap2 * (ap2 < im_width) + (a - (ap2 - im_width) - 1) * (ap2 >= im_width)
    ap2 = ap2 * (ap2 >= 0) + (-ap2) * (ap2 < 0)
    an1 = a - 1
    an1 = an1 * (an1 >= 0) + (-an1) * (an1 < 0)
    an1 = an1 * (an1 < im_width) + (a - (an1 - im_width) - 1) * (an1 >= im_width)
    # print a.shape
    # print a.max()
    # print a.min()
    term1 = 2.0 * data[a]
    term2 = -1 * data[an1] + data[ap1]
    term3 = 2.0 * data[an1] - 5.0 * data[a] + 4.0 * data[ap1] - 1.0 * data[ap2]
    term4 = -1.0 * data[an1] + 3.0 * data[a] - 3.0 * data[ap1] + 1.0 * data[ap2]
    t = pixel_map - a
    imout = term1 + t * term2 + t * t * term3 + t * t * t * term4
    imout = imout / 2.0
    imout = imout * (imout > 0) * (imout <= 255) + 255 * (imout > 255)
    imout = imout.astype('uint8') * (pixel_map2 > 0) * (pixel_map2 <= im_width - 1)
    # imout = imout.reshape((1,im_width))
    return imout


def buildMSImageUsingCubicInterpolation(out_file_name, in_file_name, lines, current_date, utc_gps, dut1, dem_directory, start_sample=1, im_width=6000, im_height=6000):

    # im_width = 6000
    lines[0] = lines[0] - 1
    lines[1] = lines[1] - 1
    lines[2] = lines[2] - 1
    lines[3] = lines[3] - 1
    end_sample = start_sample + im_width - 1
    if (end_sample > 6000) or (start_sample < 1) :
        print "The intended sample is beyond the scope of the recorded GER file."
    samples = np.arange(start_sample, start_sample + im_width)

    posB1 = np.loadtxt(in_file_name + "B1.pos")
    posB2 = np.loadtxt(in_file_name + "B2.pos")
    posB3 = np.loadtxt(in_file_name + "B3.pos")
    posB4 = np.loadtxt(in_file_name + "B4.pos")

    timeB1 = np.loadtxt(in_file_name + "B1.tim")
    timeB2 = np.loadtxt(in_file_name + "B2.tim")
    timeB3 = np.loadtxt(in_file_name + "B3.tim")
    timeB4 = np.loadtxt(in_file_name + "B4.tim")

    attB1 = np.loadtxt(in_file_name + "B1.att")
    attB2 = np.loadtxt(in_file_name + "B2.att")
    attB3 = np.loadtxt(in_file_name + "B3.att")
    attB4 = np.loadtxt(in_file_name + "B4.att")

    band1 = gdal.Open(in_file_name + "B1.tif")
    band2 = gdal.Open(in_file_name + "B2.tif")
    band3 = gdal.Open(in_file_name + "B3.tif")
    band4 = gdal.Open(in_file_name + "B4.tif")


    # out_im = np.zeros((im_height,im_height,4),'uint8')

    posB3 = posB3[lines[2]:lines[2] + im_height]
    timeB3 = timeB3[lines[2]:lines[2] + im_height]
    attB3 = attB3[lines[2]:lines[2] + im_height]
    jd3 = computeJDtime(current_date, timeB3[0], utc_gps)
    uecef3_1 = util.computeUECEF(jd3, dut1, 3000, attB3[0], 3)
    earth_post3_1 = util.findEarthSurfacePosition(uecef3_1, posB3[0])
    lat3, lon3, height3 = util.itrf2latlon(earth_post3_1)
    errmin1_1 = 1e100
    errmin1_2 = 1e100
    errmin1_4 = 1e100
    print "Finding the actual line offset........."
    for off_set in range(-500, 500):
        jd1 = computeJDtime(current_date, timeB1[off_set + lines[0]], utc_gps)
        jd2 = computeJDtime(current_date, timeB2[off_set + lines[1]], utc_gps)
        jd4 = computeJDtime(current_date, timeB4[off_set + lines[3]], utc_gps)
        uecef1 = util.computeUECEF(jd1, dut1, 3000, attB1[off_set + lines[0]], 1)
        uecef2 = util.computeUECEF(jd2, dut1, 3000, attB2[off_set + lines[1]], 2)
        uecef4 = util.computeUECEF(jd4, dut1, 3000, attB4[off_set + lines[3]], 4)
        earth_post1 = util.findEarthSurfacePosition(uecef1, posB1[off_set + lines[0]])
        earth_post2 = util.findEarthSurfacePosition(uecef2, posB2[off_set + lines[1]])
        earth_post4 = util.findEarthSurfacePosition(uecef4, posB4[off_set + lines[3]])
        lat1, lon1, height1 = util.itrf2latlon(earth_post1)
        lat2, lon2, height2 = util.itrf2latlon(earth_post2)
        lat4, lon4, height4 = util.itrf2latlon(earth_post4)
        er1_b1 = (lat3 - lat1) ** 2 + (lon3 - lon1) ** 2
        er1_b2 = (lat3 - lat2) ** 2 + (lon3 - lon2) ** 2
        er1_b4 = (lat3 - lat4) ** 2 + (lon3 - lon4) ** 2

        if er1_b1 < errmin1_1:
            errmin1_1 = er1_b1
            offset1 = off_set
        if er1_b2 < errmin1_2:
            errmin1_2 = er1_b2
            offset2 = off_set
        if er1_b4 < errmin1_4:
            errmin1_4 = er1_b4
            offset4 = off_set


    lines[0] += offset1
    lines[1] += offset2
    lines[3] += offset4
    print "Corrected First Lines are: ", lines

    posB1 = posB1[lines[0]:lines[0] + im_height]
    posB2 = posB2[lines[1]:lines[1] + im_height]
    posB4 = posB4[lines[3]:lines[3] + im_height]

    timeB1 = timeB1[lines[0]:lines[0] + im_height]
    timeB2 = timeB2[lines[1]:lines[1] + im_height]
    timeB4 = timeB4[lines[3]:lines[3] + im_height]

    attB1 = attB1[lines[0]:lines[0] + im_height]
    attB2 = attB2[lines[1]:lines[1] + im_height]
    attB4 = attB4[lines[3]:lines[3] + im_height]

    gtiffDriver = gdal.GetDriverByName('GTiff')
    dst_ds = gtiffDriver.Create(out_file_name, im_width, im_height, 4, gdal.GDT_Byte)
    ms_b1 = dst_ds.GetRasterBand(3)
    ms_b2 = dst_ds.GetRasterBand(2)
    ms_b3 = dst_ds.GetRasterBand(1)
    ms_b4 = dst_ds.GetRasterBand(4)
    # Find the shift function using the middle line
    mid_line = im_height / 2
    mid_sample = start_sample + im_width / 2
    # Building the transformation polynomial
    step = 50
    samples2 = samples[step:-step:step]
    x1 = []
    y1 = []
    x2 = []
    y2 = []
    x4 = []
    y4 = []
    v = np.arange(step, im_height - step, step)
    u = samples2.copy()
    num_u = u.shape[0]
    num_v = v.shape[0]
    AA = np.zeros((num_u * num_v, 6))
    idx = 0
    # find approprite line offset
    # consider only the first and last lines.
    sub_line_ranges = 10
    print "finding the corresponding pixels among image bands"
    for line in range(step, im_height - step, step):
        jd3 = computeJDtime(current_date, timeB3[line], utc_gps)
        uecef3 = util.computeUECEF(jd3, dut1, samples2, attB3[line], 3)
        earth_post3 = util.findEarthSurfacePosition(uecef3, posB3[line])
        lat3, lon3, height3 = util.itrf2latlon(earth_post3)
        err1 = 1e100 * np.ones_like(samples2).astype('float32')
        best_line1 = np.ones_like(samples2)
        best_sample1 = np.ones_like(samples2)
        err2 = 1e100 * np.ones_like(samples2).astype('float32')
        best_line2 = np.ones_like(samples2)
        best_sample2 = np.ones_like(samples2)
        err4 = 1e100 * np.ones_like(samples2).astype('float32')
        best_line4 = np.ones_like(samples2)
        best_sample4 = np.ones_like(samples2)
        AA[idx * num_u:(idx + 1) * num_u, 0] = 1.0
        AA[idx * num_u:(idx + 1) * num_u, 1] = samples2 - mid_sample
        AA[idx * num_u:(idx + 1) * num_u, 2] = line - mid_line
        AA[idx * num_u:(idx + 1) * num_u, 3] = (samples2 - mid_sample) * (line - mid_line)
        AA[idx * num_u:(idx + 1) * num_u, 4] = (samples2 - mid_sample) ** 2
        AA[idx * num_u:(idx + 1) * num_u, 5] = (line - mid_line) ** 2
        idx += 1

        for sub_line in range(line - sub_line_ranges, line + sub_line_ranges):
            jd1 = computeJDtime(current_date, timeB1[sub_line], utc_gps)
            jd2 = computeJDtime(current_date, timeB2[sub_line], utc_gps)
            jd4 = computeJDtime(current_date, timeB4[sub_line], utc_gps)
            uecef1 = util.computeUECEF(jd1, dut1, samples, attB1[sub_line], 1)
            uecef2 = util.computeUECEF(jd2, dut1, samples, attB2[sub_line], 2)
            uecef4 = util.computeUECEF(jd4, dut1, samples, attB4[sub_line], 4)
            earth_post1 = util.findEarthSurfacePosition(uecef1, posB1[sub_line])
            earth_post2 = util.findEarthSurfacePosition(uecef2, posB2[sub_line])
            earth_post4 = util.findEarthSurfacePosition(uecef4, posB4[sub_line])
            lat1, lon1, height1 = util.itrf2latlon(earth_post1)
            lat2, lon2, height2 = util.itrf2latlon(earth_post2)
            lat4, lon4, height4 = util.itrf2latlon(earth_post4)



            for k in range(samples2.shape[0]):
                err = (lat1 - lat3[k]) ** 2 + (lon1 - lon3[k]) ** 2
                err_min = err.min()
                if err_min < err1[k]:
                    err1[k] = err_min
                    best_line1[k] = sub_line - mid_line
                    id = np.nonzero(err == err_min)
                    best_sample1[k] = samples[id[0][0]] - mid_sample
                err = (lat2 - lat3[k]) ** 2 + (lon2 - lon3[k]) ** 2
                err_min = err.min()
                if err_min < err2[k]:
                    err2[k] = err_min
                    best_line2[k] = sub_line - mid_line
                    id = np.nonzero(err == err_min)
                    best_sample2[k] = samples[id[0][0]] - mid_sample

                err = (lat4 - lat3[k]) ** 2 + (lon4 - lon3[k]) ** 2
                err_min = err.min()
                if err_min < err4[k]:
                    err4[k] = err_min
                    best_line4[k] = sub_line - mid_line
                    id = np.nonzero(err == err_min)
                    best_sample4[k] = samples[id[0][0]] - mid_sample

        x1.append(best_sample1)
        y1.append(best_line1)
        x2.append(best_sample2)
        y2.append(best_line2)
        x4.append(best_sample4)
        y4.append(best_line4)

        # print "Band1, line:%d,  err_min_max: %f" % (line, err1.max())
        # print "Band2, line:%d,  err_min_max: %f" % (line, err2.max())
        # print "Band4, line:%d,  err_min_max: %f" % (line, err4.max())


    x1 = np.array(x1)
    y1 = np.array(y1)
    # find tune the location
    print "Total of %d pixels pairs between Band1 and Band3" % len(x1)

    b = np.array(x1).flatten()
    par_x1 = np.linalg.lstsq(AA, b)[0]
    print "max error column band 1: %f" % (np.abs(np.dot(AA, par_x1) - b).max())

    b = np.array(y1).flatten()
    par_y1 = np.linalg.lstsq(AA, b)[0]
    print "max error row band 1: %f" % (np.abs(np.dot(AA, par_y1) - b).max())
    x2 = np.array(x2)
    y2 = np.array(y2)
    print "Total of %d pixels pairs between Band2 and Band3" % len(x2)
    b = np.array(x2).flatten()
    par_x2 = np.linalg.lstsq(AA, b)[0]
    print "max error column band 2: %f" % (np.abs(np.dot(AA, par_x2) - b).max())

    b = np.array(y2).flatten()
    par_y2 = np.linalg.lstsq(AA, b)[0]
    print "max error row band 2: %f" % (np.abs(np.dot(AA, par_y2) - b).max())

    x4 = np.array(x4)
    y4 = np.array(y4)
    b = np.array(x4).flatten()
    print "Total of %d pixels pairs between Band4 and Band3" % len(x4)
    par_x4 = np.linalg.lstsq(AA, b)[0]
    print "max error column band 4: %f" % (np.abs(np.dot(AA, par_x4) - b).max())

    b = np.array(y4).flatten()
    par_y4 = np.linalg.lstsq(AA, b)[0]
    print "max error row band 4: %f" % (np.abs(np.dot(AA, par_y4) - b).max())

    # print par_x1,par_x2, par_x4
    # print par_y1,par_y2, par_y4

    # check for line offset
    line_off_set1_min = 0
    line_off_set1_max = im_height
    line_off_set2_min = 0
    line_off_set2_max = im_height
    line_off_set4_min = 0
    line_off_set4_max = im_height

    for cl in [0, im_width - 1]:
        for rw in [0, im_height - 1]:
            k = cl - mid_sample + 1
            m = rw - mid_line
            line_off_set1 = par_y1[0] + par_y1[1] * k + par_y1[2] * m + par_y1[3] * k * m + par_y1[4] * k * k \
                            + par_y1[5] * m * m + mid_line
            line_off_set1_min = int(np.floor(min(line_off_set1 - 3.0, line_off_set1_min)))
            line_off_set1_max = int(np.ceil(max(line_off_set1 + 3.0, line_off_set1_max)))

            line_off_set2 = par_y2[0] + par_y2[1] * k + par_y2[2] * m + par_y2[3] * k * m + par_y2[4] * k * k \
                            + par_y2[5] * m * m + mid_line
            line_off_set2_min = int(np.floor(min(line_off_set2 - 3.0, line_off_set2_min)))
            line_off_set2_max = int(np.ceil(max(line_off_set2 + 3.0, line_off_set2_max)))

            line_off_set4 = par_y4[0] + par_y4[1] * k + par_y4[2] * m + par_y4[3] * k * m + par_y4[4] * k * k\
                            + par_y4[5] * m * m + mid_line
            line_off_set4_min = int(np.floor(min(line_off_set4 - 3.0, line_off_set4_min)))
            line_off_set4_max = int(np.ceil(max(line_off_set4 + 3.0, line_off_set4_max)))
    print line_off_set1_min, line_off_set1_max
    print line_off_set2_min, line_off_set2_max
    print line_off_set4_min, line_off_set4_max
    max_width = 6000
    databand1 = band1.ReadAsArray(0, lines[0] + line_off_set1_min, max_width, line_off_set1_max - line_off_set1_min)
    databand2 = band2.ReadAsArray(0, lines[1] + line_off_set2_min, max_width, line_off_set2_max - line_off_set2_min)
    databand3 = band3.ReadAsArray(0, lines[2], max_width, im_height)
    databand4 = band4.ReadAsArray(0, lines[3] + line_off_set4_min, max_width, line_off_set4_max - line_off_set4_min)

    # print databand1.shape
    # print databand2.shape
    # print databand3.shape
    # print databand4.shape
    # par_y1[0] -= line_off_set1_min
    # par_y2[0] -= line_off_set2_min
    # par_y4[0] -= line_off_set4_min


    outband_fullwidth1 = np.zeros_like(databand3)
    outband_fullwidth2 = np.zeros_like(databand3)
    # outband3 = np.zeros_like(databand3)
    outband_fullwidth4 = np.zeros_like(databand3)

    # resampling in y-direction
    im_lines1 = np.arange(im_height).astype('float32') - mid_line
    im_lines2 = np.arange(im_height).astype('float32') - mid_line
    im_lines4 = np.arange(im_height).astype('float32') - mid_line
    print "Resampling image in height direction......"
    for s in range(max_width):
        s1 = float(s + 1 - mid_sample)
        one_sampleB1 = databand1[:, s].astype('float32')
        b1sub = par_y1[0] + par_y1[1] * s1 + par_y1[2] * im_lines1 + par_y1[3] * s1 * im_lines1 + par_y1[4] * s1 * s1 + \
                par_y1[5] * (im_lines1 ** 2) - line_off_set1_min
        b1sub += mid_line
        outband_fullwidth1[:, s] = cubicInterpolation(one_sampleB1, b1sub, im_lines1.shape[0])

        one_sampleB2 = databand2[:, s].astype('float32')
        b2sub = par_y2[0] + par_y2[1] * s1 + par_y2[2] * im_lines2 + par_y2[3] * s1 * im_lines2 + par_y2[4] * s1 * s1 + \
                par_y2[5] * (im_lines2 ** 2) - line_off_set2_min
        b2sub += mid_line
        outband_fullwidth2[:, s] = cubicInterpolation(one_sampleB2, b2sub, im_lines2.shape[0])

        one_sampleB4 = databand4[:, s].astype('float32')
        b4sub = par_y4[0] + par_y4[1] * s1 + par_y4[2] * im_lines4 + par_y4[3] * s1 * im_lines4 + par_y4[4] * s1 * s1 + \
                par_y4[5] * (im_lines4 ** 2) - line_off_set4_min
        b4sub += mid_line
        outband_fullwidth4[:, s] = cubicInterpolation(one_sampleB4, b4sub, im_lines4.shape[0])

    # resampling in x-direction
    # outband1 = databand1[-line_off_set1_max:im_height-line_off_set1_max,:]
    # outband2 = databand2[-line_off_set2_max:im_height-line_off_set2_max,:]
    # outband4 = databand4[-line_off_set4_max:im_height-line_off_set4_max,:]
    s = samples.copy() - 1
    samples = samples.astype('float32') - mid_sample
    outband3 = np.zeros((im_height, im_width), 'uint8')
    outband1 = np.zeros_like(outband3)
    outband2 = np.zeros_like(outband3)
    outband4 = np.zeros_like(outband3)

    print "Resampling image in width direction......"
    for k in range(im_height):
        # print "Building line %d......" % k
        one_lineB3 = databand3[k, :].astype('float32')
        # one_lineB3 = np.round((one_lineB3_t-dark_currents[2])/gains[2])
        # out_lineB3 = one_lineB3*(one_lineB3 <255.0) + 255.0*(one_lineB3>=255)

        # out_lineB3 = one_lineB3*(one_lineB3_t <255.0) + 255.0*(one_lineB3_t>=255)
        outband3[k, :] = one_lineB3[s].astype('uint8')

        k1 = float(k - mid_line)  # + line_off_set1_min
        one_lineB1 = outband_fullwidth1[k, :].astype('float32')
        # one_lineB1 = np.round((one_lineB1_t-dark_currents[0])/gains[0])
        # one_lineB1 = one_lineB1*(one_lineB1 <255.0) + 255.0*(one_lineB1>=255)
        # one_lineB1 =  one_lineB1*(one_lineB1_t <255.0) + 255.0*(one_lineB1_t>=255)
        a1sub = par_x1[0] + par_x1[1] * samples + par_x1[2] * k1 + par_x1[3] * samples * k1 + \
                par_y1[4] * samples * samples + \
                par_y1[5] * k1 * k1
        a1sub += mid_sample
        outband1[k, :] = cubicInterpolation(one_lineB1, a1sub, max_width)

        k2 = float(k - mid_line)  # + line_off_set2_min
        one_lineB2 = outband_fullwidth2[k, :].astype('float32')
        # one_lineB2 = np.round((one_lineB2_t-dark_currents[1])/gains[1])
        # one_lineB2 = one_lineB2*(one_lineB2 <255.0) + 255.0*(one_lineB2>=255)
        # one_lineB2 = one_lineB2*(one_lineB2_t <255.0) + 255.0*(one_lineB2_t>=255)
        a2sub = par_x2[0] + par_x2[1] * samples + par_x2[2] * k2 + par_x2[3] * samples * k2 + \
                par_y2[4] * samples * samples + \
                par_y2[5] * k2 * k2
        a2sub += mid_sample
        outband2[k, :] = cubicInterpolation(one_lineB2, a2sub, max_width)

        k4 = float(k - mid_line)  # + line_off_set4_min
        one_lineB4 = outband_fullwidth4[k, :].astype('float32')
        # one_lineB4 = np.round((one_lineB4_t-dark_currents[3])/gains[3])
        # one_lineB4 = one_lineB4*(one_lineB4 <255.0) + 255.0*(one_lineB4>=255)
        # one_lineB4 = one_lineB4*(one_lineB4_t <255.0) + 255.0*(one_lineB4_t >=255)
        a4sub = par_x4[0] + par_x4[1] * samples + par_x4[2] * k4 + par_x4[3] * samples * k4 + \
                par_y4[4] * samples * samples + \
                par_y4[5] * k4 * k4
        a4sub += mid_sample
        outband4[k, :] = cubicInterpolation(one_lineB4, a4sub, max_width)

    ms_b1.WriteArray(outband1, 0, 0)
    ms_b2.WriteArray(outband2, 0, 0)
    ms_b3.WriteArray(outband3, 0, 0)
    ms_b4.WriteArray(outband4, 0, 0)


def buildPANImageUsingCubicInterpolation(out_file_name, in_file_name, beg_line, current_date, utc_gps, ut1_utc,
                                         filter2D, start_sample=1, im_width=12000, im_height=12000):
    max_width = 12000

    band1 = gdal.Open(in_file_name + ".tif")
    beg_line -= 1
    start_sample -= 1

    gtiffDriver = gdal.GetDriverByName('GTiff')
    dst_ds = gtiffDriver.Create(out_file_name, im_width, im_height, 1, gdal.GDT_Byte)
    pan_b1 = dst_ds.GetRasterBand(1)

    # load as a block of 1000x1000 overlapped by 100

    for k in range(0, im_height, 1000):
        for m in range(0, im_width, 1000):
            print "Building block (%d,%d)......" % (k, m)
            y_min = max(0, beg_line + k - 100)
            x_min = max(0, m - 100 + start_sample)
            x_off_l = start_sample + m - x_min
            y_off_l = beg_line + k - y_min
            x_max = min(max_width, m + 1000 + 100 + start_sample)
            y_max = min(beg_line + im_height + 20, beg_line + k + 1000 + 100)
            x_off_h = x_max - (m + 1000) + (start_sample - 1)
            y_off_h = y_max - (beg_line + 1000 + k)
            load_width = x_max - x_min
            load_height = y_max - y_min
            one_block = band1.ReadAsArray(x_min, y_min, load_width, load_height)
            filtered_im = cv2.filter2D(one_block, cv2.CV_8UC1, filter2D)
            used_ar = filtered_im[y_off_l:y_off_l + 1000, x_off_l:x_off_l + 1000]

            # one_line = np.round((one_line-dark_currents)/gains)
            # out_line = one_line*(one_line <255.0) + 255.0*(one_line>=255)
            # outPAN = one_line.astype('uint8')
            pan_b1.WriteArray(used_ar, m, k)


if __name__ == "__main__":
    # cpf_file =  "/media/professor/Data and Backup/LEVEL0/CPF file/CPF_20110106_Delta_UT/THEOS_1_20110104_000000_20110106_000000.CPF"
    # cpf_file = r"D:\level1A_development\GER\THEOS_1_20150915_000000_20150917_000000.CPF"
    # gp,dp = readGainsAndDarkCurrent(cpf_file,"PAN", 6)
    # g1, d1 = readGainsAndDarkCurrent(cpf_file,1,5)
    # g2, d2 = readGainsAndDarkCurrent(cpf_file,2,5)
    # g3, d3 = readGainsAndDarkCurrent(cpf_file,3,5)
    # g4, d4 = readGainsAndDarkCurrent(cpf_file,4,4)
    # g4 = np.ones(g4.shape)
    # d4 = np.zeros(d4.shape)
    # g1 = np.ones(g4.shape)
    # d1 = np.zeros(d4.shape)
    # g2 = np.ones(g4.shape)
    # d2 = np.zeros(d4.shape)
    # g3 = np.ones(g4.shape)
    # d3 = np.zeros(d4.shape)
    # import matplotlib.pyplot as plt
    # plt.plot(d4)
    # plt.show()
    file_name = r"D:\level1A_development\GER\TS1_2015308_37179_004_"
    # buildRMImage(file_name,7299,7363,7428,7493,g1,g2,g3,g4,d1,d2,d3,d4)
    # gains =[g1,g2,g3,g4]
    # dark_curr = [d1,d2,d3,d4]
    out_file = file_name + "out.tif"
    # buildPANImageUsingCubicInterpolation(out_file ,file_name,43221,gp,dp,[2015,1,1],-16.0)
    buildMSImageUsingCubicInterpolation(out_file, file_name, [5379, 5441, 5503, 5565], [2015, 11, 4], -17.0, -0.200)
