__author__ = 'professor'

import dutil
import locationutil as util
import numpy as np


pos = np.loadtxt(r"C:\level0\theos_1_level0_1_111032837_32837_ms_pb_top_2_8_2015-01-02_03-26-33\TS1_2015002_32837_008_B3.pos")
att = np.loadtxt(r"C:\level0\theos_1_level0_1_111032837_32837_ms_pb_top_2_8_2015-01-02_03-26-33\TS1_2015002_32837_008_B3.att")
tt = dutil.datetime(2015, 1, 2, 3, 27, 31 - 16, 209124)
JD = tt.to_jd()
for k in range(26884, 26885) :
    uecef = util.computeUECEF(JD, 6000, att[26884], 3)
    earth_post = util.findEarthSurfacePosition(uecef, pos[k])
    lat, lon, height = util.itrf2latlon(earth_post)
    print "k: %d, lat err: %f, lon err: %f" % (k, lat, lon)
    print "k: %d, lat err: %f, lon err: %f" % (k, lat - 17.560718, lon - 100.212988)
    print "k: %d, pos: " % k, pos[k]

