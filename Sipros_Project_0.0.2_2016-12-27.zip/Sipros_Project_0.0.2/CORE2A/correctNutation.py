f = r"C:\Users\Teerasit\Dropbox\THEOS_Level2A\nutationPart2.txt"
with open(f) as fp:
    txt = fp.read()
    txt = txt.replace("0*L + ", "")
    txt = txt.replace("0*L - ", "-")
    txt = txt.replace("1*L", "L")
    txt = txt.replace("-1*L", "-L")
    txt = txt.replace("0*Lp + ", "")
    txt = txt.replace("0*Lp - ", "-")
    txt = txt.replace("+ 0*Lp", "")
    txt = txt.replace("1*Lp", "Lp")
    txt = txt.replace("-1*Lp", "-Lp")

    txt = txt.replace("0*F + ", "")
    txt = txt.replace("0*F - ", "-")
    txt = txt.replace("+ 0*F", "")
    txt = txt.replace("1*F", "F")
    txt = txt.replace("-1*F", "-F")

    txt = txt.replace("0*D + ", "")
    txt = txt.replace("0*D - ", "-")
    txt = txt.replace("+ 0*D", "")
    txt = txt.replace("1*D", "D")
    txt = txt.replace("-1*D", "-D")


    txt = txt.replace("+ 0*Om", "")
    txt = txt.replace("1*Om", "Om")
    txt = txt.replace("-1*Om", "-Om")

    txt = txt.replace("+ 0*T)", ")")
    print txt

    arg = ""
    txt2 = txt
    ix = txt2.find("cos")
    A = ""
    B = ""
    while ix >= 0 :
        ix3 = txt2.find("(")
        A += txt2[ix3 + 1:ix - 2] + " , "
        txt2 = txt2[ix + 4:]
        ix2 = txt2.find(")")
        arg += txt2[:ix2] + " , "
        ix = txt2.find("sin")
        ix3 = txt2.find(")")
        temp = txt2[ix3 + 2:ix - 1]
        if temp[0] == "+":
            temp = temp[2:]
        else:
            temp = "-" + temp[2:]

        B += temp + " , "
        txt2 = txt2[ix + 4:]
        ix = txt2.find("cos")
    print arg
    print A
    print B


