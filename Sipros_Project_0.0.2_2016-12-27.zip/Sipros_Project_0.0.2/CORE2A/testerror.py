
from osgeo import gdal

import determine_pixel_shift as dps
import numpy as np


in_file_name = r"D:\Data2APanSharpen\THEOS_1_LEVEL0_1_111038073_38073_MS_PB_TOP_2_6_2016-01-05_17-19-01\info\TS1_2016005_38073_006_"
band = 1
lines = [1015 , 1176 , 1341 , 1506]
U = np.load(in_file_name + "band_%d_U_%d.npy" % (band + 1, lines[2]))
V = np.load(in_file_name + "band_%d_V_%d.npy" % (band + 1, lines[2]))
a_x_min = np.load(in_file_name + "band_%d_axmin_%d.npy" % (band + 1, lines[2]))
a_y_min = np.load(in_file_name + "band_%d_aymin_%d.npy" % (band + 1, lines[2]))
a_x_max = np.load(in_file_name + "band_%d_axmax_%d.npy" % (band + 1, lines[2]))
a_y_max = np.load(in_file_name + "band_%d_aymax_%d.npy" % (band + 1, lines[2]))
xy = np.load(in_file_name + "band_%d_x_mean_y_mean_%d.npy" % (band + 1, lines[2]))
x_mean = xy[0]
y_mean = xy[1]
uv = np.load(in_file_name + "band_%d_u_mean_v_mean_%d.npy" % (band + 1, lines[2]))
u_mean = uv[0]
v_mean = uv[1]
hmaxmin = np.load(in_file_name + "band_%d_h_%d.npy" % (band + 1, lines[2]))
hmin = hmaxmin[0]
hmax = hmaxmin[1]
captured_time = np.load(in_file_name + "band_%d_cap_time_%d.npy" % (band + 1, lines[2]))
sat_pos = np.load(in_file_name + "band_%d_sat_pos_%d.npy" % (band + 1, lines[2]))
sat_att = np.load(in_file_name + "band_%d_sat_att_%d.npy" % (band + 1, lines[2]))
dem_file_name = in_file_name + "DEM_%d.tif" % lines[2]

dem_ds_im = gdal.Open(dem_file_name)
dem_ds = dem_ds_im.GetRasterBand(1)
print U + u_mean
print V + v_mean
urw = 787
ucl = 797
u_min = int(U.min() + u_mean)
v_min = int(V.min() + v_mean)
dem_data = dem_ds.ReadAsArray(u_min, v_min, ucl, urw)
h = dem_data.flatten()

im_width = 6000
im_height = 6000
num_samples_per_line = 300  # Smaller is faster, but less accurate
step_sample = im_width / num_samples_per_line
step_line = im_height / num_samples_per_line
num_pairs = (im_height / step_line + 1) * (im_width / step_sample + 1)


lv2_pair_min_list = []
lv2_pair_max_list = []
print "try to find the matching image pair file for ger file."
ger_pairs = np.loadtxt(in_file_name + "ger_pair_line%d.txt" % (lines[2]))
for band in [1, 2, 3, 4]:
    print "try to load matching image pair files for MS Band %d." % band
    lv2_pairs_min = np.loadtxt(in_file_name + "B%dlv2_pair_min_line%d.txt" % (band, lines[2]))
    lv2_pairs_max = np.loadtxt(in_file_name + "B%dlv2_pair_max_line%d.txt" % (band, lines[2]))
    lv2_pair_min_list.append(lv2_pairs_min)
    lv2_pair_max_list.append(lv2_pairs_max)
band = 1
v_mean = 11287 / 2.0
u_mean = 27934 / 2.0
A = np.zeros((num_pairs, 12))
u = lv2_pair_min_list[band][:, 0] - u_mean
v = lv2_pair_min_list[band][:, 1] - v_mean + 1
# print u.min(),u.max(),v.min(),v.max()
A[:, 0] = 1.0
A[:, 1] = u
A[:, 2] = v
A[:, 3] = u * v
A[:, 4] = u ** 2
A[:, 5] = v ** 2
A[:, 6] = u * v * v
A[:, 7] = v * u * u
A[:, 8] = u ** 3
A[:, 9] = v ** 3
A[:, 10] = v * u ** 3
A[:, 11] = u * v ** 3


x_mean = ger_pairs[:, 0].mean()
y_mean = ger_pairs[:, 1].mean()
bx = ger_pairs[:, 0] - x_mean
by = ger_pairs[:, 1] - y_mean
a_x_min, errx, rnkx, s = np.linalg.lstsq(A, bx)
# print rnk
a_y_min, erry, rnky, s = np.linalg.lstsq(A, by)
# print rnk
if (rnkx == 12) and (rnky == 12) :
    print "[%d] Minimun altitude average errors: %f,%f" % (band + 1, errx / numpairs, erry / num_pairs)
else:
    print "[%d]  The model for mainimum altitude is too fitted. Reduce the number of variables." % (band + 1)
    # A2 = A.copy()
    for rk in range(11, 0, -1):
        A2 = A[:, :rk]
        a_x_min2, errx, rnk, s = np.linalg.lstsq(A2, bx)
        a_y_min2, erry, rnk, s = np.linalg.lstsq(A2, by)
        if (len(a_x_min2) > 0)  and (len(a_y_min2) > 0):
            a_x_min = np.zeros((12,))
            a_y_min = np.zeros((12,))
            a_x_min[:rk] = a_x_min2
            a_y_min[:rk] = a_y_min2
            break
    print ".....................The algorithm terminates with the matrix of order %d." % rk



u = lv2_pair_max_list[band][:, 0] - u_mean
v = lv2_pair_max_list[band][:, 1] - v_mean + 1
# print u.min(),u.max(),v.min(),v.max()
A[:, 0] = 1.0
A[:, 1] = u
A[:, 2] = v
A[:, 3] = u * v
A[:, 4] = u ** 2
A[:, 5] = v ** 2
A[:, 6] = u * v * v
A[:, 7] = v * u * u
A[:, 8] = u ** 3
A[:, 9] = v ** 3
A[:, 10] = v * u ** 3
A[:, 11] = u * v ** 3


x_mean = ger_pairs[:, 0].mean()
y_mean = ger_pairs[:, 1].mean()
bx = ger_pairs[:, 0] - x_mean
by = ger_pairs[:, 1] - y_mean
a_x_max, errx, rnkx, s = np.linalg.lstsq(A, bx)
a_y_max, erry, rnky, s = np.linalg.lstsq(A, by)
if (rnkx == 12) and (rnky == 12):
    print "[%d] Maximum altitude average errors: %f,%f" % (band + 1, errx / numpairs, erry / num_pairs)
else:
    print "[%d]  The model for maximum altitude is too fitted. Reduce the number of variables." % (band + 1)
    # A2 = A.copy()
    for rk in range(11, 0, -1):
        A2 = A[:, :rk]
        a_x_max2, errx, rnk, s = np.linalg.lstsq(A2, bx)
        a_y_max2, erry, rnk, s = np.linalg.lstsq(A2, by)
        if (len(a_x_max2) > 0)  and (len(a_y_max2) > 0):
            a_x_max = np.zeros((12,))
            a_y_max = np.zeros((12,))
            a_x_max[:rk] = a_x_max2
            a_y_max[:rk] = a_y_max2
            break
    print "....................The algorithm terminates with the matrix of order %d." % rk








X, Y = dps.findGerFileLocationPreLoadFiles(U, V, h, a_x_min, a_y_min, a_x_max, a_y_max, x_mean, y_mean, u_mean,
                                           v_mean, hmin, hmax, "MS", in_file_name, 1176, (2016, 1, 5),
                                           - 17.0, 0.1, (91021.66554470453, 3914444.3279871056, 15.0, -15.0, 16),
                                           6000, 6000, sat_pos, captured_time, sat_att, band=2)

print X
print Y
