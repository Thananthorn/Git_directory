import cv2

from osgeo import gdal
from osgeo import osr
import utm

import locationutil as util
import numpy as np
import utmLatlon


if __name__ == "__main__":
    dem_dir = r"D:\level1A_development\srtm\gls"
    pan_file = r"D:\Data2APanSharpen\THEOS_37591_CASE_city\Level_2A\PAN\TH_CAT_160302060538639_1_TESTDATA_37591_PAN_3_2\TH_CAT_160302060538639_1\IMAGERY.TIF"
    pan = gdal.Open(pan_file)
    geotrans = pan.GetGeoTransform()
    xul = geotrans[0]
    yul = geotrans[3]
    dx = geotrans[1]
    dy = geotrans[5]
    xlr = xul + dx * pan.RasterXSize
    ylr = yul + dy * pan.RasterYSize
    wkt = pan.GetProjection()
    src = osr.SpatialReference(wkt=wkt)
    zone = src.GetUTMZone()
    latul, lonul = utm.to_latlon(xul, yul, zone, 'northern')
    latlr, lonlr = utm.to_latlon(xlr, ylr, zone, 'northern')
    lata, lona, h = util.load_dem_data([latul, lonul], [latlr, lonlr], dem_dir)
    x, y, z, zt = utmLatlon.from_latlon(lata, lona, force_zone_number=zone)
    cols = (x - xul) / dx
    rows = (y - yul) / dy

    r, c = np.nonzero((rows >= 0) * (rows <= pan.RasterYSize - 1) * (cols >= 0) * (cols <= pan.RasterYSize - 1))
    rows2 = (rows[r, c] / 2.).astype('int32')
    cols2 = (cols[r, c] / 2.0).astype('int32')
    width = pan.RasterXSize / 2
    height = pan.RasterYSize / 2
    out = np.zeros((height, width, 3), 'uint8')
    pan_data = pan.GetRasterBand(1).ReadAsArray()
    pansmall = pan_data[::2, ::2]
    for band in range(3):
        out[:, :, band] = pansmall
    num = rows2.size
    for k in range(num):
        cv2.circle(out, (cols2[k], rows2[k]), 6, (0, 0, 255), -1)
    cv2.imwrite(r"D:\Data2APanSharpen\THEOS_37591_CASE_city\Level_2A\PAN\TH_CAT_160302060538639_1_TESTDATA_37591_PAN_3_2\SRTM90dem.tif", out)


