__author__ = 'professor'
import cv2
import platform

import numpy as np


# from osgeo import gdal
if platform.system() == "Windows":
    from osgeo import gdal
else:
    import gdal
if __name__ == "__main__":
    imfile1 = r"C:\LEVEL0\Image Level 0\2011-02-08_REV12627\THEOS_1_LEVEL0_1_111012627_12627_MS_PB_TOP_2_8_2011-02-08_03-10-03\TS1_2011039_12627_008_out.tif"
    # imfile2 = "/media/professor/Data and Backup/LEVEL0/2011-02-08_REV12627/THEOS_1_LEVEL0_1_111012627_12627_MS_PB_TOP_2_8_2011-02-08_03-10-03/TS1_2011039_12627_008_out.tif"
    im = gdal.Open(imfile1)
    # im2 = gdal.Open(imfile2)

    # data1 = im1.GetRasterBand(2).ReadAsArray()
    # data2 = im2.GetRasterBand(2).ReadAsArray()
    # print "band %d: mse:%f"%(1,((data1-data2)**2).mean())

    data = np.zeros((600, 600, 3), 'uint8')
    for k in range(0, 6000, 600):
        for m in range(0, 6000, 600):
            data[:, :, 2] = im.GetRasterBand(3).ReadAsArray(k, m, 600, 600)
            data[:, :, 1] = im.GetRasterBand(2).ReadAsArray(k, m, 600, 600)
            data[:, :, 0] = im.GetRasterBand(1).ReadAsArray(k, m, 600, 600)
            cv2.imshow("image", data)
            cv2.waitKey(10)
            cv2.imwrite(imfile1[:-4] + "_%4d_%4d.tif" % (k, m), data)
