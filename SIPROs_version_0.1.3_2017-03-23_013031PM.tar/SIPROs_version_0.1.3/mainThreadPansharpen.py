"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""


import CompletePanSharpen as pansharpenSystem
import digitalElevationModel as demservice
from systemConstants import pansharpenMethods

# SYSTEM CONSTANTS
class demDirectory:
    SRTM30 = r"D:\srtm30\gls"
    SRTM90 = r"D:\level1A_development\srtm\gls"
    GLOBE = r"D:\globedem"
    THEOS = r"D:\old_system_dem"


class processingLevel:
    LEVEL1A = "1A"
    LEVEL2A = "2A"



class sensorType:
    PAN ="PAN"
    MS = "MS"



class pansharpenSceneInfo:
    pan_ger_dir = r"D:\Data2APanSharpen\pansharpMar17\THEOS_1_LEVEL0_1_111044162_44162_PAN_PB_TOP_1_1_2017-03-09_18-08-50"
    # GERALD Directory for the PAN Image
    ms_ger_dir = r"D:\Data2APanSharpen\pansharpMar17\THEOS_1_LEVEL0_1_111044162_44162_MS_PB_TOP_2_2_2017-03-09_18-08-51"
    # GERALD Directory for the MS Image
    cpf_file = r"D:\Data2APanSharpen\pansharpMar17\THEOS_1_20170126_000000_20170126_000000.CPF"
    pan_sharpen_info = pan_ger_dir + "\\info_sharpen"
    ger_pan_info = pan_ger_dir + "\\info"
    ger_ms_info = ms_ger_dir + "\\info"
    pansharp_out = pan_ger_dir + "\\pansharp"
    revolution = "37654"
    line_shift = 0
    grid_id = "0697-0419"

class pansharpenProcessSetup:
    processing_level = processingLevel.LEVEL2A
    dem_interpolation = demservice.digitalElevationModel.CUBIC
    dem_type = demservice.THEOS_DEM
    apf_file = r"D:\level1A_development\THEOS_nominal.APF"
    pansharpen_algorithm = pansharpenMethods.HIGHPASS_MODULATION
    pan_begin_line = 29825

def callPansharpenProcessingSystem():
    processing_level = pansharpenProcessSetup.processing_level
    pansharpen_algorithm = pansharpenProcessSetup.pansharpen_algorithm
    ms_dir = pansharpenSceneInfo.ms_ger_dir
    pan_dir = pansharpenSceneInfo.pan_ger_dir
    cpf_file = pansharpenSceneInfo.cpf_file
    begin_line = pansharpenProcessSetup.pan_begin_line
    pan_sharpen_info = pansharpenSceneInfo.pan_sharpen_info
    ger_pan_info = pansharpenSceneInfo.ger_pan_info
    ger_ms_info = pansharpenSceneInfo.ger_ms_info
    pansharp_out = pansharpenSceneInfo.pansharp_out
    apf_file = pansharpenProcessSetup.apf_file
    dem_dir = demDirectory
    dem_type = pansharpenProcessSetup.dem_type
    dem_interpolation_method = pansharpenProcessSetup.dem_interpolation
    rev_num = pansharpenSceneInfo.revolution
    grid_ref = pansharpenSceneInfo.grid_id
    line_shift = pansharpenSceneInfo.line_shift
    pansharpenSystem.build_PANSHARPEN(processing_level, pansharpen_algorithm, ms_dir, pan_dir,
                                      cpf_file,begin_line,  pan_sharpen_info, ger_pan_info, ger_ms_info,
                                      pansharp_out, apf_file,rev_num, grid_ref, line_shift,
                                      dem_dir, dem_type, dem_interpolation_method)



if __name__ == "__main__":
    callPansharpenProcessingSystem()
