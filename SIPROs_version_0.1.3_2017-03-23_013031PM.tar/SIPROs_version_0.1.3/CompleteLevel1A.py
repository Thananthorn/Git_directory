"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

 """

import generalFileReader as gr
import createImage1A as createImage
import os
import locationutil
import determine_pixel_shift as dps
import numpy as np
from xml.dom import minidom
from osgeo import gdal
from osgeo import osr
import cv2
import DIMAPLV1 as DIMAP
import time
import digitalElevationModel as demservice

dem_directories = dict()







def MSDataExtraction(ms_ger_file_names, output_file_names, cpf_file_name, force_run=False):
    year, month, day, band_band_lines, band_degraded_lines = gr.readGerMSFiles(ms_ger_file_names, output_file_names, cpf_file_name, force_run)
    return year, month, day, band_band_lines, band_degraded_lines


def PANDataExtraction(pan_ger_file_names, output_file_names, cpf_file_name, force_run=False):
    year, month, day , band_band_lines, band_degraded_lines= gr.readGerPANFiles(pan_ger_file_names, output_file_names, cpf_file_name, force_run)
    return year, month, day , band_band_lines, band_degraded_lines


def find_ger_files(ger_dir):
    ger_file_list = []
    for filename in os.listdir(ger_dir):
        base, ext = os.path.splitext(filename)
        # print base, ext
        if ext.lower() == ".ger":
            ger_file = base + ext
            ger_file_list.append(ger_file)
            ger_file_list.sort()
    return ger_file_list


def createPreview(file_name, preview_file, icon_file, width, height):
    im = gdal.Open(file_name)
    imw = im.RasterXSize
    imh = im.RasterYSize
    steph = int(imh / height)
    stepw = int(imw / width)
    if im.RasterCount == 4:  # ms Images
        outim = np.zeros((height, width, 3), 'uint8')
        b1 = im.GetRasterBand(1)
        b2 = im.GetRasterBand(2)
        b3 = im.GetRasterBand(3)
        for line in range(height):
            line_im = line * steph
            d1 = b1.ReadAsArray(0, line_im, imw, 1)
            d2 = b2.ReadAsArray(0, line_im, imw, 1)
            d3 = b3.ReadAsArray(0, line_im, imw, 1)
            outim[line, :, 2] = d1[0, ::stepw]
            outim[line, :, 1] = d2[0, ::stepw]
            outim[line, :, 0] = d3[0, ::stepw]
    else:
        outim = np.zeros((height, width), 'uint8')
        b1 = im.GetRasterBand(1)
        for line in range(height):
            line_im = line * steph
            d1 = b1.ReadAsArray(0, line_im, imw, 1)
            outim[line, :] = d1[0, ::stepw]
    cv2.imwrite(preview_file, outim)
    scale = min(height/128,width/128)
    icon = cv2.resize(outim, (width/scale, height/scale))
    cv2.imwrite(icon_file, icon)


def createLevel1A_MSImage(out_dir, ger_info_dir, ger_dir, cpf_file, band_lines, dem, dem_interp,  start_sample=1, im_width=6000,
                          im_height=6000, force_run=False):
    """

    :param out_dir: output file directory
    :param ger_info_dir: the extracted files will be put in ger_info_dir
    :param ger_dir: director where .ger is located
    :param cpf_file: a .cpf file
    :param band_line: begining line for each bands
    :param dem: dem module used in geo-positioning
    :param dem_interp: interpolation method
    :param start_sample: first sample of each line (default is 1.)
    :param im_width: Width of the MS image (default is 6000)
    :param im_height: Height of the MS image (default is 3000)
    :param force_run: True will force to extact all data.
                      False will extact only if file is too old or does not exist.
    :return:
        date = [year, month, day] when image was captured.
        utc_gps = UTC-GPS obtained from .cpf file.
        ut1_utc = UT1-UTC obtained from .cpf file.
        file_name: prefix of name of the files containing information extracted from the .ger file.
    """
    ms_ger_files = []
    ger_file_names = find_ger_files(ger_dir)
    for file_name in ger_file_names:
        ms_ger_files.append(ger_dir + "/" + file_name)
        ms_ger_files.sort()

    ms_ger_output_files = []
    for ger_file in ger_file_names:
        base, ext = os.path.splitext(ger_file)
        ms_ger_output_files.append(ger_info_dir + "/" + base)
        ms_ger_output_files.sort()

    year, month,day,  band_band_lines, band_degraded_lines = MSDataExtraction(ms_ger_files, ms_ger_output_files, cpf_file, force_run)
    date = [year, month, day]
    # date =[2015,1,2]
    file_name = ms_ger_output_files[0][:-2]
    utc_gps, ut1_utc = locationutil.readGainsAndDarkCurrent(cpf_file)
    out_file = out_dir + "/" + "IMAGERY.tif"
    if (os.path.isfile(out_file) == False) or force_run:
        g1 = []
        g2 = []
        g3 = []
        g4 = []
        d1 = []
        d2 = []
        d3 = []
        d4 = []

        for gnumber in range(1, 11):
            g, d = gr.readGainsAndDarkCurrent(cpf_file, 1, gnumber)
            g1.append(g)
            d1.append(d)

            g, d = gr.readGainsAndDarkCurrent(cpf_file, 2, gnumber)
            g2.append(g)
            d2.append(d)

            g, d = gr.readGainsAndDarkCurrent(cpf_file, 3, gnumber)
            g3.append(g)
            d3.append(d)

            g, d = gr.readGainsAndDarkCurrent(cpf_file, 4, gnumber)
            g4.append(g)
            d4.append(d)
        gain = [g1, g2, g3, g4]
        darkcurrent = [d1, d2, d3, d4]
        createImage.buildMSImageUsingCubicInterpolation(out_file, file_name, band_lines, date, utc_gps, ut1_utc,
                                                        dem, dem_interp, gain, darkcurrent, start_sample, im_width, im_height)
    scale = min(im_width/1000,im_height/1000)
    createPreview(out_file, out_dir + "/PREVIEW.JPG", out_dir + "/ICON.JPG", im_width/scale, im_height/scale)

    return date, utc_gps, ut1_utc, file_name, band_band_lines, band_degraded_lines


def loadFilter(apf_file, band="PAN", id=9):
    """

    :param apf_file: The .apf file containing filter parameters
    :param band: spectral band. Default is "PAN"
    :param id: filter id. The defualt id is 9.
    :return: a 5x5 filter
    """
    doc = minidom.parse(apf_file)
    resplist = doc.getElementsByTagName("RestorationParametersList")[0]
    resparms = resplist.getElementsByTagName("RestorationParameters")
    for resp in resparms:
        apf_band = resp.getAttribute("band")
        if apf_band == band:
            filter_list = resp.getElementsByTagName("filter")
            for filter in filter_list:
                filter_id = int(filter.getAttribute("id"))
                if filter_id == id:
                    filterout = np.fromstring(filter.childNodes[0].data, dtype="float32", sep=",")
    filter2D = filterout.reshape((5, 5))

    return filter2D


def createLevel1A_PANImage(out_dir, ger_info_dir, ger_dir, cpf_file, apf_file, band_line, start_sample=1, im_width=12000,
                    im_height=12000, force_run= False):
    """

    :param out_dir: output file directory
    :param ger_info_dir: the extracted files will be put in ger_info_dir
    :param ger_dir: director where .ger is located
    :param cpf_file: a .cpf file
    :param apf_file: a .apf file
    :param band_line: begining line
    :param force_run: True will force to extact all data.
                      False will extact only if file is too old or does not exist.
    :return:
        date = [year, month, day] when image was captured.
        utc_gps = UTC-GPS obtained from .cpf file.
        ut1_utc = UT1-UTC obtained from .cpf file.
        file_name: prefix of name of the files containing information extracted from the .ger file.
    """

    pan_ger_files = []
    ger_file_names = find_ger_files(ger_dir)
    for file_name in ger_file_names:
        pan_ger_files.append(ger_dir + "/" + file_name)
        pan_ger_files.sort()

    pan_ger_output_files = []
    for ger_file in ger_file_names:
        base, ext = os.path.splitext(ger_file)
        pan_ger_output_files.append(ger_info_dir + "/" + base)
        pan_ger_output_files.sort()

    year, month, day, band_band_lines, band_degraded_lines = PANDataExtraction(pan_ger_files, pan_ger_output_files,
                                                                               cpf_file, force_run)
    date = [year, month, day,]
    file_name = pan_ger_output_files[0]
    utc_gps, ut1_utc = locationutil.readGainsAndDarkCurrent(cpf_file)
    out_file = out_dir + "/" + "IMAGERY.tif"
    filter2D =[]
    for id in range(1,10):
        filter = loadFilter(apf_file, "PAN", id)
        filter2D.append(filter)
    if (force_run == True) or (os.path.isfile(out_file) == False):
        gain = []
        dark_cur = []
        for gnumber in range(1, 11):
            g, d = gr.readGainsAndDarkCurrent(cpf_file, "PAN", gnumber)
            gain.append(g)
            dark_cur.append(d)
        createImage.buildPANImageUsingCubicInterpolation(out_file, file_name, band_line, filter2D, gain, dark_cur, start_sample, im_width, im_height)
    scale = min(im_width/1000,im_height/1000)
    createPreview(out_file, out_dir + "/PREVIEW.JPG", out_dir + "/ICON.JPG", im_width/scale, im_height/scale)

    return date, utc_gps, ut1_utc, file_name, band_band_lines, band_degraded_lines


def computeDIMAPParameters(ger_info_prefix,  image_type, line1, date, utc_gps, ut1_utc, dem,
                           dem_interpolation_method, start_sample, im_width, im_height):
    """

    :param ger_info_prefix:  text containing all prefix to files extracted from .ger
    :param image_type:  "MS" for multispectral, "PAN" for panchromatic images
    :param line1: first line of Band 3 for multispectral image, and first line of panchromatic image
    :param date: [year, month, day] of capturing image
    :param utc_gps: UTC-GPS time
    :param ut1_utc: UT1-UTC time
    :param dem: dem module used in geopositioning
    :param dem_interpolation_method: dem interpolation method
    :param start_sample: start sample
    :param im_width: image width 6000 for MS 12,000 for PAN
    :param im_height: image height 6000 for MS 12,000 for PAN
    :return:
    upleft: latitude and longitude of pixel 1,1 in the image
    upright: latitude and longitude of pixel 1,width in the image
    lowleft = latitude and longitude of pixel height,1 in the image
    lowright = latitude and longitude of pixel height,width in the image
    midpoint = latitude and longitude of the center of the image
    view_angles = viewing angles along and across track.
    sat_angles = satellite incidence and azimuth angles
    sun_angles = sun azimuth and elevation angles
    orientation: orientation of the scene.
    """
    str_s = start_sample
    stp_s = start_sample + im_width-1
    mid_s = start_sample + im_width/2-1
    str_l = line1
    stp_l = line1 + im_height-1
    mid_l = line1 + im_height/2-1
    lat_upper_left, lon_upper_left, h_upper_left \
        = dps.findInterSectionPointArrayUsingDEM(image_type, ger_info_prefix, np.array([str_s]),np.array([str_l]),
                                                 date,utc_gps,ut1_utc, dem, dem_interpolation_method)
    #lat_upper_left = lat_upper_left[0]
    #lon_upper_left = lon_upper_left[0]


    lat_upper_right, lon_upper_right, h_upper_right\
        = dps.findInterSectionPointArrayUsingDEM(image_type, ger_info_prefix, np.array([stp_s]),np.array([str_l]),
                                                 date,utc_gps,ut1_utc, dem, dem_interpolation_method)
    #lat_upper_right = lat_upper_right[0]
    #lon_upper_right = lon_upper_right[0]

    lat_lower_left, lon_lower_left, h_lower_left \
        = dps.findInterSectionPointArrayUsingDEM(image_type, ger_info_prefix, np.array([str_s]),np.array([stp_l]),
                                                 date,utc_gps,ut1_utc, dem, dem_interpolation_method)
    #lat_lower_left = lat_lower_left[0]
    #lon_lower_left = lon_lower_left[0]

    lat_lower_right, lon_lower_right, h_lower_right \
        = dps.findInterSectionPointArrayUsingDEM(image_type, ger_info_prefix, np.array([stp_s]),np.array([stp_l]),
                                                 date,utc_gps,ut1_utc, dem, dem_interpolation_method)
    #lat_lower_right = lat_lower_right[0]
    #lon_lower_right = lon_lower_right[0]

    lat_mid, lon_mid, h_mid = dps.findInterSectionPointArrayUsingDEM(image_type, ger_info_prefix, np.array([mid_s]),
                                                                     np.array([mid_l]), date,utc_gps,ut1_utc, dem,
                                                                     dem_interpolation_method)
    #lat_mid = lat_mid[0]
    #lon_mid = lon_mid[0]

    print "(%f,%f)=======(%f,%f)" % (lat_upper_left, lon_upper_left, lat_upper_right, lon_upper_right)
    print "====(%f,%f)====" % (lat_mid, lon_mid)
    print "(%f,%f)=======(%f,%f)" % (lat_lower_left, lon_lower_left, lat_lower_right, lon_lower_right)
    al, al_along, al_across, sat_incidence, sat_azimuth, sat_altitude = dps.findViewingAngles(image_type, ger_info_prefix,
                                                                                                  mid_l, mid_s, date,
                                                                                                  utc_gps, ut1_utc,
                                                                                                  lat_mid, lon_mid)

    print "VIEWING_ANGLE_ALONG_TRACK: %f, VIEWING_ANGLE_ACROSS_TRACK: %f" % (al_along, al_across)
    print "SATELLITE_INCIDENCE_ANGLE: %f, SATELLITE_AZIMUTH_ANGLE: %f, SATELLITE_ALTITUDE: %f" % (
    sat_incidence, sat_azimuth, sat_altitude)
    orientation = dps.findOrientationAngle(image_type, ger_info_prefix,mid_l, date, utc_gps, ut1_utc,
                                           dem, dem_interpolation_method)
    print "SCENE_ORIENTATION: %f" % orientation
    sun_ev, sun_az = dps.findSunAngles(image_type, ger_info_prefix, mid_l, date, utc_gps, ut1_utc, lat_mid,
                                           lon_mid)
    print "SUN_AZIMUTH: %f,SUN_ELEVATION: %f" % (sun_az, sun_ev)

    upleft = [lat_upper_left, lon_upper_left]
    upright = [lat_upper_right, lon_upper_right]
    lowleft = [lat_lower_left, lon_lower_left]
    lowright = [lat_lower_right, lon_lower_right]
    midpoint = [lat_mid, lon_mid]
    view_angles = [al_along, al_across]
    sat_angles = [sat_incidence, sat_azimuth]
    sun_angles = [sun_az, sun_ev]
    return upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles, orientation


def buildLevel1A_MS(ger_dir, cpf_file, band_lines, ger_info_dir, out_dir, dem_type, dem_interp, start_sample=1, im_width=6000,
                    im_height=6000, force_run=False):
    """

    :param ger_dir: sting  of the absolute Directory containing GER file
    :param cpf_file: string of the absolute cpf file name
    :param band_lines: [b1,b2,b3,b4] list of the scan lines corresponding to the first line of the ourput image
    :param ger_info_dir: string of the absolute path to the directory containing all extracted information
    :param out_dir: string of the absolute path to the directory containing all extracted tiff image and previews
    :param dem_dir: string of the absolute path to DEM data
    :param start_sample: Integer indicating the first sample of each line. Default value is 1
    :param im_width: width of the MS image. Default is 6000
    :param im_height: height of the MS image. Default is 60000
    :param force_run: True will force the program to re-extract and create all images again, False will extract file
                      only if the file does not exist.
    :return:
        upleft: lat,lon at pixel (1,1)
        upright: lat, lon at (1, im_width)
        midpoint: lat, lon at (im_height/2,im_width/2)
        lowleft: lat, lon at (im_height,1)
        lowright: lat, lon at (im_height,im_width)
        view_angles: viewing angles along and across track
        sat_angles: satellite incidence and azimuth angles
        sat_altitude: satellite altitude in meters
        sun_angles: sun elevation and azimuth angles
        orientation: scene orientation
    """
    print "Extracting GER file....."
    if dem_type == demservice.SRTM90_DEM:
        dem = demservice.srtm90(dem_directories[dem_type])
    elif dem_type == demservice.GLOBE_DEM:
        dem = demservice.globedem(dem_directories[dem_type])
    elif dem_type == demservice.THEOS_DEM:
        dem = demservice.theosDEM(dem_directories[dem_type])
    elif dem_type == demservice.SRTM30_DEM :
        dem = demservice.srtm30(dem_directories[dem_type])

    date, utc_gps, ut1_utc, ger_prefix,  band_band_lines, band_degraded_lines = \
        createLevel1A_MSImage(out_dir, ger_info_dir, ger_dir, cpf_file, band_lines,
                              dem, dem_interp, start_sample, im_width, im_height, force_run)
    print "file extraction completed."
    print "computing TILE points."
    upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles, orientation = \
        computeDIMAPParameters(ger_prefix, "MS", band_lines[2], date, utc_gps, ut1_utc, dem, dem_interp, start_sample, im_width,
                               im_height)
    print "completed."
    print "Embedding TILE points into theimage file.."
    ms = gdal.Open(out_dir + "/IMAGERY.tif", gdal.GA_Update)
    proj = osr.SpatialReference()
    proj.SetWellKnownGeogCS("EPSG:4326")
    p11 = gdal.GCP()
    p11.GCPLine = 0.5
    p11.GCPPixel = 0.5
    p11.GCPX = upleft[1][0]
    p11.GCPY = upleft[0][0]
    p11.Id = '1'
    p1_6000 = gdal.GCP()
    p1_6000.GCPLine = 0.5
    p1_6000.GCPPixel = float(im_width)-0.5
    p1_6000.GCPX = upright[1][0]
    p1_6000.GCPY = upright[0][0]
    p1_6000.Id = '2'

    p6000_1 = gdal.GCP()
    p6000_1.GCPLine = float(im_height)-0.5
    p6000_1.GCPPixel = 0.5
    p6000_1.GCPX = lowleft[1][0]
    p6000_1.GCPY = lowleft[0][0]
    p6000_1.Id = '4'

    p6000_6000 = gdal.GCP()
    p6000_6000.GCPLine = float(im_height)-0.5
    p6000_6000.GCPPixel = float(im_width)-0.5
    p6000_6000.GCPX = lowright[1][0]
    p6000_6000.GCPY = lowright[0][0]
    p6000_6000.Id = '3'
    ms.SetGCPs([p11, p1_6000, p6000_1, p6000_6000], proj.ExportToWkt())
    import time
    t = time.gmtime()
    metadata = {'TIFFTAG_DATETIME': '%s  ' % time.strftime("%Y%m%d %H:%M:%S", t), 'TIFFTAG_IMAGEDESCRIPTION': 'PAN',
                'AREA_OR_POINT': 'Point'}
    ms.SetMetadata(metadata)
    ms = None
    print "completed."
    return upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles, orientation,\
           band_band_lines, band_degraded_lines


def buildLevel1A_PAN(ger_dir, cpf_file, apf_file, band_line, ger_info_dir, out_dir,  dem_type,
                     dem_interp = demservice.digitalElevationModel.CUBIC, start_sample=1, im_width=12000,
                     im_height=12000, force_run=False):
    """

    :param ger_dir: sting  of the absolute Directory containing GER file
    :param cpf_file: string of the absolute cpf file name
    :param band_line: the scan lines corresponding to the first line of the ourput image
    :param ger_info_dir: string of the absolute path to the directory containing all extracted information
    :param out_dir: string of the absolute path to the directory containing all extracted tiff image and previews
    :param dem_dir: string of the absolute path to DEM data
    :param force_run: True will force the program to re-extract and create all images again, False will extract file
                      only if the file does not exist.
    :return:
        upleft: lat,lon at (1,1)
        upright: lat, lon at (1, 12000)
        midpoint: lat, lon at (6000,6000)
        lowleft: lat, lon at (12000,1)
        lowright: lat, lon at (12000,12000)
        view_angles: viewing angles along and across track
        sat_angles: satellite incidence and azimuth angles
        sat_altitude: satellite altitude in meters
        sun_angles: sun elevation and azimuth angles
        orientation: scene orientation
    """
    if dem_type == demservice.SRTM90_DEM:
        dem = demservice.srtm90(dem_directories[dem_type])
    elif dem_type == demservice.GLOBE_DEM:
        dem = demservice.globedem(dem_directories[dem_type])
    elif dem_type == demservice.THEOS_DEM:
        dem = demservice.theosDEM(dem_directories[dem_type])
    elif dem_type == demservice.SRTM30_DEM :
        dem = demservice.srtm30(dem_directories[dem_type])

    print "GER file extracing......."
    date, utc_gps, ut1_utc, ger_prefix, band_band_lines, band_degraded_lines \
        = createLevel1A_PANImage(out_dir, ger_info_dir, ger_dir, cpf_file, apf_file, band_line,
                                 start_sample=start_sample,im_width= im_width, im_height=im_height, force_run=force_run)
    print "Extraction completed."
    print "computing the TILE points"
    upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles, orientation \
        = computeDIMAPParameters(ger_prefix, "PAN", band_line, date, utc_gps, ut1_utc, dem, dem_interp,
                                 start_sample, im_width,im_height)
    print "completed."
    print "embedded the TILE points into the image file."
    pan = gdal.Open(out_dir + "/IMAGERY.tif", gdal.GA_Update)
    proj = osr.SpatialReference()
    proj.SetWellKnownGeogCS("EPSG:4326")
    # pan.SetProjection(proj.ExportToWkt())
    # geotrans = (0.0, 1.0, 0.0, 0.0, 0.0, 1.0)
    # pan.SetGeoTransform(geotrans)
    p11 = gdal.GCP()
    p11.GCPLine = 0.5
    p11.GCPPixel = 0.5
    p11.GCPX = upleft[1][0]
    p11.GCPY = upleft[0][0]
    p11.Id = '1'

    p1_12000 = gdal.GCP()
    p1_12000.GCPLine = 0.5
    p1_12000.GCPPixel = float(im_width) - 0.5
    p1_12000.GCPX = upright[1][0]
    p1_12000.GCPY = upright[0][0]
    p1_12000.Id = '2'

    p12000_1 = gdal.GCP()
    p12000_1.GCPLine = float(im_height)-0.5
    p12000_1.GCPPixel = 0.5
    p12000_1.GCPX = lowleft[1][0]
    p12000_1.GCPY = lowleft[0][0]
    p12000_1.Id = '4'

    p12000_12000 = gdal.GCP()
    p12000_12000.GCPLine =  float(im_height)-0.5
    p12000_12000.GCPPixel = float(im_width) - 0.5
    p12000_12000.GCPX = lowright[1][0]
    p12000_12000.GCPY = lowright[0][0]
    p12000_12000.Id = '3'
    pan.SetGCPs([p11, p1_12000, p12000_1, p12000_12000], proj.ExportToWkt())
    import time
    t = time.gmtime()
    metadata = {'TIFFTAG_DATETIME': '%s  ' % time.strftime("%Y%m%d %H:%M:%S", t), 'TIFFTAG_IMAGEDESCRIPTION': 'PAN',
                'AREA_OR_POINT': 'Point'}
    pan.SetMetadata(metadata)
    pan = None
    print "completed."
    return upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles, \
           orientation, band_band_lines, band_degraded_lines


def buildLevel1AImage(image_type,ger_directory,cpf_file, apf_file,begin_line,dem_type,info_directory,destination_directory,
                      rev_num, grid_ref, dem_dirs, dem_interpolation=demservice.digitalElevationModel.CUBIC,line_shifted=0,start_sample = 1,
                      im_width=None,im_height = None,force_run= False):
    """
    The main code for building Level2A MS and PAN IMAGE
    :param image_type: "PAN" or "MS"
    :param ger_directory: directory containing ger files
    :param cpf_file: the cpf file associated with GER file
    :param apf_file: the advanced parameter files
    :param begin_line: the first line of the image
    :param dem_type: type of DEM used in the creation of LEVEL 2A product.
    :param info_directory: The directory that is used to stored all extracted data
    :param destination_directory: The output directory
    :param rev_num: revolution number
    :param grid_ref: the grid reference
    :param dem_dirs: dem directories object
    :param dem_interpolation: the interpolation method NEAREST, LINEAR, CUBIC, RBF, KRIGING
    :param line_shifted: "The number of line shifted from the grid
    :param start_sample: The start sample. The default values i one
    :param im_width: Image width 6000 for MS and  12000 for PAN
    :param im_height: Image height6000 for MS and  12000 for PAN
    :param force_run: True to force the system to re-extracting all files.
    :return: None
    """
    job_time = time.time()
    dem_directories[demservice.SRTM90_DEM] = dem_dirs.SRTM90
    dem_directories[demservice.GLOBE_DEM] = dem_dirs.GLOBE
    dem_directories[demservice.THEOS_DEM] = dem_dirs.THEOS
    dem_directories[demservice.SRTM30_DEM] = dem_dirs.SRTM30

    if image_type =="PAN": # PAN IMAGE
        if (im_width is None):
            im_width = 12000
        if (im_height is None):
            im_height = 12000

        if isinstance(begin_line, list):
            if len(begin_line) > 1:
                raise ("begin_line must be one dimension list or an integer!!")
            else:
                begin_line = begin_line[0]
        elif not isinstance(begin_line, int):
            raise ("begin_line must be one dimension list or an integer!!")

        dem_directories[demservice.SRTM90_DEM] = dem_dirs.SRTM90
        dem_directories[demservice.GLOBE_DEM] = dem_dirs.GLOBE
        dem_directories[demservice.THEOS_DEM] = dem_dirs.THEOS

        upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles,\
        orientation, band_band_lines, band_degraded_lines = \
            buildLevel1A_PAN(
                ger_directory, cpf_file, apf_file, begin_line, info_directory, destination_directory, dem_type,
                dem_interp= dem_interpolation, start_sample=start_sample, im_width=im_width, im_height=im_height,
                force_run=force_run)
        angle_list = [upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles,
                      orientation]

        print "Create DIMAP file."
        DIMAP.dimap_create(destination_directory, rev_num, "PAN", grid_ref, [begin_line], info_directory, cpf_file, angle_list,
                           start_sample, im_width, im_height, band_band_lines, band_degraded_lines,
                           line_shifted, job_time)
        print "completed."

    elif image_type == "MS": # MS IMAGE
        if (im_width is None):
            im_width = 6000
        if (im_height is None):
            im_height = 6000
        upleft, upright, midpoint, lowleft, lowright,  view_angles, sat_angles, sat_altitude, sun_angles, \
        orientation, band_band_lines, band_degraded_lines \
            = buildLevel1A_MS(ger_directory, cpf_file, begin_line, info_directory, destination_directory,
                                      dem_type, dem_interp= dem_interpolation, start_sample=start_sample,
                                      im_width=im_width, im_height=im_height, force_run=force_run)

        angle_list = [upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles,
                      orientation]
        print "completed."
        DIMAP.dimap_create(destination_directory, rev_num, "MS", grid_ref, begin_line, info_directory, cpf_file, angle_list,
                           start_sample, im_width, im_height, band_band_lines, band_degraded_lines, line_shifted,
                           job_time)
    else:
        print "Invalid image type"
        exit(1)
    job_time2 = time.time()
    print "Total Prpcessing time is %f s." % (job_time2 - job_time)


if __name__ == "__main__":
    EXAMPLE = "MS"
    #im_file = r"D:\level1A_development\Image Level 1A\03122013_Rev27231\11-TH_CAT_131203111611763_1_1P_S820391_Rev27231_03Dec2013\TH_CAT_131203111611763_1\IMAGERY.TIF"
    #previewfile = r"D:\level1A_development\Image Level 1A\03122013_Rev27231\11-TH_CAT_131203111611763_1_1P_S820391_Rev27231_03Dec2013\TH_CAT_131203111611763_1\PREVIEW2.JPG"
    #iconfile = r"D:\level1A_development\Image Level 1A\03122013_Rev27231\11-TH_CAT_131203111611763_1_1P_S820391_Rev27231_03Dec2013\TH_CAT_131203111611763_1\PREVIEW2.JPG"
    #createPreview(im_file, previewfile, iconfile, 1000, 1000)
    #exit()

    if pc:
        apf_file = r"D:\level1A_development\THEOS_nominal.APF"
    else:
        apf_file = "C:\Users\SURFACE\Google Drive\woks\level2a\THEOS_nominal.APF"#  r"D:\level1A_development\THEOS_nominal.APF" #r"C:\Users\SURFACE\Google Drive\woks\level2a\THEOS_nominal.APF" #  #r"C:\Users\SURFACE\Google Drive\woks\level2a\THEOS_nominal.APF" # r"D:\level1A_development\THEOS_nominal.APF" #r"C:\Users\SURFACE\Google Drive\woks\level2a\THEOS_nominal.APF"  # absolute location of apf file
    dem_dir = r"D:\dem\globe"  #r"D:\globedem"  #r"D:\level1A_development\srtm\gls"# r"D:\dem\globe" #r"D:\globedem" #  ### r"D:\level1A_development\srtm\gls"
    job_time = time.time()
    if EXAMPLE == "PAN":
        ger_dir = r"D:\THEOS_37591_CASE_city\GEARL_PAN" # r"D:\THEOS_1_LEVEL0_1_111041472_41472_PAN_PB_TOP_1_15_2016-09-01_05-11-01" # directory of ger file
        cpf_file = r"D:\THEOS_37591_CASE_city\THEOS_1_20151118_000000_20151126_000000.CPF"#  r"D:\THEOS_1_LEVEL0_1_111041472_41472_PAN_PB_TOP_1_15_2016-09-01_05-11-01\THEOS_1_20160830_000000_20160901_000000.CPF"
      # absolute location of cpf file

        bandline = 5594# begining line of PAN image
        start_sample = 1
        im_width = 12000
        im_height = 12000
        ger_info_dir = ger_dir + "/info"
        # absolute directory containing all extracted information from ger files.
        out_dir = ger_dir + "/level1a"
        # absolute director containing final image

        # absolute directory containing dem files.
        upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles, orientation, \
        band_band_lines, band_degraded_lines = buildLevel1A_PAN(
            ger_dir, cpf_file, apf_file, bandline, ger_info_dir, out_dir, dem_type=demservice.THEOS_DEM,
            dem_interp= demservice.digitalElevationModel.CUBIC, start_sample= start_sample, im_width = im_width,
            im_height=im_height, force_run=False)
        angle_list = [upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles,
                      orientation]
        rev_num = "37719"
        grid_ref = "0373-0413"
        line_shifted = 0

        print "Create DIMAP file."
        DIMAP.dimap_create(out_dir, rev_num, "PAN", grid_ref, [bandline], ger_info_dir, cpf_file, angle_list,
                            start_sample,im_width,im_height,band_band_lines, band_degraded_lines ,
                            line_shifted,job_time)
        print "completed."
        #im1 = display.displayRMImage(out_dir + "/IMAGERY.tif", win_name="PAN")
        # im.displayWhole([1,2,3],scale=20)
        #im1.band_list = [1, 1, 1]
        #im1.start()
    elif EXAMPLE == "MS":
        ger_dir = r"D:\THEOS_37591_CASE_city\GERAL_MS"  # directory of ger file
        cpf_file = r"D:\THEOS_37591_CASE_city\THEOS_1_20151118_000000_20151126_000000.CPF"
        #cpf_file = r"D:\Data2APanSharpen\Level 2A - SIPROS\THEOS_1_20160830_000000_20160901_000000.CPF"

        bandlines =  [373 , 435 , 497 , 559] #[4642, 4695,  4755, 4816]  #begining line of MS image
        org_bandlines = [bandlines[0],bandlines[1],bandlines[2],bandlines[3]]

        start_sample = 1
        im_width = 6000
        im_height = 6000

        ger_info_dir = ger_dir + "/info" #"/info"
        # absolute directory containing all extracted information from ger files.
        out_dir = ger_dir + "/level1a"
        # absolute director containing final image

        # absolute directory containing dem files.

        print bandlines

        upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles, orientation,\
        band_band_lines, band_degraded_lines = buildLevel1A_MS(ger_dir, cpf_file, bandlines, ger_info_dir, out_dir,
                                                               dem_type= demservice.THEOS_DEM,
                                                               dem_interp= demservice.digitalElevationModel.CUBIC,
                                                               start_sample = start_sample,im_width= im_width,
                                                               im_height = im_height, force_run=False)

        angle_list = [upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles,
                      orientation]
        print "completed."
        #im1 = display.displayRMImage(out_dir + "/IMAGERY.tif", win_name="MS")
        # im.displayWhole([1,2,3],scale=20)
        rev_num = "41472"
        grid_ref = "0086-0246"
        print "creating DIMAP"
        line_shifted = 0
        print bandlines
        DIMAP.dimap_create(out_dir, rev_num, "MS", grid_ref, org_bandlines, ger_info_dir, cpf_file, angle_list,
                            start_sample,im_width,im_height,band_band_lines, band_degraded_lines,line_shifted,job_time)

        #im1.band_list = [1, 2, 3]
        #im1.start()
