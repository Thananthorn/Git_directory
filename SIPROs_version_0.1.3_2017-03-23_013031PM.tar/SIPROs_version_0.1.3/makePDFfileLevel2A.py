"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import numpy as np
import lxml.etree as et
import os
import shutil
def make_init_part(date):
    # 1. date = [year, month, day]
# 2. sat_id = 1
# 3. time = [hour,minute,second]
# 4. icon_name = icon file name
# 5. logo_nbame = logo file name
# 6. k k grid
# 7. j j grid
# 8. line_shift: shift line of band ref
    initial_part = """
\\documentclass[english]{article}
\\usepackage{mathptmx}
\\renewcommand{\\familydefault}{\\rmdefault}
\\usepackage[T1]{fontenc}
\\usepackage[latin9]{inputenc}
\\usepackage[a4paper]{geometry}
\\geometry{verbose,tmargin=3cm,bmargin=3cm,lmargin=2.5cm,rmargin=2.5cm,headheight=1cm,headsep=2cm,footskip=1cm}
\\setcounter{secnumdepth}{3}
\\setcounter{tocdepth}{3}
\\usepackage{array}
\\usepackage{url}
\\usepackage{multirow}
\\usepackage{graphicx}
\\makeatletter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% LyX specific LaTeX commands.
%% Because html converters don't know tabularnewline
\\providecommand{\\tabularnewline}{\\\\}

\\usepackage{beamerarticle,pgf}
% this default might be overridden by plain title style
\\newcommand\\makebeamertitle{\\frame{\\maketitle}}%
\\AtBeginDocument{
\\let\\origtableofcontents=\\tableofcontents
\\def\\tableofcontents{\\@ifnextchar[{\\origtableofcontents}{\\gobbletableofcontents}}
\\def\\gobbletableofcontents#1{\\origtableofcontents}
}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% User specified LaTeX commands.
\\usepackage{color}
\\usepackage{fancyhdr}
\\pagestyle{fancy} \n
"""
    initial_part += "\\cfoot{(c) GISTDA - %d}\n"%date[0]
    initial_part += """

\\makeatother

\\usepackage{babel}

"""
    return initial_part

def make_preview_table(icon_file,sat_id,product_level,logo_file,date, time,k,j,line_shifted):
    preview_table = """
\\begin{document}
\\begin{center}
{\\huge THEOS-1 DIMAP product data-sheet}
\\par\\end{center}

\\begin{tabular*}{6in}{@{\\extracolsep{\\fill}}|cccc|}
\\hline \n""" +"\\multirow{7}{*}{\\includegraphics[width=2.5cm]{%s}} & Type & THEOS %d SCENE %s & \\multirow{7}{*}" \
               "{\\includegraphics[width=4.5cm]{%s}}\\tabularnewline \n"%(icon_file,sat_id,product_level,logo_file) +\
                    " & \\multirow{3}{*}{Layer} & \\multirow{2}{*}{SCENE T %d M %d/%02d/%02d} & \\tabularnewline \n"%(sat_id,date[0],date[1],date[2]) + \
                    " &  &  & \\tabularnewline \n" +" &  & %02d:%02d:%02.1f %04d-%04d %d & \\tabularnewline \n"%(time[0],time[1],time[2],k,j,line_shifted) +\
        """
 &  &  & \\tabularnewline
 & Format & DIMAP & \\tabularnewline
 & Raster & GEOTIFF & \\tabularnewline
\\hline
\\end{tabular*}

    """
    return preview_table

def make_gen_info_table(sat_id,date,time,k,j,line_shifted):
    gen_info = """
    \\medskip{}


\\begin{tabular*}{6in}{@{\\extracolsep{\\fill}}|cc|}
\\hline
\\multicolumn{2}{|c|}{General Information}\\tabularnewline
\\hline
\\hline """ + "Map Name & SCENE T%d M %02d/%02d/%02d %02d:%02d:%02.1f %04d-%04d %d\\tabularnewline"%(sat_id,date[0],date[1],date[2], time[0],time[1],time[2],k,j,line_shifted) + \
        """
Geometric Processing Level & CARTO\\tabularnewline
Radiometric Processing Level & SYSTEM\\tabularnewline
\\hline
\\end{tabular*}
"""
    return gen_info

def make_im_demension_table(width,height,nband) :
    im_dem = """
    \\medskip{}


\\begin{tabular*}{6in}{@{\\extracolsep{\\fill}}|cc|}
\\hline
\\multicolumn{2}{|c|}{Image dimensions}\\tabularnewline
\\hline
\\hline """ + "Number of pixels per line & %d\\tabularnewline \n"%(width) + \
        "Number of lines & %d \\tabularnewline \n"%(height) + \
        "Number of spectral bands &%d\\tabularnewline \n"%(nband) + """
\\hline
\\end{tabular*}
    """
    return im_dem

def make_daateset_framing_table(upleft,upright,lowleft,lowright,center,width,height):
    def deg_lat(lat) :
        txt = ""
        h = int(lat)
        if h >= 0:
            txt = "N%d\\textdegree"%h
        else:
            h = -h
            lat = -lat
            txt = "S%d\\textdegree"%(h)
        lat = lat-h
        m = int(lat*60)
        txt = txt+"%02d'"%(m)
        lat = (lat*60-m)*60
        sec = int(round(lat,0))
        txt = txt+"%02d''"%(sec)
        return txt
    def deg_lon(lon) :
        txt = ""
        h = int(lon)
        if h >= 0:
            txt = "E%d\\textdegree"%h
        else:
            h = -h
            lon = -lon
            txt = "W%d\\textdegree"%h
        lon = lon-h
        m = int(lon*60)
        txt = txt+"%02d'"%m
        lon = (lon*60-m)*60
        sec = int(round(lon,0))
        txt = txt+"%02d''"%sec
        return txt
    dateset = """

\\medskip{}


\\begin{tabular*}{6in}{@{\\extracolsep{\\fill}}|ccccc|}
\\hline
\\multicolumn{5}{|c|}{Dataset framing}\\tabularnewline
\\hline
\\hline
Corner & Longitude (DEG) & Latitude (DEG) & Line & Pixel\\tabularnewline \n""" +\
        "\\#1 &"+deg_lon(upleft[3])+"&" +deg_lat(upleft[2])+" & %d & %d\\tabularnewline \n"%(upleft[0],upleft[1]) +\
        "\\#2 &"+deg_lon(upright[3])+"&" +deg_lat(upright[2])+" & %d & %d\\tabularnewline \n"%(upright[0],upright[1]) +\
        "\\#3 &"+deg_lon(lowleft[3])+"&" +deg_lat(lowleft[2])+" & %d & %d\\tabularnewline \n"%(lowleft[0],lowleft[1]) +\
        "\\#4 &"+deg_lon(lowright[3])+"&" +deg_lat(lowright[2])+" & %d & %d\\tabularnewline \n"%(lowright[0],lowright[1]) +\
        "Center &"+deg_lon(center[3])+"&" +deg_lat(center[2])+" & %d & %d\\tabularnewline \n"%(center[0],center[1]) +\
        """
\\hline
\\end{tabular*}
"""
    return dateset


def make_datesource_table(sat_id, date, time, k,j, line_shifted,instrument,sensor,sat_angl,view_ang,sun_ang):
    sat_inc = sat_angl[0]
    sat_az = sat_angl[1]
    viewalong = view_ang[0]
    viewacross = view_ang[1]
    sun_az = sun_ang[0]
    sun_ele = sun_ang[1]
    scene_name = "SCENE T%d M %d/%02d/%02d %02d:%02d:%02.1f %04d-%04d %d " \
                "\n"%(sat_id,date[0],date[1],date[2],time[0],time[1],time[2],k,j,line_shifted)
    datasource = """
    \\medskip{}


\\begin{tabular*}{6in}{@{\\extracolsep{\\fill}}|lc|}
\\hline
\\multicolumn{2}{|c|}{Dataset Sources}\\tabularnewline
\\hline
\\hline \n""" + "\\multicolumn{2}{|l|}{"+scene_name+"}\\tabularnewline " + \
                 "Id & "+ scene_name+ "\\tabularnewline \n" +\
                 "K-J & %04d-%04d\\tabularnewline\n"%(k,j) + \
                 "Line shift & %d\\tabularnewline \n"%(line_shifted) + \
                 "Date & %d-%02d-%02d\\tabularnewline\n"%(date[0],date[1],date[2]) + \
                 "Time & %02d:%02d:%02f\\tabularnewline\n"%(time[0],time[1],time[2]) + \
                 "Instrument & %s\\tabularnewline \n"%instrument + "Sensor & %s\\tabularnewline\n"%sensor +\
                 "Satellite incidence angle & %f\\tabularnewline\n"%(sat_inc) +\
                 "Satellite azimuth angle & %f\\tabularnewline\n"%(sat_az) +\
                 "Viewing angle along track & %f\\tabularnewline \n"%(viewalong) +\
                 "Viewing angle across track & %f \\tabularnewline\n"%(viewacross) + \
                 "Sun azimuth & %f\\tabularnewline \n"%(sun_az) +\
                 "Sun elevation & %f\\tabularnewline\n"%(sun_ele) + """
\\hline
\\end{tabular*}\\medskip{}


    """
    return datasource

def make_datastrip_file(sensor, data_strip_id,file_name,rev_num, cpf_file_name,gnums, pgains,pbiases):
    if data_strip_id.find("_") :
        data_strip_id = data_strip_id.replace("_","\\_")
    if cpf_file_name.find("_"):
        cpf_file_name = cpf_file_name.replace("_","\\_")
    if sensor == "MS":
        data_strip = """

\\newpage{}

\\begin{center}
{\\huge THEOS-1 DIMAP product data-sheet}
\\par\\end{center}

\\begin{tabular*}{6in}{@{\\extracolsep{\\fill}}|cc|}
\\hline
\\multicolumn{2}{|c|}{Data Strip/ Calibration}\\tabularnewline
\\hline
\\hline  """
        data_strip += "Data Strip id & " + data_strip_id +" \\tabularnewline \n" + \
        "Filename & %s \\tabularnewline\n"%file_name + \
        "Revolution number & %d\\tabularnewline\n"%rev_num +\
        "Calibration type & NOMINAL\\tabularnewline\n" +\
        "Calibration filename &" + cpf_file_name+ "\\tabularnewline\n"
        data_strip += """
        \\cline{2-2}
        \\multicolumn{1}{|c|}{\\multirow{16}{*}{BAND DESCRIPTION}} & \\color{blue} Band BLUE\\tabularnewline
    \\cline{2-2}"""
        data_strip += " & \\color{black}Gain number : %d\\tabularnewline  &"%gnums[0]+ \
                     " Physical Gain : %1.17e\\tabularnewline\n"%pgains[0] + " & Physical Bias : %1.17e\\tabularnewline\n"%pbiases[0] +\
                     """\\cline{2-2}
     & \\color{green}Band GREEN\\tabularnewline
    \\cline{2-2}"""
        data_strip += "& \\color{black}Gain number : %d\\tabularnewline\n"%gnums[1] +\
        "& Physical Gain :%1.17e\\tabularnewline\n"%pgains[1] + \
        "& Physical Bias : %1.17e\\tabularnewline"%pbiases[1] + """\\cline{2-2}
     & \\color{red} Band RED\\tabularnewline
    \\cline{2-2} """
        data_strip += "& \\color{black}Gain number : %d\\tabularnewline\n"%gnums[2] + \
        "& Physical Gain : %1.17e\\tabularnewline\n"%(pgains[2]) + \
        "& Physical Bias : %1.17e\\tabularnewline\n"%(pbiases[2]) +"""
        \\cline{2-2}
     & Band NIR\\tabularnewline
    \\cline{2-2}"""
        data_strip +=" & Gain number : %d\\tabularnewline\n"%gnums[3] +\
        "& Physical Gain : %1.17e\\tabularnewline\n"%pgains[3] +\
        " & Physical Bias : %1.17e\\tabularnewline \n"%pbiases[3] +"""
\\hline
\\end{tabular*}
"""
    elif sensor == "PAN" :
        data_strip = """

\\newpage{}

\\begin{center}
{\\huge THEOS-1 DIMAP product data-sheet}
\\par\\end{center}

\\begin{tabular*}{6in}{@{\\extracolsep{\\fill}}|cc|}
\\hline
\\multicolumn{2}{|c|}{Data Strip/ Calibration}\\tabularnewline
\\hline
\\hline  """
        data_strip += "Data Strip id & " + data_strip_id +" \\tabularnewline \n" + \
        "Filename & %s \\tabularnewline\n"%file_name + \
        "Revolution number & %d\\tabularnewline\n"%rev_num +\
        "Calibration type & NOMINAL\\tabularnewline\n" +\
        "Calibration filename &" + cpf_file_name+ "\\tabularnewline\n"
        data_strip += """
        \\cline{2-2}
        \\multicolumn{1}{|c|}{\\multirow{4}{*}{BAND DESCRIPTION}} & Band Panchromatic\\tabularnewline
    \\cline{2-2}"""
        data_strip += " & \\color{black}Gain number : %d\\tabularnewline  &"%gnums[0]+ \
                     " Physical Gain : %1.17e\\tabularnewline\n"%pgains[0] + " & Physical Bias : %1.17e\\tabularnewline\n"%pbiases[0] +\
        """
\\hline
\\end{tabular*}
"""
    return data_strip

def make_produc_file(proc_date,job_id,prod_type,producer,prod_url):
    job_id = job_id.replace("_","\_")
    product = """
    \\medskip{}
\\begin{tabular*}{6in}{@{\\extracolsep{\\fill}}|cc|}
\\hline
\\multicolumn{2}{|c|}{Production}\\tabularnewline
\\hline
\\hline
Production Date & """ +proc_date +"\\tabularnewline \n" + \
              "Job identification & "+job_id+ "\\tabularnewline\n" + \
              "Product type identification & "+prod_type +"\\tabularnewline \n" + \
              "Dataset Producer Identification & "+ producer +"\\tabularnewline \n " +\
              "Producer link & \\color{blue}\\url{"+prod_url+"}\\tabularnewline \n "+ """
\\hline
\\end{tabular*}
"""
    return product
def make_latex_file(date,time,sat_id,icon_name, logo_name,k,j,line_shifted, tilepoints,instrument,sensor,
                    sat_ang,view_ang,sun_ang,data_strip_id,file_name,rev_num,cpf_file_name,gnums,pgains,pbiases,
                    proc_date,job_id,prod_type,producer,prod_url,horizon_cs_name, quick_look_file):
    coord_ref = """

\\medskip{}


\\begin{tabular*}{6in}{@{\\extracolsep{\\fill}}|cc|}
\\hline 
\\multicolumn{2}{|c|}{Coordinate Reference System}\\tabularnewline
\\hline 
\\hline 
\\textit{Horizontal Coordinate System} & \\ \\tabularnewline
Geocoding tables identification & EPSG(5.2)\\tabularnewline
Horizontal Coordinate System type & PROJECTED\\tabularnewline
Horizontal coordinate system identification name &""" +horizon_cs_name +"""\\tabularnewline
\\textit{Geographic Coordinate System} & \\ \\tabularnewline
\\hline 
\\end{tabular*}
"""
    rest = """

\\newpage{}

\\begin{center}
{\\huge THEOS-1 DIMAP product data-sheet}
\\par\\end{center}

\\begin{tabular}{|c|}
\\hline 
Quicklook\\tabularnewline
\\hline 
\\hline 
\\includegraphics[width=6in]{""" +quick_look_file +"""}\\tabularnewline
\\hline 
\\end{tabular}
\\end{document}
    """
    upleft = tilepoints[0]
    upright  =tilepoints[1]
    lowleft = tilepoints[2]
    lowright = tilepoints[3]
    center = tilepoints[4]
    width = tilepoints[3][1]
    height = tilepoints[3][0]
    init_part = make_init_part(date)
    preview = make_preview_table(icon_name,sat_id,"level 2A",logo_name,date, time,k,j,line_shifted)
    gen_info = make_gen_info_table(sat_id,date,time,k,j,line_shifted)
    if sensor == "MS":
        im_dem = make_im_demension_table(width,height,4)
    elif sensor == "PAN" :
        im_dem = make_im_demension_table(width,height,1)
    dateset = make_daateset_framing_table(upleft,upright,lowleft,lowright,center,width,height)
    datesource = make_datesource_table(sat_id, date, time, k,j, line_shifted,instrument,sensor,sat_ang,view_ang,sun_ang)
    datastrip = make_datastrip_file(sensor, data_strip_id,file_name,rev_num, cpf_file_name,gnums, pgains,pbiases)
    product = make_produc_file(proc_date,job_id,prod_type,producer,prod_url)
    out = init_part + preview + gen_info + im_dem + dateset + datesource +  datastrip + coord_ref + product+ rest
    return out

def make_pdf_file(dimapfile,pdf_dir):
    #dimapfile = r"C:\LEVEL0\Image Level 1A\02012015_Rev32837\6-TH_CAT_150102050901960_1_1M_S972591_Rev32837_02Jan2015\TH_CAT_150102050901960_1\METADATA.DIM"
    ettree = et.parse(dimapfile)
    shutil.copy("/home/sipros/Application_1A_2A/Sipros_System/CODE/SIPROs_version_0.1.3/LOGO.JPG",pdf_dir)
    date_et = ettree.find("./Dataset_Sources/Source_Information/Scene_Source/IMAGING_DATE")
    imaging_date_str= date_et.text.split("-")
    year = int(imaging_date_str[0])
    month = int(imaging_date_str[1])
    day  = int(imaging_date_str[2])
    date=[year,month,day]
    time_et = ettree.find("./Dataset_Sources/Source_Information/Scene_Source/IMAGING_TIME")
    time_st  = time_et.text.split(":")
    hour = int(time_st[0])
    minute = int(time_st[1])
    sec = float(time_st[2])
    time = [hour,minute,sec]
    mission = ettree.find("./Dataset_Sources/Source_Information/Scene_Source/MISSION_INDEX")
    sat_id = int(mission.text)
    icon = ettree.find("./Dataset_Id/DATASET_TN_PATH")
    icon_name = icon.get("href")
    logo_name = "LOGO.JPG"
    grid = ettree.find("./Dataset_Sources/Source_Information/Scene_Source/GRID_REFERENCE")
    grid_ref = grid.text.split("-")
    k = int(grid_ref[0])
    j = int(grid_ref[1])
    shift  = ettree.find("./Dataset_Sources/Source_Information/Scene_Source/SHIFT_VALUE")
    line_shift = int(shift.text)
    vertexes = ettree.findall("Dataset_Frame/Vertex")
    tilepoints =[]
    for vertex in vertexes:
        lon = float(vertex.find("FRAME_LON").text)
        lat = float(vertex.find("FRAME_LAT").text)
        row = int(vertex.find("FRAME_ROW").text)
        col = int(vertex.find("FRAME_COL").text)
        tilepoints.append([row,col,lat,lon])
    center = ettree.find("Dataset_Frame/Scene_Center")
    lon = float(center.find("FRAME_LON").text)
    lat = float(center.find("FRAME_LAT").text)
    row = int(center.find("FRAME_ROW").text)
    col = int(center.find("FRAME_COL").text)
    tilepoints.append([row,col,lat,lon])

    #upleft = [17.710803, 99.248840]
    #upright = [17.560718, 100.212988]
    #lowleft = [16.948982, 99.075274]
    #lowright = [16.798716, 100.035735]
    #center = [17.253848,99.648618]
    #tilepoints = [upleft,upright,lowleft,lowright,center]
    instrument_et = ettree.find("./Dataset_Sources/Source_Information/Scene_Source/INSTRUMENT")
    instrument = instrument_et.text
    instrument_id = ettree.find("./Dataset_Sources/Source_Information/Scene_Source/INSTRUMENT_INDEX")
    instrument += instrument_id.text
    imag_mode = ettree.find("./Dataset_Sources/Source_Information/Scene_Source/IMAGING_MODE")
    sensor = imag_mode.text
    sat_incidence = ettree.find("./Dataset_Sources/Source_Information/Scene_Source/SATELLITE_INCIDENCE_ANGLE")
    sat_azimuth = ettree.find("./Dataset_Sources/Source_Information/Scene_Source/SATELLITE_AZIMUTH_ANGLE")
    sat_ang = [float(sat_incidence.text),float(sat_azimuth.text)]
    view_along = ettree.find("./Dataset_Sources/Source_Information/Scene_Source/VIEWING_ANGLE_ALONG_TRACK")
    view_across = ettree.find("./Dataset_Sources/Source_Information/Scene_Source/VIEWING_ANGLE_ACROSS_TRACK")
    view_ang = [float(view_along.text),float(view_across.text)]
    sun_az = ettree.find("./Dataset_Sources/Source_Information/Scene_Source/SUN_AZIMUTH")
    sun_ele = ettree.find("./Dataset_Sources/Source_Information/Scene_Source/SUN_ELEVATION")
    sun_ang = [float(sun_az.text),float(sun_ele.text)]
    data_strip_id = ettree.find("./Data_Strip/Data_Strip_Identification/DATA_STRIP_ID").text
    file_name = ettree.find("./Data_Strip/Data_Strip_Identification/FILE_NAME").text
    rev_num =int(ettree.find("./Dataset_Sources/Source_Information/Scene_Source/REVOLUTION_NUMBER").text)
    cpf_file_name = ettree.find("Data_Strip/Sensor_Calibration/Calibration/CALIBRATION_FILENAME").text
    band_infos = ettree.findall("Data_Strip/Sensor_Calibration/Calibration/Band_Parameters")
    if sensor == "MS":
        gnums = np.zeros((4,),'int32')
        pgains = np.zeros((4,),'float64')
        pbiases = np.zeros((4,),'float64')
    elif sensor == "PAN":
        gnums = np.zeros((1,),'int32')
        pgains = np.zeros((1,),'float64')
        pbiases = np.zeros((1,),'float64')

    for band_info in band_infos:
        id = int(band_info.find("BAND_INDEX").text)-1
        gnums[id] = int(band_info.find("Gain_Section_List/Gain_Section/GAIN_NUMBER").text)
        pgains[id] = float(band_info.find("Gain_Section_List/Gain_Section/PHYSICAL_GAIN").text)
        pbiases[id]= float(band_info.find("Gain_Section_List/Gain_Section/PHYSICAL_BIAS").text)
    #gnums = [6,6,6,4]
    #pgains= [2.9370599999999998,3.00142, 3.42038,1.67119]
    #pbiases = [0,0,0,0]
    proc_date = ettree.find("Production/DATASET_PRODUCTION_DATE").text
    job_id = ettree.find("Production/JOB_ID").text
    prod_type = ettree.find("Production/PRODUCT_TYPE").text
    producer = ettree.find("Production/DATASET_PRODUCER_NAME").text
    prod_url = ettree.find("Production/DATASET_PRODUCER_URL").get("href")
    horizon_cs_name = ettree.find("Coordinate_Reference_System/Horizontal_CS/HORIZONTAL_CS_NAME").text
    quick_look_file  =ettree.find("Dataset_Id/DATASET_QL_PATH").get("href")

    txt = make_latex_file(date,time,sat_id,icon_name, logo_name,k,j,line_shift,tilepoints,instrument,sensor,sat_ang,
                          view_ang,sun_ang,data_strip_id,file_name,rev_num,cpf_file_name,gnums,pgains,pbiases,
                          proc_date,job_id,prod_type,producer,prod_url,horizon_cs_name, quick_look_file)

    with open(pdf_dir+"/"+job_id+".tex","w") as fp:
        fp.write(txt)
        fp.close()
    os.chdir(pdf_dir)
    command = "pdflatex %s"%(job_id+".tex")
    # open this if windows 
    # os.system("del *.tex")
    # os.system("del *.log")
    # os.system("del *.aux")

    # open this if windows 
    os.system("rm *.tex")
    os.system("rm *.log")
    os.system("rm *.aux")

if __name__ == "__main__":
    dimap_file = r"C:\LEVEL0\Image Level 1A\02012015_Rev32837\6-TH_CAT_150102050901960_1_1M_S972591_Rev32837_02Jan2015\TH_CAT_150102050901960_1\METADATA.DIM"
    out_dir  = r"C:\LEVEL0\Image Level 0\2015-01-02_REV32837\THEOS_1_LEVEL0_1_111032837_32837_MS_PB_TOP_2_8_2015-01-02_03-26-33\output"
    make_pdf_file(dimap_file,out_dir)