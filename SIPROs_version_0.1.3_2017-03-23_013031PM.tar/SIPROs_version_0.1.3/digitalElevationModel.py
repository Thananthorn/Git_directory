"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

 """

import numpy as np
from osgeo import gdal
import scipy.interpolate as interp
import scipy.optimize as opt
import cv2
import os


THEOS_DEM = "THEOS"
GLOBE_DEM = "GLOBE"
SRTM90_DEM = "SRTM90"
SRTM30_DEM = "SRTM30"

# geoid_file = "/home/asuna/workspace/2017-03-19_114627/SIPROs_version_0.1.3/geoid/GEOID.DEM"

# geoid_file = "C:/Worker/Support-Worker/Sipros_system/CODE/workspace/SIPROs_version_0.1.3/geoid/GEOID.DEM"

geoid_file = "/home/sipros/Application_1A_2A/Sipros_System/CODE/SIPROs_version_0.1.3/geoid/GEOID.DEM"

def rbfInterpolate(xout,yout, x,y,z,basisfunction):
    N = z.size
    if z.ndim > 1:
        x = x.flatten()
        y = y.flatten()
        z = z.flatten()
    xi = np.zeros((2, N))
    xi[0,:] = x
    xi[1,: ] = y
    x1 = xi[..., :, np.newaxis]
    x2 = xi[..., np.newaxis, :]
    r  = np.sqrt(((x1 - x2)**2).sum(axis=0))

    ximax = np.amax(xi, axis=1)
    ximin = np.amin(xi, axis=1)
    edges = ximax - ximin
    edges = edges[np.nonzero(edges)]
    epsilon = np.power(np.prod(edges) / N, 1.0 / edges.size)
    smooth = 0.1
    A = basisfunction(r, epsilon) - np.eye(N) * smooth
    nodes = np.linalg.solve(A, z)
    num_out = xout.size
    k_step = num_out/1000
    out = np.zeros((num_out))

    if num_out > 0:
        step_size = min(max(1024 * 1024 * 800 / (8 * N), 1), num_out)
        num_step = num_out / step_size
    for k in range(num_step + 1):
        num = min(step_size,num_out - k*step_size)
        str = k*step_size
        stp = str + num
        xa = np.zeros((2,num))
        xa[0, :] = xout[str:stp]
        xa[1, :] = yout[str:stp]
        x1 = xa[..., :, np.newaxis]
        r = np.sqrt(((x1 - x2) ** 2).sum(axis=0))
        out[str:stp] = np.dot(basisfunction(r, epsilon), nodes).reshape(num)
    return out

def gaussian(r, epsilon):
    return np.exp(-(1.0 / (epsilon) * r) ** 2)
def multiquadric(r, epsilon):
    return np.sqrt((1.0/epsilon*r)**2 + 1)

def inverse_multiquadric( r, epsilon):
    return 1.0/np.sqrt((1.0/epsilon*r)**2 + 1)

def linear(r,  epsilon):
    return r

def cubic(r,  epsilon):
    return r**3

def quintic(r, epsilon):
    return r**5


class krigingInterpolation:
    def __init__(self,x,y,z):
        z = z.astype('float64')
        N = z.size
        xi = np.zeros((2, N))
        if z.ndim == 2:
            x = x.flatten()
            y = y.flatten()
            z = z.flatten()
        xi[0, :] = x
        xi[1, :] = y
        self.xi = xi
        self.z = z
        x1 = xi[..., :, np.newaxis]
        x2 = xi[..., np.newaxis, :]
        d = np.sqrt(((x1 - x2) ** 2).sum(axis=0))
        ximax = d.max()
        ximin = d.min()
        edges = ximax - ximin
        sample_size = int(np.sqrt(N))
        epsilon = edges / sample_size
        hs = d.max() * np.arange(0, 21).astype('float64') / sample_size
        sv = SV(x, y, z, hs, epsilon/4.0 )
        h = sv[0,:]
        semivar = sv[1,:]
        c0 = z.var()
        error_min = 1e100
        errs = dict()
        print "Find the best semivariogram model"
        for semivarfunc in [spherical, gaussiansv, exponential, powersv]:
            a0 = self.findBestParam(h,c0,semivar,semivarfunc)
            y = semivarfunc(h,a0,c0)
            err = np.sqrt(((y-semivar)**2).mean())
            errs[err] = [semivarfunc, a0]
        sorted_errors = sorted(list(errs))
        find_propermodel = False
        for key  in sorted_errors:
            semimodel, abest = errs[key]
            data_cov = np.zeros((N + 1, N + 1))
            data_cov[:-1, :-1] = c0 - semimodel(d, abest, c0)
            data_cov[:-1, -1] = 1.0
            data_cov[-1, :-1] = 1.0
            if np.linalg.matrix_rank(data_cov) == data_cov.shape[0]:
                self.data_icov = np.linalg.inv(data_cov)
                self.semivarr_model = semimodel
                self.a0 = abest
                self.c0 = c0
                find_propermodel = True
                break
        if find_propermodel:
            print "The " + self.semivarr_model.__name__ + " is chosen with a = %f and c0 =%f." %(self.a0, c0)
        else:

            c0 = semivar.max()
            print "Warning: The matrix is singular!"
            print "Increase covariance"
            a0 = self.findBestParam(h, c0, semivar, spherical)
            data_cov = np.zeros((N + 1, N + 1))
            data_cov[:-1, :-1] = c0 - spherical(d, a0, c0)
            data_cov[:-1, -1] = 1.0
            data_cov[-1, :-1] = 1.0
            if np.linalg.matrix_rank(data_cov) == data_cov.shape[0]:
                print "Successful"
                self.data_icov = np.linalg.inv(data_cov)
                self.semivarr_model = spherical
                self.a0 = a0
                self.c0 = c0

            else:
                print "add identity matrix"
                data_cov[:-1, :-1] = c0 - spherical(d, a0, c0) + (1e-6)*np.eye(N)
                data_cov[:-1, -1] = 1.0
                data_cov[-1, :-1] = 1.0
                self.data_icov = np.linalg.inv(data_cov)
                self.semivarr_model = spherical
                self.a0 = a0
                self.c0 = c0
                self.data_icov = np.linalg.inv(data_cov)




    def eval(self,x,y):
        N = x.size
        out = np.zeros((N))
        if N > 0:
            if self.data_icov is not None:
                M = self.xi.shape[1]
                x1 = self.xi[..., :, np.newaxis]
                step_size = min(max(1024*1024*800/(8*M),1),N)
                num_step = N / step_size
                for k in range(num_step+1):
                    str = k*step_size
                    step = min(step_size,N- str )
                    stp  = str + step
                    xj = np.zeros((2, step))
                    xj[0, :] = x[str:stp]
                    xj[1, :] = y[str:stp]
                    x2 = xj[..., np.newaxis, :]
                    d = np.sqrt(((x1 - x2) ** 2).sum(axis=0)) #M x N
                    cov = self.c0 - self.semivarr_model(d,self.a0, self.c0) #M x N
                    out_cov = np.zeros((M+1,step)) #M+1 x N
                    out_cov[:-1,:] = cov
                    out_cov[-1,:] = 1
                    w_lamb = np.dot(self.data_icov,out_cov) #M+1 x N
                    w = w_lamb[:-1,:] #M x N
                    outt = np.dot(w.T,self.z)
                    out[str:stp] = outt.flatten()
                return out
            else:
                out += self.z.mean()
                return out
        else:
            return np.array([])


    def cost_funct(self, parm, h, c0, sv, semivarfunc):
        ycomp = semivarfunc(h,parm, c0)
        err  = (ycomp - sv)**2
        return np.sqrt(err.mean())
    def findBestParam(self, h,c0,sv, semivarfunc):
        opt_parm = opt.fmin(self.cost_funct,1.0,(h,c0,sv,semivarfunc),disp=False )
        return opt_parm

def SVh( x,y, z, h, bw ):
    '''
    Experimental semivariogram for a single lag
    '''
    N = z.size
    xi = np.zeros((2, N))
    xi[0, :] = x
    xi[1, :] = y
    x1 = xi[..., :, np.newaxis]
    x2 = xi[..., np.newaxis, :]
    d = np.sqrt(((x1 - x2) ** 2).sum(axis=0))
    idx,idy = np.nonzero((d>=h-bw)*(d<h+bw))
    Z = (z[idx]-z[idy])**2
    if len(Z) > 0:
        out = Z.mean()/2.0
    else:
        out = None
    # for i in range(N):
    #     for j in range(i+1,N):
    #         if( d[i,j] >= h-bw )and( d[i,j] <= h+bw ):
    #             Z.append( ( z[i] - z[j]**2.0 ))
    return out


def SV(x, y, z, hs, bw):
    '''
    Experimental variogram for a collection of lags
    '''
    sv = []
    for h in hs:
        svout = SVh(x,y,z, h, bw)
        if svout is not None:
            sv.append([h, svout])
    #sv = [[hs[i], sv[i]] for i in range(len(hs)) if sv[i] > 0]
    return np.array(sv).T


def C(x,y,z, h, bw):
    '''
    Calculate the sill
    '''
    c0 = np.var(z)
    if h == 0:
        return c0
    return c0 - SVh(x,y,z, h, bw)

def spherical( h, a, C0 ):
    __name__ = "spherical"
    '''
    Spherical model of the semivariogram
    '''
    # if h is a single digit
    f0 = C0 * (1.5 * h / a - 0.5 * (h / a) ** 3.0)
    fout = f0*(h<=a) + C0*(h>a)
    if a ==0:
        fout = C0*np.ones_like(h)
    return fout

def gaussiansv(h,a,C0):
    __name__ = "gaussian"
    """

    :param h:
    :param a:
    :param C0:
    :return:
    """
    fout = C0*(1-np.exp(-((h/a)**2)))
    if a != 0:
        return fout
    else:
        return C0*np.ones_like(h)
def exponential(h, a, C0):
    __name__ = "exponential"
    """

    :param h:
    :param a:
    :param C0:
    :return:
    """

    if a != 0:
        return C0 * (1 - np.exp(-((h / a))))
    else:
        return C0 * np.ones_like(h)
def powersv(h, a, C0):
    __name__ = "power"
    """

    :param h:
    :param a:
    :param CO:
    :return:
    """
    return C0*(h**a)

class digitalElevationModel:
    TYPE_AVERAGE = "AVG"
    TYPE_MAXIMUM = "MAX"
    TYPE_MINIMUM = "MIN"
    KRIGING = "KRIG"
    NEAREST = "NEAR"
    CUBIC = "CUBIC"
    LINEAR = "LINEAR"
    RBF = "RBF"
    def __init__(self):        
        self.resolution = 30./3600.
        self.num_of_value_per_degree = 120
    def loadDEMFile(self,latitude, longitude, dem_type = TYPE_AVERAGE):
        pass
    def getNeighboringGrids(self, lat,lon, ksizex=1, ksizey= 1,dem_type = TYPE_AVERAGE):
        pass
    def getValuesFromRetangularArea(self, up_left_lat, up_left_lon, bot_right_lat, bot_right_lon,
                                    dem_type = TYPE_AVERAGE, resample = False):
        up_left_lat_deg = np.int(np.floor(up_left_lat))
        up_left_lon_deg = np.int(np.floor(up_left_lon))
        bot_right_lat_deg = np.int(np.floor(bot_right_lat))
        bot_right_lon_deg = np.int(np.floor(bot_right_lon))
        dx = self.resolution
        dy = -self.resolution
        latvec = []
        lonvec = []
        demvec = []
        for lat_deg in range(up_left_lat_deg, bot_right_lat_deg - 1, -1):
            dem_one_line = []
            lat_one_line = []
            lon_one_line = []
            for lon_deg in range(up_left_lon_deg, bot_right_lon_deg + 1):
                lats, lons, dems = self.loadDEMFile(lat_deg + 0.5, lon_deg + 0.5, dem_type=dem_type)
                n_rows, n_cols = dems.shape
                dx = 1. / float(n_cols)
                dy = -1. / float(n_rows)
                xmin = int(np.floor((up_left_lon - lon_deg) / dx))
                xmin = max(xmin, 0)
                ymin = int(np.floor((up_left_lat - lat_deg - 1) / dy))
                ymin = max(ymin, 0)
                xmax = int(np.ceil((bot_right_lon - lon_deg) / dx))
                xmax = min(xmax, n_cols)
                ymax = int(np.ceil((bot_right_lat - lat_deg - 1) / dy))
                ymax = min(ymax, n_rows)
                scale_factor = self.num_of_value_per_degree / n_cols
                if (ymax > ymin) & (xmax > xmin):
                    latpart = lats[ymin:ymax, xmin:xmax]
                    lonpart = lons[ymin:ymax, xmin:xmax]
                    dempart = dems[ymin:ymax, xmin:xmax]
                    n_rows, n_cols = dempart.shape
                    if resample and (scale_factor > 1):
                        dempart2 = np.zeros((n_rows * scale_factor, n_cols * scale_factor))
                        xmin2 = int(np.floor((up_left_lon - lon_deg) / self.resolution))
                        xmin2 = max(xmin2, 0)
                        xmax2 = int(np.ceil((bot_right_lon - lon_deg) / self.resolution))
                        xmax2 = min(xmax2, self.num_of_value_per_degree)

                        ymin2 = int(np.floor((up_left_lat - lat_deg - 1) / self.resolution))
                        ymin2 = max(ymin2, 0)
                        ymax2 = int(np.ceil((bot_right_lat - lat_deg - 1) / self.resolution))
                        ymax2 = min(ymax2, self.num_of_value_per_degree)
                        for i in range(scale_factor):
                            for j in range(scale_factor):
                                dempart2[j:scale_factor, i::scale_factor] = dempart

                        onelon = (np.arange(xmin2, xmax2) * self.resolution + lon_deg)
                        onelat = (np.arange(ymin2, ymax2) * (-self.resolution) + lat_deg + 1 + self.resolution)
                        lonpart, latpart = np.meshgrid(onelon, onelat)
                        dempart = dempart2.copy()
                    if len(dem_one_line) > 0:
                        if dem_one_line.shape[0] == dempart.shape[0]:
                            dem_one_line = np.hstack((dem_one_line, dempart))
                            lat_one_line = np.hstack((lat_one_line, latpart))
                            lon_one_line = np.hstack((lon_one_line, lonpart))
                        else:
                            dem_one_line = np.hstack((dem_one_line.flatten(), dempart.flatten()))
                            lon_one_line = np.hstack((lon_one_line.flatten(), lonpart.flatten()))
                            lat_one_line = np.hstack((lat_one_line.flatten(), latpart.flatten()))
                    else:
                        dem_one_line = dempart.copy()
                        lat_one_line = latpart.copy()
                        lon_one_line = lonpart.copy()
            if len(demvec) > 0:
                if resample:
                    demvec = np.vstack((demvec, dem_one_line))
                    lonvec = np.vstack((lonvec, lon_one_line))
                    latvec = np.vstack((latvec, lat_one_line))
                else:
                    shape_old = demvec.shape
                    shape_new = dem_one_line.shape
                    if (len(shape_old) == 2) and (len(shape_new) == 2):
                        if shape_old[1] != shape_new[1]:
                            demvec = np.hstack((demvec.flatten(), dem_one_line.flatten()))
                            lonvec = np.hstack((lonvec.flatten(), lon_one_line.flatten()))
                            latvec = np.hstack((latvec.flatten(), lat_one_line.flatten()))
                        else:
                            demvec = np.vstack((demvec, dem_one_line))
                            lonvec = np.vstack((lonvec, lon_one_line))
                            latvec = np.vstack((latvec, lat_one_line))
                    else:
                        demvec = np.hstack((demvec.flatten(), dem_one_line.flatten()))
                        lonvec = np.hstack((lonvec.flatten(), lon_one_line.flatten()))
                        latvec = np.hstack((latvec.flatten(), lat_one_line.flatten()))
            else:
                if resample:
                    demvec = dem_one_line
                    lonvec = lon_one_line
                    latvec = lat_one_line
                else:
                    demvec = dem_one_line  # .flatten()
                    lonvec = lon_one_line  # .flatten()
                    latvec = lat_one_line  # .flatten()
        return latvec, lonvec, demvec

    def __demLinearInterpolate(self, lat, lon, demtype = TYPE_AVERAGE):
        if isinstance(lat,np.ndarray):            # operate as grid sytems
            lat_min = lat.min()
            lon_min = lon.min()
            lat_max = lat.max()
            lon_max = lon.max()
            lats, lons, dems = self.getValuesFromRetangularArea(lat_max + 0.5, lon_min - 0.5, lat_min - 0.5,
                                                                lon_max + 0.5, dem_type=demtype)

            if lats.ndim == 1:
                num_data = lats.shape[0]
                points = np.zeros((num_data, 2))
                points[:, 0] = lats
                points[:, 1] = lons

                finterp = interp.LinearNDInterpolator(points, dems, rescale=True)
                x =np.zeros((lat.flatten().shape[0],2))
                x[:,0] = lat.flatten()
                x[:,1] = lon.flatten()
                out = finterp.__call__(x)
                out = out.reshape(lat.shape)
                return out
            elif lats.ndim == 2:
                lat_grid = lats[::-1, 0]
                lon_grid = lons[0, :]
                dems2 = dems[::-1,:]
                finterp = interp.RegularGridInterpolator((lat_grid,lon_grid), dems2, method = "linear")
                x = np.zeros((lat.flatten().shape[0], 2))
                x[:, 0] = lat.flatten()
                x[:, 1] = lon.flatten()
                out = finterp(x)
                out = out.reshape(lat.shape)
                return out


        else:
            lats, lons, dems = self.getValuesFromRetangularArea(lat +0.5, lon-0.5, lat - 0.5, lon+0.5, dem_type = demtype )
            num_data = lats.shape[0]
            points = np.zeros((num_data,2))
            points[:,0] = lats
            points[:,1] = lons
            finterp = interp.LinearNDInterpolator(points, dems, rescale=True)
            x = np.array([[lat,lon]])
            y = finterp.__call__(x)[0]
            return y
    def __demCubicInterpolate(self, lat, lon, demtype = TYPE_AVERAGE):
        if isinstance(lat,np.ndarray):            # operate as grid sytems
            lat_min = lat.min()
            lon_min = lon.min()
            lat_max = lat.max()
            lon_max = lon.max()
            delta = 0.5
            ndim = lat.ndim
            if ndim == 2:
                n_row, n_col = lat.shape
                lat = lat.reshape((n_row * n_col))
                lon = lon.reshape((n_row * n_col))
            lats, lons, dems = self.getValuesFromRetangularArea(lat_max + delta, lon_min - delta, lat_min - delta,
                                                                lon_max + delta,  dem_type=demtype)
            if lats.ndim == 1:
                while lats.size > 4000:
                    delta *= 0.8
                    lats, lons, dems = self.getValuesFromRetangularArea(lat[0] + delta, lon[0] - delta, lat[0] - delta, lon[0] + delta,
                                                                        dem_type=demtype)
                #print "Optimum step is %f."%delta
                num_lat = int(np.ceil((lat_max-lat_min)/delta)+1)
                num_lon = int(np.ceil((lon_max-lon_min)/delta)+1)
                #print "We divide the areas into %d x %d grids." %(num_lon, num_lat)
                out = np.zeros_like(lat)
                for k_lat in range(num_lat):
                    for k_lon in range(num_lon):

                        latc = lat_max - k_lat*delta
                        lonc = lon_min + k_lon*delta
                        lats, lons, dems = self.getValuesFromRetangularArea(latc + delta, lonc - delta, latc - delta,
                                                                            lonc + delta,
                                                                            dem_type=demtype)

                        if lats.ndim == 1:

                            # finterp = interp.Rbf(lats, lons, dems, function='gaussian')
                            idx = np.nonzero((lat>latc - delta/2.0)*(lat<=latc + delta/2.0)*(lon>lonc - delta/2.0)*(lon<=lonc + delta/2.0))[0]
                            points =np.zeros((lats.size,2))
                            points[:, 0] = lats
                            points[:, 1] = lons
                            finterp = interp.CloughTocher2DInterpolator(points, dems) #rbfInterpolate(lat[idx], lon[idx], lats, lons, dems, gaussian)

                            points = np.zeros((len(idx), 2))
                            points[:, 0] = lat[idx]
                            points[:, 1] = lon[idx]
                            out[idx] = finterp.__call__(points)

                        elif lats.ndim == 2:
                            idx = np.nonzero((lat > latc - delta / 2.0) * (lat <= latc + delta / 2.0) * (
                            lon > lonc - delta / 2.0) * (lon <= lonc + delta / 2.0))[0]
                            if len(idx) > 0:
                                dy = lats[1, 0] - lats[0, 0]
                                dx = lons[0, 1] - lons[0, 0]
                                y_grid = ((lat[idx] - lats[0, 0]) / dy).astype('float32')
                                x_grid = ((lon[idx] - lons[0, 0]) / dx).astype('float32')
                                out2 = cv2.remap(dems.astype('float32'), x_grid, y_grid, cv2.INTER_CUBIC)
                                out[idx] = out2.flatten()

                if ndim == 2:
                    out = out.reshape((n_row, n_col))
                return out
            elif lats.ndim == 2:
                dy = lats[1,0]-  lats[0,0]
                dx = lons[0,1] - lons[0,0]
                y_grid = ((lat  - lats[0,0])/ dy).astype('float32')
                x_grid = ((lon - lons[0,0])/ dx).astype('float32')


                out = cv2.remap(dems.astype('float32'),x_grid, y_grid,cv2.INTER_CUBIC)
                if ndim == 2:
                    out = out.reshape((n_row, n_col))
                return out


        else:
            delta = 0.5
            lats, lons, dems = self.getValuesFromRetangularArea(lat + delta, lon - delta, lat - delta, lon + delta, dem_type = demtype )
            while  lats.size > 4000:
                delta *= 0.8
                lats, lons, dems = self.getValuesFromRetangularArea(lat + delta, lon - delta, lat - delta, lon + delta,
                                                                    dem_type=demtype)

            finterp = interp.interp2d(lats, lons, dems,
                                      kind="cubic")  # rbfInterpolate(lat[idx], lon[idx], lats, lons, dems, gaussian)
            out = finterp(lat, lon)

            return out
    def __demRBFInterpolate(self, lat, lon, demtype = TYPE_AVERAGE):
        if isinstance(lat,np.ndarray):            # operate as grid sytems
            lat_min = lat.min()
            lon_min = lon.min()
            lat_max = lat.max()
            lon_max = lon.max()
            delta = 0.5
            latc = (lat_max + lat_min) / 2.0
            lonc = (lon_max + lon_min) / 2.0
            lats, lons, dems = self.getValuesFromRetangularArea(latc + delta, lonc - delta, latc - delta, lonc + delta,
                                                                dem_type=demtype)
            while lats.size > 2000:
                delta *= 0.8
                lats, lons, dems = self.getValuesFromRetangularArea(latc + delta, lonc - delta, latc - delta, lonc + delta,
                                                                    dem_type=demtype)
            print "Optimum step is %f."%delta
            num_lat = int(np.ceil((lat_max-lat_min)/delta)+1)
            num_lon = int(np.ceil((lon_max-lon_min)/delta)+1)
            print "We divide the areas into %d x %d grids." %(num_lon, num_lat)
            out = np.zeros_like(lat)
            for k_lat in range(num_lat):
                for k_lon in range(num_lon):
                    print "Working on (%d, %d) "%(k_lon, k_lat)

                    latc = lat_max - k_lat*delta
                    lonc = lon_min + k_lon*delta

                    lats, lons, dems = self.getValuesFromRetangularArea(latc + delta, lonc - delta, latc - delta,
                                                                        lonc + delta,
                                                                        dem_type=demtype)

                    # finterp = interp.Rbf(lats, lons, dems, function='gaussian')
                    if lat.ndim == 1:
                        idx = np.nonzero((lat>latc - delta/2.0)*(lat<=latc + delta/2.0)*(lon>lonc - delta/2.0)*(lon<=lonc + delta/2.0))[0]
                        if len(idx) > 0:
                            outc = rbfInterpolate(lat[idx], lon[idx], lats, lons, dems, multiquadric)[0]
                            out[idx] = outc
                    elif lat.ndim == 2:
                        idx, idy = np.nonzero(
                            (lat > latc - delta / 2.0) * (lat <= latc + delta / 2.0) * (lon > lonc - delta / 2.0) * (
                            lon <= lonc + delta / 2.0))
                        if len(idx) > 0:
                            outc = rbfInterpolate(lat[idx,idy], lon[idx,idy], lats, lons, dems, multiquadric)
                            out[idx, idy] = outc


            return out

        else:
            delta = 0.5
            lats, lons, dems = self.getValuesFromRetangularArea(lat + delta, lon - delta, lat - delta, lon + delta, dem_type = demtype )
            while  lats.size > 4000:
                delta *= 0.8
                lats, lons, dems = self.getValuesFromRetangularArea(lat + delta, lon - delta, lat - delta, lon + delta,
                                                                    dem_type=demtype)

            finterp = interp.Rbf(lats, lons, dems, function='gaussian')
            y = finterp(lat, lon)
            return y

    def __demNEARESTInterpolate(self, lat, lon, demtype=TYPE_AVERAGE):
        if isinstance(lat, np.ndarray):  # operate as grid sytems
            lat_min = lat.min()
            lon_min = lon.min()
            lat_max = lat.max()
            lon_max = lon.max()
            lats, lons, dems = self.getValuesFromRetangularArea(lat_max + 0.5, lon_min - 0.5, lat_min - 0.5,
                                                                lon_max + 0.5, dem_type=demtype)

            if lats.ndim == 1:
                num_data = lats.shape[0]
                points = np.zeros((num_data, 2))
                points[:, 0] = lats
                points[:, 1] = lons

                finterp = interp.NearestNDInterpolator(points, dems)
                x = np.zeros((lat.flatten().shape[0], 2))
                x[:, 0] = lat.flatten()
                x[:, 1] = lon.flatten()
                out = finterp.__call__(x)
                out = out.reshape(lat.shape)
                return out
            elif lats.ndim == 2:
                lat_grid = lats[::-1, 0]
                lon_grid = lons[0, :]
                dems2 = dems[::-1, :]
                finterp = interp.RegularGridInterpolator((lat_grid, lon_grid), dems2, method="nearest")
                x = np.zeros((lat.flatten().shape[0], 2))
                x[:, 0] = lat.flatten()
                x[:, 1] = lon.flatten()
                out = finterp(x)
                out = out.reshape(lat.shape)
                return out

        else:
            lats, lons, dems = self.getValuesFromRetangularArea(lat +0.5, lon-0.5, lat - 0.5, lon+0.5, dem_type = demtype )
            num_data = lats.shape[0]
            points = np.zeros((num_data,2))
            points[:,0] = lats
            points[:,1] = lons
            finterp = interp.NearestNDInterpolator(points, dems)
            x = np.array([[lat,lon]])
            y = finterp.__call__(x)[0]
            return y
    def __demKrigingInterpolate(self, lat, lon, demtype = TYPE_AVERAGE):
        if isinstance(lat,np.ndarray):            # operate as grid sytems
            lat_min = lat.min()
            lon_min = lon.min()
            lat_max = lat.max()
            lon_max = lon.max()
            delta = 0.5
            latc = (lat_max + lat_min) / 2.0
            lonc = (lon_max + lon_min) / 2.0
            lats, lons, dems = self.getValuesFromRetangularArea(latc + delta, lonc - delta, latc - delta, lonc + delta,
                                                                dem_type=demtype)
            while lats.size > 2000:
                delta *= 0.8
                lats, lons, dems = self.getValuesFromRetangularArea(latc + delta, lonc - delta, latc - delta, lonc + delta,
                                                                    dem_type=demtype)
            if lat.size < 1500:
                delta = delta/0.8
                lats, lons, dems = self.getValuesFromRetangularArea(latc + delta, lonc - delta, latc - delta, lonc + delta,
                                                                    dem_type=demtype)

            print "Optimum step is %f."%delta
            num_lat = int(np.ceil((lat_max-lat_min)/delta)+1)
            num_lon = int(np.ceil((lon_max-lon_min)/delta)+1)
            print "We divide the areas into %d x %d grids." %(num_lon, num_lat)
            out = np.zeros_like(lat)
            nout = np.zeros_like(lat, 'int')
            for k_lat in range(num_lat):
                for k_lon in range(num_lon) :
                    #k_lon = 5
                    print "Working on (%d, %d)." % (k_lon, k_lat)

                    latc = lat_max - k_lat*delta
                    lonc = lon_min + k_lon*delta

                    lats, lons, dems = self.getValuesFromRetangularArea(latc + delta, lonc - delta, latc - delta,
                                                                        lonc + delta,
                                                                        dem_type=demtype)
                    md = krigingInterpolation(lats,lons,dems)
                    # finterp = interp.Rbf(lats, lons, dems, function='gaussian')
                    if lat.ndim == 1:
                        idx = np.nonzero((lat>latc - delta/2)*(lat<=latc + delta/2)*(lon>lonc - delta/2)*(lon<=lonc + delta/2))[0]
                        outtemp = md.eval(lat[idx], lon[idx])
                        nout[idx] += 1
                        out[idx] = (outtemp +  (nout[idx]-1)*out[idx])/nout[idx]
                    elif lat.ndim == 2:
                        idx,idy = np.nonzero(
                            (lat > latc - delta / 2) * (lat <= latc + delta / 2) * (lon > lonc - delta / 2) * (
                            lon <= lonc + delta / 2))
                        lat_k = lat[idx, idy]
                        lon_k = lon[idx, idy]
                        outtemp = md.eval(lat_k, lon_k)
                        nout[idx, idy] += 1
                        out[idx, idy] = (outtemp + (nout[idx,idy] - 1) * out[idx, idy]) / nout[idx, idy]

            return out

        else:
            delta = 0.5
            lats, lons, dems = self.getValuesFromRetangularArea(lat + delta, lon - delta, lat - delta, lon + delta, dem_type = demtype )
            while  lats.size > 2000:
                delta *= 0.8
                lats, lons, dems = self.getValuesFromRetangularArea(lat + delta, lon - delta, lat - delta, lon + delta,
                                                                    dem_type=demtype)
            if lat.size < 1500:
                delta = delta/0.8
                lats, lons, dems = self.getValuesFromRetangularArea(lat + delta, lon - delta, lat - delta, lon + delta,
                                                                    dem_type=demtype)

            md = krigingInterpolation(lats, lons, dems)
            y = md.eval(lat, lon)
            return y
    def interpolate(self, lat, lon, interpolation_method = LINEAR, demtype = TYPE_AVERAGE):
        if interpolation_method == self.LINEAR:
            return self.__demLinearInterpolate(lat, lon ,demtype)
        elif interpolation_method == self.CUBIC:
            return self.__demCubicInterpolate(lat, lon, demtype)
        elif interpolation_method == self.RBF:
            return self.__demRBFInterpolate(lat, lon, demtype)
        elif interpolation_method == self.NEAREST:
            return self.__demNEARESTInterpolate(lat, lon, demtype)
        elif interpolation_method == self.KRIGING:
            return self.__demKrigingInterpolate(lat, lon, demtype)


class globedem(digitalElevationModel):
    def __init__(self, dem_directory):
        self.dem_directory = dem_directory
        self.dem_database = GLOBE_DEM
        self.resolution = 30./3600.
        self.geoid = geoid_file
        self.num_of_value_per_degree = 120
    def loadDEMFile(self,latitude, longitude, dem_type = digitalElevationModel.TYPE_AVERAGE):
        lat_deg = int(np.floor(latitude))
        lon_deg = int(np.floor(longitude))
        dem_directory = self.dem_directory
        if (lat_deg >= 50.0):
            if (lon_deg < -90.0):
                dem_file = dem_directory + "/a10g"
            elif (lon_deg < 0):
                dem_file = dem_directory + "/b10g"
            elif (lon_deg < 90):
                dem_file = dem_directory + "/c10g"
            else:
                dem_file = dem_directory + "/d10g"
        elif (lat_deg >= 0) & (lat_deg < 50):
            if (lon_deg < -90.0):
                dem_file = dem_directory + "/e10g"
            elif (lon_deg < 0):
                dem_file = dem_directory + "/f10g"
            elif (lon_deg < 90):
                dem_file = dem_directory + "/g10g"
            else:
                dem_file = dem_directory + "/h10g"
        elif (lat_deg >= -50) & (lat_deg < 0):
            if (lon_deg < -90.0):
                dem_file = dem_directory + "/i10g"
            elif (lon_deg < 0):
                dem_file = dem_directory + "/j10g"
            elif (lon_deg < 90):
                dem_file = dem_directory + "/k10g"
            else:
                dem_file = dem_directory + "/l10g"
        else:
            if (lon_deg < -90.0):
                dem_file = dem_directory + "/m10g"
            elif (lon_deg < 0):
                dem_file = dem_directory + "/n10g"
            elif (lon_deg < 90):
                dem_file = dem_directory + "/o10g"
            else:
                dem_file = dem_directory + "/p10g"



        dem = gdal.Open(dem_file)
        geot = dem.GetGeoTransform()
        lon0 = (geot[0]+15.)/3600.0
        lat0 = (geot[3]+15)/3600.0
        dx  = 30./3600.
        dy = -30./3600.
        width = dem.RasterXSize
        height = dem.RasterYSize

        lat_values = lat_deg + 1.0 - np.arange(120)*30./3600. - 15./3600.
        lon_values = lon_deg + np.arange(120)*30./3600. + 15./3600.
        lon_grid, lat_grid = np.meshgrid(lon_values, lat_values)
        cols = (lon_grid - lon0) / dx
        cols = np.floor(cols).astype('int')
        rows = (lat_grid - lat0) / dy
        rows = np.floor(rows).astype('int')
        line_min = rows.min()
        line_max = rows.max()
        sample_min = cols.min()
        sample_max = cols.max()
        width = max(sample_max - sample_min + 1 ,1)
        height = max(line_max - line_min + 1, 1)

        dem_temp = dem.ReadAsArray(sample_min, line_min, width,height)
        dem_array = dem_temp[rows- line_min, cols - sample_min]
        idx, idy = np.nonzero(dem_array == -500)
        dem = None
        demgeo = gdal.Open(self.geoid)
        data = demgeo.ReadAsArray().astype('int16')
        lat0 = 90.0
        lon0 = -180.0
        dx = 0.5
        dy = -0.5
        lats = lat_grid
        rows = (lats - lat0) / dy
        rows = np.floor(rows).astype('int')
        lons = lon_grid
        cols = (lons - lon0) / dx
        cols = np.floor(cols).astype('int')
        dem_add = data[rows, cols]
        dem_array += dem_add

        dem = None
        if len(idx) > 0:
            # Load geoid data
            dem_array[idx, idy] = dem_add[idx, idy]
        return lat_grid, lon_grid, dem_array


class srtm30(digitalElevationModel):
    def __init__(self, dem_directory):
        self.dem_directory = dem_directory
        self.dem_database = SRTM90_DEM
        self.resolution = 1./3600.
        self.geoid = geoid_file
        self.num_of_value_per_degree = 36000
    def loadDEMFile(self,latitude, longitude, dem_type = digitalElevationModel.TYPE_AVERAGE):
        lat_deg = int(np.floor(latitude))
        lon_deg = int(np.floor(longitude))
        if (lat_deg >=0) & (lon_deg>=0): #East and north
            file_name = self.dem_directory + "/n%02de%03d.bil"%(lat_deg, lon_deg)
        elif (lat_deg < 0) & (lon_deg >=0):
            file_name = self.dem_directory + "/s%02de%03d.bil" % (-lat_deg, lon_deg)
        elif (lat_deg >=0) & (lon_deg < 0 ):
            file_name = self.dem_directory + "/n%02dw%03d.bil" % (lat_deg, -lon_deg)
        elif (lat_deg < 0) & (lon_deg < 0):
            file_name = self.dem_directory + "/s%02dw%03d.bil" % (-lat_deg, -lon_deg)
        else:
            AssertionError("Invalid Latitude and/or Longitude!")

        if os.path.getsize(file_name) > 0:
            dem = gdal.Open(file_name)
            geot = dem.GetGeoTransform()
            lon0 = (geot[0]+0.5)/3600.0
            lat0 = (geot[3]-0.5)/3600.0
            width = dem.RasterXSize
            height = dem.RasterYSize
            lat_values = lat0  + geot[5] * np.arange(height) / 3600.
            lon_values = lon0 + geot[1] * np.arange(width) / 3600.
            lon_grid, lat_grid = np.meshgrid(lon_values, lat_values)
            dem_array = dem.ReadAsArray()
            lon_grid = lon_grid[1:, :-1]
            lat_grid = lat_grid [1:, :-1]
            dem_array = dem_array[1:, :-1]
            idx, idy = np.nonzero(dem_array == -32767)

            demgeo = gdal.Open(self.geoid)
            data = demgeo.ReadAsArray().astype('int16')
            lat0 = 90.0
            lon0 = -180.0
            dx = 0.5
            dy = -0.5
            lats = lat_grid
            rows = (lats - lat0) / dy
            rows = np.floor(rows).astype('int')
            lons = lon_grid
            cols = (lons - lon0) / dx
            cols = np.floor(cols).astype('int')
            dem_add = data[rows, cols]
            dem_array += dem_add

            dem = None
            if len(idx) > 0:
                #Load geoid data
                dem_array[idx, idy] = dem_add[idx,idy]
            return lat_grid, lon_grid, dem_array
        else:
            # File containing nothing. Use goeid
            demgeo = gdal.Open(self.geoid)
            data = demgeo.ReadAsArray().astype('int16')
            lat0 = 90.0
            lon0 = -180.0
            dx = 0.5
            dy = -0.5
            lat_values = np.array([lat_deg+0.5, lat_deg])
            lon_values = np.array([lon_deg, lon_deg + 0.5])
            lon_grid, lat_grid = np.meshgrid(lon_values, lat_values)
            lats = lat_grid
            rows = (lats - lat0) / dy
            rows = np.floor(rows).astype('int')
            lons = lon_grid
            cols = (lons - lon0) / dx
            cols = np.floor(cols).astype('int')
            dem_array = data[rows, cols]
            return lat_grid, lon_grid, dem_array



class srtm90(digitalElevationModel):
    def __init__(self, dem_directory):
        self.dem_directory = dem_directory
        self.dem_database = SRTM90_DEM
        self.resolution = 3./3600.
        self.geoid = geoid_file
        self.num_of_value_per_degree = 1200
    def loadDEMFile(self,latitude, longitude, dem_type = digitalElevationModel.TYPE_AVERAGE):
        lat_deg = int(np.floor(latitude))
        lon_deg = int(np.floor(longitude))
        if (lat_deg >=0) & (lon_deg>=0): #East and north
            file_name = self.dem_directory + "/n%02de%03d.bil"%(lat_deg, lon_deg)
        elif (lat_deg < 0) & (lon_deg >=0):
            file_name = self.dem_directory + "/s%02de%03d.bil" % (-lat_deg, lon_deg)
        elif (lat_deg >=0) & (lon_deg < 0 ):
            file_name = self.dem_directory + "/n%02dw%03d.bil" % (lat_deg, -lon_deg)
        elif (lat_deg < 0) & (lon_deg < 0):
            file_name = self.dem_directory + "/s%02dw%03d.bil" % (-lat_deg, -lon_deg)
        else:
            AssertionError("Invalid Latitude and/or Longitude!")

        if os.path.getsize(file_name) > 0:
            dem = gdal.Open(file_name)
            geot = dem.GetGeoTransform()
            lon0 = (geot[0]+1.5)/3600.0
            lat0 = (geot[3]-1.5)/3600.0
            width = dem.RasterXSize
            height = dem.RasterYSize
            lat_values = lat0  + geot[5]*np.arange(height) / 3600.
            lon_values = lon0 + geot[1] * np.arange(width) / 3600.
            lon_grid, lat_grid = np.meshgrid(lon_values, lat_values)
            dem_array = dem.ReadAsArray()
            lon_grid = lon_grid[1:, :-1]
            lat_grid = lat_grid [1:, :-1]
            dem_array = dem_array[1:, :-1]
            idx, idy = np.nonzero(dem_array == -32767)

            demgeo = gdal.Open(self.geoid)
            data = demgeo.ReadAsArray().astype('int16')
            lat0 = 90.0
            lon0 = -180.0
            dx = 0.5
            dy = -0.5
            lats = lat_grid
            rows = (lats - lat0) / dy
            rows = np.floor(rows).astype('int')
            lons = lon_grid
            cols = (lons - lon0) / dx
            cols = np.floor(cols).astype('int')
            dem_add = data[rows, cols]
            dem_array += dem_add

            dem = None
            if len(idx) > 0:
                #Load geoid data
                dem_array[idx, idy] = dem_add[idx,idy]
            return lat_grid, lon_grid, dem_array
        else:
            # File containing nothing. Use goeid
            demgeo = gdal.Open(self.geoid)
            data = demgeo.ReadAsArray().astype('int16')
            lat0 = 90.0
            lon0 = -180.0
            dx = 0.5
            dy = -0.5
            lat_values = np.array([lat_deg+0.5, lat_deg])
            lon_values = np.array([lon_deg, lon_deg + 0.5])
            lon_grid, lat_grid = np.meshgrid(lon_values, lat_values)
            lats = lat_grid
            rows = (lats - lat0) / dy
            rows = np.floor(rows).astype('int')
            lons = lon_grid
            cols = (lons - lon0) / dx
            cols = np.floor(cols).astype('int')
            dem_array = data[rows, cols]
            return lat_grid, lon_grid, dem_array



class theosDEM(digitalElevationModel):
    def __init__(self, dem_directory):
        self.dem_directory = dem_directory
        self.dem_database = THEOS_DEM
        self.resolution = 30./3600.
        self.geoid = geoid_file
        self.num_of_value_per_degree = 120

    def loadDEMFile(self,latitude, longitude, dem_type = digitalElevationModel.TYPE_AVERAGE):
        lat_deg = int(np.floor(latitude))
        long_deg = int(np.floor(longitude))
        if (lat_deg > 90):
            lat_deg = 180. - lat_deg
        if (lat_deg < -90) :
            lat_deg = -180 - lat_deg
        if (long_deg > 179) :
            long_deg = long_deg - 360
        if (long_deg < -180) :
            long_deg = long_deg + 360
        if (lat_deg >=0) & (long_deg>=0): #East and north
            file_name = "e%03d/e%03dn%02d"%(long_deg,long_deg,lat_deg)
        elif (lat_deg < 0) & (long_deg >=0):
            file_name = "e%03d/e%03ds%02d" % (long_deg, long_deg, -lat_deg)
        elif (lat_deg >=0) & (long_deg < 0 ):
            file_name = "w%03d/w%03dn%02d" % (-long_deg, -long_deg, lat_deg)
        elif (lat_deg < 0) & (long_deg < 0):
            file_name = "w%03d/w%03ds%02d" % (-long_deg, -long_deg, -lat_deg)
        else:

            AssertionError("Invalid Latitude and/or Longitude!")
        if dem_type == digitalElevationModel.TYPE_AVERAGE:
            desfile = self.dem_directory + "/average/" + file_name + ".avg"
        elif dem_type == digitalElevationModel.TYPE_MAXIMUM:
            desfile = self.dem_directory + "/maximum/" + file_name + ".max"
        elif dem_type == digitalElevationModel.TYPE_MINIMUM:
            desfile = self.dem_directory + "/minimum/" + file_name + ".min"
        else:
            AssertionError("Invalid DEM TYPE")
        dem_array = None
        if os.path.isfile(desfile):
            with open(desfile,"rb") as fp:
                height = 120
                data = fp.read()
                width = len(data)/(2*height)
                data = data[::-1]
                dem_array = np.frombuffer(data,np.int16)
                dem_array = dem_array[::-1]
                dem_array = dem_array.reshape((height,width))
                lat_deg = int(np.floor(latitude))
                long_deg = int(np.floor(longitude))
                lat_values = np.arange(0,-height,-1)*(self.resolution) -\
                             (self.resolution)/2.0 + lat_deg+1
                long_values =np.arange(0,width,1)*(self.resolution*120/width) + \
                             (self.resolution*120/width)/2.0 + long_deg
                lon_grid, lat_grid = np.meshgrid(long_values,lat_values)
                lats = lat_grid
                lons = lon_grid
                dems = dem_array
                return lats, lons, dems
        else:
            #print "The dem file do not exist. Probably, it is over the ocean!"
            #print "Use the GEOID instead!"
            geoidem =  gdal.Open( self.geoid)
            data = geoidem.ReadAsArray().astype('int16')
            lat0 = 90.0
            lon0 = -180.0
            dx = 0.5
            dy = -0.5
            lat_values = np.array([lat_deg + 0.5, lat_deg])
            lon_values = np.array([long_deg, long_deg + 0.5])
            lon_grid, lat_grid = np.meshgrid(lon_values, lat_values)
            lats = lat_grid
            rows = (lats - lat0) / dy
            rows = np.floor(rows).astype('int')
            lons = lon_grid
            cols = (lons - lon0) / dx
            cols = np.floor(cols).astype('int')
            dem_array = data[rows, cols]
            lat_deg = int(np.floor(latitude))
            long_deg = int(np.floor(longitude))
            lat_values = np.array([lat_deg + 0.5, lat_deg])
            lon_values = np.array([long_deg, long_deg + 0.5])
            lon_grid, lat_grid = np.meshgrid(lon_values, lat_values)
            return lat_grid, lon_grid, dem_array








    def getNeighboringGrids(self, lat,lon, ksizex=1, ksizey= 1,dem_type = digitalElevationModel.TYPE_AVERAGE):
        lats, lons, dems = self.loadDEMFile(lat,lon,dem_type=dem_type)


        data_size = lats.size
        dy = 30./3600
        num_y = 120
        num_x = data_size/120
        if data_size != (num_x*num_y):
            AssertionError("Invalid data size")
        dx = dy*120./num_y
        dy = -dy
        lat_deg = int(np.floor(lat))
        lon_deg = int(np.floor(lon))
        kx = (lon - lon_deg) / dx
        ky = (lat - lat_deg - 1) / dy
        kc = int(np.floor(kx))
        mc = int(np.floor(ky))
        k0 = kc - ksizex
        m0 = mc - ksizey
        k1 = kc + ksizex
        m1 = mc + ksizey
        neighbor_lat = np.zeros((2*ksizey + 1, 2*ksizex + 1))
        neighbor_lon = np.zeros((2*ksizey + 1, 2*ksizex + 1))
        neighbor_dem = np.zeros((2*ksizey + 1, 2*ksizex + 1))
        if (k0 < 0) :
            new_ksizex = -k0 - 1
            sub_lat, sub_lon, sub_dem = self.getNeighboringGrids(lat, lon + (k0-kc)*dx, new_ksizex, ksizey)
            sub_lat = sub_lat.reshape(2*ksizey+1,2*new_ksizex+1)
            sub_lon = sub_lon.reshape(2*ksizey+1,2*new_ksizex+1)
            sub_dem = sub_dem.reshape(2*ksizey+1,2*new_ksizex+1)
            k0 = 0
            neighbor_lat[:,:(new_ksizex + 1)] = sub_lat[:, new_ksizex:]
            neighbor_lon[:,:(new_ksizex + 1)] = sub_lon[:, new_ksizex:]
            neighbor_dem[:,:(new_ksizex + 1)] = sub_dem[:, new_ksizex:]
        x_remain = k0 - kc + ksizex

        if (m0 < 0) :
            new_ksizey = -m0 - 1

            sub_lat, sub_lon, sub_dem = self.getNeighboringGrids(lat+(m0-mc)*dy, lon , ksizex, new_ksizey)
            sub_lat = sub_lat.reshape(2 * new_ksizey + 1, 2 * ksizex + 1)
            sub_lon = sub_lon.reshape(2 * new_ksizey+ 1, 2 * ksizex + 1)
            sub_dem = sub_dem.reshape(2 * new_ksizey + 1, 2 * ksizex + 1)
            sub_latu = sub_lat[new_ksizey:, x_remain:]
            sub_lonu = sub_lon[new_ksizey:, x_remain:]
            sub_demu = sub_dem[new_ksizey:, x_remain:]
            m0 = 0
            neighbor_lat[:(new_ksizey + 1), x_remain:] = sub_latu
            neighbor_lon[:(new_ksizey + 1), x_remain:] = sub_lonu
            neighbor_dem[:(new_ksizey + 1), x_remain:] = sub_demu
        y_remain = m0 - mc + ksizey
        x_end = 2*ksizex +1
        if (k1 >= num_x) :
            new_ksizex = k1 - num_x
            sub_lat, sub_lon, sub_dem = self.getNeighboringGrids(lat, lon+ (k1 -kc +1) * dx, new_ksizex, ksizey)
            sub_lat = sub_lat.reshape(2 * ksizey + 1, 2 * new_ksizex + 1)
            sub_lon = sub_lon.reshape(2 * ksizey + 1, 2 * new_ksizex + 1)
            sub_dem = sub_dem.reshape(2 * ksizey + 1, 2 * new_ksizex + 1)
            sub_latr = sub_lat[y_remain:, :(new_ksizex+1)]
            sub_lonr = sub_lon[y_remain:, :(new_ksizex+1)]
            sub_demr = sub_dem[y_remain:, :(new_ksizex+1)]
            k1 = num_x - 1
            str = 2*ksizex-new_ksizex
            neighbor_lat[y_remain:, str:] = sub_latr
            neighbor_lon[y_remain:, str:] = sub_lonr
            neighbor_dem[y_remain:, str:] = sub_demr
            x_end = str
        y_end = 2*ksizey + 1
        if (m1 >= num_y) :
            new_ksizey = m1 - num_y
            sub_lat, sub_lon, sub_dem = self.getNeighboringGrids(lat + (m1 - mc + 1) * dy , lon , ksizex, new_ksizey)
            sub_lat = sub_lat.reshape(2 * new_ksizey + 1, 2 * ksizex + 1)
            sub_lon = sub_lon.reshape(2 * new_ksizey + 1, 2 * ksizex + 1)
            sub_dem = sub_dem.reshape(2 * new_ksizey + 1, 2 * ksizex + 1)
            sub_latd = sub_lat[:(new_ksizey + 1), x_remain:x_end]
            sub_lond = sub_lon[:(new_ksizey + 1), x_remain:x_end]
            sub_demd = sub_dem[:(new_ksizey + 1), x_remain:x_end]
            m1 = num_y - 1
            str = 2 * ksizey - new_ksizey
            neighbor_lat[str:, x_remain:x_end] = sub_latd
            neighbor_lon[str:, x_remain:x_end] = sub_lond
            neighbor_dem[str:, x_remain:x_end] = sub_demd
            y_end = str

        if (k0 >= 0) & (m0 >= 0) & (k1 < num_x) & (m1 < num_y):
            sub_demc = dems[m0:(m1 + 1), k0:(k1 + 1)]
            sub_latc = lats[m0:(m1 + 1), k0:(k1 + 1)]
            sub_lonc = lons[m0:(m1 + 1), k0:(k1 + 1)]
            neighbor_lat[y_remain:y_end, x_remain:x_end] = sub_latc
            neighbor_lon[y_remain:y_end, x_remain:x_end] = sub_lonc
            neighbor_dem[y_remain:y_end, x_remain:x_end] = sub_demc

        return neighbor_lat, neighbor_lon, neighbor_dem

import utmLatlon
import psutil

def makingDEMData( dem_file_name, lv_width, lv_height, map_geotransform,  dem,
                   dem_interpolation_method):

    gtiffDriver = gdal.GetDriverByName('GTiff')


    dem_ds_im = gtiffDriver.Create(dem_file_name, lv_width, lv_height, 1, gdal.GDT_Float32)
    dem_ds = dem_ds_im.GetRasterBand(1)
    mem = psutil.virtual_memory()
    mem_available = mem.available
    if dem_interpolation_method != "rbf":
        max_num_pixels_dem = (mem_available - 1024 * 1024 * 1024) / (
        (200) * 8)  # 400 memory block per pixels and 8 for double
    else:
        max_num_pixels_dem = 100 ** 2
    block_num_lines = int(np.sqrt(max_num_pixels_dem))
    block_num_pixels = block_num_lines
    off_set = 10
    block_num_lines2 = block_num_lines + off_set
    block_num_pixels2 = block_num_pixels + off_set
    for line in range(0, lv_height, block_num_lines):
        for sample in range(0, lv_width, block_num_pixels):
            line_max = min((lv_height - line), block_num_lines2)
            samp_max = min(lv_width - sample, block_num_pixels2)
            if (line == 0) & (sample == 0):
                V, U = np.mgrid[0:int(line_max), 0:int(samp_max)]
            elif (line == 0) & (sample > 0):
                V, U = np.mgrid[0:int(line_max), sample - off_set:int(samp_max + sample)]
            elif (line > 0) & (sample == 0):

                V, U = np.mgrid[line - off_set:int(line_max + line), 0:int(samp_max)]
            else:
                V, U = np.mgrid[line - off_set:int(line_max + line), sample - off_set:int(samp_max + sample)]
            x2_up_left, y2_up_left, dx2, dy2,zonec, zoneletter_c  = map_geotransform
            u_earth = U * dx2 + x2_up_left
            v_earth = V * dy2 + y2_up_left
            late, lone = utmLatlon.to_latlon(u_earth, v_earth, zonec, zoneletter_c)

            # h = util.determineHeight(late,lone,dem_directory)
            latem = int(np.round(late.mean()))
            lonem = int(np.round(lone.mean()))
            dem_temp = None
            print "[DEM]  coord:", late.min(), late.max(), lone.min(), lone.max()
            h = dem.interpolate(late, lone, interpolation_method = dem_interpolation_method)
            ofx = off_set * (sample != 0)
            ofy = off_set * (line != 0)
            dem_out = h[ofy:, ofx:].astype('float64')
            print "sample:%d, line:%d" % (sample, line), h.shape
            dem_ds.WriteArray(dem_out, sample, line)
    dem_ds_im = None


if  __name__ == "__main__":
    dem = theosDEM(r"D:\old_system_dem")
    lt,ln, h = dem.getValuesFromRetangularArea(21.43741896,69.8824453, 20.54125951,70.96510304  )
    print h
# import matplotlib.pyplot as plt
# import os
# if __name__ == "__main__":
#     for root, dirs, files in os.walk(r"D:\Data2APanSharpen\test_dems"):
#         for file in files:
#             if file.endswith(".tif"):
#                 im = gdal.Open(root + "/" + file)
#                 d1 = im.ReadAsArray()
#                 plt.plot(d1[:,300])
#                 plt.savefig(root + "/" + file[:-4] +"_pixel3000.png")
#                 plt.close()
#     exit()
#
#     geo_trans = [2.6345117460343021e+05, 5.8949500926707126e+06, 2, -2, 31, 'U']
#
#
#     dem = srtm30(r"D:\srtm30\gls")
#     file_name ="srtm30_dem_cubic_pan"
#     makingDEMData(r"D:\Data2APanSharpen\test_dems" +"/" + file_name + ".tif", 12000, 12000, geo_trans, dem,
#                   digitalElevationModel.CUBIC)
#     im = gdal.Open(r"D:\Data2APanSharpen\test_dems" +"/" + file_name + ".tif")
#     b1 = im.GetRasterBand(1)
#     d1 = b1.ReadAsArray()
#     d1 = d1/d1.max()
#     plt.imsave(r"D:\Data2APanSharpen\test_dems" +"/" + file_name + ".png",d1)