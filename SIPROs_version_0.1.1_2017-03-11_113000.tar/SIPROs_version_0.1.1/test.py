import os , shutil
out_dir = r"C:\Worker\Support-Worker\Sipros_system\PRODUCT_FILES\THEOS_1_LEVEL0_1_111043217_43217_MS_PB_TOP_2_10_2017-01-02_05-50-19\TH_CAT_170310160857423R43217M1A_20170102_055030"
shutil.make_archive(out_dir , "zip" , out_dir)
		
			