"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

 """

import generalFileReader as gr
import createPanSharpenImage as createImage
import os
import locationutil
import determine_pixel_shift as dps
import numpy as np
from xml.dom import minidom
from osgeo import gdal
from osgeo import osr
import cv2
import DIMAPLV2 as DIMAP1
import time
import digitalElevationModel as demservice


dem_directories = dict()





def MSDataExtraction(ms_ger_file_names, output_file_names, cpf_file_name, force_run=False):
    year, month, day,  band_bad_lines, band_degraded_lines = gr.readGerMSFiles(ms_ger_file_names, output_file_names, cpf_file_name, force_run)
    return year, month, day,  band_bad_lines, band_degraded_lines


def PANDataExtraction(pan_ger_file_names, output_file_names, cpf_file_name, force_run=False):
    year, month, day,  band_bad_lines, band_degraded_lines = gr.readGerPANFiles(pan_ger_file_names, output_file_names, cpf_file_name, force_run)
    return year, month, day,  band_bad_lines, band_degraded_lines


def find_ger_files(ger_dir):
    ger_file_list = []
    for filename in os.listdir(ger_dir):
        base, ext = os.path.splitext(filename)
        # print base, ext
        if ext.lower() == ".ger":
            ger_file = base + ext
            ger_file_list.append(ger_file)
    return ger_file_list


def createPreview(file_name, preview_file, icon_file, width, height):
    im = gdal.Open(file_name)
    imw = im.RasterXSize
    imh = im.RasterYSize
    scalex = float(imw)/float(width)
    scaley = float(imh)/float(height)
    scale = max(scalex , scaley)
    #steph = int(imh / height)
    #stepw = int(imw / width)
    scale_int = int(np.ceil(scale))

    realheight = int(np.ceil(float(imh) / scale_int))
    realwidht = int(np.ceil(float(imw) / scale_int))
    strx = width / 2 - realwidht / 2
    stpx = strx + realwidht
    stry = height / 2 - realheight / 2
    stpy = stry + realheight
    if im.RasterCount == 4:  # ms Images
        outim = np.zeros((realheight, realwidht, 3), 'uint8')
        preview_im = np.zeros((width, height,3),'uint8')

        b1 = im.GetRasterBand(3)
        b2 = im.GetRasterBand(2)
        b3 = im.GetRasterBand(1)
        for line in range(realheight):
            line_im = line * scale_int
            d1 = b1.ReadAsArray(0, line_im, imw, 1)
            d2 = b2.ReadAsArray(0, line_im, imw, 1)
            d3 = b3.ReadAsArray(0, line_im, imw, 1)
            outim[line, :, 0] = d1[0, ::scale_int]
            outim[line, :, 1] = d2[0, ::scale_int]
            outim[line, :, 2] = d3[0, ::scale_int]

        preview_im[stry:stpy,strx:stpx,:] = outim
    else:
        outim = np.zeros((realheight, realwidht), 'uint8')
        preview_im = np.zeros((width, height), 'uint8')
        b1 = im.GetRasterBand(1)
        for line in range(realheight):
            line_im = line * scale_int
            d1 = b1.ReadAsArray(0, line_im, imw, 1)
            outim[line, :] = d1[0, ::scale_int]
        preview_im[stry:stpy, strx:stpx] = outim
    cv2.imwrite(preview_file, preview_im)
    scale = min(width / 128, height / 128)
    icon = cv2.resize(preview_im, (width / scale, height / scale))
    cv2.imwrite(icon_file, icon)

def loadFilter(apf_file, band="PAN", id=9):
    """

    :param apf_file: The .apf file containing filter parameters
    :param band: spectral band. Default is "PAN"
    :param id: filter id. The defualt id is 9.
    :return: a 5x5 filter
    """
    doc = minidom.parse(apf_file)
    resplist = doc.getElementsByTagName("RestorationParametersList")[0]
    resparms = resplist.getElementsByTagName("RestorationParameters")
    for resp in resparms:
        apf_band = resp.getAttribute("band")
        if apf_band == band:
            filter_list = resp.getElementsByTagName("filter")
            for filter in filter_list:
                filter_id = int(filter.getAttribute("id"))
                if filter_id == id:
                    filterout = np.fromstring(filter.childNodes[0].data, dtype="float32", sep=",")
    filter2D = filterout.reshape((5, 5))

    return filter2D
def computeDIMAPParametersLevel2A(ger_info_prefix, dem, dem_interpolation_method, image_type, line1, date, utc_gps, ut1_utc, start_sample,
                                  im_width, im_height, midpoint):
    """

    :param ger_info_prefix: text containing all prefix to files extracted from .ger
    :param dem: dem service
    :param dem_interpolation_method: string indicate dem tyoe
    :param image_type: "MS" for multispectral, "PAN" for panchromatic images
    :param line1: first line of Band 3 for multispectral image, and first line of panchromatic image
    :param date: [year, month, day] of capturing image
    :param utc_gps: UTC-GPS time
    :param ut1_utc: UT1-UTC time
    :param midpoint = latitude and longitude of the center of the image
    :return:
    upleft: latitude and longitude of pixel 1,1 in the image
    upright: latitude and longitude of pixel 1,width in the image
    lowleft = latitude and longitude of pixel height,1 in the image
    lowright = latitude and longitude of pixel height,width in the image
    midpoint = latitude and longitude of the center of the image
    view_angles = viewing angles along and across track.
    sat_angles = satellite incidence and azimuth angles
    sun_angles = sun azimuth and elevation angles
    orientation: orientation of the scene.

    """

    mid_s = start_sample + im_width / 2 - 1
    mid_l = line1 + im_height / 2 - 1
    lat_mid = midpoint[2][1]
    lon_mid = midpoint[2][0]

    al, al_along, al_across, sat_incidence, sat_azimuth, sat_altitude = dps.findViewingAngles(image_type,
                                                                                              ger_info_prefix,
                                                                                              mid_l, mid_s, date,
                                                                                              utc_gps, ut1_utc,
                                                                                              lat_mid, lon_mid)

    print "VIEWING_ANGLE_ALONG_TRACK: %f, VIEWING_ANGLE_ACROSS_TRACK: %f" % (al_along, al_across)
    print "SATELLITE_INCIDENCE_ANGLE: %f, SATELLITE_AZIMUTH_ANGLE: %f, SATELLITE_ALTITUDE: %f" % (
        sat_incidence, sat_azimuth, sat_altitude)
    orientation = dps.findOrientationAngle(image_type, ger_info_prefix, mid_l, date, utc_gps, ut1_utc, dem,
                                           dem_interpolation_method)
    print "SCENE_ORIENTATION: %f" % orientation
    sun_ev, sun_az = dps.findSunAngles(image_type, ger_info_prefix, mid_l, date, utc_gps, ut1_utc, lat_mid,
                                       lon_mid)
    print "SUN_AZIMUTH: %f,SUN_ELEVATION: %f" % (sun_az, sun_ev)

    view_angles = [al_along, al_across]
    sat_angles = [sat_incidence, sat_azimuth]
    sun_angles = [sun_az, sun_ev]
    return view_angles, sat_angles, sat_altitude, sun_angles, orientation


def createPanSharpenImage(product_level, pansharpen_method, pansharpen_out_dir, ger_ms_info_dir,
                          pansharpen_info_dir, ger_pan_info_dir,   ger_ms_dir, ger_pan_dir, cpf_file, band_line_pan,
                          dem, dem_interp, apf_file, start_sample=1, im_width=12000, im_height=12000, ms_width=6000,
                          ms_height=6000,    force_run=False):

    """

    :param out_dir: output file directory
    :param ger_info_dir: the extracted files will be put in ger_info_dir
    :param ger_dir: director where .ger is located
    :param cpf_file: a .cpf file
    :param apf_file: a .apf file
    :param band_line: begining line
    :param start_sample: first sample of each line (default is 1.)
    :param im_width: Width of the MS image (default is 6000)
    :param im_height: Height of the MS image (default is 3000)
    :param force_run: True will force to extact all data.
                      False will extact only if file is too old or does not exist.
    :return:
        date = [year, month, day] when image was captured.
        utc_gps = UTC-GPS obtained from .cpf file.
        ut1_utc = UT1-UTC obtained from .cpf file.
        file_name: prefix of name of the files containing information extracted from the .ger file.
    """
    ms_ger_files = []
    ger_file_names = find_ger_files(ger_ms_dir)
    for file_name in ger_file_names:
        ms_ger_files.append(ger_ms_dir + "/" + file_name)
        ms_ger_files.sort()
    ms_ger_output_files = []
    for ger_file in ger_file_names:
        base, ext = os.path.splitext(ger_file)
        ms_ger_output_files.append(ger_ms_info_dir + "/" + base)
        ms_ger_output_files.sort()

    date = MSDataExtraction(ms_ger_files, ms_ger_output_files, cpf_file, force_run)
    # date =[2015,1,2]
    ms_file_name = ms_ger_output_files[0][:-2]
    pan_ger_files = []
    ger_file_names = find_ger_files(ger_pan_dir)
    for file_name in ger_file_names:
        pan_ger_files.append(ger_pan_dir + "/" + file_name)
        pan_ger_files.sort()
    pan_ger_output_files = []
    for ger_file in ger_file_names:
        base, ext = os.path.splitext(ger_file)
        pan_ger_output_files.append(ger_pan_info_dir + "/" + base)
        pan_ger_output_files.sort()

    year, month, day, band_bad_lines, band_degraded_linees = PANDataExtraction(pan_ger_files, pan_ger_output_files, cpf_file, force_run)
    file_name = pan_ger_output_files[0]
    # date = [2015,1,2]
    pan_file_name = pan_ger_output_files[0]
    utc_gps, ut1_utc = locationutil.readGainsAndDarkCurrent(cpf_file)
    out_file = pansharpen_out_dir + "/IMAGERYPANSHARPEN.tif"
    g1 = []
    g2 = []
    g3 = []
    g4 = []
    d1 = []
    d2 = []
    d3 = []
    d4 = []
    gp = []
    dp = []

    for gnumber in range(1, 11):
        g, d = gr.readGainsAndDarkCurrent(cpf_file, 1, gnumber)
        g1.append(g)
        d1.append(d)

        g, d = gr.readGainsAndDarkCurrent(cpf_file, 2, gnumber)
        g2.append(g)
        d2.append(d)

        g, d = gr.readGainsAndDarkCurrent(cpf_file, 3, gnumber)
        g3.append(g)
        d3.append(d)

        g, d = gr.readGainsAndDarkCurrent(cpf_file, 4, gnumber)
        g4.append(g)
        d4.append(d)

        g, d = gr.readGainsAndDarkCurrent(cpf_file, "PAN", gnumber)
        gp.append(g)
        dp.append(d)
    gain = [g1, g2, g3, g4, gp]
    darkcurrent = [d1, d2, d3, d4, dp]


    filter2D = []
    for id in range(1, 10):
        filter = loadFilter(apf_file, "PAN", id)
        filter2D.append(filter)

    #if (os.path.isfile(out_file) == False) or force_run:


    upleft, upright, midpoint, lowleft, lowright, map_info = \
        createImage.buildPanSharpenImageUsingCubicInterpolation(product_level, out_file,  pan_file_name, ms_file_name,
                                                                pansharpen_info_dir, band_line_pan, date, utc_gps,
                                                                ut1_utc,dem, dem_interp, gain, darkcurrent,
                                                                pansharpen_method, filter2D, start_sample= start_sample,
                                                                im_width = im_width, im_height=im_height,
                                                                ms_width_max = ms_width, ms_height_max = ms_height)


    scale = min(im_width/1000,im_height/1000)
    createPreview(out_file, pansharpen_out_dir + "/PREVIEW.JPG", pansharpen_out_dir + "/ICON.JPG", im_width/scale, im_height/scale)


    return date, utc_gps, ut1_utc, file_name, upleft, upright, midpoint, lowleft, lowright, map_info,  \
           band_bad_lines, band_degraded_linees



def build_PANSHARPEN(product_level,pansharpen_method, ger_ms_dir, ger_pan_dir, cpf_file, band_line_pan, pansharpen_info,
                     ger_pan_info_dir, ger_ms_info_dir, pansharpen_out_dir,  apf_file, rev_num, grid_ref, line_shift,
                     dem_dirs, dem_type, dem_interp=demservice.digitalElevationModel.CUBIC,  start_sample=1,
                     im_width=12000,  im_height=12000, force_run=False):
    """

    :param product_level:  Processing Level 1A or 2A
    :param pansharpen_method: Pansharpening Algorithms {Brovey, PCA, GRAM-SCHMIDT, Highpass Modulation
    :param ger_ms_dir: Directory containing MS Ger files
    :param ger_pan_dir:  Directory Containing PAN GER File
    :param cpf_file:  string of the absolute cpf file name
    :param band_line_pan: Begin line of PAN SCENE
    :param pansharpen_info: Directory to save all PANSHARPEN INFO
    :param ger_pan_info_dir: Directory to save all PAN INFO
    :param ger_ms_info_dir:  Directory to save all MS INFO
    :param pansharpen_out_dir:  Directory to save all output file
    :param apf_file:  APF file
    :param dem_dirs: Dem database Directory
    :param dem_type:  Type of dem {THEOS, GLOBE, SRTM90, SRTM30}
    :param dem_interp: Interpolation Method
    :param start_sample: Integer indicating the first sample of each line. Default value is 1
    :param im_width: width of the MS image. Default is 12000
    :param im_height: height of the MS image. Default is 12000
    :param force_run: True will force the program to re-extract and create all images again, False will extract file
                      only if the file does not exist.
    :return:
    """

    ts = time.time()
    print "Building PAN Image......."
    print "Extracting GER file....."
    dem_directories[demservice.SRTM90_DEM] = dem_dirs.SRTM90
    dem_directories[demservice.GLOBE_DEM] = dem_dirs.GLOBE
    dem_directories[demservice.THEOS_DEM] = dem_dirs.THEOS
    if dem_type == demservice.SRTM90_DEM:
        dem = demservice.srtm90(dem_directories[dem_type])
    elif dem_type == demservice.GLOBE_DEM:
        dem = demservice.globedem(dem_directories[dem_type])
    elif dem_type == demservice.THEOS_DEM:
        dem = demservice.theosDEM(dem_directories[dem_type])

    ts = time.time()

    date, utc_gps, ut1_utc, ger_prefix, upleft, upright, midpoint, lowleft, lowright, map_info, \
    band_band_lines, band_degraded_lines =createPanSharpenImage(product_level, pansharpen_method, pansharpen_out_dir,
                                                                 ger_ms_info_dir, pansharpen_info,
                                                                  ger_pan_info_dir, ger_ms_dir, ger_pan_dir, cpf_file,
                                                                  band_line_pan,   dem, dem_interp, apf_file, start_sample,
                                                                  im_width, im_height,  force_run=force_run)

    print "file extraction completed."
    print "computing TILE points."
    view_angles, sat_angles, sat_altitude, sun_angles, orientation = computeDIMAPParametersLevel2A(ger_prefix, dem,
                                                                                                   dem_interp,
                                                                                                   "PAN",
                                                                                                   band_line_pan, date,
                                                                                                   utc_gps,
                                                                                                   ut1_utc,
                                                                                                   start_sample,
                                                                                                   im_width, im_height,
                                                                                                   midpoint)

    print "completed."
    print "Embedding TILE points into theimage file.."
    ms = gdal.Open(pansharpen_out_dir + "/IMAGERYPANSHARPEN.tif", gdal.GA_Update)
    t = time.gmtime()
    metadata = {'TIFFTAG_DATETIME': '%s  ' % time.strftime("%Y%m%d %H:%M:%S", t), 'TIFFTAG_IMAGEDESCRIPTION': 'PAN',
                'AREA_OR_POINT': 'Point'}
    ms.SetMetadata(metadata)
    ms = None
    print "completed."
    tp = time.time()
    print "Total processing time: %fs." % (tp - ts)
    out_file = pansharpen_out_dir + "/IMAGERYPANSHARPEN.tif"
    im = gdal.Open(out_file)
    proj = im.GetProjection()
    src = osr.SpatialReference()
    src.ImportFromWkt(proj)
    epsg = src.GetAttrValue("AUTHORITY", 1)
    map_info.append(epsg)
    width = im.RasterXSize
    height = im.RasterYSize
    map_info.append([width, height])

    angle_list = [upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles,
                  orientation, map_info]
    print "Create DIMAP file."
    job_time = time.time()
    DIMAP1.dimap_create(pansharpen_out_dir, rev_num, "PAN", grid_ref, [band_line_pan], ger_pan_info_dir, cpf_file,
                        angle_list, start_sample, im_width, im_height, band_band_lines,
                        band_degraded_lines, line_shift, job_time)
    return upleft, upright, midpoint, lowleft, lowright, map_info, view_angles, sat_angles, \
           sat_altitude, sun_angles, orientation, band_band_lines, band_degraded_lines



def buildPanSharpen2A(pan_ger_directory,ms_ger_directory,cpf_file,apf_file,pan_begin_line,dem_directory,pan_info_directory,
                      ms_info_directory, pansharpen_info_directory,destination_directory, pan_out_directory,
                      rev_num, grid_ref,dem_interpolation=None,   line_shift=0,start_sample = 1,im_width=None,im_height = None,force_run= False):
    """

    :param pan_ger_directory:
    :param ms_ger_directory:
    :param cpf_file:
    :param apf_file:
    :param pan_begin_line:
    :param dem_directory:
    :param pan_info_directory:
    :param pansharpen_info_directory:
    :param destination_directory:
    :param rev_num:
    :param grid_ref:
    :param dem_interpolation:
    :param line_shift:
    :param start_sample:
    :param im_width:
    :param im_height:
    :param force_run:
    :return:
    """

    upleft, upright, midpoint, lowleft, lowright, map_info, view_angles, sat_angles, sat_altitude, sun_angles, \
    orientation, band_band_lines, band_degraded_lines =\
        build_PANSHARPEN(ms_ger_directory, pan_ger_directory, cpf_file, pan_begin_line, pansharpen_info_directory,
                         pan_info_directory, ms_info_directory,destination_directory, pan_out_directory, dem_directory,
                         apf_file)
    angle_list = [upleft, upright, midpoint, lowleft, lowright, view_angles, sat_angles, sat_altitude, sun_angles,
                  orientation, map_info]
    print "Create DIMAP file."
    job_time = time.time()
    DIMAP1.dimap_create(destination_directory, rev_num, "PAN", grid_ref, [pan_begin_line], pan_info_directory, cpf_file,
                        angle_list, start_sample, im_width, im_height, band_band_lines,
                        band_degraded_lines, line_shift, job_time)
