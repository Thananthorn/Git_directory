"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

 """

import numpy as np
import xml.etree.ElementTree as ET
import locationutil as util
import cv2
import determine_pixel_shift as dps
import utmLatlon
import scipy.signal as signal
import gdal
import psutil
import scipy.interpolate as inplt


from systemConstants import LV1_2ProductionConstants


def readGainsAndDarkCurrent(cpf_file, band, gain_number):
    """
    read CPF file
    :param cpf_file:
    :param band: BAND "PAN", "1", "2", "3", 4"
    :param gain_number:  "Gain number 0 to 9
    :return:
    array of relative gains and dark currrents for each CCD sensor
    """
    tree = ET.parse(cpf_file)
    root = tree.getroot()
    if band == "PAN":
        gains_txt = root.findall("./RadiometricParameters/PAN/G%d/DetectorRelativeGains" % (gain_number))[0].text
        darkCurrent_txt = root.findall("./RadiometricParameters/PAN/G%d/DarkCurrents" % (gain_number))[0].text
    else:
        gains_txt = root.findall("./RadiometricParameters/B%d/G%d/DetectorRelativeGains" % (band, gain_number))[0].text
        darkCurrent_txt = root.findall("./RadiometricParameters/B%d/G%d/DarkCurrents" % (band, gain_number))[0].text
    # print gains_txt
    gains_txt = gains_txt.split(",")

    darkCurrent_txt = darkCurrent_txt.split(",")
    gains = []
    darkCurrents = []
    for it in range(len(gains_txt)):
        gains.append(float(gains_txt[it]))
        darkCurrents.append(float(darkCurrent_txt[it]))
    gains = np.array(gains)
    darkCurrents = np.array(darkCurrents)
    return gains, darkCurrents
def readDataBand(gdalband ,sample, line, width, height, gain, dark_curr, gain_numbers, im_type):

    pixels = np.arange(sample, sample + width).reshape((1, width))
    y_min = line
    im_data = gdalband.ReadAsArray(sample, line, width, height)

    if im_type == "PAN":
        nlines = gain_numbers.shape[0]
        glo = gain_numbers[:, 0].reshape((nlines, 1))
        gle = gain_numbers[:, 1].reshape((nlines, 1))
        gro = gain_numbers[:, 2].reshape((nlines, 1))
        gre = gain_numbers[:, 3].reshape((nlines, 1))
        gns = glo[y_min:(y_min + height), :] * (pixels < 6000) * (pixels % 2 == 0) + \
              gle[y_min:(y_min + height), :] * (pixels < 6000) * (pixels % 2 == 1) + \
              gro[y_min:(y_min + height), :] * (pixels >= 6000) * (pixels % 2 == 0) + \
              gre[y_min:(y_min + height), :] * (pixels >= 6000) * (pixels % 2 == 1)
    elif im_type == "MS":
        nlines = gain_numbers.shape[0]
        g = gain_numbers.reshape((nlines,1))
        gns = np.repeat(g[y_min:(y_min + height),:],width, 1)
    pix_gain = np.zeros_like(im_data, 'float32')
    pix_drk = np.zeros_like(im_data, 'float32')
    for idg in range(len(gain)):
        pix_gain = pix_gain + (gns == (idg)) * gain[idg][pixels]
        pix_drk = pix_drk + (gns == (idg)) * dark_curr[idg][pixels]
    # print gain[2][pixels], pix_gain, pix_gain.min(), pix_gain.max()
    # print np.nonzero(pix_gain == 0.0)
    # pix_gain = gain[gns]
    # pix_drk = dark_cur[gns]
    im_data = im_data.astype('float32')
    saturated_pix = (im_data >= 254.8).astype('float32')
    if LV1_2ProductionConstants.EQUALIZATION:
        im_data = (im_data - pix_drk) / pix_gain
    im_data = im_data*(1-saturated_pix) + LV1_2ProductionConstants.MAX_DN*saturated_pix
    im_data = im_data.astype('float32')
    return im_data

def findSamplesPoints(in_file_name, step, lines,sat_pos, sat_time, sat_att, image_data,offset_mins, current_date,
                      utc_gps, dut1, dem, dem_interpolation_method, im_width, im_height, precision_error = 1.0,
                      max_percision_error = 5.0,process_box = 500, im_register = False):
    """
    Find the sample points used for Band to Ban registration on MS Image
    :param in_file_name: a string containing file name prefix of MS data
    :param step: Number of step grid
    :param lines:  starting lines of all MS bands
    :param sat_pos: Array of satellite Position
    :param sat_time: Array of satellite time
    :param sat_att: Array of satellite Attitude
    :param image_data: List of image data from all bands
    :param offset_mins: # The offset in the data loading
    :param current_date: [Year, month, day] of image acquisition date
    :param utc_gps: UTC-GPS time
    :param dut1: UT1-UTC time
    :param dem: Dem object
    :param dem_interpolation_method: Dem interpolation techqiue
    :param im_width:  width of Band 3 Scene
    :param im_height: Height of Band 3 scene
    :param precision_error: The desired precion erros
    :param max_percision_error: The maximum allowed errors
    :param process_box: Processing Box size
    :param im_register: Flag to indicate fine tune registration using image to image registration.
    :return:
        x1out, x2out, x3out, x4out, y1out, y2out, y3out, y4outx1out, x2out, x3out, x4out, y1out, y2out, y3out, y4out:
        tie points for Band1, Band2, Band3 and Band4
    """


    pos1, pos2, pos3, pos4 = sat_pos
    time1, time2, time3, time4 = sat_time
    att1, att2, att3, att4 = sat_att

    x1 = []
    y1 = []
    x2 = []
    y2 = []
    x3 = []
    y3 = []
    x4 = []
    y4 = []



    for block_line in range(0,im_height, process_box) :
        for block_sample in range(0, im_width, process_box):

            #block_line = 5500
            mid_sample = block_sample + process_box/2
            mid_line = block_line + process_box/2

            print "Find the initial shift at the middle of an image (%d,%d)" % (mid_sample, mid_line)
            lat3a, lon3a, h3a = dps.findInterSectionPointArrayUsingDEMPreloaded("MS", in_file_name,np.array([mid_sample]),
                                                                                [mid_line + lines[2]], pos3, time3,att3,
                                                                                current_date, utc_gps, dut1, dem,
                                                                                dem_interpolation_method, band=3)

            x3a, y3a, zn3, zt3 = utmLatlon.from_latlon(lat3a, lon3a)
            dx_init = np.zeros((4,))
            dy_init = np.zeros((4,))
            for band in [1, 2, 4]:
                best_solution_found = False
                dx = 0
                dy = 0
                while not best_solution_found:
                    err_min = 1e100

                    for tx in [-1,0,1]:
                        for ty in [-1,0,1]:
                            latb, lonb, hb = util.computeViewLatLongArrayWithHeight(band, np.array([dx]) + tx + mid_sample,
                                                                                    np.array([dy]) + ty + mid_line, h3a,
                                                                                    lines[band - 1],
                                                                                    sat_pos[band - 1],
                                                                                    sat_att[band - 1],
                                                                                    sat_time[band - 1],
                                                                                    current_date[0], current_date[1],
                                                                                    current_date[2], utc_gps, dut1)
                            xb, yb, zn, zt = utmLatlon.from_latlon(latb, lonb, zn3)
                            error = np.sqrt((xb - x3a) ** 2 + (yb - y3a) ** 2)[0]
                            if error < err_min:
                                err_min = error
                                dx_temp = tx
                                dy_temp = ty

                    if (dx_temp == 0) and (dy_temp == 0):
                        best_solution_found = True

                        dx_init[band - 1] = dx
                        dy_init[band - 1] = dy
                    else:
                        dx += dx_temp
                        dy += dy_temp

                print "The initial dislacement for Band %d is (%d,%d)" % (band, dx_init[band - 1], dy_init[band - 1])
            bline = block_line
            bsample = block_sample
            #block_width = im_width
            max_block_height = process_box
            max_block_width = process_box
            block_height = min((im_height - bline), max_block_height)
            block_width = min(im_width - bsample, max_block_width)
            line_str = block_line
            line_stp = line_str + block_height
            sample_str = block_sample
            sample_stp = sample_str + block_width
            samples2 = np.arange(sample_str + step/2, sample_stp, step)



            for line in range(line_str + step/2 , line_stp, step):
                print "working on Line: %d" % (line)


                lat3a, lon3a, h3a = dps.findInterSectionPointArrayUsingDEMPreloaded("MS", in_file_name, samples2+1,
                                                                                        [line + lines[2]], pos3, time3,
                                                                                        att3, current_date,
                                                                                        utc_gps, dut1, dem,
                                                                                        dem_interpolation_method,
                                                                                        band=3)
                x3a, y3a, zn3, zt3 = utmLatlon.from_latlon(lat3a, lon3a, zn3)
                #x3.append(samples2)
                #y3.append(line*np.ones_like(samples2))
                sard_times = np.loadtxt(in_file_name + "B%dsadr_times.txt"%3)
                sard_last_time = sard_times[-1]
                valid_pixels = np.ones_like(samples2)
                for band in [1, 2, 4]:
                    sx_in = (samples2 + dx_init[band - 1]).astype('float64')
                    sy_in = (np.array(line + dy_init[band - 1]) * np.ones_like(samples2)).astype('float64')
                    err_sx = np.ones_like(sx_in) * 2.0
                    err_sy = np.ones_like(sx_in) * 2.0
                    num_fail = 0
                    idx = np.arange(len(samples2))
                    it = 0
                    while it < LV1_2ProductionConstants.MAX_ITERATION_BAND2BAND_CORRESPONDING_POINTS :
                        sx = sx_in[idx]
                        sy = sy_in[idx]
                        hb = h3a[idx]
                        lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy,
                                                                              hb, lines[band - 1], sat_pos[band - 1],
                                                                              sat_att[band - 1], sat_time[band - 1],
                                                                              current_date[0], current_date[1],
                                                                              current_date[2], utc_gps, dut1)
                        xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon, zn3)
                        errx = xb - x3a[idx]
                        erry = yb - y3a[idx]


                        lat1, lon1, ht = util.computeViewLatLongArrayWithHeight(band, sx + 1.0, sy,
                                                                                hb, lines[band - 1], sat_pos[band - 1],
                                                                                sat_att[band - 1], sat_time[band - 1],
                                                                                current_date[0], current_date[1],
                                                                                current_date[2], utc_gps, dut1)
                        lat2, lon2, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy + 1.0,
                                                                                hb, lines[band - 1], sat_pos[band - 1],
                                                                                sat_att[band - 1], sat_time[band - 1],
                                                                                current_date[0], current_date[1],
                                                                                current_date[2], utc_gps, dut1)
                        xb1, yb1, zn, zt = utmLatlon.from_latlon(lat1, lon1, zn3)
                        xb2, yb2, zn, zt = utmLatlon.from_latlon(lat2, lon2, zn3)

                        total_errors = np.sqrt(errx ** 2 + erry ** 2)
                        gx = 2.0 * errx * (xb1 - xb) + 2.0 * (erry) * (yb1 - yb)
                        gy = 2.0 * errx * (xb2 - xb) + 2.0 * (erry) * (yb2 - yb)
                        lamb = (0.1 / total_errors)
                        lamb = (lamb > 0.001) * 0.001 + (lamb <= 0.001) * lamb

                        lamb = (lamb < 1e-7) * 1e-7 + (lamb >= 1e-7) * lamb

                        itx = 0
                        it_max = 100
                        new_total_error = total_errors.copy()
                        while (new_total_error >= total_errors).sum() and (itx < it_max):
                            sxt = sx - lamb * gx
                            syt = sy - lamb * gy

                            lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sxt, syt,
                                                                                  hb, lines[band - 1],
                                                                                  sat_pos[band - 1],
                                                                                  sat_att[band - 1], sat_time[band - 1],
                                                                                  current_date[0], current_date[1],
                                                                                  current_date[2], utc_gps, dut1)

                            try:
                                xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon, zn3)
                                errold_x = errx.copy()
                                errold_y = erry.copy()
                                errx = xb - x3a[idx]
                                erry = yb - y3a[idx]

                                old_total_error = new_total_error.copy()
                                new_total_error = np.sqrt(errx ** 2 + erry ** 2)
                                lamb = (lamb / 2.0) * (new_total_error >= total_errors) + \
                                       (lamb / 2.0) * (new_total_error < total_errors) * (
                                           new_total_error < old_total_error) + \
                                       (lamb) * (new_total_error < total_errors) * (new_total_error >= old_total_error)

                                errx = errx * (new_total_error >= total_errors) + \
                                       errx * (new_total_error < total_errors) * (new_total_error < old_total_error) + \
                                       errold_x * (new_total_error < total_errors) * (
                                           new_total_error >= old_total_error)

                                erry = erry * (new_total_error >= total_errors) + \
                                       erry * (new_total_error < total_errors) * (new_total_error < old_total_error) + \
                                       errold_y * (new_total_error < total_errors) * (
                                           new_total_error >= old_total_error)

                                itx += 1
                            except:
                                lamb = lamb / 10.0

                                itx += 1

                        sx = sx - (lamb * 2) * gx
                        sy = sy - (lamb * 2) * gy
                        sx_in[idx] = sx
                        sy_in[idx] = sy
                        err_sx[idx] = errx
                        err_sy[idx] = erry

                        if itx == it_max:
                            # print "[%d] cannot improve the performance any future!" % (band),
                            # print "..... error x: %f, error y: %f." % ( errxm, errym)
                            # print "Exiting the solution searching"
                            # print "Try to randomly move around. "
                            sx_bestold = sx.copy()
                            sy_bestold = sy.copy()
                            if num_fail < 5:
                                sx = sx_bestold + 2.0 * (
                                np.random.rand(sx.shape[0]) - 0.5)  # samples2 + dx_init[band - 1]
                                sy = sy_bestold + 2.0 * (np.random.rand(
                                    sx.shape[0]) - 0.5)  # np.array(line + dy_init[band - 1]) * np.ones_like(samples2)
                                num_fail += 1
                            else:
                                print "Warning: There are saving %d pixels from Band %d with positioning error more than " \
                                      "%f meters." % (sx.shape[0], band, precision_error)

                                id_max = np.nonzero((np.abs(err_sx) > max_percision_error) + (np.abs(err_sy) > max_percision_error))[0]

                                valid_pixels[id_max] = 0

                        idx = np.nonzero((np.abs(err_sx)>precision_error )+(np.abs(err_sy) >precision_error ))[0]
                        if len(idx) == 0 : #and (not brute_force):

                            it = 200
                        else:
                            it += 1




                    if band == 1:
                        #print "1:", np.abs(sx1-sx_in).mean() , np.abs(sy1-sy_in).mean(),  np.abs(sx1-sx_in).max() , np.abs(sy1-sy_in).max()
                        sx1 = sx_in.copy()  # x1.append(sx)
                        sy1 = sy_in.copy()  # y1.append(sy)
                    elif band == 2:
                        #print "2:", np.abs(sx2 - sx_in).mean(), np.abs(sy2 - sy_in).mean(),  np.abs(sx2-sx_in).max() , np.abs(sy2-sy_in).max()
                        sx2 = sx_in.copy()  # x2.append(sx)
                        sy2 = sy_in.copy()  # y2.append(sy)
                    elif band == 4:
                        #print "4:", np.abs(sx4 - sx_in).mean(), np.abs(sy4 - sy_in).mean(),   np.abs(sx4-sx_in).max() , np.abs(sy4-sy_in).max()
                        sx4 = sx_in.copy()  # x4.append(sx)
                        sy4 = sy_in.copy()  # sy4.append(sy)




                if (sx1 is not None) & (sy1 is not None) & (sx2 is not None) & (sy2 is not None) & (sx4 is not None) &  (sy4 is not None):

                    id_ready = np.nonzero(valid_pixels)[0]
                    id_max = np.nonzero(valid_pixels == 0)[0]
                    if np.any(sx1) is None:
                        print sx1
                    if len(id_max) > 0 :
                        print "Warning: We need to remove %d pixels due to the maximum error is more than the " \
                              "maximum limit of %f meters" % (id_max.shape[0], max_percision_error)
                        if valid_pixels.sum() > 0 :
                            x1.append(sx1[id_ready])
                            x2.append(sx2[id_ready])
                            x3.append(samples2[id_ready])
                            x4.append(sx4[id_ready])

                            y1.append(sy1[id_ready])
                            y2.append(sy2[id_ready])
                            y3.append(line*np.ones_like(samples2[id_ready]))
                            y4.append(sy4[id_ready])
                    else:
                        x1.append(sx1)
                        x2.append(sx2)
                        x3.append(samples2)
                        x4.append(sx4)

                        y1.append(sy1)
                        y2.append(sy2)
                        y3.append(line * np.ones_like(samples2))
                        y4.append(sy4)

    num_items = 0
    for item in x1:
        num_items += len(item)
    x1out = np.zeros((num_items,))
    x2out = np.zeros((num_items,))
    x3out = np.zeros((num_items,))
    x4out = np.zeros((num_items,))

    y1out = np.zeros((num_items,))
    y2out = np.zeros((num_items,))
    y3out = np.zeros((num_items,))
    y4out = np.zeros((num_items,))

    num_list = len(x1)
    str = 0
    for list_id in range(num_list):
        stp = str + len(x1[list_id])
        x1out[str:stp] = x1[list_id]
        x2out[str:stp] = x2[list_id]
        x3out[str:stp] = x3[list_id]
        x4out[str:stp] = x4[list_id]

        y1out[str:stp] = y1[list_id]
        y2out[str:stp] = y2[list_id]
        y3out[str:stp] = y3[list_id]
        y4out[str:stp] = y4[list_id]
        str = stp


    if im_register :
        print "Fine Tuning using SIFT-based image-to-image registration"
        print "Find keys points between images"
        size_width = 1000
        margins = 100
        sf = cv2.SIFT()
        FLANN_INDEX_KDTREE = 0
        index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
        search_params = dict(checks=50)  # or pass empty dictionary
        flann = cv2.FlannBasedMatcher(index_params, search_params)
        bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
        keys_points = []
        descriotors = []
        points13out = list()
        points23out = list()
        points43out = list()
        for band in  range(4):
            data_h, data_w = image_data[band].shape
            keys_band = []
            des_band =[]
            for k in range(0,data_h,size_width):
                for m in range(0,data_w, size_width):
                    str_row = max(0, k - margins)
                    str_col = max(0, m - margins)
                    stp_row = min(data_h, k + size_width + margins)
                    stp_col = min(data_w, m + size_width + margins)
                    data_k = image_data[band][str_row:stp_row, str_col:stp_col]
                    data_k = (data_k > 0) * (data_k < 255) * data_k + 255*(data_k >= 255)
                    data_k = np.round(data_k).astype('uint8')
                    keys, des = sf.detectAndCompute(data_k, None)
                    for cnt in range(len(keys)):
                        pt = keys[cnt].pt
                        x = pt[0] + str_col
                        y = pt[1] + str_row
                        if (y > k) and (y < k+size_width) and (x > m) and (x < m + size_width):
                            keys_band.append(np.array([x,y]))
                            des_band.append(des[cnt])
            if len(keys_band) > 0:
                keys_band = np.array(keys_band)
                des_band = np.array(des_band)
                print "There are %d key points for Band %d." %(len(keys_band), band + 1)

            keys_points.append(keys_band)
            descriotors.append(des_band)

        num_sample_points = x3out.size
        wd = step/2
        for k in range(num_sample_points):
            sx3 = int(x3out[k])
            sy3 = int(y3out[k])
            if (sx3 >= wd) & (sx3 < im_width - wd) & (sy3 >= wd) & (sy3 < im_height - wd):
                valid_area = (keys_points[2][:,0] >= sx3-wd) * (keys_points[2][:,0] < sx3 + wd)
                valid_area *=  (keys_points[2][:,1] >= sy3-wd) * (keys_points[2][:,1] < sy3 + wd)
                id_keys = np.nonzero(valid_area)[0]
                if (len(id_keys) > 0 ):
                    keys3 = keys_points[2][id_keys,:]
                    des3 = descriotors[2][id_keys, :].astype('float32')
                    for band in [1, 2, 4]:

                        band_id = band -1
                        if band == 1:
                            sxb = x1out[k]
                            syb = y1out[k]
                        elif band == 2:
                            sxb = x2out[k]
                            syb = y2out[k]
                        elif band == 4:
                            syb = y1out[k]
                        bandheight = image_data[band - 1].shape[0]
                        max_lineb = bandheight + offset_mins[band - 1]
                        if (sxb >= wd) & (sxb < im_width - wd) & (syb >= wd) & (syb < max_lineb - wd):

                            valid_area = (keys_points[band_id][:, 0] >= sxb - wd) * (keys_points[band_id][:, 0] < sxb + wd)
                            valid_area *= (keys_points[band_id][:, 1] >= syb - wd - offset_mins[band_id]) * \
                                          (keys_points[band_id][:, 1] < syb + wd - offset_mins[band_id])
                            id_keys = np.nonzero(valid_area)[0]
                            if (len(id_keys) > 0):
                                keysb = keys_points[band_id][id_keys, :]
                                desb = descriotors[band_id][id_keys, :].astype('float32')
                                if len(keys3) >= 1 and len(keysb) > 1:
                                    matches = flann.knnMatch(des3, desb, k=2)
                                    scores = np.zeros(len(matches))
                                    # matchesMask = [[0, 0] for i in range(len(matches))]
                                    cnt = 0

                                    for (m0, m1) in matches:
                                        scores[cnt] = m1.distance / m0.distance
                                        cnt += 1

                                    if scores.max() > 2:
                                        good_points = np.nonzero(scores > 2)[0]

                                        dx = 0
                                        dy = 0
                                        num_good_points = len(good_points)

                                        for pnt in good_points:
                                            mbest = matches[pnt][0]
                                            p3 = np.round(keys3[mbest.queryIdx])
                                            #print "p3:", p3
                                            #image_data_in[2][int(p3[1]), int(p3[0])] = 255
                                            pb = np.round(keysb[mbest.trainIdx])
                                            #print "pb: ", pb
                                            #image_data_in[band_id][int(pb[1]),  int(pb[0])] = 255
                                            tx = pb[0] - p3[0] - (sxb - sx3)
                                            ty = pb[1] + offset_mins[band_id] - p3[1] - (syb - sy3)
                                            if sy3 < 5000:
                                                if abs(tx) <= 1 and abs(ty) < 1 :
                                                    dx += tx
                                                    dy += ty
                                                else:
                                                    num_good_points  -= 1
                                            else:
                                                if abs(tx) <= 3 and abs(ty) < 3 :
                                                    dx += tx
                                                    dy += ty
                                                else:
                                                    num_good_points  -= 1



                                            if band == 1:
                                                points13out.append(np.array([pb, p3]))
                                            elif band == 2:
                                                points23out.append(np.array([pb, p3]))
                                            elif band == 4:
                                                points43out.append(np.array([pb, p3]))
                                            #if matches[pnt][0].distance < min_distace:
                                            #    min_distace = matches[pnt][0].distance

                                        if num_good_points > 0:
                                            dx = dx / num_good_points
                                            dy = dy / num_good_points
                                        #print "new dx =%f, dy = %f." % (dx, dy)
                                        if band == 1:
                                            x1out[k] += dx
                                            y1out[k] += dy
                                        elif band == 2:
                                            x2out[k] += dx
                                            y2out[k] += dy
                                        elif band == 4:
                                            x4out[k] += dx
                                            y4out[k] += dy

    return x1out, x2out, x3out, x4out, y1out, y2out, y3out, y4out


def remapImageBandGridMethod(xb, yb, x3, y3, line_str, sample_str, block_size, im_width, im_height, offset_min,
                             max_error=0.1, desired_size = 500):

    end_line = min(line_str + block_size, im_height)
    end_sample = min(sample_str + block_size, im_width)
    #print "working on line:%d to %d and sample: %d to %d" % (line_str, end_line, sample_str, end_sample)
    block_height = end_line - line_str
    block_width = end_sample - sample_str
    out_x = np.zeros((block_height, block_width),'float32')
    out_y = np.zeros((block_height, block_width), 'float32')
    mask  = np.ones((block_height, block_width),'uint8')
    idx = np.nonzero((x3 >= sample_str) * (x3 < end_sample) * (y3 >= line_str) * (y3 < end_line))[0]
    u = x3[idx]
    v = y3[idx]
    num_samples = u.size
    mid_sample = np.median(u)
    mid_line = np.median(v)
    ut = (u - mid_sample).astype('float64')
    vt = (v - mid_line).astype('float64')
    AA = np.zeros((num_samples, 6), 'float64')
    AA[:, 0] = 1.0
    AA[:, 1] = ut
    AA[:, 2] = vt
    AA[:, 3] = ut * vt
    AA[:, 4] = ut ** 2
    AA[:, 5] = vt ** 2

    x1 = xb[idx]
    y1 = yb[idx]
    b = x1 - mid_sample
    par_x1 = np.linalg.lstsq(AA, b)[0]
    errx1 = (np.abs(np.dot(AA, par_x1) - b).max())
    #print "max error column: %f" % errx1

    b = y1 - mid_line
    par_y1 = np.linalg.lstsq(AA, b)[0]
    erry1 = (np.abs(np.dot(AA, par_y1) - b).max())
    #print "max error row: %f" % erry1
    if ((errx1>max_error) or (erry1 > max_error)) and (block_size > desired_size):
        new_block_size = desired_size #max(block_size / 2,500)
        for sub_line in range(line_str, end_line, new_block_size):
            for sub_sample in range(sample_str, end_sample, new_block_size):

                lstr = sub_line - line_str
                sstr = sub_sample - sample_str
                sub_block_line_end = min(sub_line + new_block_size, end_line)
                sub_block_sample_end = min(sub_sample + new_block_size, end_sample)
                sub_out_x, sub_out_y, sub_mask = remapImageBandGridMethod( xb, yb, x3, y3, sub_line, sub_sample,
                                                                 new_block_size, im_width,im_height, offset_min,
                                                                 max_error)

                sub_block_line_end -= line_str
                sub_block_sample_end -= sample_str
                #print lstr, sstr, sub_block_line_end, sub_block_sample_end
                w = sub_block_sample_end - sstr
                h = sub_block_line_end - lstr
                out_x[lstr:sub_block_line_end, sstr: sub_block_sample_end] = sub_out_x[:h,:w]
                out_y[lstr:sub_block_line_end, sstr: sub_block_sample_end] = sub_out_y[:h, :w]
                mask[lstr:sub_block_line_end, sstr: sub_block_sample_end] = sub_mask[:h,:w]
    else:
        bline = line_str
        bsample = sample_str
        V, U = np.mgrid[bline:bline+block_height, bsample:bsample + block_width]

        sub_mask = np.ones_like(U,"uint8")

        u1d = U.flatten()
        v1d = V.flatten()
        num_pairs = u1d.size
        A = np.zeros((num_pairs, 6))
        ut = (u1d - mid_sample).astype('float64')
        vt = (v1d - mid_line).astype('float64')
        A[:, 0] = 1.0
        A[:, 1] = ut
        A[:, 2] = vt
        A[:, 3] = ut * vt
        A[:, 4] = ut ** 2
        A[:, 5] = vt ** 2

        sub_mask = sub_mask.flatten()

        x = np.dot(A, par_x1) + mid_sample
        y = np.dot(A, par_y1) + mid_line - offset_min
        x = x.astype('float32')
        y = y.astype('float32')
        out_x = x.reshape(U.shape)
        out_y = y.reshape(U.shape)
        idx = np.nonzero((x < 0))[0]
        sub_mask[idx] = 0
        idx = np.nonzero((x > im_width - 1))[0]
        sub_mask[idx] = 0
        # mask[y > im_height-1, x > im_width-1] = 0

        sub_mask = sub_mask.reshape(U.shape)
        out_x = out_x
        out_y = out_y
        mask = sub_mask



    return out_x, out_y, mask


def gainCorrectionPAN(one_block, x_min, y_min, load_width, load_height, glo, gle ,gro, gre,  gain, dark_cur):
    pixels = np.arange(x_min, x_min + load_width).reshape((1, load_width))
    gns = glo[y_min:(y_min + load_height), :] * (pixels < 6000) * (pixels % 2 == 0) + \
          gle[y_min:(y_min + load_height), :] * (pixels < 6000) * (pixels % 2 == 1) + \
          gro[y_min:(y_min + load_height), :] * (pixels >= 6000) * (pixels % 2 == 0) + \
          gre[y_min:(y_min + load_height), :] * (pixels >= 6000) * (pixels % 2 == 1)

    pix_gain = np.zeros_like(one_block, 'float32')
    pix_drk = np.zeros_like(one_block, 'float32')
    for idg in range(len(gain)):
        pix_gain = pix_gain + (gns == (idg)) * gain[idg][pixels]
        pix_drk = pix_drk + (gns == (idg)) * dark_cur[idg][pixels]
    one_block = one_block.astype('float32')
    one_block = (one_block - pix_drk) / pix_gain
    one_block = one_block.astype('float32')
    return one_block

def panDeconvolution(one_block,filter2D):
    summ = cv2.GaussianBlur(one_block.astype('uint8'), LV1_2ProductionConstants.PAN_GAUSSIAN_SIZE,
                            LV1_2ProductionConstants.PAN_GAUSSIAN_SIGMA)
    edges = cv2.Canny(summ.astype('uint8'), LV1_2ProductionConstants.PAN_CANNY_TH1,
                      LV1_2ProductionConstants.PAN_CANNY_TH2, L2gradient=False)
    edges = cv2.filter2D(edges, cv2.CV_8U, LV1_2ProductionConstants.PAN_EDGE_KERNEL)

    kernel = LV1_2ProductionConstants.PAN_SUM_KERNEL
    summ = signal.convolve2d(one_block, kernel, mode='same', fillvalue=0.0)
    gradient = np.abs(one_block - summ) * (edges > 0)

    gradient[0, :] = 0
    gradient[1, :] = 0
    gradient[-1, :] = 0
    gradient[-2, :] = 0
    gradient[:, 0] = 0
    gradient[:, 1] = 0
    gradient[:, -1] = 0
    gradient[:, -2] = 0
    my_filter_im = np.zeros_like(one_block).astype('float32')
    idx, idy = np.nonzero(gradient < LV1_2ProductionConstants.PAN_TH1)
    my_filter_im[idx, idy] = one_block[idx, idy]
    idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH1) * (
        gradient < LV1_2ProductionConstants.PAN_TH2))
    tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[3], borderType=cv2.BORDER_REFLECT)
    my_filter_im[idx, idy] = tem[idx, idy]
    idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH2) * (
        gradient < LV1_2ProductionConstants.PAN_TH3))
    tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[4], borderType=cv2.BORDER_REFLECT)
    my_filter_im[idx, idy] = tem[idx, idy]
    idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH3) * (
        gradient < LV1_2ProductionConstants.PAN_TH4))
    tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[5], borderType=cv2.BORDER_REFLECT)
    my_filter_im[idx, idy] = tem[idx, idy]
    idx, idy = np.nonzero((gradient >= LV1_2ProductionConstants.PAN_TH4))
    tem = cv2.filter2D(one_block, cv2.CV_32F, filter2D[6], borderType=cv2.BORDER_REFLECT)
    my_filter_im[idx, idy] = tem[idx, idy]
    filtered_im = my_filter_im.copy()
    return filtered_im



def findSamplesPointsMS2PAN(ms_in_file_name, pan_in_file_name, step, samples_zero_ms, ms_lines, pan_line, sat_pos, sat_time, sat_att,
                            current_date, utc_gps, dut1, dem, dem_interpolation_method, im_width, im_height,
                            precision_error = 0.1, max_percision_error = 2.0, im_register = False):
    """
    Find the sample points used for Band to Ban registration on MS Image
    :param in_file_name: a string containing file name prefix of MS data
    :param step: Number of step grid
    :param lines:  starting lines of all MS bands
    :param sat_pos: Array of satellite Position
    :param sat_time: Array of satellite time
    :param sat_att: Array of satellite Attitude
    :param image_data: List of image data from all bands
    :param offset_mins: # The offset in the data loading
    :param current_date: [Year, month, day] of image acquisition date
    :param utc_gps: UTC-GPS time
    :param dut1: UT1-UTC time
    :param dem: Dem object
    :param dem_interpolation_method: Dem interpolation techqiue
    :param im_width:  width of Band 3 Scene
    :param im_height: Height of Band 3 scene
    :param precision_error: The desired precion erros
    :param max_percision_error: The maximum allowed errors
    :param process_box: Processing Box size
    :param im_register: Flag to indicate fine tune registration using image to image registration.
    :return:
        x1out, x2out, x3out, x4out, y1out, y2out, y3out, y4outx1out, x2out, x3out, x4out, y1out, y2out, y3out, y4out:
        tie points for Band1, Band2, Band3 and Band4
    """


    pos1, pos2, pos3, pos4, pos_pan = sat_pos
    time1, time2, time3, time4, time_pan = sat_time
    att1, att2, att3, att4, att_pan = sat_att

    x1 = []
    y1 = []
    x2 = []
    y2 = []
    x3 = []
    y3 = []
    x4 = []
    y4 = []
    xp = []
    yp = []


    panToMsFactor = 2.0/15.0

    block_line  = 0 #in range(0,im_height, process_box) :
    block_sample = 0 #in range(0, im_width, process_box):

    #block_line = 5500
    org_sample = block_sample
    org_line = block_line
    ms_org_line = (org_line * 2)/15
    ms_org_sample = (org_sample * 2) / 15

    print "Find the initial shift at the middle of an image (%d,%d)" % (org_sample, org_line)
    latpa, lonpa, hpa = dps.findInterSectionPointArrayUsingDEMPreloaded("PAN", pan_in_file_name,
                                                                        np.array([org_sample]),
                                                                        [org_line + pan_line], pos_pan, time_pan,
                                                                        att_pan, current_date, utc_gps, dut1, dem,
                                                                        dem_interpolation_method)

    xpa, ypa, znp, ztp = utmLatlon.from_latlon(latpa, lonpa)
    dx_init = np.zeros((4,))
    dy_init = np.zeros((4,))
    for band in [1, 2, 3, 4]:
        best_solution_found = False
        dx = 0
        dy = 0
        while not best_solution_found:
            err_min = 1e100

            for tx in [-1,0,1]:
                for ty in [-1,0,1]:

                    latb, lonb, hb = util.computeViewLatLongArrayWithHeight(band, np.array([dx]) + tx
                                                                            + ms_org_sample + samples_zero_ms[band-1],
                                                                            np.array([dy]) + ty + ms_org_line, hpa,
                                                                            ms_lines[band - 1],
                                                                            sat_pos[band - 1],
                                                                            sat_att[band - 1],
                                                                            sat_time[band - 1],
                                                                            current_date[0], current_date[1],
                                                                            current_date[2], utc_gps, dut1)
                    xb, yb, zn, zt = utmLatlon.from_latlon(latb, lonb, znp)
                    error = np.sqrt((xb - xpa) ** 2 + (yb - ypa) ** 2)[0]
                    if error < err_min:
                        err_min = error
                        dx_temp = tx
                        dy_temp = ty

            if (dx_temp == 0) and (dy_temp == 0):
                best_solution_found = True

                dx_init[band - 1] = dx
                dy_init[band - 1] = dy
            else:
                dx += dx_temp
                dy += dy_temp

        print "The initial dislacement for Band %d is (%d,%d)" % (band, dx_init[band - 1], dy_init[band - 1])
    bline = block_line
    bsample = block_sample
    #block_width = im_width
    max_block_height = im_height
    max_block_width = im_width
    block_height = min((im_height - bline), max_block_height)
    block_width = min(im_width - bsample, max_block_width)
    line_str = block_line
    line_stp = line_str + block_height
    sample_str = block_sample
    sample_stp = sample_str + block_width
    samples2 = np.arange(sample_str + step/2, sample_stp, step)



    for line in range(line_str + step/2 , line_stp, step):
        print "working on Line: %d" % (line)


        latpa, lonpa, hpa = dps.findInterSectionPointArrayUsingDEMPreloaded("PAN", pan_in_file_name, samples2+1,
                                                                            [line + pan_line], pos_pan, time_pan,
                                                                            att_pan, current_date, utc_gps, dut1,
                                                                            dem, dem_interpolation_method)
        xpa, ypa, znp, ztp = utmLatlon.from_latlon(latpa, lonpa, znp)
        #x3.append(samples2)
        #y3.append(line*np.ones_like(samples2))
        #sard_times = np.loadtxt(pan_in_file_name + "sadr_times.txt")
        #sard_last_time = sard_times[-1]
        valid_pixels = np.ones_like(samples2)
        for band in [1, 2, 3, 4]:
            sx_in = (samples2 * panToMsFactor + dx_init[band - 1]).astype('float64') + samples_zero_ms[band-1]
            sy_in = (np.array(line * panToMsFactor + dy_init[band - 1]) * np.ones_like(samples2)).astype('float64')
            err_sx = np.ones_like(sx_in) * 2.0
            err_sy = np.ones_like(sx_in) * 2.0
            num_fail = 0
            idx = np.arange(len(samples2))
            it = 0
            while it < LV1_2ProductionConstants.MAX_ITERATION_BAND2BAND_CORRESPONDING_POINTS :
                sx = sx_in[idx]
                sy = sy_in[idx]
                hb = hpa[idx]
                lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy,
                                                                      hb, ms_lines[band - 1], sat_pos[band - 1],
                                                                      sat_att[band - 1], sat_time[band - 1],
                                                                      current_date[0], current_date[1],
                                                                      current_date[2], utc_gps, dut1)
                xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon, znp)
                errx = xb - xpa[idx]
                erry = yb - ypa[idx]


                lat1, lon1, ht = util.computeViewLatLongArrayWithHeight(band, sx + 1.0, sy,
                                                                        hb, ms_lines[band - 1], sat_pos[band - 1],
                                                                        sat_att[band - 1], sat_time[band - 1],
                                                                        current_date[0], current_date[1],
                                                                        current_date[2], utc_gps, dut1)
                lat2, lon2, ht = util.computeViewLatLongArrayWithHeight(band, sx, sy + 1.0,
                                                                        hb, ms_lines[band - 1], sat_pos[band - 1],
                                                                        sat_att[band - 1], sat_time[band - 1],
                                                                        current_date[0], current_date[1],
                                                                        current_date[2], utc_gps, dut1)
                xb1, yb1, zn, zt = utmLatlon.from_latlon(lat1, lon1, znp)
                xb2, yb2, zn, zt = utmLatlon.from_latlon(lat2, lon2, znp)

                total_errors = np.sqrt(errx ** 2 + erry ** 2)
                gx = 2.0 * errx * (xb1 - xb) + 2.0 * (erry) * (yb1 - yb)
                gy = 2.0 * errx * (xb2 - xb) + 2.0 * (erry) * (yb2 - yb)
                lamb = (0.1 / total_errors)
                lamb = (lamb > 0.001) * 0.001 + (lamb <= 0.001) * lamb

                lamb = (lamb < 1e-7) * 1e-7 + (lamb >= 1e-7) * lamb

                itx = 0
                it_max = 100
                new_total_error = total_errors.copy()
                while (new_total_error >= total_errors).sum() and (itx < it_max):
                    sxt = sx - lamb * gx
                    syt = sy - lamb * gy

                    lat, lon, ht = util.computeViewLatLongArrayWithHeight(band, sxt, syt,
                                                                          hb, ms_lines[band - 1],
                                                                          sat_pos[band - 1],
                                                                          sat_att[band - 1], sat_time[band - 1],
                                                                          current_date[0], current_date[1],
                                                                          current_date[2], utc_gps, dut1)

                    try:
                        xb, yb, zn, zt = utmLatlon.from_latlon(lat, lon, znp)
                        errold_x = errx.copy()
                        errold_y = erry.copy()
                        errx = xb - xpa[idx]
                        erry = yb - ypa[idx]

                        old_total_error = new_total_error.copy()
                        new_total_error = np.sqrt(errx ** 2 + erry ** 2)
                        lamb = (lamb / 2.0) * (new_total_error >= total_errors) + \
                               (lamb / 2.0) * (new_total_error < total_errors) * (
                                   new_total_error < old_total_error) + \
                               (lamb) * (new_total_error < total_errors) * (new_total_error >= old_total_error)

                        errx = errx * (new_total_error >= total_errors) + \
                               errx * (new_total_error < total_errors) * (new_total_error < old_total_error) + \
                               errold_x * (new_total_error < total_errors) * (
                                   new_total_error >= old_total_error)

                        erry = erry * (new_total_error >= total_errors) + \
                               erry * (new_total_error < total_errors) * (new_total_error < old_total_error) + \
                               errold_y * (new_total_error < total_errors) * (
                                   new_total_error >= old_total_error)

                        itx += 1
                    except:
                        lamb = lamb / 10.0

                        itx += 1

                sx = sx - (lamb * 2) * gx
                sy = sy - (lamb * 2) * gy
                sx_in[idx] = sx
                sy_in[idx] = sy
                err_sx[idx] = errx
                err_sy[idx] = erry

                if itx == it_max:
                    # print "[%d] cannot improve the performance any future!" % (band),
                    # print "..... error x: %f, error y: %f." % ( errxm, errym)
                    # print "Exiting the solution searching"
                    # print "Try to randomly move around. "
                    sx_bestold = sx.copy()
                    sy_bestold = sy.copy()
                    if num_fail < 5:
                        sx = sx_bestold + 2.0 * (
                        np.random.rand(sx.shape[0]) - 0.5)  # samples2 + dx_init[band - 1]
                        sy = sy_bestold + 2.0 * (np.random.rand(
                            sx.shape[0]) - 0.5)  # np.array(line + dy_init[band - 1]) * np.ones_like(samples2)
                        num_fail += 1
                    else:
                        print "Warning: There are saving %d pixels from Band %d with positioning error more than " \
                              "%f meters." % (sx.shape[0], band, precision_error)

                        id_max = np.nonzero((np.abs(err_sx) > max_percision_error) + (np.abs(err_sy) > max_percision_error))[0]

                        valid_pixels[id_max] = 0

                idx = np.nonzero((np.abs(err_sx)>precision_error )+(np.abs(err_sy) >precision_error ))[0]
                if len(idx) == 0 : #and (not brute_force):

                    it = 200
                else:
                    it += 1




            if band == 1:
                #print "1:", np.abs(sx1-sx_in).mean() , np.abs(sy1-sy_in).mean(),  np.abs(sx1-sx_in).max() , np.abs(sy1-sy_in).max()
                sx1 = sx_in.copy()  # x1.append(sx)
                sy1 = sy_in.copy()  # y1.append(sy)
            elif band == 2:
                #print "2:", np.abs(sx2 - sx_in).mean(), np.abs(sy2 - sy_in).mean(),  np.abs(sx2-sx_in).max() , np.abs(sy2-sy_in).max()
                sx2 = sx_in.copy()  # x2.append(sx)
                sy2 = sy_in.copy()  # y2.append(sy)
            elif band == 3:
                sx3 = sx_in.copy()
                sy3 = sy_in.copy()
            elif band == 4:
                #print "4:", np.abs(sx4 - sx_in).mean(), np.abs(sy4 - sy_in).mean(),   np.abs(sx4-sx_in).max() , np.abs(sy4-sy_in).max()
                sx4 = sx_in.copy()  # x4.append(sx)
                sy4 = sy_in.copy()  # sy4.append(sy)




        if (sx1 is not None) & (sy1 is not None) & (sx2 is not None) & (sy2 is not None) & (sx3 is not None) & \
                (sy3 is not None) & (sx4 is not None) &  (sy4 is not None):

            id_ready = np.nonzero(valid_pixels)[0]
            id_max = np.nonzero(valid_pixels == 0)[0]
            if np.any(sx1) is None:
                print sx1
            if len(id_max) > 0 :
                print "Warning: We need to remove %d pixels due to the maximum error is more than the " \
                      "maximum limit of %f meters" % (id_max.shape[0], max_percision_error)
                if valid_pixels.sum() > 0 :
                    x1.append(sx1[id_ready])
                    x2.append(sx2[id_ready])
                    x3.append(sx3[id_ready])
                    x4.append(sx4[id_ready])
                    xp.append(samples2[id_ready])

                    y1.append(sy1[id_ready])
                    y2.append(sy2[id_ready])
                    y3.append(sy3[id_ready])
                    y4.append(sy4[id_ready])
                    yp.append(line * np.ones_like(samples2[id_ready]))
            else:
                x1.append(sx1)
                x2.append(sx2)
                x3.append(sx3)
                x4.append(sx4)
                xp.append(samples2)

                y1.append(sy1)
                y2.append(sy2)
                y3.append(sy3)
                y4.append(sy4)
                yp.append(line * np.ones_like(samples2))

    num_items = 0
    for item in x1:
        num_items += len(item)
    x1out = np.zeros((num_items,))
    x2out = np.zeros((num_items,))
    x3out = np.zeros((num_items,))
    x4out = np.zeros((num_items,))
    xpout = np.zeros((num_items,))

    y1out = np.zeros((num_items,))
    y2out = np.zeros((num_items,))
    y3out = np.zeros((num_items,))
    y4out = np.zeros((num_items,))
    ypout = np.zeros((num_items,))

    num_list = len(x1)
    str = 0
    for list_id in range(num_list):
        stp = str + len(x1[list_id])
        x1out[str:stp] = x1[list_id]
        x2out[str:stp] = x2[list_id]
        x3out[str:stp] = x3[list_id]
        x4out[str:stp] = x4[list_id]
        xpout[str:stp] = xp[list_id]

        y1out[str:stp] = y1[list_id]
        y2out[str:stp] = y2[list_id]
        y3out[str:stp] = y3[list_id]
        y4out[str:stp] = y4[list_id]
        ypout[str:stp] = yp[list_id]
        str = stp


    return x1out, x2out, x3out, x4out, xpout, y1out, y2out, y3out, y4out, ypout



def findLV2RemapFuncitionPANWithInterpolation(in_file_name, beg_line, ger_pairs, lv2_pair_min,lv2_pair_max, lv2_geotrans,
                                              dem_ds, hmin,hmax, current_date, utc_gps, dut1, lv_width, lv_height,
                                              im_width, im_height, lv2_step_size = 10):


    x2_up_left, y2_up_left, dx2, dy2, zonec  = lv2_geotrans
    off_set = 10

    numpairs = ger_pairs.shape[0]
    print "  Band PAN....."
    print "  Finding the reversed model......."
    band_map_info = []
    A = np.zeros((numpairs, 12))
    u_mean = lv_width / 2.0
    v_mean = lv_height / 2.0
    u = lv2_pair_min[:, 0] - u_mean
    v = lv2_pair_min[:, 1] - v_mean + 1
    # print u.min(),u.max(),v.min(),v.max()
    A[:, 0] = 1.0
    A[:, 1] = u
    A[:, 2] = v
    A[:, 3] = u * v
    A[:, 4] = u ** 2
    A[:, 5] = v ** 2
    A[:, 6] = u * v * v
    A[:, 7] = v * u * u
    A[:, 8] = u ** 3
    A[:, 9] = v ** 3
    A[:, 10] = v * u ** 3
    A[:, 11] = u * v ** 3

    x_mean = ger_pairs[:, 0].mean()
    y_mean = ger_pairs[:, 1].mean()
    bx = ger_pairs[:, 0] - x_mean
    by = ger_pairs[:, 1] - y_mean
    a_x_min, errx, rnkx, s = np.linalg.lstsq(A, bx)
    # print rnk
    a_y_min, erry, rnky, s = np.linalg.lstsq(A, by)
    # print rnk
    if (rnkx == 12) and (rnky == 12):
        print "[PAN] Minimun altitude average errors: %f,%f" % ( errx / numpairs, erry / numpairs)
    else:
        print "[PAN]  The model for mainimum altitude is too fitted. Reduce the number of variables."
        # A2 = A.copy()
        for rk in range(11, 0, -1):
            A2 = A[:, :rk]
            a_x_min2, errx, rnk, s = np.linalg.lstsq(A2, bx)
            a_y_min2, erry, rnk, s = np.linalg.lstsq(A2, by)
            if (len(a_x_min2) > 0) and (len(a_y_min2) > 0):
                a_x_min = np.zeros((12,))
                a_y_min = np.zeros((12,))
                a_x_min[:rk] = a_x_min2
                a_y_min[:rk] = a_y_min2
                break
        print ".....................The algorithm terminates with the matrix of order %d." % rk

    u = lv2_pair_max[:, 0] - u_mean
    v = lv2_pair_max[:, 1] - v_mean + 1
    # print u.min(),u.max(),v.min(),v.max()
    A[:, 0] = 1.0
    A[:, 1] = u
    A[:, 2] = v
    A[:, 3] = u * v
    A[:, 4] = u ** 2
    A[:, 5] = v ** 2
    A[:, 6] = u * v * v
    A[:, 7] = v * u * u
    A[:, 8] = u ** 3
    A[:, 9] = v ** 3
    A[:, 10] = v * u ** 3
    A[:, 11] = u * v ** 3
    x_mean = ger_pairs[:, 0].mean()
    y_mean = ger_pairs[:, 1].mean()
    bx = ger_pairs[:, 0] - x_mean
    by = ger_pairs[:, 1] - y_mean
    a_x_max, errx, rnkx, s = np.linalg.lstsq(A, bx)
    a_y_max, erry, rnky, s = np.linalg.lstsq(A, by)
    if (rnkx == 12) and (rnky == 12):
        print "[PAN] Maximum altitude average errors: %f,%f" % ( errx / numpairs, erry / numpairs)
    else:
        print "[PAN]    model for maximum altitude is too fitted. Reduce the number of variables."
        # A2 = A.copy()
        for rk in range(11, 0, -1):
            A2 = A[:, :rk]
            a_x_max2, errx, rnk, s = np.linalg.lstsq(A2, bx)
            a_y_max2, erry, rnk, s = np.linalg.lstsq(A2, by)
            if (len(a_x_max2) > 0) and (len(a_y_max2) > 0):
                a_x_max = np.zeros((12,))
                a_y_max = np.zeros((12,))
                a_x_max[:rk] = a_x_max2
                a_y_max[:rk] = a_y_max2
                break
        print "....................The algorithm terminates with the matrix of order %d." % rk

    print "The reversed model is computed......"


    sat_pos = np.loadtxt(in_file_name + ".pos" )
    captured_time = np.loadtxt(in_file_name + ".tim" )
    sat_att = np.loadtxt(in_file_name + ".att" )
    # block_info_filep = open(in_file_name + "Band%d.txt"%(band+1),"w")

    line = 0
    sample  = 0


    line_max = lv_height
    samp_max = lv_width
    print "[PAN] Mapping Sample: %d to %d, and Line: %d to %d." % (sample, sample + samp_max, line,
                                                                  line + line_max)
    Ux = np.arange(lv2_step_size/2,lv_width, lv2_step_size)
    Vx = np.arange(lv2_step_size/2,lv_height, lv2_step_size)
    U,V = np.meshgrid(Ux,Vx)


    dem_data = dem_ds.ReadAsArray(0, 0, lv_width, lv_height)
    h = np.zeros_like(U, 'float64')
    h[:, :] = dem_data[lv2_step_size/2::lv2_step_size, lv2_step_size/2::lv2_step_size]

    # print "[%d] remapping line: %d to %d and sample: %d to %d"%(band+1,line,line+line_max,sample,sample+samp_max)

    U = U - u_mean
    V = V - v_mean

    U = U.flatten()
    V = V.flatten()
    h = h.flatten()
    print "Create LV2->LV1 tie points at the step of %d pixels" % lv2_step_size
    try:
        X, Y = dps.findGerFileLocationPreLoadFiles(U, V, h, a_x_min, a_y_min, a_x_max, a_y_max, x_mean, y_mean,
                                                   u_mean,
                                                   v_mean, hmin, hmax, "PAN", in_file_name,beg_line,
                                                   current_date,
                                                   utc_gps, dut1, (x2_up_left, y2_up_left, dx2, dy2, zonec),
                                                   im_width, im_height, sat_pos, captured_time, sat_att)
    except:
        np.save(in_file_name + "band_PAN_U_%d.npy" % (beg_line), U)
        np.save(in_file_name + "band_PAN_V_%d.npy" % (beg_line), V)
        np.save(in_file_name + "band_PAN_h_%d.npy" % (beg_line), h)
        np.save(in_file_name + "band_PAN_axmin_%d.npy" % (beg_line), a_x_min)
        np.save(in_file_name + "band_PAN_aymin_%d.npy" % (beg_line), a_y_min)
        np.save(in_file_name + "band_PAN_axmax_%d.npy" % (beg_line), a_x_max)
        np.save(in_file_name + "band_PAN_aymax_%d.npy" % (beg_line), a_y_max)
        np.save(in_file_name + "band_PAN_x_mean_y_mean_%d.npy" % (beg_line),
                np.array([x_mean, y_mean]))
        np.save(in_file_name + "band_PAN_u_mean_v_mean_%d.npy" % (beg_line),
                np.array([u_mean, v_mean]))
        np.save(in_file_name + "band_PAN_hminmax_%d.npy" % (beg_line),
                np.array([hmin, hmax]))
        print "filename", in_file_name
        print "Line:", beg_line
        print "data", current_date
        print "utc_gps", utc_gps
        print "dut1", dut1
        print "mapInfo", [x2_up_left, y2_up_left, dx2, dy2, zonec]
        np.save(in_file_name + "band_PAN_cap_time_%d.npy" % (beg_line), captured_time)
        np.save(in_file_name + "band_PAN_sat_pos_%d.npy" % (beg_line), sat_pos)
        np.save(in_file_name + "band_PAN_sat_att_%d.npy" % (beg_line), sat_att)
        exit()

    print "Done!"

    X =  X.flatten()
    Y =  Y.flatten()
    U2 = Ux
    V2 = Vx
    X2 = X.reshape(V2.shape[0], U2.shape[0]).T
    Y2 = Y.reshape(V2.shape[0], U2.shape[0]).T
    fx = inplt.RectBivariateSpline(U2,V2,X2,bbox=[0,lv_width, 0, lv_height])
    fy = inplt.RectBivariateSpline(U2,V2,Y2, bbox=[0,lv_width, 0, lv_height])

    mem = psutil.virtual_memory()
    mem_available = mem.available
    max_num_pixels = (mem_available - 1024 * 1024 * 1024) / ((100) * 8)  # 100 memory block per pixels and 8 for double
    num_block_lines = int(np.sqrt(max_num_pixels))
    num_block_pixels = num_block_lines
    print "Making the mapping function between LV2-LV1"
    for line in range(0, lv_height, num_block_lines):
        for sample in range(0, lv_width, num_block_pixels):
            line_max = min((lv_height - line), num_block_lines)
            samp_max = min(lv_width - sample, num_block_pixels)
            if (line == 0) & (sample == 0):
                V, U = np.mgrid[0:int(line_max), 0:int(samp_max)]
            elif (line == 0) & (sample > 0):
                V, U = np.mgrid[0:int(line_max), sample - off_set:int(samp_max + sample)]
            elif (line > 0) & (sample == 0):

                V, U = np.mgrid[line - off_set:int(line_max + line), 0:int(samp_max)]
            else:
                V, U = np.mgrid[line - off_set:int(line_max + line), sample - off_set:int(samp_max + sample)]

            U1 = U.flatten()
            V1 = V.flatten()
            X = fx.ev(U1,V1)
            Y = fy.ev(U1,V1)


            Xmin = int(X.min())
            Xmax = int(np.ceil(X.max()))
            Ymin = int(Y.min())
            Ymax = int(np.ceil(Y.max()))
            strx = int(max(Xmin, 0))
            stpx = min(Xmax + 1, im_width)

            stry = max(Ymin, 0)
            stpy = min(Ymax + 1, im_height)

            # print "[%d] Used the data from (%d,%d)->(%d,%d)"%(band+1,strx,stry,stpx,stpy)
            # maskxy = np.zero_like(U,'uint8')
            x_file_name = None
            y_file_name = None
            # print "Before:", mask_data[line:line+line_max,sample:sample+samp_max].max(), mask_data[line:line+line_max,sample:sample+samp_max].min()
            if (strx < stpx) & (stry < stpy):
                # original = databand[stry:stpy,strx:stpx]
                tr, tc = U.shape
                X = X.astype('float32')
                Y = Y.astype('float32')
                # remap_out = cv2.remap(original,X-strx,Y-stry,cv2.INTER_CUBIC,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
                # print remap_out.shape
                # print temp[(X>=X.min())*(X<=X.max())*(Y>=Y.min())*(Y<=Y.max())].shape
                X = X.reshape(tr, tc)
                Y = Y.reshape(tr, tc)
                # temp[(X>=X.min())*(X<=X.max())*(Y>=Y.min())*(Y<=Y.max())] = remap_out.flatten()
                maskxy = (X >= 0) * (Y >= 0) * (X <= im_width - 1) * (Y <= im_height - 1)
                xout = X.copy()
                yout = Y.copy()
                if (line == 0) & (sample == 0):
                    # outimage_data = temp
                    maskxy = maskxy


                elif (line == 0):
                    # outimage_data = temp[:,off_set:]
                    maskxy = maskxy[:, off_set:]
                    xout = xout[:, off_set:]
                    yout = yout[:, off_set:]


                elif (sample == 0):
                    # outimage_data = temp[off_set:,:]
                    maskxy = maskxy[off_set:, :]
                    xout = xout[off_set:, :]
                    yout = yout[off_set:, :]
                else:
                    # outimage_data = temp[off_set:,off_set:]
                    maskxy = maskxy[off_set:, off_set:]
                    xout = xout[off_set:, off_set:]
                    yout = yout[off_set:, off_set:]

                x_file_name = in_file_name + "X_BandPAN_Line%d_Sample%d.npy" % (line, sample)
                y_file_name = in_file_name + "Y_BandPAN_Line%d_Sample%d.npy" % (line, sample)
                np.save(x_file_name, xout)
                np.save(y_file_name, yout)
                # block_info_filep.writelines("%d, %d, %d, %d"%(line, sample, line_max, samp_max))
            band_map_info.append([line, sample, line_max, samp_max, x_file_name, y_file_name])

    band_map_info_array = np.array(band_map_info)
    #np.save(in_file_name + "_map_info_band_%d.npy" % (band + 1), band_map_info_array)
    print "Done."

    return band_map_info_array


def makingDEMData( dem_file_name, lv_width, lv_height, map_geotransform,  dem,
                   dem_interpolation_method):

    gtiffDriver = gdal.GetDriverByName('GTiff')


    dem_ds_im = gtiffDriver.Create(dem_file_name, lv_width, lv_height, 1, gdal.GDT_Float32)
    dem_ds = dem_ds_im.GetRasterBand(1)
    mem = psutil.virtual_memory()
    mem_available = mem.available
    if dem_interpolation_method != "rbf":
        max_num_pixels_dem = (mem_available - 1024 * 1024 * 1024) / (
        (200) * 8)  # 400 memory block per pixels and 8 for double
    else:
        max_num_pixels_dem = 100 ** 2
    block_num_lines = int(np.sqrt(max_num_pixels_dem))
    block_num_pixels = block_num_lines
    off_set = 10
    block_num_lines2 = block_num_lines + off_set
    block_num_pixels2 = block_num_pixels + off_set
    for line in range(0, lv_height, block_num_lines):
        for sample in range(0, lv_width, block_num_pixels):
            line_max = min((lv_height - line), block_num_lines2)
            samp_max = min(lv_width - sample, block_num_pixels2)
            if (line == 0) & (sample == 0):
                V, U = np.mgrid[0:int(line_max), 0:int(samp_max)]
            elif (line == 0) & (sample > 0):
                V, U = np.mgrid[0:int(line_max), sample - off_set:int(samp_max + sample)]
            elif (line > 0) & (sample == 0):

                V, U = np.mgrid[line - off_set:int(line_max + line), 0:int(samp_max)]
            else:
                V, U = np.mgrid[line - off_set:int(line_max + line), sample - off_set:int(samp_max + sample)]
            x2_up_left, y2_up_left, dx2, dy2,zonec, zoneletter_c  = map_geotransform
            u_earth = U * dx2 + x2_up_left
            v_earth = V * dy2 + y2_up_left
            late, lone = utmLatlon.to_latlon(u_earth, v_earth, zonec, zoneletter_c)

            # h = util.determineHeight(late,lone,dem_directory)
            latem = int(np.round(late.mean()))
            lonem = int(np.round(lone.mean()))
            dem_temp = None
            print "[DEM]  coord:", late.min(), late.max(), lone.min(), lone.max()
            h = dem.interpolate(late, lone, interpolation_method = dem_interpolation_method)
            ofx = off_set * (sample != 0)
            ofy = off_set * (line != 0)
            dem_out = h[ofy:, ofx:].astype('float64')
            print "sample:%d, line:%d" % (sample, line), h.shape
            dem_ds.WriteArray(dem_out, sample, line)
    dem_ds_im = None


