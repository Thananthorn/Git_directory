"""

Copyright 2017 GISTDA


The Software is written by Dr. Teerasit Kasetkasem from Kasetsart University, Thailand, aa a part of the cooperation
between GISTDA and Kasetsart University under the SIPROs project.

GISTDA retains the right to use, copy, modify, merge, publish, distribute, sublicense, and/or shell copies of the
Software. Any distribution, use, copy, modification, publication of this Software must be explicitly granted by GISTDA.
However, Dr. Teerasit Kasetkasem retains the right to use, copy, modify, merge, publish, and/or shell copies of the
Software without any permission from GISTDA for the following conditions:
1) Correction and maintenance of the Software
2) Educational activities
3) Research activities

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import numpy as np
import dutil
import platform
import xml.etree.ElementTree as ET
import scipy.optimize as opt
import demKriging
import matplotlib.pyplot as plt
import time
if platform.system() == "Windows":
    from osgeo import gdal
else:
    import gdal

import os
import ctypes
import nutationConst
sin = np.sin
cos = np.cos
import cv2
import scipy.spatial.distance as distance
import digitalElevationModel as demservices

class memoryCheck():
    """Checks memory of a given system"""

    def __init__(self):

        if os.name == "posix":
            self.value = self.linuxRam()
        elif os.name == "nt":
            self.value = self.windowsRam()
        else:
            print "I only work with Win or Linux :P"

    def windowsRam(self):
        """Uses Windows API to check RAM in this OS"""
        kernel32 = ctypes.windll.kernel32
        c_ulong = ctypes.c_ulong
        class MEMORYSTATUS(ctypes.Structure):
            _fields_ = [
                ("dwLength", c_ulong),
                ("dwMemoryLoad", c_ulong),
                ("dwTotalPhys", c_ulong),
                ("dwAvailPhys", c_ulong),
                ("dwTotalPageFile", c_ulong),
                ("dwAvailPageFile", c_ulong),
                ("dwTotalVirtual", c_ulong),
                ("dwAvailVirtual", c_ulong)
            ]
        memoryStatus = MEMORYSTATUS()
        memoryStatus.dwLength = ctypes.sizeof(MEMORYSTATUS)
        kernel32.GlobalMemoryStatus(ctypes.byref(memoryStatus))

        return int(memoryStatus.dwTotalPhys/1024**2)

    def linuxRam(self):
        """Returns the RAM of a linux system"""
        totalMemory = os.popen("free -m").readlines()[1].split()[1]
        return int(totalMemory)


def readGainsAndDarkCurrent(cpf_file):
    tree = ET.parse(cpf_file)
    root  = tree.getroot()

    gps_utc = float(root.findall("./DatationParameters/DeltaGPS-UTC")[0].text)
    utc_gps = - gps_utc
    ut1_utc = float(root.findall("./DatationParameters/DeltaUT1-UTC")[0].text)


    return utc_gps, ut1_utc

def sind(omega) :
    x = np.sin(omega*np.pi/180.)
    return x

def cosd(omega) :
    x = np.cos(omega*np.pi/180.)
    return x
def JD2GMST(JD) :
    #Find the Julian Date of the previous midnight, JD0
    if np.isscalar(JD):
        JDmin = np.floor(JD)-.5
        JDmax = np.floor(JD)+.5
        if (JD > JDmin) :
            JD0 = JDmin
        if (JD > JDmax):
            JD0 = JDmax
        H = (JD-JD0)*24 #       %Time in hours past previous midnight
        D = JD - 2451545.0 #     %Compute the number of days since J2000
        D0 = JD0 - 2451545.0 #   %Compute the number of days since J2000
        T = D/36525           #Compute the number of centuries since J2000
        #Calculate GMST in hours (0h to 24h) ... then convert to degrees

        GMST = ((6.697374558 + 0.06570982441908*D0  + 1.00273790935*H + \
               0.000026*(T**2))%24)*15
    else:
        JDmin = np.floor(JD)-.5
        JDmax = np.floor(JD)+.5
        JD0 = JDmax*(JD>JDmax) + JDmin*(JD<=JDmax)*(JD>JDmin)
        H = (JD-JD0)*24 #       %Time in hours past previous midnight
        D = JD - 2451545.0 #     %Compute the number of days since J2000
        D0 = JD0 - 2451545.0 #   %Compute the number of days since J2000
        T = D/36525           #Compute the number of centuries since J2000
        #Calculate GMST in hours (0h to 24h) ... then convert to degrees

        GMST = ((6.697374558 + 0.06570982441908*D0  + 1.00273790935*H + \
               0.000026*(T**2))%24)*15

    return GMST

def JD2GAST(JD) :
    #THETAm is the mean siderial time in degrees
    THETAm = JD2GMST(JD)
    #Compute the number of centuries since J2000
    T = (JD - 2451545.0)/36525.

    #Mean obliquity of the ecliptic (EPSILONm)
    # see http://www.cdeagle.com/ccnum/pdf/demogast.pdf equation 3
    # also see Vallado, Fundamentals of Astrodynamics and Applications, second edition.
    # pg. 214 EQ 3-53
    EPSILONm = 23.439291-0.0130111*T - 1.64E-07*(T**2) + 5.04E-07*(T**3)
    # Nutations in obliquity and longitude (degrees
    # see http://www.cdeagle.com/ccnum/pdf/demogast.pdf equation 4
    L = 280.4665 + 36000.7698*T
    dL = 218.3165 + 481267.8813*T
    OMEGA = 125.04452 - 1934.136261*T
    # Calculate nutations using the following two equations:
    # see http://www.cdeagle.com/ccnum/pdf/demogast.pdf equation 5
    dPSI = -17.20*sind(OMEGA) - 1.32*sind(2.*L) - .23*sind(2.*dL) \
           + .21*sind(2.*OMEGA)
    dEPSILON = 9.20*cosd(OMEGA) + .57*cosd(2.*L) + .10*cosd(2.*dL) - \
               .09*cosd(2.*OMEGA)
    # Convert the units from arc-seconds to degrees
    dPSI = dPSI*(1/3600.);
    dEPSILON = dEPSILON*(1/3600.)

    #(GAST) Greenwhich apparent sidereal time expression in degrees
    # see http://www.cdeagle.com/ccnum/pdf/demogast.pdf equation 1
    GAST = (THETAm + dPSI*cosd(EPSILONm+dEPSILON))%360
    #print GAST
    return GAST


def T3D(THETA):
    T = np.zeros((3,3))
    T[0,0] = cosd(THETA)
    T[0,1] = sind(THETA)
    T[1,0] = -T[0,1]
    T[1,1] = T[0,0]
    T[2,2] = 1.0
    return T

def Tdot3D(THETA,omega_e) :
    Tdot = np.zeros((3,3))
    Tdot[0,0] = -omega_e*sind(THETA)
    Tdot[0,1] = omega_e*cosd(THETA)
    Tdot[1,0] = -Tdot[0,1]
    Tdot[1,1] = Tdot[0,0]
    return Tdot

def Tddot3D(THETA,omega_e) :
    Tddot = np.zeros((3,3))
    Tddot[1,1] = -(omega_e**2)*cosd(THETA)
    Tddot[1,2] = -(omega_e**2)*sind(THETA)
    Tddot[2,1] = -Tddot[1,2]
    Tddot[2,2] =  Tddot[1,1]
    return Tddot


def computePrecessionAngles(JED) :
    d = JED - 2451545.0
    T = d/ 36525.
    zeta = (2306.2181*T + 0.30188*(T**2) + 0.017998*(T**3))/3600.
    z = (2306.2181*T + 1.09468*(T**2) + 0.018203*(T**3))/3600.
    theta = (2004.3109*T - 0.42665*(T**2) - 0.041833*(T**3))/3600.

    return zeta, z, theta

def computeNutitionLogitude(JD):
    T  = (JD - 2451545.) / 36525.
    T2 = T*T
    T3 = T*T2
    DegToRad = 3.1415926535897932 / 180
    w1 = 297.85036 + 445267.11148*T - 0.0019142*T2 + (T3 / 189474)
    w1 = DegToRad*(w1)

    w2 = 357.52772 + 35999.05034*T - 0.0001603*T2 - (T3 / 300000)
    w2 = DegToRad*(w2)

    w3 = 134.96298 + 477198.867398*T + 0.0086972*T2 + (T3 / 56250)
    w3 = DegToRad*(w3)

    w4 = 93.27191 + 483202.017538*T - 0.0036825*T2 + (T3 / 327270)
    w4 = DegToRad*(w4)

    w5 = 125.04452 - 1934.136261*T + 0.0020708*T2 + (T3 / 450000)
    w5 = DegToRad*(w5)

    w = np.sin(w5)*(-174.2*T - 171996)
    w = w + np.sin(2*(w4 + w5 - w1))*(-1.6*T - 13187)
    w = w + np.sin(2*(w4 + w5))*(-2274 - 0.2*T)
    w = w + np.sin(2 * w5)*(0.2*T + 2062)
    w = w + np.sin(w2)*(1426 - 3.4*T)
    w = w + np.sin(w3)*(0.1*T + 712)
    w = w + np.sin(2*(w4 + w5 - w1) + w2)*(1.2*T - 517)
    w = w + sin(2 * w4 + w5)*(-0.4*T - 386)
    w = w + sin(2*(w4 + w5 - w1) - w2)*(217 - 0.5*T)
    w = w + sin(2*(w4 - w1) + w5)*(129 + 0.1*T)
    w = w + sin(w3 + w5)*(0.1*T + 63)
    w = w + sin(w5 - w3)*(-0.1*T - 58)
    w = w + sin(2*w2)*(17 - 0.1*T)
    w = w + sin(2*(w2 + w4 + w5 - w1))*(0.1*T - 16)
    w = w - 301*sin(2*(w4 + w5) + w3)
    w = w - 158*sin(w3 - 2*w1)
    w = w + 123*sin(2*(w4 + w5) - w3)
    w = w +  63*sin(2*w1)
    w = w -  59*sin(2*(w1 + w4 + w5) - w3)
    w = w -  51*sin(2 * w4 + w3 + w5)
    w = w +  48*sin(2*(w3 - w1))
    w = w +  46*sin(2*(w4 - w3) + w5)
    w = w -  38*sin(2*(w1 + w4 + w5))
    w = w -  31*sin(2*(w3 + w4 + w5))
    w = w +  29*sin(2*w3)
    w = w +  29*sin(2*(w4 + w5 - w1) + w3)
    w = w +  26*sin(2*w4)
    w = w -  22*sin(2*(w4 - w1))
    w = w +  21*sin(2*w4 + w5 - w3)
    w = w +  16*sin(2*w1 - w3 + w5)
    w = w -  15*sin(w2 + w5)
    w = w -  13*sin(w3 + w5 - 2*w1)
    w = w -  12*sin(w5 - w2)
    w = w +  11*sin(2*(w3 - w4))
    w = w -  10*sin(2*(w4 + w1) + w5 - w3)
    w = w -   8*sin(2*(w4 + w1 + w5) + w3)
    w = w +   7*sin(2*(w4 + w5) + w2)
    w = w -   7*sin(w3 - 2*w1 + w2)
    w = w -   7*sin(2*(w4 + w5) - w2)
    w = w -   7*sin(2*w1 + 2*w4 + w5)
    w = w +   6*sin(2*w1 + w3)
    w = w +   6*sin(2*(w3 + w4 + w5 - w1))
    w = w +   6*sin(2*(w4 - w1) + w3 + w5)
    w = w -   6*sin(2*(w1 - w3) + w5)
    w = w -   6*sin(2*w1 + w5)
    w = w +   5*sin(w3 - w2)
    w = w -   5*sin(2*(w4 - w1) + w5 - w2)
    w = w -   5*sin(w5 - 2*w1)
    w = w -   5*sin(2*(w3 + w4) + w5)
    w = w +   4*sin(2*(w3 - w1) + w5)
    w = w +   4*sin(2*(w4 - w1) + w2 + w5)
    w = w +   4*sin(w3 - 2*w4)
    w = w -   4*sin(w3 - w1)
    w = w -   4*sin(w2 - 2*w1)
    w = w -   4*sin(w1)
    w = w +   3*sin(2*w4 + w3)
    w = w -   3*sin(2*(w4 + w5 - w3))
    w = w -   3*sin(w3 - w1 - w2)
    w = w -   3*sin(w2 + w3)
    w = w -   3*sin(2*(w4 + w5) + w3 - w2)
    w = w -   3*sin(2*(w1 + w4 + w5) - w2 - w3)
    w = w -   3*sin(2*(w4 + w5) + 3*w3)
    w = w -   3*sin(2*(w1 + w4 + w5) - w2)

    dPsiDeg = w / 36000000.0
    return dPsiDeg




def computeCNutationObliquity(JD):
    T  = (JD - 2451545.) / 36525.
    T2 = T * T
    T3 = T * T2
    DegToRad = 3.1415926535897932 / 180

    w1 = DegToRad*(297.85036 + 445267.11148*T  - 0.0019142*T2 + (T3/189474))
    w2 = DegToRad*(357.52772 + 35999.05034*T   - 0.0001603*T2 - (T3/300000))
    w3 = DegToRad*(134.96298 + 477198.867398*T + 0.0086972*T2 + (T3/56250))
    w4 = DegToRad*(93.27191  + 483202.017538*T - 0.0036825*T2 + (T3/327270))
    w5 = DegToRad*(125.04452 - 1934.136261*T   + 0.0020708*T2 + (T3/450000))

    w = cos(w5)*(92025 + 8.9*T)
    w = w + cos(2*(w4 - w1 + w5))*(5736 - 3.1*T)
    w = w + cos(2*(w4 + w5))*(977 - 0.5*T)
    w = w + cos(2*w5)*(0.5*T - 895)
    w = w + cos(w2)*(54 - 0.1*T)
    w = w + cos(w2 + 2*(w4 - w1 + w5))*(224 - 0.6*T)
    w = w + cos(w3 + 2*(w4 + w5))*(129 - 0.1*T)
    w = w + cos(2*(w4 - w1 + w5) - w2)*(0.3*T - 95)
    w = w + 200*cos(2*w4 + w5)
    w = w - 70*cos(2*(w4 - w1) + w5)
    w = w - 53*cos(2*(w4 + w5) - w3)
    w = w - 33*cos(w3 + w5)
    w = w + 26*cos(2*(w1 + w4 + w5) - w3)
    w = w + 32*cos(w5 - w3)
    w = w + 27*cos(w3 + 2*w4 + w5)
    w = w - 24*cos(2*(w4 - w3) + w5)
    w = w + 16*cos(2*(w1 + w4 + w5))
    w = w + 13*cos(2*(w3 + w4 + w5))
    w = w - 12*cos(w3 + 2*(w4 - w1 + w5))
    w = w - 10*cos(2*w4 + w5 - w3)
    w = w - 8*cos(2*w1 - w3 + w5)
    w = w + 7*cos(2*(w2 - w1 + w4 + w5))
    w = w - 7*cos(w3)
    w = w + 9*cos(w2 + w5)
    w = w + 7*cos(w3 + w5 - 2*w1)
    w = w + 6*cos(w5 - w2)
    w = w + 5*cos(2*(w1 + w4) - w3 + w5)
    w = w + 3*cos(w3 + 2*(w4 + w1 + w5))
    w = w - 3*cos(w2 + 2*(w4 + w5))
    w = w + 3*cos(2*(w4 + w5) - w2)
    w = w + 3*cos(2*(w1 + w4) + w5)
    w = w - 3*cos(2*(w3 + w4 + w5 - w1))
    w = w - 3*cos(w3 + 2*(w4 - w1) + w5)
    w = w + 3*cos(2*(w1 - w3) + w5)
    w = w + 3*cos(2*w1 + w5)
    w = w + 3*cos(2*(w4 - w1) + w5 - w2)
    w = w + 3*cos(w5 - 2*w1)
    w = w + 3*cos(2*(w3 + w4) + w5)
    dEpsDeg = w / 36000000.
    dEpsBarDeg = 84381.448 -46.8150*T -0.00059*T2 +0.001813**T3
    dEpsBarDeg /= (60*60)
    return dEpsDeg, dEpsBarDeg


def comNutation2000BLongitude(JD):
    DegToRad = 3.141592653589793 / 180.0
    T = (JD - 2451545.0) / 36525.0
    T2 = T * T
    T3 = T * T2
    T4 = T * T3
    #Mean anomaly of the Moon in radians
    L  = DegToRad*((485868.249036 + 1717915923.2178*T + 31.8792*T2\
                    + 0.051635*T3 - 0.00024470*T4) / 3600.0)
    #Mean anomaly of the Sun in radians
    Lp = DegToRad*((1287104.79305 + 129596581.0481*T \
                    - 0.5532*T2  + 0.000136*T3 - 0.00001149*T4) / 3600.0)
    #----------------------------------------------------
    #Mean argument of the latitude of the Moon in radians
    F  = DegToRad*((335779.526232 + 1739527262.8478*T \
                    - 12.7512*T2 - 0.001037*T3 + 0.00000417*T4) / 3600.0)

    #---------------------------------------------------
    #Mean elongation of the Moon from the Sun in radians
    D  = DegToRad*((1072260.70369 + 1602961601.2090*T\
                    - 6.3706*T2  + 0.006593*T3 - 0.00003169*T4) / 3600.0)
    #-----------------------------------------------------------
    #Mean longitude of the ascending node of the Moon in radians

    Om = DegToRad*((450160.398036 - 6962890.5431*T \
     + 7.4722*T2  + 0.007702*T3 - 0.00005939*T4) / 3600.0)

    #-------------------------------------------------------------------
    #EVALUATE THE SERIES FOR NUTATION IN LONGITUDE IN ARC SEC * 10000000

    #--------------------------------------------------------
    #Using the table data, the terms take the following form:
    #Let:
    # arg = (m1*L + m2*Lp + m3*F + m4*D + m5*Om)
    # then
    # dPsiTerm = (AA + BB*T)*sin(arg) + CC*cos(arg)
    #  The computational angles are assumed to be in radians.
    #
    # -------------------------------------------------------------------
    # Using the data table above, the following raw terms can be built.
    # Notice there are numerous elements that equate to zero.  Those
    # elements may subsequently be removed and most of the remaining
    # terms may be algebraically reduced to simpler forms.
    #
    # Each line represents a single term in the nutation series.
    #
    # Compare the data table values to the numbers used in raw series below.
    #
    # The variable s is used to hold the accumulating sum (s) of the terms
    # as they are sequentially evaluated.  This value is converted into
    # decimal degrees at the end of the summation.
    # s = 0
    # s = s + (-172064161 - 174666*T)*sin(0*L + 0*Lp + 0*F + 0*D + 1*Om) + 33386*cos(0*L + 0*Lp + 0*F + 0*D + 1*Om)
    # s = s + (-13170906 - 1675*T)*sin(0*L + 0*Lp + 2*F - 2*D + 2*Om) - 13696*cos(0*L + 0*Lp + 2*F - 2*D + 2*Om)
    # s = s + (-2276413 - 234*T)*sin(0*L + 0*Lp + 2*F + 0*D + 2*Om) + 2796*cos(0*L + 0*Lp + 2*F + 0*D + 2*Om)
    # s = s + (2074554 + 207*T)*sin(0*L + 0*Lp + 0*F + 0*D + 2*Om) - 698*cos(0*L + 0*Lp + 0*F + 0*D + 2*Om)
    # s = s + (1475877 - 3633*T)*sin(0*L + 1*Lp + 0*F + 0*D + 0*Om) + 11817*cos(0*L + 1*Lp + 0*F + 0*D + 0*Om)
    # s = s + (-516821 + 1226*T)*sin(0*L + 1*Lp + 2*F - 2*D + 2*Om) - 524*cos(0*L + 1*Lp + 2*F - 2*D + 2*Om)
    # s = s + (711159 + 73*T)*sin(1*L + 0*Lp + 0*F + 0*D + 0*Om) - 872*cos(1*L + 0*Lp + 0*F + 0*D + 0*Om)
    # s = s + (-387298 - 367*T)*sin(0*L + 0*Lp + 2*F + 0*D + 1*Om) + 380*cos(0*L + 0*Lp + 2*F + 0*D + 1*Om)
    # s = s + (-301461 - 36*T)*sin(1*L + 0*Lp + 2*F + 0*D + 2*Om) + 816*cos(1*L + 0*Lp + 2*F + 0*D + 2*Om)
    # s = s + (215829 - 494*T)*sin(0*L - 1*Lp + 2*F - 2*D + 2*Om) + 111*cos(0*L - 1*Lp + 2*F - 2*D + 2*Om)
    # s = s + (128227 + 137*T)*sin(0*L + 0*Lp + 2*F - 2*D + 1*Om) + 181*cos(0*L + 0*Lp + 2*F - 2*D + 1*Om)
    # s = s + (123457 + 11*T)*sin(-1*L + 0*Lp + 2*F + 0*D + 2*Om) + 19*cos(-1*L + 0*Lp + 2*F + 0*D + 2*Om)
    # s = s + (156994 + 10*T)*sin(-1*L + 0*Lp + 0*F + 2*D + 0*Om) - 168*cos(-1*L + 0*Lp + 0*F + 2*D + 0*Om)
    # s = s + (63110 + 63*T)*sin(1*L + 0*Lp + 0*F + 0*D + 1*Om) + 27*cos(1*L + 0*Lp + 0*F + 0*D + 1*Om)
    # s = s + (-57976 - 63*T)*sin(-1*L + 0*Lp + 0*F + 0*D + 1*Om) - 189*cos(-1*L + 0*Lp + 0*F + 0*D + 1*Om)
    # s = s + (-59641 - 11*T)*sin(-1*L + 0*Lp + 2*F + 2*D + 2*Om) + 149*cos(-1*L + 0*Lp + 2*F + 2*D + 2*Om)
    # s = s + (-51613 - 42*T)*sin(1*L + 0*Lp + 2*F + 0*D + 1*Om) + 129*cos(1*L + 0*Lp + 2*F + 0*D + 1*Om)
    # s = s + (45893 + 50*T)*sin(-2*L + 0*Lp + 2*F + 0*D + 1*Om) + 31*cos(-2*L + 0*Lp + 2*F + 0*D + 1*Om)
    # s = s + (63384 + 11*T)*sin(0*L + 0*Lp + 0*F + 2*D + 0*Om) - 150*cos(0*L + 0*Lp + 0*F + 2*D + 0*Om)
    # s = s + (-38571 - 1*T)*sin(0*L + 0*Lp + 2*F + 2*D + 2*Om) + 158*cos(0*L + 0*Lp + 2*F + 2*D + 2*Om)
    # s = s + (32481 + 0*T)*sin(0*L - 2*Lp + 2*F - 2*D + 2*Om) + 0*cos(0*L - 2*Lp + 2*F - 2*D + 2*Om)
    # s = s + (-47722 + 0*T)*sin(-2*L + 0*Lp + 0*F + 2*D + 0*Om) - 18*cos(-2*L + 0*Lp + 0*F + 2*D + 0*Om)
    # s = s + (-31046 - 1*T)*sin(2*L + 0*Lp + 2*F + 0*D + 2*Om) + 131*cos(2*L + 0*Lp + 2*F + 0*D + 2*Om)
    # s = s + (28593 + 0*T)*sin(1*L + 0*Lp + 2*F - 2*D + 2*Om) - 1*cos(1*L + 0*Lp + 2*F - 2*D + 2*Om)
    # s = s + (20441 + 21*T)*sin(-1*L + 0*Lp + 2*F + 0*D + 1*Om) + 10*cos(-1*L + 0*Lp + 2*F + 0*D + 1*Om)
    # s = s + (29243 + 0*T)*sin(2*L + 0*Lp + 0*F + 0*D + 0*Om) - 74*cos(2*L + 0*Lp + 0*F + 0*D + 0*Om)
    # s = s + (25887 + 0*T)*sin(0*L + 0*Lp + 2*F + 0*D + 0*Om) - 66*cos(0*L + 0*Lp + 2*F + 0*D + 0*Om)
    # s = s + (-14053 - 25*T)*sin(0*L + 1*Lp + 0*F + 0*D + 1*Om) + 79*cos(0*L + 1*Lp + 0*F + 0*D + 1*Om)
    # s = s + (15164 + 10*T)*sin(-1*L + 0*Lp + 0*F + 2*D + 1*Om) + 11*cos(-1*L + 0*Lp + 0*F + 2*D + 1*Om)
    # s = s + (-15794 + 72*T)*sin(0*L + 2*Lp + 2*F - 2*D + 2*Om) - 16*cos(0*L + 2*Lp + 2*F - 2*D + 2*Om)
    # s = s + (21783 + 0*T)*sin(0*L + 0*Lp - 2*F + 2*D + 0*Om) + 13*cos(0*L + 0*Lp - 2*F + 2*D + 0*Om)
    # s = s + (-12873 - 10*T)*sin(1*L + 0*Lp + 0*F - 2*D + 1*Om) - 37*cos(1*L + 0*Lp + 0*F - 2*D + 1*Om)
    # s = s + (-12654 + 11*T)*sin(0*L - 1*Lp + 0*F + 0*D + 1*Om) + 63*cos(0*L - 1*Lp + 0*F + 0*D + 1*Om)
    # s = s + (-10204 + 0*T)*sin(-1*L + 0*Lp + 2*F + 2*D + 1*Om) + 25*cos(-1*L + 0*Lp + 2*F + 2*D + 1*Om)
    # s = s + (16707 - 85*T)*sin(0*L + 2*Lp + 0*F + 0*D + 0*Om) - 10*cos(0*L + 2*Lp + 0*F + 0*D + 0*Om)
    # s = s + (-7691 + 0*T)*sin(1*L + 0*Lp + 2*F + 2*D + 2*Om) + 44*cos(1*L + 0*Lp + 2*F + 2*D + 2*Om)
    # s = s + (-11024 + 0*T)*sin(-2*L + 0*Lp + 2*F + 0*D + 0*Om) - 14*cos(-2*L + 0*Lp + 2*F + 0*D + 0*Om)
    # s = s + (7566 - 21*T)*sin(0*L + 1*Lp + 2*F + 0*D + 2*Om) - 11*cos(0*L + 1*Lp + 2*F + 0*D + 2*Om)
    # s = s + (-6637 - 11*T)*sin(0*L + 0*Lp + 2*F + 2*D + 1*Om) + 25*cos(0*L + 0*Lp + 2*F + 2*D + 1*Om)
    # s = s + (-7141 + 21*T)*sin(0*L - 1*Lp + 2*F + 0*D + 2*Om) + 8*cos(0*L - 1*Lp + 2*F + 0*D + 2*Om)
    # s = s + (-6302 - 11*T)*sin(0*L + 0*Lp + 0*F + 2*D + 1*Om) + 2*cos(0*L + 0*Lp + 0*F + 2*D + 1*Om)
    # s = s + (5800 + 10*T)*sin(1*L + 0*Lp + 2*F - 2*D + 1*Om) + 2*cos(1*L + 0*Lp + 2*F - 2*D + 1*Om)
    # s = s + (6443 + 0*T)*sin(2*L + 0*Lp + 2*F - 2*D + 2*Om) - 7*cos(2*L + 0*Lp + 2*F - 2*D + 2*Om)
    # s = s + (-5774 - 11*T)*sin(-2*L + 0*Lp + 0*F + 2*D + 1*Om) - 15*cos(-2*L + 0*Lp + 0*F + 2*D + 1*Om)
    # s = s + (-5350 + 0*T)*sin(2*L + 0*Lp + 2*F + 0*D + 1*Om) + 21*cos(2*L + 0*Lp + 2*F + 0*D + 1*Om)
    # s = s + (-4752 - 11*T)*sin(0*L - 1*Lp + 2*F - 2*D + 1*Om) - 3*cos(0*L - 1*Lp + 2*F - 2*D + 1*Om)
    # s = s + (-4940 - 11*T)*sin(0*L + 0*Lp + 0*F - 2*D + 1*Om) - 21*cos(0*L + 0*Lp + 0*F - 2*D + 1*Om)
    # s = s + (7350 + 0*T)*sin(-1*L - 1*Lp + 0*F + 2*D + 0*Om) - 8*cos(-1*L - 1*Lp + 0*F + 2*D + 0*Om)
    # s = s + (4065 + 0*T)*sin(2*L + 0*Lp + 0*F - 2*D + 1*Om) + 6*cos(2*L + 0*Lp + 0*F - 2*D + 1*Om)
    # s = s + (6579 + 0*T)*sin(1*L + 0*Lp + 0*F + 2*D + 0*Om) - 24*cos(1*L + 0*Lp + 0*F + 2*D + 0*Om)
    # s = s + (3579 + 0*T)*sin(0*L + 1*Lp + 2*F - 2*D + 1*Om) + 5*cos(0*L + 1*Lp + 2*F - 2*D + 1*Om)
    # s = s + (4725 + 0*T)*sin(1*L - 1*Lp + 0*F + 0*D + 0*Om) - 6*cos(1*L - 1*Lp + 0*F + 0*D + 0*Om)
    # s = s + (-3075 + 0*T)*sin(-2*L + 0*Lp + 2*F + 0*D + 2*Om) - 2*cos(-2*L + 0*Lp + 2*F + 0*D + 2*Om)
    # s = s + (-2904 + 0*T)*sin(3*L + 0*Lp + 2*F + 0*D + 2*Om) + 15*cos(3*L + 0*Lp + 2*F + 0*D + 2*Om)
    # s = s + (4348 + 0*T)*sin(0*L - 1*Lp + 0*F + 2*D + 0*Om) - 10*cos(0*L - 1*Lp + 0*F + 2*D + 0*Om)
    # s = s + (-2878 + 0*T)*sin(1*L - 1*Lp + 2*F + 0*D + 2*Om) + 8*cos(1*L - 1*Lp + 2*F + 0*D + 2*Om)
    # s = s + (-4230 + 0*T)*sin(0*L + 0*Lp + 0*F + 1*D + 0*Om) + 5*cos(0*L + 0*Lp + 0*F + 1*D + 0*Om)
    # s = s + (-2819 + 0*T)*sin(-1*L - 1*Lp + 2*F + 2*D + 2*Om) + 7*cos(-1*L - 1*Lp + 2*F + 2*D + 2*Om)
    # s = s + (-4056 + 0*T)*sin(-1*L + 0*Lp + 2*F + 0*D + 0*Om) + 5*cos(-1*L + 0*Lp + 2*F + 0*D + 0*Om)
    # s = s + (-2647 + 0*T)*sin(0*L - 1*Lp + 2*F + 2*D + 2*Om) + 11*cos(0*L - 1*Lp + 2*F + 2*D + 2*Om)
    # s = s + (-2294 + 0*T)*sin(-2*L + 0*Lp + 0*F + 0*D + 1*Om) - 10*cos(-2*L + 0*Lp + 0*F + 0*D + 1*Om)
    # s = s + (2481 + 0*T)*sin(1*L + 1*Lp + 2*F + 0*D + 2*Om) - 7*cos(1*L + 1*Lp + 2*F + 0*D + 2*Om)
    # s = s + (2179 + 0*T)*sin(2*L + 0*Lp + 0*F + 0*D + 1*Om) - 2*cos(2*L + 0*Lp + 0*F + 0*D + 1*Om)
    # s = s + (3276 + 0*T)*sin(-1*L + 1*Lp + 0*F + 1*D + 0*Om) + 1*cos(-1*L + 1*Lp + 0*F + 1*D + 0*Om)
    # s = s + (-3389 + 0*T)*sin(1*L + 1*Lp + 0*F + 0*D + 0*Om) + 5*cos(1*L + 1*Lp + 0*F + 0*D + 0*Om)
    # s = s + (3339 + 0*T)*sin(1*L + 0*Lp + 2*F + 0*D + 0*Om) - 13*cos(1*L + 0*Lp + 2*F + 0*D + 0*Om)
    # s = s + (-1987 + 0*T)*sin(-1*L + 0*Lp + 2*F - 2*D + 1*Om) - 6*cos(-1*L + 0*Lp + 2*F - 2*D + 1*Om)
    # s = s + (-1981 + 0*T)*sin(1*L + 0*Lp + 0*F + 0*D + 2*Om) + 0*cos(1*L + 0*Lp + 0*F + 0*D + 2*Om)
    # s = s + (4026 + 0*T)*sin(-1*L + 0*Lp + 0*F + 1*D + 0*Om) - 353*cos(-1*L + 0*Lp + 0*F + 1*D + 0*Om)
    # s = s + (1660 + 0*T)*sin(0*L + 0*Lp + 2*F + 1*D + 2*Om) - 5*cos(0*L + 0*Lp + 2*F + 1*D + 2*Om)
    # s = s + (-1521 + 0*T)*sin(-1*L + 0*Lp + 2*F + 4*D + 2*Om) + 9*cos(-1*L + 0*Lp + 2*F + 4*D + 2*Om)
    # s = s + (1314 + 0*T)*sin(-1*L + 1*Lp + 0*F + 1*D + 1*Om) + 0*cos(-1*L + 1*Lp + 0*F + 1*D + 1*Om)
    # # s = s + (-1283 + 0*T)*sin(0*L - 2*Lp + 2*F - 2*D + 1*Om) + 0*cos(0*L - 2*Lp + 2*F - 2*D + 1*Om)
    # s = s + (-1331 + 0*T)*sin(1*L + 0*Lp + 2*F + 2*D + 1*Om) + 8*cos(1*L + 0*Lp + 2*F + 2*D + 1*Om)
    # s = s + (1383 + 0*T)*sin(-2*L + 0*Lp + 2*F + 2*D + 2*Om) - 2*cos(-2*L + 0*Lp + 2*F + 2*D + 2*Om)
    # s = s + (1405 + 0*T)*sin(-1*L + 0*Lp + 0*F + 0*D + 2*Om) + 4*cos(-1*L + 0*Lp + 0*F + 0*D + 2*Om)
    # s = s + (1290 + 0*T)*sin(1*L + 1*Lp + 2*F - 2*D + 2*Om) + 0*cos(1*L + 1*Lp + 2*F - 2*D + 2*Om)

    if not np.isscalar(JD):
        num = JD.shape[0]
        args = np.array([Om , 2*F - 2*D + 2*Om , 2*F + 2*Om , 2*Om , Lp  , Lp + 2*F - 2*D + 2*Om , L  , 2*F + Om ,
                         L + 2*F + 2*Om , -Lp + 2*F - 2*D + 2*Om , 2*F - 2*D + Om , -L + 2*F + 2*Om , -L + 2*D  , L + Om ,
                         -L + Om , -L + 2*F + 2*D + 2*Om , L + 2*F + Om , -2*L + 2*F + Om , 2*D  , 2*F + 2*D + 2*Om ,
                         -2*Lp + 2*F - 2*D + 2*Om , -2*L + 2*D  , 2*L + 2*F + 2*Om , L + 2*F - 2*D + 2*Om , -L + 2*F + Om ,
                         2*L  , 2*F  , Lp + Om , -L + 2*D + Om , 2*Lp + 2*F - 2*D + 2*Om , -2*F + 2*D  , L + -2*D + Om ,
                         -Lp + Om , -L + 2*F + 2*D + Om , 2*Lp  , L + 2*F + 2*D + 2*Om , -2*L + 2*F  , Lp + 2*F + 2*Om ,
                         2*F + 2*D + Om , -Lp + 2*F + 2*Om , 2*D + Om , L + 2*F - 2*D + Om , 2*L + 2*F - 2*D + 2*Om ,
                         -2*L + 2*D + Om , 2*L + 2*F + Om , -Lp + 2*F - 2*D + Om , -2*D + Om , -L - Lp + 2*D  ,
                         2*L + -2*D + Om , L + 2*D  , Lp + 2*F - 2*D + Om , L - Lp  , -2*L + 2*F + 2*Om , 3*L + 2*F + 2*Om ,
                         -Lp + 2*D  , L - Lp + 2*F + 2*Om , D  , -L - Lp + 2*F + 2*D + 2*Om , -L + 2*F  ,
                         -Lp + 2*F + 2*D + 2*Om , -2*L + Om , L + Lp + 2*F + 2*Om , 2*L + Om , -L + Lp + D  ,
                         L + Lp  , L + 2*F  , -L + 2*F - 2*D + Om , L + 2*Om , -L + D  , 2*F + D + 2*Om ,
                         -L + 2*F + 4*D + 2*Om , -L + Lp + D + Om , -2*Lp + 2*F - 2*D + Om , L + 2*F + 2*D + Om ,
                         -2*L + 2*F + 2*D + 2*Om , -L + 2*Om , L + Lp + 2*F - 2*D + 2*Om])
        cosargs = cos(args)
        sinargs = sin(args)
        args = None

        A = np.array([-172064161 - 174666*T , -13170906 - 1675*T , -2276413 - 234*T , 2074554 + 207*T , 1475877 - 3633*T ,
                      -516821 + 1226*T , 711159 + 73*T , -387298 - 367*T , -301461 - 36*T , 215829 - 494*T , 128227 + 137*T ,
                      123457 + 11*T , 156994 + 10*T , 63110 + 63*T , -57976 - 63*T , -59641 - 11*T , -51613 - 42*T ,
                      45893 + 50*T , 63384 + 11*T , -38571 - 1*T , 32481  , -47722  , -31046 - 1*T , 28593  ,
                      20441 + 21*T , 29243  , 25887  , -14053 - 25*T , 15164 + 10*T , -15794 + 72*T , 21783  , -12873 - 10*T ,
                      -12654 + 11*T , -10204  , 16707 - 85*T , -7691  , -11024  , 7566 - 21*T , -6637 - 11*T ,
                      -7141 + 21*T , -6302 - 11*T , 5800 + 10*T , 6443  , -5774 - 11*T , -5350  , -4752 - 11*T , -4940 - 11*T ,
                      7350  , 4065  , 6579  , 3579  , 4725  , -3075  , -2904  , 4348  , -2878  , -4230  , -2819  , -4056  ,
                      -2647  , -2294  , 2481  , 2179  , 3276  , -3389  , 3339  , -1987  , -1981  , 4026  , 1660  , -1521  ,
                      1314  , -1283  , -1331  , 1383  , 1405  , 1290])
        B = np.array([33386 , -13696 , 2796 , -698 , 11817 , -524 , -872 , 380 , 816 , 111 , 181 , 19 , -168 , 27 , -189 ,
                      149 , 129 , 31 , -150 , 158 , 0 , -18 , 131 , -1 , 10 , -74 , -66 , 79 , 11 , -16 , 13 , -37 , 63 , 25
                         , -10 , 44 , -14 , -11 , 25 , 8 , 2 , 2 , -7 , -15 , 21 , -3 , -21 , -8 , 6 , -24 , 5 , -6 , -2 ,
                      15 , -10 , 8 , 5 , 7 , 5 , 11 , -10 , -7 , -2 , 1 , 5 , -13 , -6 , 0 , -353 , -5 , 9 , 0 , 0 , 8 , -2 ,
                      4 , 0]).reshape((77,1))
        Ap = np.array([92052331 + 9086*T , 5730336 - 3015*T , 978459 - 485*T , -897492 + 470*T , 73871 - 184*T , 224386 - 677*T ,
                       -6750  , 200728 + 18*T , 129025 - 63*T , -95929 + 299*T , -68982 - 9*T , -53311 + 32*T , -1235  ,
                       -33228  , 31429  , 25543 - 11*T , 26366  , -24236 - 10*T , -1220  , 16452 - 11*T , -13870  , 477  ,
                       13238 - 11*T , -12338 + 10*T , -10758  , -609  , -550  , 8551 - 2*T , -8001  , 6850 - 42*T , -167  ,
                       6953  , 6415  , 5222  , 168 - 1*T , 3268  , 104  , -3250  , 3353  , 3070  , 3272  , -3045  , -2768  ,
                       3041  , 2695  , 2719  , 2720  , -51  , -2206  , -199  , -1900  , -41  , 1313  , 1233  , -81  , 1232  ,
                       -20  , 1207  , 40  , 1129  , 1266  , -1062  , -1129  , -9  , 35  , -107  , 1073  , 854  , -553  , -710  ,
                       647  , -700  , 672  , 663  , -594  , -610  , -556])
        Bp = np.array([15377 , -4587 , 1374 , -291 , -1924 , -174 , 358 , 318 , 367 , 132 , 39 , -4 , 82 , -9 , -75 , 66 ,
                       78 , 20 , 29 , 68 , 0 , -25 , 59 , -3 , -3 , 13 , 11 , -45 , -1 , -5 , 13 , -14 , 26 , 15 , 10 , 19 ,
                       2 , -5 , 14 , 4 , 4 , -1 , -4 , -5 , 12 , -3 , -9 , 4 , 1 , 2 , 1 , 3 , -1 , 7 , 2 , 4 , -2 , 3 , -2 ,
                       5 , -4 , -3 , -2 , 0 , -2 , 1 , -2 , 0 , -139 , -2 , 4 , 0 , 0 , 4 , -2 , 2 , 0]).reshape(77,1)

        # print "A: %f"%(A.nbytes/(1024.*1024))
        # print "Ap: %f"%(Ap.nbytes/(1024.*1024))
        # print "sin: %f"%(sinargs.nbytes/(1024.*1024))
        # print "cos: %f"%(cosargs.nbytes/(1024.*1024))
        s1 = 0
        s2 = 0
        for k in range(77):
            s1 += A[k]*sinargs[k,:] + B[k]*cosargs[k,:]
            s2 += Ap[k]*cosargs[k,:] + Bp[k]*sinargs[k,:]
        #    A[k,:]= temp1[k]
        #    temp1[k] = 0
        #    Ap[k,:]= temp2[k]
        #    temp2[k] = 0
        #s = A*sinargs + B*sinargs
        #s = s.sum(0)
        dPsiDeg = s1 / 36000000000.0
        #s = Ap*cosargs + Bp*sinargs
        #s =s.sum(0)
        dEpsDeg = s2 / 36000000000.0
        sinargs = None
        cosargs = None
    else:


        s = 0
        s = s + (-172064161 - 174666*T)*sin(Om) + 33386*cos(Om)
        s = s + (-13170906 - 1675*T)*sin(2*F - 2*D + 2*Om) - 13696*cos(2*F - 2*D + 2*Om)
        s = s + (-2276413 - 234*T)*sin(2*F + 2*Om) + 2796*cos(2*F + 2*Om)
        s = s + (2074554 + 207*T)*sin(2*Om) - 698*cos(2*Om)
        s = s + (1475877 - 3633*T)*sin(Lp ) + 11817*cos(Lp )
        s = s + (-516821 + 1226*T)*sin(Lp + 2*F - 2*D + 2*Om) - 524*cos(Lp + 2*F - 2*D + 2*Om)
        s = s + (711159 + 73*T)*sin(L ) - 872*cos(L )
        s = s + (-387298 - 367*T)*sin(2*F + Om) + 380*cos(2*F + Om)
        s = s + (-301461 - 36*T)*sin(L + 2*F + 2*Om) + 816*cos(L + 2*F + 2*Om)
        s = s + (215829 - 494*T)*sin(-Lp + 2*F - 2*D + 2*Om) + 111*cos(-Lp + 2*F - 2*D + 2*Om)
        s = s + (128227 + 137*T)*sin(2*F - 2*D + Om) + 181*cos(2*F - 2*D + Om)
        s = s + (123457 + 11*T)*sin(-L + 2*F + 2*Om) + 19*cos(-L + 2*F + 2*Om)
        s = s + (156994 + 10*T)*sin(-L + 2*D ) - 168*cos(-L + 2*D )
        s = s + (63110 + 63*T)*sin(L + Om) + 27*cos(L + Om)
        s = s + (-57976 - 63*T)*sin(-L + Om) - 189*cos(-L + Om)
        s = s + (-59641 - 11*T)*sin(-L + 2*F + 2*D + 2*Om) + 149*cos(-L + 2*F + 2*D + 2*Om)
        s = s + (-51613 - 42*T)*sin(L + 2*F + Om) + 129*cos(L + 2*F + Om)
        s = s + (45893 + 50*T)*sin(-2*L + 2*F + Om) + 31*cos(-2*L + 2*F + Om)
        s = s + (63384 + 11*T)*sin(2*D ) - 150*cos(2*D )
        s = s + (-38571 - 1*T)*sin(2*F + 2*D + 2*Om) + 158*cos(2*F + 2*D + 2*Om)
        s = s + (32481 )*sin(-2*Lp + 2*F - 2*D + 2*Om) + 0*cos(-2*Lp + 2*F - 2*D + 2*Om)
        s = s + (-47722 )*sin(-2*L + 2*D ) - 18*cos(-2*L + 2*D )
        s = s + (-31046 - 1*T)*sin(2*L + 2*F + 2*Om) + 131*cos(2*L + 2*F + 2*Om)
        s = s + (28593 )*sin(L + 2*F - 2*D + 2*Om) - 1*cos(L + 2*F - 2*D + 2*Om)
        s = s + (20441 + 21*T)*sin(-L + 2*F + Om) + 10*cos(-L + 2*F + Om)
        s = s + (29243 )*sin(2*L ) - 74*cos(2*L )
        s = s + (25887 )*sin(2*F ) - 66*cos(2*F )
        s = s + (-14053 - 25*T)*sin(Lp + Om) + 79*cos(Lp + Om)
        s = s + (15164 + 10*T)*sin(-L + 2*D + Om) + 11*cos(-L + 2*D + Om)
        s = s + (-15794 + 72*T)*sin(2*Lp + 2*F - 2*D + 2*Om) - 16*cos(2*Lp + 2*F - 2*D + 2*Om)
        s = s + (21783 )*sin(-2*F + 2*D ) + 13*cos(-2*F + 2*D )
        s = s + (-12873 - 10*T)*sin(L + -2*D + Om) - 37*cos(L + -2*D + Om)
        s = s + (-12654 + 11*T)*sin(-Lp + Om) + 63*cos(-Lp + Om)
        s = s + (-10204 )*sin(-L + 2*F + 2*D + Om) + 25*cos(-L + 2*F + 2*D + Om)
        s = s + (16707 - 85*T)*sin(2*Lp ) - 10*cos(2*Lp )
        s = s + (-7691 )*sin(L + 2*F + 2*D + 2*Om) + 44*cos(L + 2*F + 2*D + 2*Om)
        s = s + (-11024 )*sin(-2*L + 2*F ) - 14*cos(-2*L + 2*F )
        s = s + (7566 - 21*T)*sin(Lp + 2*F + 2*Om) - 11*cos(Lp + 2*F + 2*Om)
        s = s + (-6637 - 11*T)*sin(2*F + 2*D + Om) + 25*cos(2*F + 2*D + Om)
        s = s + (-7141 + 21*T)*sin(-Lp + 2*F + 2*Om) + 8*cos(-Lp + 2*F + 2*Om)
        s = s + (-6302 - 11*T)*sin(2*D + Om) + 2*cos(2*D + Om)
        s = s + (5800 + 10*T)*sin(L + 2*F - 2*D + Om) + 2*cos(L + 2*F - 2*D + Om)
        s = s + (6443 )*sin(2*L + 2*F - 2*D + 2*Om) - 7*cos(2*L + 2*F - 2*D + 2*Om)
        s = s + (-5774 - 11*T)*sin(-2*L + 2*D + Om) - 15*cos(-2*L + 2*D + Om)
        s = s + (-5350 )*sin(2*L + 2*F + Om) + 21*cos(2*L + 2*F + Om)
        s = s + (-4752 - 11*T)*sin(-Lp + 2*F - 2*D + Om) - 3*cos(-Lp + 2*F - 2*D + Om)
        s = s + (-4940 - 11*T)*sin(-2*D + Om) - 21*cos(-2*D + Om)
        s = s + (7350 )*sin(-L - Lp + 2*D ) - 8*cos(-L - Lp + 2*D )
        s = s + (4065 )*sin(2*L + -2*D + Om) + 6*cos(2*L + -2*D + Om)
        s = s + (6579 )*sin(L + 2*D ) - 24*cos(L + 2*D )
        s = s + (3579 )*sin(Lp + 2*F - 2*D + Om) + 5*cos(Lp + 2*F - 2*D + Om)
        s = s + (4725 )*sin(L - Lp ) - 6*cos(L - Lp )
        s = s + (-3075 )*sin(-2*L + 2*F + 2*Om) - 2*cos(-2*L + 2*F + 2*Om)
        s = s + (-2904 )*sin(3*L + 2*F + 2*Om) + 15*cos(3*L + 2*F + 2*Om)
        s = s + (4348 )*sin(-Lp + 2*D ) - 10*cos(-Lp + 2*D )
        s = s + (-2878 )*sin(L - Lp + 2*F + 2*Om) + 8*cos(L - Lp + 2*F + 2*Om)
        s = s + (-4230 )*sin(D ) + 5*cos(D )
        s = s + (-2819 )*sin(-L - Lp + 2*F + 2*D + 2*Om) + 7*cos(-L - Lp + 2*F + 2*D + 2*Om)
        s = s + (-4056 )*sin(-L + 2*F ) + 5*cos(-L + 2*F )
        s = s + (-2647 )*sin(-Lp + 2*F + 2*D + 2*Om) + 11*cos(-Lp + 2*F + 2*D + 2*Om)
        s = s + (-2294 )*sin(-2*L + Om) - 10*cos(-2*L + Om)
        s = s + (2481 )*sin(L + Lp + 2*F + 2*Om) - 7*cos(L + Lp + 2*F + 2*Om)
        s = s + (2179 )*sin(2*L + Om) - 2*cos(2*L + Om)
        s = s + (3276 )*sin(-L + Lp + D ) + 1*cos(-L + Lp + D )
        s = s + (-3389 )*sin(L + Lp ) + 5*cos(L + Lp )
        s = s + (3339 )*sin(L + 2*F ) - 13*cos(L + 2*F )
        s = s + (-1987 )*sin(-L + 2*F - 2*D + Om) - 6*cos(-L + 2*F - 2*D + Om)
        s = s + (-1981 )*sin(L + 2*Om) + 0*cos(L + 2*Om)
        s = s + (4026 )*sin(-L + D ) - 353*cos(-L + D )
        s = s + (1660 )*sin(2*F + D + 2*Om) - 5*cos(2*F + D + 2*Om)
        s = s + (-1521 )*sin(-L + 2*F + 4*D + 2*Om) + 9*cos(-L + 2*F + 4*D + 2*Om)
        s = s + (1314 )*sin(-L + Lp + D + Om) + 0*cos(-L + Lp + D + Om)
        s = s + (-1283 )*sin(-2*Lp + 2*F - 2*D + Om) + 0*cos(-2*Lp + 2*F - 2*D + Om)
        s = s + (-1331 )*sin(L + 2*F + 2*D + Om) + 8*cos(L + 2*F + 2*D + Om)
        s = s + (1383 )*sin(-2*L + 2*F + 2*D + 2*Om) - 2*cos(-2*L + 2*F + 2*D + 2*Om)
        s = s + (1405 )*sin(-L + 2*Om) + 4*cos(-L + 2*Om)
        s = s + (1290 )*sin(L + Lp + 2*F - 2*D + 2*Om) + 0*cos(L + Lp + 2*F - 2*D + 2*Om)

        # s = 0
        # s = s + (-172064161 - 174666*T)*sin( Om) + 33386*cos(Om)
        # s = s + (-13170906 - 1675*T)*sin( 2*F - 2*D + 2*Om) - 13696*cos( 2*F - 2*D + 2*Om)
        # s = s + (-2276413 - 234*T)*sin( 2*F + 2*Om) + 2796*cos( 2*F + 2*Om)
        # s = s + (2074554 + 207*T)*sin( 2*Om) - 698*cos(2*Om)
        # s = s + (1475877 - 3633*T)*sin(Lp ) + 11817*cos(Lp )
        # s = s + (-516821 + 1226*T)*sin(Lp + 2*F - 2*D + 2*Om) - 524*cos(Lp + 2*F - 2*D + 2*Om)
        # s = s + (711159 + 73*T)*sin(L) - 872*cos(L)
        # s = s + (-387298 - 367*T)*sin(2*F + Om) + 380*cos( 2*F +Om)
        # s = s + (-301461 - 36*T)*sin(L + 2*F + 2*Om) + 816*cos(L + 2*F  + 2*Om)
        # s = s + (215829 - 494*T)*sin(- Lp + 2*F - 2*D + 2*Om) + 111*cos(-Lp + 2*F - 2*D + 2*Om)
        # s = s + (128227 + 137*T)*sin(2*F - 2*D + Om) + 181*cos( 2*F - 2*D + Om)
        # s = s + (123457 + 11*T)*sin(-L + 2*F + 2*Om) + 19*cos(-L + 2*F  + 2*Om)
        # s = s + (156994 + 10*T)*sin(-L  + 2*D ) - 168*cos(-L +  2*D )
        # s = s + (63110 + 63*T)*sin(L + Om) + 27*cos(L + Om)
        # s = s + (-57976 - 63*T)*sin(-L + Om) - 189*cos(-L +Om)
        # s = s + (-59641 - 11*T)*sin(-L +  2*F + 2*D + 2*Om) + 149*cos(-L + 2*F + 2*D + 2*Om)
        # s = s + (-51613 - 42*T)*sin(L +  2*F +  Om) + 129*cos(L +  2*F + Om)
        # s = s + (45893 + 50*T)*sin(-2*L + 2*F +  Om) + 31*cos(-2*L + 2*F + Om)
        # s = s + (63384 + 11*T)*sin(2*D ) - 150*cos( 2*D )
        # s = s + (-38571 - T)*sin(2*F + 2*D + 2*Om) + 158*cos( 2*F + 2*D + 2*Om)
        # s = s + (32481 )*sin(-2*Lp + 2*F - 2*D + 2*Om) + 0*cos(-2*Lp + 2*F - 2*D + 2*Om)
        # s = s + (-47722 )*sin(-2*L  + 2*D) - 18*cos(-2*L  + 2*D )
        # s = s + (-31046 - T)*sin(2*L  + 2*F +  2*Om) + 131*cos(2*L + 2*F + 2*Om)
        # s = s + (28593 )*sin(L + 2*F - 2*D + 2*Om) - 1*cos(L + 2*F - 2*D + 2*Om)
        # s = s + (20441 + 21*T)*sin(-L +  2*F + Om) + 10*cos(-L +  2*F + Om)
        # s = s + (29243 )*sin(2*L ) - 74*cos(2*L )
        # s = s + (25887 )*sin(  2*F ) - 66*cos( 2*F )
        # s = s + (-14053 - 25*T)*sin(Lp +Om) + 79*cos(Lp + Om)
        # s = s + (15164 + 10*T)*sin(-L + 2*D + Om) + 11*cos(-L + 2*D + Om)
        # s = s + (-15794 + 72*T)*sin(2*Lp + 2*F - 2*D + 2*Om) - 16*cos(2*Lp + 2*F - 2*D + 2*Om)
        # s = s + (21783 )*sin( - 2*F + 2*D ) + 13*cos(- 2*F + 2*D )
        # s = s + (-12873 - 10*T)*sin(1*L  - 2*D + Om) - 37*cos(1*L  - 2*D + Om)
        # s = s + (-12654 + 11*T)*sin( - Lp +Om) + 63*cos(- Lp + Om)
        # s = s + (-10204 )*sin(-L +  2*F + 2*D + Om) + 25*cos(L +  2*F + 2*D + Om)
        # s = s + (16707 - 85*T)*sin( 2*Lp ) - 10*cos(2*Lp )
        # s = s + (-7691 )*sin(L + 2*F + 2*D + 2*Om) + 44*cos(L +  2*F + 2*D + 2*Om)
        # s = s + (-11024 )*sin(-2*L + 2*F ) - 14*cos(-2*L + 2*F )
        # s = s + (7566 - 21*T)*sin(Lp + 2*F  + 2*Om) - 11*cos(Lp + 2*F +  2*Om)
        # s = s + (-6637 - 11*T)*sin( 2*F + 2*D + Om) + 25*cos(2*F + 2*D + Om)
        # s = s + (-7141 + 21*T)*sin(-Lp + 2*F + 2*Om) + 8*cos(-Lp + 2*F + 2*Om)
        # s = s + (-6302 - 11*T)*sin(2*D + Om) + 2*cos(2*D + Om)
        # s = s + (5800 + 10*T)*sin(L + 2*F - 2*D + Om) + 2*cos(L  + 2*F - 2*D + Om)
        # s = s + (6443 )*sin(2*L +  2*F - 2*D + 2*Om) - 7*cos(2*L + 2*F - 2*D + 2*Om)
        # s = s + (-5774 - 11*T)*sin(-2*L + 2*D + Om) - 15*cos(-2*L + 2*D + Om)
        # s = s + (-5350 )*sin(2*L + 2*F + Om) + 21*cos(2*L  + 2*F +Om)
        # s = s + (-4752 - 11*T)*sin(-Lp + 2*F - 2*D + Om) - 3*cos(-Lp + 2*F - 2*D + Om)
        # s = s + (-4940 - 11*T)*sin( -2*D + Om) - 21*cos(-2*D + Om)
        # s = s + (7350 )*sin(-L - Lp + 2*D ) - 8*cos(-L - Lp +  2*D )
        # s = s + (4065 )*sin(2*L - 2*D + Om) + 6*cos(2*L - 2*D + Om)
        # s = s + (6579 )*sin(L + 2*D ) - 24*cos(L + 2*D )
        # s = s + (3579 )*sin(Lp + 2*F - 2*D + Om) + 5*cos(Lp + 2*F - 2*D + Om)
        # s = s + (4725 )*sin(L - Lp ) - 6*cos(L - Lp )
        # s = s + (-3075 )*sin(-2*L  + 2*F + 2*Om) - 2*cos(-2*L +  2*F + 2*Om)
        # s = s + (-2904 )*sin(3*L  + 2*F +  2*Om) + 15*cos(3*L  + 2*F  + 2*Om)
        # s = s + (4348 )*sin(-Lp + 2*D ) - 10*cos(-Lp + 2*D )
        # s = s + (-2878 )*sin(L - Lp + 2*F +  2*Om) + 8*cos(L - Lp + 2*F + 2*Om)
        # s = s + (-4230 )*sin( D ) + 5*cos(D )
        # s = s + (-2819 )*sin(-L - Lp + 2*F + 2*D + 2*Om) + 7*cos(-L - Lp + 2*F + 2*D + 2*Om)
        # s = s + (-4056 )*sin(-L +2*F ) + 5*cos(-L  + 2*F )
        # s = s + (-2647 )*sin(-Lp + 2*F + 2*D + 2*Om) + 11*cos(-Lp + 2*F + 2*D + 2*Om)
        # s = s + (-2294)*sin(-2*L + Om) - 10*cos(-2*L+ Om)
        # s = s + (2481 )*sin(L + Lp + 2*F +  2*Om) - 7*cos(L + Lp + 2*F +  2*Om)
        # s = s + (2179)*sin(2*L + Om) - 2*cos(2*L + Om)
        # s = s + (3276)*sin(-L + Lp +  D ) + 1*cos(-L +Lp  + D )
        # s = s + (-3389)*sin(L + Lp ) + 5*cos(L + Lp )
        # s = s + (3339)*sin(L +  2*F ) - 13*cos(L + 2*F )
        # s = s + (-1987)*sin(-L +  2*F - 2*D + Om) - 6*cos(-L + 2*F - 2*D + Om)
        # s = s + (-1981)*sin(L + 2*Om) + 0*cos(L +  2*Om)
        # s = s + (4026)*sin(-L + D ) - 353*cos(-L+ D )
        # s = s + (1660)*sin( 2*F + D + 2*Om) - 5*cos(2*F +D + 2*Om)
        # s = s + (-1521)*sin(-L + 2*F + 4*D + 2*Om) + 9*cos(-L + 2*F + 4*D + 2*Om)
        # s = s + (1314)*sin(-L + Lp + D + Om) + 0*cos(-L + Lp + D + Om)
        # s = s + (-1283)*sin(-2*Lp + 2*F - 2*D + Om)
        # s = s + (-1331)*sin(L + 2*F + 2*D + Om) + 8*cos(L + 2*F + 2*D + Om)
        # s = s + (1383)*sin(-2*L  + 2*F + 2*D + 2*Om) - 2*cos(-2*L + 2*F + 2*D + 2*Om)
        # s = s + (1405 )*sin(-L  + 2*Om) + 4*cos(-L + 2*Om)
        # s = s + (1290 )*sin(L + Lp + 2*F - 2*D + 2*Om) + 0*cos(L + Lp + 2*F - 2*D + 2*Om)

        # -----------------------------------------------------
        # Convert nutation in longitude from arc sec * 10000000
        # into decimal degrees. This is the value returned by
        # the function.

        dPsiDeg = s / 36000000000.0
        # -------------------------------------------------------------------
        # EVALUATE THE SERIES FOR NUTATION IN LONGITUDE IN ARC SEC * 10000000
        #
        # --------------------------------------------------------
        # Using the table data, the terms take the following form:
        #
        # dEpsTerm = (DD + EE*T)*cos(arg) + FF*sin(arg)
        #
        # Where:
        # arg = (m1*L + m2*Lp + m3*F + m4*D + m5*Om)
        #
        # The angles are assumed to be in radians.
        #
        # -----------------------------------------------------------------
        # Using the data table above, the following raw terms can be built.
        # Notice there are numerous elements that equate to zero.  Those
        # elements may subsequently be removed and the remaining terms
        # algebraically simplified.
        #
        # Each data line represents the elements of a term in the nutation series.
        #
        # Compare the data table values to the numbers used in raw series below.
        #
        # The variable s is used to hold the accumulating sum (s) of the terms
        # as they are sequentially evaluated.  This value is converted into
        # decimal degrees at the end of the summation.

        s = 0
        s = s + (92052331 + 9086*T)*cos(Om) + 15377*sin(Om)
        s = s + (5730336 - 3015*T)*cos(2*F - 2*D + 2*Om) - 4587*sin(2*F - 2*D + 2*Om)
        s = s + (978459 - 485*T)*cos(2*F + 2*Om) + 1374*sin(2*F + 2*Om)
        s = s + (-897492 + 470*T)*cos(2*Om) - 291*sin(2*Om)
        s = s + (73871 - 184*T)*cos(Lp ) - 1924*sin(Lp )
        s = s + (224386 - 677*T)*cos(Lp + 2*F - 2*D + 2*Om) - 174*sin(Lp + 2*F - 2*D + 2*Om)
        s = s + (-6750 )*cos(L ) + 358*sin(L )
        s = s + (200728 + 18*T)*cos(2*F + Om) + 318*sin(2*F + Om)
        s = s + (129025 - 63*T)*cos(L + 2*F + 2*Om) + 367*sin(L + 2*F + 2*Om)
        s = s + (-95929 + 299*T)*cos(-Lp + 2*F - 2*D + 2*Om) + 132*sin(-Lp + 2*F - 2*D + 2*Om)
        s = s + (-68982 - 9*T)*cos(2*F - 2*D + Om) + 39*sin(2*F - 2*D + Om)
        s = s + (-53311 + 32*T)*cos(-L + 2*F + 2*Om) - 4*sin(-L + 2*F + 2*Om)
        s = s + (-1235 )*cos(-L + 2*D ) + 82*sin(-L + 2*D )
        s = s + (-33228 )*cos(L + Om) - 9*sin(L + Om)
        s = s + (31429 )*cos(-L + Om) - 75*sin(-L + Om)
        s = s + (25543 - 11*T)*cos(-L + 2*F + 2*D + 2*Om) + 66*sin(-L + 2*F + 2*D + 2*Om)
        s = s + (26366 )*cos(L + 2*F + Om) + 78*sin(L + 2*F + Om)
        s = s + (-24236 - 10*T)*cos(-2*L + 2*F + Om) + 20*sin(-2*L + 2*F + Om)
        s = s + (-1220 )*cos(2*D ) + 29*sin(2*D )
        s = s + (16452 - 11*T)*cos(2*F + 2*D + 2*Om) + 68*sin(2*F + 2*D + 2*Om)
        s = s + (-13870 )*cos(-2*Lp + 2*F - 2*D + 2*Om) + 0*sin(-2*Lp + 2*F - 2*D + 2*Om)
        s = s + (477 )*cos(-2*L + 2*D ) - 25*sin(-2*L + 2*D )
        s = s + (13238 - 11*T)*cos(2*L + 2*F + 2*Om) + 59*sin(2*L + 2*F + 2*Om)
        s = s + (-12338 + 10*T)*cos(L + 2*F - 2*D + 2*Om) - 3*sin(L + 2*F - 2*D + 2*Om)
        s = s + (-10758 )*cos(-L + 2*F + Om) - 3*sin(-L + 2*F + Om)
        s = s + (-609 )*cos(2*L ) + 13*sin(2*L )
        s = s + (-550 )*cos(2*F ) + 11*sin(2*F )
        s = s + (8551 - 2*T)*cos(Lp + Om) - 45*sin(Lp + Om)
        s = s + (-8001 )*cos(-L + 2*D + Om) - 1*sin(-L + 2*D + Om)
        s = s + (6850 - 42*T)*cos(2*Lp + 2*F - 2*D + 2*Om) - 5*sin(2*Lp + 2*F - 2*D + 2*Om)
        s = s + (-167 )*cos(-2*F + 2*D ) + 13*sin(-2*F + 2*D )
        s = s + (6953 )*cos(L + -2*D + Om) - 14*sin(L + -2*D + Om)
        s = s + (6415 )*cos(-Lp + Om) + 26*sin(-Lp + Om)
        s = s + (5222 )*cos(-L + 2*F + 2*D + Om) + 15*sin(-L + 2*F + 2*D + Om)
        s = s + (168 - 1*T)*cos(2*Lp ) + 10*sin(2*Lp )
        s = s + (3268 )*cos(L + 2*F + 2*D + 2*Om) + 19*sin(L + 2*F + 2*D + 2*Om)
        s = s + (104 )*cos(-2*L + 2*F ) + 2*sin(-2*L + 2*F )
        s = s + (-3250 )*cos(Lp + 2*F + 2*Om) - 5*sin(Lp + 2*F + 2*Om)
        s = s + (3353 )*cos(2*F + 2*D + Om) + 14*sin(2*F + 2*D + Om)
        s = s + (3070 )*cos(-Lp + 2*F + 2*Om) + 4*sin(-Lp + 2*F + 2*Om)
        s = s + (3272 )*cos(2*D + Om) + 4*sin(2*D + Om)
        s = s + (-3045 )*cos(L + 2*F - 2*D + Om) - 1*sin(L + 2*F - 2*D + Om)
        s = s + (-2768 )*cos(2*L + 2*F - 2*D + 2*Om) - 4*sin(2*L + 2*F - 2*D + 2*Om)
        s = s + (3041 )*cos(-2*L + 2*D + Om) - 5*sin(-2*L + 2*D + Om)
        s = s + (2695 )*cos(2*L + 2*F + Om) + 12*sin(2*L + 2*F + Om)
        s = s + (2719 )*cos(-Lp + 2*F - 2*D + Om) - 3*sin(-Lp + 2*F - 2*D + Om)
        s = s + (2720 )*cos(-2*D + Om) - 9*sin(-2*D + Om)
        s = s + (-51 )*cos(-L - Lp + 2*D ) + 4*sin(-L - Lp + 2*D )
        s = s + (-2206 )*cos(2*L + -2*D + Om) + 1*sin(2*L + -2*D + Om)
        s = s + (-199 )*cos(L + 2*D ) + 2*sin(L + 2*D )
        s = s + (-1900 )*cos(Lp + 2*F - 2*D + Om) + 1*sin(Lp + 2*F - 2*D + Om)
        s = s + (-41 )*cos(L - Lp ) + 3*sin(L - Lp )
        s = s + (1313 )*cos(-2*L + 2*F + 2*Om) - 1*sin(-2*L + 2*F + 2*Om)
        s = s + (1233 )*cos(3*L + 2*F + 2*Om) + 7*sin(3*L + 2*F + 2*Om)
        s = s + (-81 )*cos(-Lp + 2*D ) + 2*sin(-Lp + 2*D )
        s = s + (1232 )*cos(L - Lp + 2*F + 2*Om) + 4*sin(L - Lp + 2*F + 2*Om)
        s = s + (-20 )*cos(D ) - 2*sin(D )
        s = s + (1207 )*cos(-L - Lp + 2*F + 2*D + 2*Om) + 3*sin(-L - Lp + 2*F + 2*D + 2*Om)
        s = s + (40 )*cos(-L + 2*F ) - 2*sin(-L + 2*F )
        s = s + (1129 )*cos(-Lp + 2*F + 2*D + 2*Om) + 5*sin(-Lp + 2*F + 2*D + 2*Om)
        s = s + (1266 )*cos(-2*L + Om) - 4*sin(-2*L + Om)
        s = s + (-1062 )*cos(L + Lp + 2*F + 2*Om) - 3*sin(L + Lp + 2*F + 2*Om)
        s = s + (-1129 )*cos(2*L + Om) - 2*sin(2*L + Om)
        s = s + (-9 )*cos(-L + Lp + D ) + 0*sin(-L + Lp + D )
        s = s + (35 )*cos(L + Lp ) - 2*sin(L + Lp )
        s = s + (-107 )*cos(L + 2*F ) + 1*sin(L + 2*F )
        s = s + (1073 )*cos(-L + 2*F - 2*D + Om) - 2*sin(-L + 2*F - 2*D + Om)
        s = s + (854 )*cos(L + 2*Om) + 0*sin(L + 2*Om)
        s = s + (-553 )*cos(-L + D ) - 139*sin(-L + D )
        s = s + (-710 )*cos(2*F + D + 2*Om) - 2*sin(2*F + D + 2*Om)
        s = s + (647 )*cos(-L + 2*F + 4*D + 2*Om) + 4*sin(-L + 2*F + 4*D + 2*Om)
        s = s + (-700 )*cos(-L + Lp + D + Om) + 0*sin(-L + Lp + D + Om)
        s = s + (672 )*cos(-2*Lp + 2*F - 2*D + Om) + 0*sin(-2*Lp + 2*F - 2*D + Om)
        s = s + (663 )*cos(L + 2*F + 2*D + Om) + 4*sin(L + 2*F + 2*D + Om)
        s = s + (-594 )*cos(-2*L + 2*F + 2*D + 2*Om) - 2*sin(-2*L + 2*F + 2*D + 2*Om)
        s = s + (-610 )*cos(-L + 2*Om) + 2*sin(-L + 2*Om)
        s = s + (-556 )*cos(L + Lp + 2*F - 2*D + 2*Om) + 0*sin(L + Lp + 2*F - 2*D + 2*Om)
        # s = s + (92052331 + 9086*T)*cos(0*L + 0*Lp + 0*F + 0*D + 1*Om) + 15377*sin(0*L + 0*Lp + 0*F + 0*D + 1*Om)
        # s = s + (5730336 - 3015*T)*cos(0*L + 0*Lp + 2*F - 2*D + 2*Om) - 4587*sin(0*L + 0*Lp + 2*F - 2*D + 2*Om)
        # s = s + (978459 - 485*T)*cos(0*L + 0*Lp + 2*F + 0*D + 2*Om) + 1374*sin(0*L + 0*Lp + 2*F + 0*D + 2*Om)
        # s = s + (-897492 + 470*T)*cos(0*L + 0*Lp + 0*F + 0*D + 2*Om) - 291*sin(0*L + 0*Lp + 0*F + 0*D + 2*Om)
        # s = s + (73871 - 184*T)*cos(0*L + 1*Lp + 0*F + 0*D + 0*Om) - 1924*sin(0*L + 1*Lp + 0*F + 0*D + 0*Om)
        # s = s + (224386 - 677*T)*cos(0*L + 1*Lp + 2*F - 2*D + 2*Om) - 174*sin(0*L + 1*Lp + 2*F - 2*D + 2*Om)
        # s = s + (-6750 + 0*T)*cos(1*L + 0*Lp + 0*F + 0*D + 0*Om) + 358*sin(1*L + 0*Lp + 0*F + 0*D + 0*Om)
        # s = s + (200728 + 18*T)*cos(0*L + 0*Lp + 2*F + 0*D + 1*Om) + 318*sin(0*L + 0*Lp + 2*F + 0*D + 1*Om)
        # s = s + (129025 - 63*T)*cos(1*L + 0*Lp + 2*F + 0*D + 2*Om) + 367*sin(1*L + 0*Lp + 2*F + 0*D + 2*Om)
        # s = s + (-95929 + 299*T)*cos(0*L - 1*Lp + 2*F - 2*D + 2*Om) + 132*sin(0*L - 1*Lp + 2*F - 2*D + 2*Om)
        # s = s + (-68982 - 9*T)*cos(0*L + 0*Lp + 2*F - 2*D + 1*Om) + 39*sin(0*L + 0*Lp + 2*F - 2*D + 1*Om)
        # s = s + (-53311 + 32*T)*cos(-1*L + 0*Lp + 2*F + 0*D + 2*Om) - 4*sin(-1*L + 0*Lp + 2*F + 0*D + 2*Om)
        # s = s + (-1235 + 0*T)*cos(-1*L + 0*Lp + 0*F + 2*D + 0*Om) + 82*sin(-1*L + 0*Lp + 0*F + 2*D + 0*Om)
        # s = s + (-33228 + 0*T)*cos(1*L + 0*Lp + 0*F + 0*D + 1*Om) - 9*sin(1*L + 0*Lp + 0*F + 0*D + 1*Om)
        # s = s + (31429 + 0*T)*cos(-1*L + 0*Lp + 0*F + 0*D + 1*Om) - 75*sin(-1*L + 0*Lp + 0*F + 0*D + 1*Om)
        # s = s + (25543 - 11*T)*cos(-1*L + 0*Lp + 2*F + 2*D + 2*Om) + 66*sin(-1*L + 0*Lp + 2*F + 2*D + 2*Om)
        # s = s + (26366 + 0*T)*cos(1*L + 0*Lp + 2*F + 0*D + 1*Om) + 78*sin(1*L + 0*Lp + 2*F + 0*D + 1*Om)
        # s = s + (-24236 - 10*T)*cos(-2*L + 0*Lp + 2*F + 0*D + 1*Om) + 20*sin(-2*L + 0*Lp + 2*F + 0*D + 1*Om)
        # s = s + (-1220 + 0*T)*cos(0*L + 0*Lp + 0*F + 2*D + 0*Om) + 29*sin(0*L + 0*Lp + 0*F + 2*D + 0*Om)
        # s = s + (16452 - 11*T)*cos(0*L + 0*Lp + 2*F + 2*D + 2*Om) + 68*sin(0*L + 0*Lp + 2*F + 2*D + 2*Om)
        # s = s + (-13870 + 0*T)*cos(0*L - 2*Lp + 2*F - 2*D + 2*Om) + 0*sin(0*L - 2*Lp + 2*F - 2*D + 2*Om)
        # s = s + (477 + 0*T)*cos(-2*L + 0*Lp + 0*F + 2*D + 0*Om) - 25*sin(-2*L + 0*Lp + 0*F + 2*D + 0*Om)
        # s = s + (13238 - 11*T)*cos(2*L + 0*Lp + 2*F + 0*D + 2*Om) + 59*sin(2*L + 0*Lp + 2*F + 0*D + 2*Om)
        # s = s + (-12338 + 10*T)*cos(1*L + 0*Lp + 2*F - 2*D + 2*Om) - 3*sin(1*L + 0*Lp + 2*F - 2*D + 2*Om)
        # s = s + (-10758 + 0*T)*cos(-1*L + 0*Lp + 2*F + 0*D + 1*Om) - 3*sin(-1*L + 0*Lp + 2*F + 0*D + 1*Om)
        # s = s + (-609 + 0*T)*cos(2*L + 0*Lp + 0*F + 0*D + 0*Om) + 13*sin(2*L + 0*Lp + 0*F + 0*D + 0*Om)
        # s = s + (-550 + 0*T)*cos(0*L + 0*Lp + 2*F + 0*D + 0*Om) + 11*sin(0*L + 0*Lp + 2*F + 0*D + 0*Om)
        # s = s + (8551 - 2*T)*cos(0*L + 1*Lp + 0*F + 0*D + 1*Om) - 45*sin(0*L + 1*Lp + 0*F + 0*D + 1*Om)
        # s = s + (-8001 + 0*T)*cos(-1*L + 0*Lp + 0*F + 2*D + 1*Om) - 1*sin(-1*L + 0*Lp + 0*F + 2*D + 1*Om)
        # s = s + (6850 - 42*T)*cos(0*L + 2*Lp + 2*F - 2*D + 2*Om) - 5*sin(0*L + 2*Lp + 2*F - 2*D + 2*Om)
        # s = s + (-167 + 0*T)*cos(0*L + 0*Lp - 2*F + 2*D + 0*Om) + 13*sin(0*L + 0*Lp - 2*F + 2*D + 0*Om)
        # s = s + (6953 + 0*T)*cos(1*L + 0*Lp + 0*F - 2*D + 1*Om) - 14*sin(1*L + 0*Lp + 0*F - 2*D + 1*Om)
        # s = s + (6415 + 0*T)*cos(0*L - 1*Lp + 0*F + 0*D + 1*Om) + 26*sin(0*L - 1*Lp + 0*F + 0*D + 1*Om)
        # s = s + (5222 + 0*T)*cos(-1*L + 0*Lp + 2*F + 2*D + 1*Om) + 15*sin(-1*L + 0*Lp + 2*F + 2*D + 1*Om)
        # s = s + (168 - 1*T)*cos(0*L + 2*Lp + 0*F + 0*D + 0*Om) + 10*sin(0*L + 2*Lp + 0*F + 0*D + 0*Om)
        # s = s + (3268 + 0*T)*cos(1*L + 0*Lp + 2*F + 2*D + 2*Om) + 19*sin(1*L + 0*Lp + 2*F + 2*D + 2*Om)
        # s = s + (104 + 0*T)*cos(-2*L + 0*Lp + 2*F + 0*D + 0*Om) + 2*sin(-2*L + 0*Lp + 2*F + 0*D + 0*Om)
        # s = s + (-3250 + 0*T)*cos(0*L + 1*Lp + 2*F + 0*D + 2*Om) - 5*sin(0*L + 1*Lp + 2*F + 0*D + 2*Om)
        # s = s + (3353 + 0*T)*cos(0*L + 0*Lp + 2*F + 2*D + 1*Om) + 14*sin(0*L + 0*Lp + 2*F + 2*D + 1*Om)
        # s = s + (3070 + 0*T)*cos(0*L - 1*Lp + 2*F + 0*D + 2*Om) + 4*sin(0*L - 1*Lp + 2*F + 0*D + 2*Om)
        # s = s + (3272 + 0*T)*cos(0*L + 0*Lp + 0*F + 2*D + 1*Om) + 4*sin(0*L + 0*Lp + 0*F + 2*D + 1*Om)
        # s = s + (-3045 + 0*T)*cos(1*L + 0*Lp + 2*F - 2*D + 1*Om) - 1*sin(1*L + 0*Lp + 2*F - 2*D + 1*Om)
        # s = s + (-2768 + 0*T)*cos(2*L + 0*Lp + 2*F - 2*D + 2*Om) - 4*sin(2*L + 0*Lp + 2*F - 2*D + 2*Om)
        # s = s + (3041 + 0*T)*cos(-2*L + 0*Lp + 0*F + 2*D + 1*Om) - 5*sin(-2*L + 0*Lp + 0*F + 2*D + 1*Om)
        # s = s + (2695 + 0*T)*cos(2*L + 0*Lp + 2*F + 0*D + 1*Om) + 12*sin(2*L + 0*Lp + 2*F + 0*D + 1*Om)
        # s = s + (2719 + 0*T)*cos(0*L - 1*Lp + 2*F - 2*D + 1*Om) - 3*sin(0*L - 1*Lp + 2*F - 2*D + 1*Om)
        # s = s + (2720 + 0*T)*cos(0*L + 0*Lp + 0*F - 2*D + 1*Om) - 9*sin(0*L + 0*Lp + 0*F - 2*D + 1*Om)
        # s = s + (-51 + 0*T)*cos(-1*L - 1*Lp + 0*F + 2*D + 0*Om) + 4*sin(-1*L - 1*Lp + 0*F + 2*D + 0*Om)
        # s = s + (-2206 + 0*T)*cos(2*L + 0*Lp + 0*F - 2*D + 1*Om) + 1*sin(2*L + 0*Lp + 0*F - 2*D + 1*Om)
        # s = s + (-199 + 0*T)*cos(1*L + 0*Lp + 0*F + 2*D + 0*Om) + 2*sin(1*L + 0*Lp + 0*F + 2*D + 0*Om)
        # s = s + (-1900 + 0*T)*cos(0*L + 1*Lp + 2*F - 2*D + 1*Om) + 1*sin(0*L + 1*Lp + 2*F - 2*D + 1*Om)
        # s = s + (-41 + 0*T)*cos(1*L - 1*Lp + 0*F + 0*D + 0*Om) + 3*sin(1*L - 1*Lp + 0*F + 0*D + 0*Om)
        # s = s + (1313 + 0*T)*cos(-2*L + 0*Lp + 2*F + 0*D + 2*Om) - 1*sin(-2*L + 0*Lp + 2*F + 0*D + 2*Om)
        # s = s + (1233 + 0*T)*cos(3*L + 0*Lp + 2*F + 0*D + 2*Om) + 7*sin(3*L + 0*Lp + 2*F + 0*D + 2*Om)
        # s = s + (-81 + 0*T)*cos(0*L - 1*Lp + 0*F + 2*D + 0*Om) + 2*sin(0*L - 1*Lp + 0*F + 2*D + 0*Om)
        # s = s + (1232 + 0*T)*cos(1*L - 1*Lp + 2*F + 0*D + 2*Om) + 4*sin(1*L - 1*Lp + 2*F + 0*D + 2*Om)
        # s = s + (-20 + 0*T)*cos(0*L + 0*Lp + 0*F + 1*D + 0*Om) - 2*sin(0*L + 0*Lp + 0*F + 1*D + 0*Om)
        # s = s + (1207 + 0*T)*cos(-1*L - 1*Lp + 2*F + 2*D + 2*Om) + 3*sin(-1*L - 1*Lp + 2*F + 2*D + 2*Om)
        # s = s + (40 + 0*T)*cos(-1*L + 0*Lp + 2*F + 0*D + 0*Om) - 2*sin(-1*L + 0*Lp + 2*F + 0*D + 0*Om)
        # s = s + (1129 + 0*T)*cos(0*L - 1*Lp + 2*F + 2*D + 2*Om) + 5*sin(0*L - 1*Lp + 2*F + 2*D + 2*Om)
        # s = s + (1266 + 0*T)*cos(-2*L + 0*Lp + 0*F + 0*D + 1*Om) - 4*sin(-2*L + 0*Lp + 0*F + 0*D + 1*Om)
        # s = s + (-1062 + 0*T)*cos(1*L + 1*Lp + 2*F + 0*D + 2*Om) - 3*sin(1*L + 1*Lp + 2*F + 0*D + 2*Om)
        # s = s + (-1129 + 0*T)*cos(2*L + 0*Lp + 0*F + 0*D + 1*Om) - 2*sin(2*L + 0*Lp + 0*F + 0*D + 1*Om)
        # s = s + (-9 + 0*T)*cos(-1*L + 1*Lp + 0*F + 1*D + 0*Om) + 0*sin(-1*L + 1*Lp + 0*F + 1*D + 0*Om)
        # s = s + (35 + 0*T)*cos(1*L + 1*Lp + 0*F + 0*D + 0*Om) - 2*sin(1*L + 1*Lp + 0*F + 0*D + 0*Om)
        # s = s + (-107 + 0*T)*cos(1*L + 0*Lp + 2*F + 0*D + 0*Om) + 1*sin(1*L + 0*Lp + 2*F + 0*D + 0*Om)
        # s = s + (1073 + 0*T)*cos(-1*L + 0*Lp + 2*F - 2*D + 1*Om) - 2*sin(-1*L + 0*Lp + 2*F - 2*D + 1*Om)
        # s = s + (854 + 0*T)*cos(1*L + 0*Lp + 0*F + 0*D + 2*Om) + 0*sin(1*L + 0*Lp + 0*F + 0*D + 2*Om)
        # s = s + (-553 + 0*T)*cos(-1*L + 0*Lp + 0*F + 1*D + 0*Om) - 139*sin(-1*L + 0*Lp + 0*F + 1*D + 0*Om)
        # s = s + (-710 + 0*T)*cos(0*L + 0*Lp + 2*F + 1*D + 2*Om) - 2*sin(0*L + 0*Lp + 2*F + 1*D + 2*Om)
        # s = s + (647 + 0*T)*cos(-1*L + 0*Lp + 2*F + 4*D + 2*Om) + 4*sin(-1*L + 0*Lp + 2*F + 4*D + 2*Om)
        # s = s + (-700 + 0*T)*cos(-1*L + 1*Lp + 0*F + 1*D + 1*Om) + 0*sin(-1*L + 1*Lp + 0*F + 1*D + 1*Om)
        # s = s + (672 + 0*T)*cos(0*L - 2*Lp + 2*F - 2*D + 1*Om) + 0*sin(0*L - 2*Lp + 2*F - 2*D + 1*Om)
        # s = s + (663 + 0*T)*cos(1*L + 0*Lp + 2*F + 2*D + 1*Om) + 4*sin(1*L + 0*Lp + 2*F + 2*D + 1*Om)
        # s = s + (-594 + 0*T)*cos(-2*L + 0*Lp + 2*F + 2*D + 2*Om) - 2*sin(-2*L + 0*Lp + 2*F + 2*D + 2*Om)
        # s = s + (-610 + 0*T)*cos(-1*L + 0*Lp + 0*F + 0*D + 2*Om) + 2*sin(-1*L + 0*Lp + 0*F + 0*D + 2*Om)
        # s = s + (-556 + 0*T)*cos(1*L + 1*Lp + 2*F - 2*D + 2*Om) + 0*sin(1*L + 1*Lp + 2*F - 2*D + 2*Om)

        # -----------------------------------------------------
        # Convert nutation in obliquity from arc sec * 10000000
        # into decimal degrees. This is the value returned by
        # the function.

        dEpsDeg = s / 36000000000.0

    # Compute mean obliquity in arc seconds.
    t1 = T/100.
    w  = 84381.448
    try:
        p = t1.copy()
    except:
        p = t1
    w -=  4680.93*p
    p *= t1
    w -= 1.55*p
    p *= t1
    w +=  1999.25*p
    p *= t1
    w -=  51.38*p
    p *= t1
    w -= 249.67*p
    p *= t1
    w -= 39.05*p
    p *= t1
    w += 7.12*p
    p *= t1
    w += 27.87*p
    p *= t1
    w += 5.79*p
    p *= t1
    w += 2.45*p
    EpsMeanDeg = w/3600.
    return dPsiDeg, dEpsDeg, EpsMeanDeg


def computeSiderealAngles(JD) :
    gamma = JD2GAST(JD)
    return gamma



def computeNutationMatrixCPP(JD):
    t_1 = (JD-2451545.0)/36525.0
    t_2 = t_1*t_1
    t_3 = t_2*t_1
    GC_arc_second_2_rad = (np.pi/(180.0*60.*60.))
    eps_a=GC_arc_second_2_rad*(84381.448-46.815*t_1-0.00059*t_2+0.001813*t_3)
    l_n= GC_arc_second_2_rad*(485866.733+1717915922.633*t_1+31.31*t_2+0.064*t_3)
    l_np=GC_arc_second_2_rad*(1287099.804+129596581.224*t_1-0.577*t_2-0.012*t_3)
    f_n= GC_arc_second_2_rad*(335778.877+1739527263.137*t_1-13.257*t_2+0.011*t_3)
    d_n= GC_arc_second_2_rad*(1072261.307+1602961601.328*t_1-6.891*t_2+0.019*t_3)
    om_n=GC_arc_second_2_rad*(450160.28-6962890.539*t_1+7.455*t_2+0.008*t_3)
    p1=-171996.0-174.2*t_1
    p2=2062.0+0.2*t_1
    p9=-13187.0-1.6*t_1
    p10=1426.0-3.4*t_1
    p11=-517.0+1.2*t_1
    p12=217.0-0.5*t_1
    p13=129.0+0.1*t_1
    p31=-2274.0-0.2*t_1
    p32=712.0+0.1*t_1
    p33=-386.0-0.4*t_1
    p34=-301.0
    p35=-158.0
    p36=123.0
    q1=92025.0+8.9*t_1
    q2=-895.0+0.5*t_1
    q9=5736.0-3.1*t_1
    q10=54.0-0.1*t_1
    q11=224.0-0.6*t_1
    q12=-95.0+0.3*t_1
    q13=-70.0
    q31=977.0-0.5*t_1
    q32=-7.0
    q33=200.0
    q34=129.0-0.1*t_1
    q35=-1.0
    q36=-53.0
    delta_psi=p1*sin(om_n)+p2*sin(2.0*om_n)+p9*sin(2.0*(f_n-d_n+om_n))\
              +p10*sin(l_np)+p11*sin(l_np+2.0*f_n-2.0*d_n+2.0*om_n)\
              +p12*sin(-l_np+2.0*f_n-2.0*d_n+2.0*om_n)+p13*sin(2.0*f_n-2.0*d_n+om_n)\
              +p31*sin(2.0*f_n+2.0*om_n)+p32*sin(l_n)+p33*sin(2.0*f_n+om_n)+\
              p34*sin(l_n+2.0*f_n+2.0*om_n)+p35*sin(l_n-2.0*d_n)+\
              p36*sin(-l_n+2.0*f_n+2.0*om_n)
    delta_eps=q1*cos(om_n)+q2*cos(2.0*om_n)+q9*cos(2.0*(f_n-d_n+om_n))\
              +q10*cos(l_np)+q11*cos(l_np+2.0*f_n-2.0*d_n+2.0*om_n)\
              +q12*cos(-l_np+2.0*f_n-2.0*d_n+2.0*om_n)+q13*cos(2.0*f_n-2.0*d_n+om_n)\
              +q31*cos(2.0*f_n+2.0*om_n)+q32*cos(l_n)+q33*cos(2.0*f_n+om_n)+\
              q34*cos(l_n+2.0*f_n+2.0*om_n)+q35*cos(l_n-2.0*d_n)+\
              q36*cos(-l_n+2.0*f_n+2.0*om_n)
    delta_psi=delta_psi*GC_arc_second_2_rad*0.0001
    delta_eps=delta_eps*GC_arc_second_2_rad*0.0001
    sin_ep=sin(eps_a)
    cos_ep=cos(eps_a)
    #print delta_psi, cos_ep
    m_nutation = np.array([[1.0-0.5*delta_psi*delta_psi,-delta_psi*cos_ep,-delta_psi*sin_ep], \
                           [delta_psi*cos_ep-delta_eps*delta_psi*sin_ep,1.0-0.5*delta_eps*delta_eps-0.5*delta_psi*delta_psi*cos_ep*cos_ep, \
                            -delta_eps-0.5*delta_psi*delta_psi*sin_ep*cos_ep],
                           [delta_psi*sin_ep+delta_eps*delta_psi*cos_ep,delta_eps-0.5*delta_psi*delta_psi*sin_ep*cos_ep,\
                            1.0-0.5*delta_eps*delta_eps-0.5*delta_psi*delta_psi*sin_ep*sin_ep]])
    return m_nutation.astype('float32'), delta_psi,cos_ep

def computeSideRealMatrixCPP(JD,d_ut1,delta_psi,cos_ep):
    # print JD
    # GC_swtwopi = np.pi*2
    ## JD = JD +d_ut1/86400.00
    # t_1 = (JD-2451545.0)/36525.0
    # t_2 = t_1*t_1
    # t_3 = t_2*t_1
    # JDmin = np.floor(JD)-.5
    # JDmax = np.floor(JD)+.5
    # if (JD > JDmin) :
    #     JD0 = JDmin
    # if (JD > JDmax):
    #     JD0 = JDmax
    # hour = (JD-JD0)*24 #       %Time in hours past previous midnight
    # ut_0= hour*3600.
    # #d_ut1 = 0.5
    # utc = ut_0%(24.*3600.)
    # ut1 = (ut_0+d_ut1)
    # print ut1
    # delta_h = np.arctan(cos_ep*np.tan(delta_psi))
    # wt = 0#(0.7790572732640 + 1.00273781191135448*(JD+d_ut1/86400.))
    # t_sid=  ut1 + 24110.54841+8640184.812866*t_1+0.093104*t_2-0.0000062*t_3
    # #print ut_0
    #
    # #print "DTUT1",  d_ut1
    # #print 24110.54841+8640184.812866*t_1+0.093104*t_2-0.0000062*t_3
    # #print t_sid%(60.*60.*24)
    # t_sid = t_sid*GC_swtwopi/86400.0+delta_h +wt #delta_psi*cos_ep;
    # t_sid2 = t_sid%(2.*np.pi)
    # t_sid2 =t_sid2*86400.0/(2*np.pi)
    # hour = int(t_sid2/(3600))
    # mins = int((t_sid2-hour*3600)/(60))
    # sec = t_sid2%60
    # print "h:%f, m:%f, sec:%f "%(hour,mins,sec)
    #t_sid = (t_sid%GC_swtwopi)
    JD = JD +d_ut1/86400.00
    if np.isscalar(JD):
        siderealAngle = computeSiderealAngles(JD)*np.pi/180.0
        delta_h = np.arctan(cos_ep*np.tan(delta_psi))
        siderealAngle += delta_h
        t_sid = siderealAngle
        T = np.zeros((3,3))
        T[0,0] = cos(t_sid)
        T[0,1] = sin(t_sid)
        T[1,0] = -T[0,1]
        T[1,1] = T[0,0]
        T[2,2] = 1.0
        return T.astype('float32')
    else:
        num = JD.shape[0]
        siderealAngle = computeSiderealAngles(JD)*np.pi/180.0
        delta_h = np.arctan(cos_ep*np.tan(delta_psi))
        siderealAngle += delta_h
        t_sid = siderealAngle

        T = np.zeros((3,3,num))
        T[0,0,:] = cos(t_sid)
        T[0,1,:] = sin(t_sid)
        T[1,0,:] = -T[0,1,:]
        T[1,1,:] = T[0,0,:]
        T[2,2,:] = 1.0
        return T.astype('float64')





def computePrecessionMatrix(JD):
    zeta, z, theta = computePrecessionAngles(JD)
    z = z
    zeta = zeta
    theta = theta
    D = np.array([[cosd(z)*cosd(theta)*cosd(zeta)-sind(z)*sind(zeta), -cosd(z)*cosd(theta)*sind(zeta)-sind(z)*cosd(zeta),\
                  -cosd(z)*sind(theta)],\
                 [sind(z)*cosd(theta)*cosd(zeta)+cosd(z)*sind(zeta), -sind(z)*cosd(theta)*sind(zeta)+cosd(z)*cosd(zeta),\
                  -sind(z)*sind(theta)],\
                 [sind(theta)*cosd(zeta), -sind(theta)*sind(zeta), \
                  cosd(theta)]])
    return D.astype('float64')

def computeNutationMatrix(JD,dPsi,depsi, epsi_bar ) :
    #dPsi = computeNutitionLogitude(JD)
    #depsi, epsi_bar = computeCNutationObliquity(JD)
    #dPsi,depsi, epsi_bar = comNutation2000BLongitude(JD)

    epsi = depsi + epsi_bar
    #print dPsi

    C = np.array([[cosd(dPsi), -sind(dPsi)*cosd(epsi_bar), -sind(dPsi)*sind(epsi_bar)],\
                 [cosd(epsi)*sind(dPsi), cosd(epsi)*cosd(dPsi)*cosd(epsi_bar)+sind(epsi)*sind(epsi_bar),\
                  cosd(epsi)*cosd(dPsi)*sind(epsi_bar)-sind(epsi)*cosd(epsi_bar)],\
                  [sind(epsi)*sind(dPsi), sind(epsi)*cosd(dPsi)*cosd(epsi_bar)-cosd(epsi)*sind(epsi_bar),\
                  sind(epsi)*cosd(dPsi)*sind(epsi_bar)+cosd(epsi)*cosd(epsi_bar)]])
    return C

def computeSiderealMatrix(JD) :
    gamma = computeSiderealAngles(JD)
    #print gamma
    B= np.array([[cosd(gamma), sind(gamma), 0],[-sind(gamma),cosd(gamma), 0],[0,0,1]])
    return B

def ECItoECEF(JD,r_ECI,dut1) :
    #Calculate the Greenwich Apparent Sideral Time (THETA)
    #See http://www.cdeagle.com/omnum/pdf/csystems.pdf equation 27
    #THETA = JD2GAST(JD)
    #Average inertial rotation rate of the earth radians per second
    #omega_e = 7.29211585275553e-005
    #Assemble the transformation matricies to go from ECI to ECEF
    #See htt    p://www.cdeagle.com/omnum/pdf/csystems.pdf equation 26
    #print T3D(THETA)

    #nt = nutationConst.nutation2000b(JD)
    #D = nt.getprecsssionMatrix()#
    D=  computePrecessionMatrix(JD)
    #C,d_phi, cos_eps = computeNutationMatrixCPP(JD)

    d_phi, d_esp, esp_bar = comNutation2000BLongitude(JD)
    C = computeNutationMatrix(JD,d_phi, d_esp, esp_bar )
    #C = nt.getNulMat()
    #print d_phi
    ts = time.time()
    d_phi = d_phi*np.pi/180.
    cos_eps = cosd(esp_bar)
    #dut1 = -459.9090/1000.0
    B = computeSideRealMatrixCPP(JD,dut1 ,d_phi,cos_eps)
    if B.ndim == 2:
        C = C.reshape((3,3))
        D  = D.reshape((3,3))
        #r_ECI = r_ECI.reshape((3,1))
        X = np.dot(B,C)
        X = np.dot(X,D)
        r_ECEF = np.dot(X,r_ECI)

    else:

        r_ECEF =np.zeros_like(r_ECI)
        r_ECIT = r_ECI.T
        r_ECEF[:,0] = (r_ECIT*D[0,:,:]).sum(0)
        r_ECEF[:,1] = (r_ECIT*D[1,:,:]).sum(0)
        r_ECEF[:,2] = (r_ECIT*D[2,:,:]).sum(0)
        r_ECIT = r_ECEF.T.copy()
        r_ECEF[:,0] = (r_ECIT*C[0,:,:]).sum(0)
        r_ECEF[:,1] = (r_ECIT*C[1,:,:]).sum(0)
        r_ECEF[:,2] = (r_ECIT*C[2,:,:]).sum(0)
        r_ECIT = r_ECEF.T.copy()
        r_ECEF[:,0] = (r_ECIT*B[0,:,:]).sum(0)
        r_ECEF[:,1] = (r_ECIT*B[1,:,:]).sum(0)
        r_ECEF[:,2] = (r_ECIT*B[2,:,:]).sum(0)

    return r_ECEF#, v_ECEF, a_ECEF




def findEarthSurfacePosition(uecef,lense_position):
    a = 6378137.0
    f = 1./298.257223563
    b = a*(1-f)
    ux = uecef[0]
    uy = uecef[1]
    uz = uecef[2]
    XL = lense_position[0]
    YL = lense_position[1]
    ZL = lense_position[2]
    t1 = (ux**2+uy**2)/(a**2) + (uz**2)/(b**2)
    t2 = 2.*((ux*XL+uy*YL)/(a**2)+uz*ZL/(b**2))
    t3 = (XL**2+YL**2)/(a**2) + (ZL**2)/(b**2)- 1.0
    #print t1, t2, t3
    term1 = np.sqrt(t2**2-4*t1*t3)
    root1 = (-t2+term1)/(2*t1)
    root2 = (-t2-term1)/(2*t1)
    mumin = root1*(root1<=root2) +root2*(root1>root2)
    #mu = np.roots([t1,t2,t3])
    #mumin = min(mu)
    XA = XL + mumin*ux
    YA = YL + mumin*uy
    ZA = ZL + mumin*uz
    earth_surface_position = [XA, YA, ZA]
    return earth_surface_position

def itrf2latlon(itrf_post) :
    XA  = itrf_post[0]
    YA  = itrf_post[1]
    ZA  = itrf_post[2]
    a = 6378137.
    f = 1./298.257223563
    b = a*(1-f)
    e = np.sqrt((a**2-b**2)/(a**2))
    e2 = np.sqrt((a**2-b**2)/(b**2))
    p = np.sqrt((XA**2)+(YA**2))
    theta = np.arctan2((ZA * a),(p * b))
    lon = np.arctan2(YA, XA )
    lat = np.arctan2(ZA + (e2**2) * b * (np.sin(theta)**3), p - (e**2) * a * (np.cos(theta)**3))
    N = a / (np.sqrt(1 - ((e**2) * (np.sin(lat)**2))))
    m = (p / np.cos(lat))
    height = m - N
    lon = lon * 180.0 / np.pi
    lat = lat * 180.0 / np.pi
    return lat, lon, height

def findViewingLocationLatLong(uecef,lense_position,height=0):
    """

    :param uecef:
    :param lense_position:
    :param height:
    :return:
    """
    a = 6378137.0
    f = 1./298.257223563
    b = a*(1-f)
    a += height
    b += height
    ux = uecef[0]
    uy = uecef[1]
    uz = uecef[2]
    XL = lense_position[0]
    YL = lense_position[1]
    ZL = lense_position[2]
    t1 = (ux**2+uy**2)/(a**2) + (uz**2)/(b**2)
    t2 = 2.*((ux*XL+uy*YL)/(a**2)+uz*ZL/(b**2))
    t3 = (XL**2+YL**2)/(a**2) + (ZL**2)/(b**2)- 1.0
    #print t1, t2, t3
    term1 = np.sqrt(t2**2-4*t1*t3)
    root1 = (-t2+term1)/(2*t1)
    root2 = (-t2-term1)/(2*t1)
    mumin = root1*(root1<=root2) +root2*(root1>root2)
    #mu = np.roots([t1,t2,t3])
    #mumin = min(mu)
    XA = XL + mumin*ux
    YA = YL + mumin*uy
    ZA = ZL + mumin*uz
    earth_surface_position = [XA, YA, ZA]
    lat,lon,h = itrf2latlon(earth_surface_position)
    return lat,lon,h

def latlon2itrf(lat,lon,h):
    lat = lat*np.pi/180.0
    lon = lon*np.pi/180.0
    a = 6378137.
    f = 1./298.257223563
    b = a*(1-f)
    e = np.sqrt((a**2-b**2)/(a**2))
    e2 = e**2
    sin2 = np.sin(lat)**2
    u = a/np.sqrt(1-e2*sin2)
    uh = u + h
    XA = uh*np.cos(lat)*np.cos(lon)
    YA = uh*np.cos(lat)*np.sin(lon)
    ZA  = ((1-e2)*u+h)*np.sin(lat)
    return XA, YA, ZA
def irf2latlonV2(itrf_post) :
    b = 6356.75231424*1000.0
    e2 =0.00669437999013
    a =6378.137*1000.0
    #e2 = np.sqrt((a**2-b**2)/(b**2))
    dor =57.29577951
    ep2= e2/(1.0-e2)
    aob=a/b
    XA  = itrf_post[0]
    YA  = itrf_post[1]
    ZA  = itrf_post[2]
    p=np.sqrt(XA*XA+YA*YA)
    theta=  np.arctan2(ZA*aob,p)
    sin_th=np.sin(theta)
    cos_th=np.cos(theta)
    sin_th3=sin_th*sin_th*sin_th
    cos_th3=cos_th*cos_th*cos_th
    lat_rad=np.arctan((ZA+ep2*b*sin_th3)/(p-e2*a*cos_th3))
    lon_rad=np.arctan2(YA,XA)
    sin_lat= np.sin(lat_rad)
    cos_lat= np.cos(lat_rad)
    radius= a/(np.sqrt(1.0-e2*sin_lat*sin_lat))
    altitude =p/cos_lat-radius
    longitude=lon_rad*dor
    longitude=longitude%360.0
    if longitude  >180 :
        longitude =longitude -360
    if longitude < -180 :
        longitude =longitude +360
    latitude=lat_rad*dor
    return latitude, longitude, altitude


''

def computeUECEF(JD,dut1,sample, quarternion,band):
    if band == "PAN":
        roll =  7.77619784614573e-04
        pitch = -3.96157545487306e-04
        yaw = 1.09478530648895e-04
    else:
        roll =  6.5991209596211403e-04
        pitch = -8.30730280198418e-04
        yaw = 2.60531951646004e-06
    # Band 1

    if band == 1:
        XLOS =np.array( [-5.64386773737977e+01,1.87603440114033e-02 ,2.51482470613764e-08  ,\
                         -2.81072936768217e-12 ],'float64')/1000.0
        YLOS = np.array( [2.08358226050628e+00, 2.74118683409263e-07 ,1.94869621248422e-10,\
                          -3.14863243948727e-14],'float64')/1000.0
    elif band ==2 :
        # Band 2
        XLOS =np.array( [-5.64399703561670e+01 ,1.87596208982883e-02 ,2.55950408827066e-08 ,\
                         -2.85793462006183e-12 ],'float64')/1000.0
        YLOS = np.array( [1.04002614769951e+00,1.59963514942009e-06 ,-3.56440483618224e-10,\
                           2.85698030634138e-14],'float64')/1000.0
    elif band == 3:
        # Band 3
        XLOS =np.array( [-5.64396406090353e+01,1.87584774628217e-02, 2.59609656739278e-08 ,\
                         -2.88457756116942e-12],'float64')/1000.0
        YLOS = np.array( [-2.25648281796593e-03, 8.18103975700301e-07 , -6.02722977568500e-11,\
                          -2.10578363971240e-15],'float64')/1000.0

    elif band == 4:
        #Band 4
        XLOS =np.array( [-5.64386179785625e+01,1.87524124587818e-02, 2.78767164745339e-08  ,\
                         -3.03848934201707e-12],'float64')/1000.0
        YLOS = np.array( [-1.04660771241013e+00, 3.05951163818994e-07 , 5.60667858453505e-10,\
                          -9.70686921049864e-14],'float64')/1000.0
    elif band == "PAN":
        XLOS =np.array( [-1.34103048970642e+01,2.22032090570242e-03, 3.58240556977001e-09 ,\
                         -1.97809568473004e-13],'float64')/1000.0
        YLOS = np.array( [-2.75975559329229e-03 , 1.71820520179567e-06 , -2.02116761813481e-10,\
                          5.05505016712029e-15],'float64')/1000.0

    #s = float(sample)
    if isinstance(sample,np.ndarray):
        s = sample.astype('float64')
    elif isinstance(sample, int ) :
        s = float(sample)
    else:
        s = sample

    phi_x = XLOS[0]+ XLOS[1]*s + XLOS[2]*(s**2) + XLOS[3]*(s**3)
    phi_y = YLOS[0]+ YLOS[1]*s + YLOS[2]*(s**2) + YLOS[3]*(s**3)
    u0 = np.tan(phi_y)
    u1 = -np.tan(phi_x)
    u2 = np.ones_like(s)
    u = np.vstack((u0,u1,u2))

    #u = np.array([np.tan(phi_y), -np.tan(phi_x), 1.0 ])
    #u = u /np.linalg.norm(u)

    Rroll = np.array([[1,0,0],\
             [0, np.cos(roll),-np.sin(roll)],\
             [0,np.sin(roll),np.cos(roll)]],'float64')

    Rpitch = np.array([[np.cos(pitch),0,np.sin(pitch)],\
                       [0,1,0],\
                       [-np.sin(pitch),0,np.cos(pitch)]],'float64')
    Ryaw = np.array([[np.cos(yaw),-np.sin(yaw),0],\
                     [np.sin(yaw),np.cos(yaw),0],\
                     [0,0,1]],'float64')
    Rb = np.dot(np.dot(Ryaw,Rpitch),Rroll)
    ursat = np.dot(Rb,u)

    if quarternion.ndim > 1:
        num,dim = quarternion.shape
        qnorm = np.linalg.norm(quarternion,axis=1).reshape(num,1)
        quarternion = quarternion/qnorm
        q0 = quarternion[:,0]
        q1 = quarternion[:,1]
        q2 = quarternion[:,2]
        q3 = quarternion[:,3]
        ueci = np.zeros((num,3),'float64')
        Rq1 = np.array([1.-2*(q2**2+q3**2)   , 2*(q2*q1-q0*q3)   , 2*(q1*q3+q0*q2)])

        ueci[:,0] = (Rq1*ursat).sum(0)

        Rq2 = np.array([2*(q2*q1+q0*q3)     , 1.-2*(q1**2+q3**2) , 2*(q2*q3-q0*q1)])
        ueci[:,1] = (Rq2*ursat).sum(0)

        Rq3 = np.array([2*(q1*q3-q0*q2)     ,2*(q2*q3+q0*q1)    , 1.-2*(q1**2+q2**2)])
        ueci[:,2] = (Rq3*ursat).sum(0)

        uecef =  ECItoECEF(JD,ueci,dut1)



    else:

        quarternion = quarternion/np.linalg.norm(quarternion)
        q0 = quarternion[0]
        q1 = quarternion[1]
        q2 = quarternion[2]
        q3 = quarternion[3]

        Rq = np.array([[ 1.-2*(q2**2+q3**2)   , 2*(q2*q1-q0*q3)   , 2*(q1*q3+q0*q2) ],\
                      [ 2*(q2*q1+q0*q3)     , 1.-2*(q1**2+q3**2) , 2*(q2*q3-q0*q1) ],\
                      [ 2*(q1*q3-q0*q2)     ,2*(q2*q3+q0*q1)    , 1.-2*(q1**2+q2**2)]])

        ueci = np.dot(Rq,ursat)
        uecef =  ECItoECEF(JD,ueci,dut1)

    return uecef

def estimageLensePostion(P, T,tk):
    pout = 0.0
    for j in range(8) :
        t_fac = 1.0
        for i in range(8):
            if (i != j) :
                t_fac *= (tk-T[i])/(T[j]-T[i])
        pout += P[j]*t_fac
    return pout

def computeViewLatLongFingGrid(band,pixel,sat_position, sat_attitude, year,month,day,hour, mins,sec,microsec,utc_gps,dut1,dem_directory) :

    tt = dutil.datetime(year, month, day,hour, mins,sec,microsec)
    JD = tt.to_jd() + utc_gps/(24*60.*60.) #determine julian time from the utc time

    uecef1 = computeUECEF(JD,dut1,pixel,sat_attitude,band) # look direction
    look_u = uecef1.flatten()
    earth_post = findEarthSurfacePosition(uecef1,sat_position) # look position without elevation
    latint, lonint, heightint = itrf2latlon(earth_post) #initial latitude and longitude

    lat11 = int(latint)
    lon11 = int(lonint)
    #load 9x9 DEMs around the lat & lon of interest
    dem_file_array2D = []
    dem2D = []
    geotrans2D = []
    for k in range(-1,2):
        dem_file_array = []
        dem1D = []
        geotrans1D = []
        for m in range(-1,2):

            lat = lat11 +k
            lon = lon11+ m
            #print "lat,lon", lat, lon
            if (lat >=0) &( lon >= 0) :
                dem_file = dem_directory + "/n%02de%03d.bil"%(lat,lon)
                #dem_file01 = dem_directory + "n%02de%03d.bil"%(lat,lon)
            elif (lat>0) & (lon<0) :
                dem_file = dem_directory + "/n%02dw%03d.bil"%(lat,-lon)
            elif (lat<0) & (lon>=0):
                dem_file = dem_directory + "/s%02de%03d.bil"%(-lat,lon)
            else:
                dem_file = dem_directory + "/s%02dw%03d.bil"%(-lat,-lon)
            dem_file_array.append(dem_file)
            dem = gdal.Open(dem_file)
            dem1D.append(dem)
            geotrans = dem.GetGeoTransform()
            geotrans1D.append(geotrans)
        dem_file_array2D.append(dem_file_array)
        dem2D.append(dem1D)
        geotrans2D.append(geotrans1D)
    lat_sec = latint*3600.
    lon_sec = lonint*3600.
    #dem = gdal.Open(dem_file)

    #Load the rectangular grids of size NxN round the corresponding pixels
    N = 40 #block size 40x40
    N2= N/2
    dem_width = dem2D[0][0].RasterXSize
    dem_height = dem2D[0][0].RasterYSize

    # load dem, latitude and longitude from dem files
    dem_data2D = []
    latpos2D = []
    lonpos2D = []

    for k in range(0,3):
        one_rowh = []
        one_rowx = []
        one_rowy = []
        for m in range(0,3):
            geotrans = geotrans2D[k][m]
            x = (lon_sec-geotrans[0])/geotrans[1]
            y = (lat_sec-geotrans[3])/geotrans[5]

            #print x,y
            x = int(np.floor(x))
            y = int(np.floor(y))
            if (k==1) & (m==1):
                print "initial block is (%d,%d)"%(x,y)
            xmin= x-N2
            xmax = xmin+N
            ymin = y-N2
            ymax = ymin+N

            if (xmin>-N2) & (ymin>-N2) & (xmin <dem_width) & (ymin <dem_height) : # ovelapped
                xmin = max(xmin,0)
                ymin = max(ymin,0)
                width = min(dem_width-xmin,xmax-xmin)
                height = min(dem_height-ymin,ymax-ymin)
                data = dem2D[k][m].ReadAsArray(xmin,ymin,width,height)
                xa = geotrans[0] + geotrans[1]*np.arange(xmin,xmin+width)
                ya = geotrans[3] + geotrans[5]*np.arange(ymin,ymin+height)
                xa = xa.flatten()/3600.
                ya = ya.flatten()/3600.
                xmesh =np.meshgrid(ya,xa)
                ya = xmesh[0]
                xa = xmesh[1]
                if len(one_rowh) == 0:
                    one_rowh = data
                    one_rowx = xa
                    one_rowy = ya

                else:
                    one_rowh = np.hstack((one_rowh,data))
                    one_rowx = np.hstack((one_rowx,xa))
                    one_rowy = np.hstack(one_rowy,ya)
        if (len(dem_data2D) == 0) & (len(one_rowh)>0):
            dem_data2D = one_rowh
            latpos2D = one_rowy
            lonpos2D = one_rowx
        elif len(one_rowh)>0:
            dem_data2D = np.vstack((dem_data2D,one_rowh))
            latpos2D = np.vstack((latpos2D,one_rowy))
            lonpos2D = np.vstack((lonpos2D,one_rowx))
    h =  dem_data2D.flatten()
    lona = lonpos2D.flatten()
    lata = latpos2D.flatten()
    # convert to ECEF coordinates
    x,y,z = latlon2itrf(lata,lona,h)
    ground_pos = np.vstack((x,y,z)).T
    # Make it an array of NxNx3
    postion_grid =ground_pos.reshape(N,N,3)
    rw,cl,bd  = postion_grid.shape
    rw_grids = np.arange(rw-1)
    cl_grids = np.arange(cl-1)
    rw_g,cl_g = np.meshgrid(rw_grids,cl_grids)
    rw_g = rw_g.flatten()
    cl_g = cl_g.flatten()
    # find the referenced points of the triangles
    p_ref1 = postion_grid[rw_g,cl_g,:] #upper left
    p_ref2 = postion_grid[rw_g+1,cl_g+1,:] #lower right
    # find the plane vectors
    vec11 = postion_grid[rw_g+1,cl_g,:]-p_ref1
    vec12 = postion_grid[rw_g,cl_g+1,:]-p_ref1
    n1 = np.cross(vec11,vec12)

    vec21 = postion_grid[rw_g+1,cl_g,:]-p_ref2
    vec22 = postion_grid[rw_g,cl_g+1,:]-p_ref2
    n2 = np.cross(vec21,vec22)
    d1 = np.diag(np.dot(p_ref1-sat_position,n1.T))/np.dot(look_u,n1.T)
    d2 = np.diag(np.dot(p_ref2-sat_position,n2.T))/np.dot(look_u,n2.T)
    P = []
    for d in d1:
        P.append(sat_position+d*look_u)
    for d in d2:
        P.append(sat_position+d*look_u)
    P = np.array(P)
    p_ref = np.vstack((p_ref1,p_ref2))
    # vec1 = np.vstack((postion_grid[rw_g+1,cl_g,:], postion_grid[rw_g+1,cl_g,:]))
    # vec2 = np.vstack((postion_grid[rw_g,cl_g+1,:], postion_grid[rw_g,cl_g+1,:]))
    # vec3 = np.vstack((postion_grid[rw_g,cl_g,:], postion_grid[rw_g+1,cl_g+1,:]))
    # p = P-p_ref
    # dis = np.sqrt((p**2).sum(1))
    # indexes = np.argsort(dis)
    # for id in indexes:
    #     v1 = vec1[id]
    #     v2 = vec2[id]
    #     v3 = vec3[id]
    #     p = P[id]
    #     A = np.vstack((v1,v2,v3)).T
    #     par = np.linalg.lstsq(A,p)
    #     a = par[0][0]
    #     b = par[0][1]
    #     c = par[0][2]
    #     if (a>=0) & (b>=0) &(c >=0) & (a+b+c <=1):
    #         break

    vec1 = np.vstack((vec11,vec21))
    vec2 = np.vstack((vec12,vec22))
    p = P-p_ref
    dis = np.sqrt((p**2).sum(1))
    indexes = np.argsort(dis)
    #print dis[idx[:5]]
    for id in indexes:
        v1 = vec1[id]
        v2 = vec2[id]
        pr = p_ref[id]
        p = P[id]
        dif = p-pr
        A = np.vstack((v1,v2)).T
        par = np.linalg.lstsq(A,dif)
        a = par[0][0]
        b = par[0][1]
        if (a>=0) & (a<1) &(b>=0) &(b<1) & (a+b <=1):
            break
    #print p
    lat,lon,h = itrf2latlon(p)
    #print lat,lon,h
    geotrans = geotrans2D[1][1]
    x = (lon*3600.-geotrans[0])/geotrans[1]
    y = (lat*3600-geotrans[3])/geotrans[5]
    x = int(np.floor(x))
    y = int(np.floor(y))
    print "resulting block is (%d,%d)"%(x,y)


    return lat,lon,h

def computeViewLatLong(band,pixel,sat_position, sat_attitude, year,month,day,hour, mins,sec,microsec,utc_gps,dut1,dem_directory) :
    # def load_dem_file(lat,lon,dem_directory):
    #     lat = int(lat)
    #     lon = int(lon)
    #     if (lat >=0) &( lon >= 0) :
    #         dem_file = dem_directory + "/n%02de%03d.bil"%(lat,lon)
    #         #dem_file01 = dem_directory + "n%02de%03d.bil"%(lat,lon)
    #     elif (lat>0) & (lon<0) :
    #         dem_file = dem_directory + "/n%02dw%03d.bil"%(lat,-lon)
    #     elif (lat<0) & (lon>=0):
    #         dem_file = dem_directory + "/s%02de%03d.bil"%(-lat,lon)
    #     else:
    #         dem_file = dem_directory + "/s%02dw%03d.bil"%(-lat,-lon)
    #     dem = gdal.Open(dem_file)
    #     return dem
    #
    # def load_dem_data(upleft,lowright,dem_dir) :
    #     lat_int_min = int(np.floor(upleft[0]))
    #     lon__int_min = int(np.floor(upleft[1]))
    #     lat_int_max = int(np.floor(lowright[0]))
    #     lon_int_max = int(np.floor(lowright[1]))
    #     latsec_min = upleft[0]*3600.
    #     lonsec_min = upleft[1]*3600.
    #     latsec_max = lowright[0]*3600.
    #     lonsec_max = lowright[1]*3600.
    #     #load DEM file
    #     dem = load_dem_file(lat_int_max,lon__int_min,dem_dir)
    #     dem_geo = dem.GetGeoTransform()
    #     xorg = dem_geo[0]
    #     yorg = dem_geo[3]
    #     xstep = dem_geo[1]
    #     ystep = dem_geo[5]
    #     latsec_min = int((upleft[0]*3600.-yorg)/ystep)*ystep +yorg
    #     lonsec_min = int((upleft[1]*3600.-xorg)/xstep)*xstep + xorg
    #     latsec_max = int((lowright[0]*3600.-yorg)/ystep)*ystep +yorg
    #     lonsec_max = int((lowright[1]*3600.-xorg)/xstep)*xstep +xorg
    #
    #     x_size = int((lowright[1]-upleft[1])*3600./xstep)
    #     y_size = int((lowright[0]-upleft[0])*3600./ystep)
    #     lat_grid = np.zeros((y_size,x_size),'float64')
    #     lon_grid = np.zeros((y_size,x_size),'float64')
    #     h_grid   = np.zeros((y_size,x_size),'float64')
    #     for lat in range(lat_int_min,lat_int_max-1,-1):
    #         for lon in range(lon__int_min,lon_int_max+1) :
    #             dem = load_dem_file(lat,lon,dem_dir)
    #             dem_x_size = dem.RasterXSize
    #             dem_y_size = dem.RasterYSize
    #             dem_geo = dem.GetGeoTransform()
    #             x_min_dem = int((dem_geo[0]-lonsec_min)/xstep)
    #             y_min_dem = int((dem_geo[3]-latsec_min)/ystep)
    #             x_max_dem = x_min_dem +dem_x_size
    #             y_max_dem = y_min_dem+dem_y_size
    #             x_min = max(x_min_dem,0)
    #             y_min = max(y_min_dem,0)
    #             x_max = min(x_max_dem,x_size)
    #             y_max = min(y_max_dem,y_size)
    #             x_min_dem = x_min-x_min_dem
    #             y_min_dem = y_min -y_min_dem
    #             lon_a = dem_geo[0]+np.arange(x_min_dem,x_min_dem+x_max-x_min)*xstep
    #             lat_a = dem_geo[3]+np.arange(y_min_dem,y_min_dem+y_max-y_min)*ystep
    #             lon_temp,lat_temp = np.meshgrid(lon_a,lat_a)
    #             lat_grid[y_min:y_max,x_min:x_max] = lat_temp
    #             lon_grid[y_min:y_max,x_min:x_max] = lon_temp
    #             h_grid[y_min:y_max,x_min:x_max] = dem.ReadAsArray(x_min_dem,y_min_dem,x_max-x_min,y_max-y_min)
    #     lat_grid = lat_grid/3600.
    #     lon_grid = lon_grid/3600.
    #     h_grid = h_grid*(h_grid>-32767)
    #     return lat_grid,lon_grid,h_grid

    tt = dutil.datetime(year, month, day,hour, mins,sec,microsec)
    JD = tt.to_jd() + utc_gps/(24*60.*60.) #determine julian time from the utc time
    temp = load_dem_file(13,90,dem_directory)
    geot = temp.GetGeoTransform()
    pixel_size = geot[1]/3600.

    uecef1 = computeUECEF(JD,dut1,pixel,sat_attitude,band) # look direction
    look_u = uecef1.flatten()
    earth_post = findEarthSurfacePosition(uecef1,sat_position) # look position without elevation
    latint, lonint, heightint = itrf2latlon(earth_post) #initial latitude and longitude
    lat_min = latint[0] - 20.*pixel_size
    lat_max = latint[0] + 20.*pixel_size
    lon_min = lonint[0] - 20.*pixel_size
    lon_max = lonint[0] + 20.*pixel_size
    lat_grid,lon_grid,h_grid =  load_dem_data([lat_max,lon_min],[lat_min,lon_max],dem_directory)
    y_size,x_size = lat_grid.shape
    lat_grid = lat_grid.flatten()
    lon_grid = lon_grid.flatten()
    h_grid = h_grid.flatten()
    x,y,z = latlon2itrf(lat_grid,lon_grid,h_grid)
    ground_pos = np.vstack((x,y,z)).T
    # Make it an array of NxNx3
    postion_grid =ground_pos.reshape(y_size,x_size,3)
    rw,cl,bd  = postion_grid.shape
    rw_grids = np.arange(rw-1)
    cl_grids = np.arange(cl-1)
    rw_g,cl_g = np.meshgrid(rw_grids,cl_grids)
    rw_g = rw_g.flatten()
    cl_g = cl_g.flatten()
    # find the referenced points of the triangles
    p_ref1 = postion_grid[rw_g,cl_g,:] #upper left
    p_ref2 = postion_grid[rw_g+1,cl_g+1,:] #lower right
    # find the plane vectors
    vec11 = postion_grid[rw_g+1,cl_g,:]-p_ref1
    vec12 = postion_grid[rw_g,cl_g+1,:]-p_ref1
    n1 = np.cross(vec11,vec12)

    vec21 = postion_grid[rw_g+1,cl_g,:]-p_ref2
    vec22 = postion_grid[rw_g,cl_g+1,:]-p_ref2
    n2 = np.cross(vec21,vec22)
    d1 = np.diag(np.dot(p_ref1-sat_position,n1.T))/np.dot(look_u,n1.T)
    d2 = np.diag(np.dot(p_ref2-sat_position,n2.T))/np.dot(look_u,n2.T)
    P = []
    for d in d1:
        P.append(sat_position+d*look_u)
    for d in d2:
        P.append(sat_position+d*look_u)
    P = np.array(P)
    p_ref = np.vstack((p_ref1,p_ref2))
    vec1 = np.vstack((vec11,vec21))
    vec2 = np.vstack((vec12,vec22))
    p = P-p_ref
    dis = np.sqrt((p**2).sum(1))
    indexes = np.argsort(dis)
    #print dis[idx[:5]]
    for id in indexes:
        v1 = vec1[id]
        v2 = vec2[id]
        pr = p_ref[id]
        p = P[id]
        dif = p-pr
        A = np.vstack((v1,v2)).T
        par = np.linalg.lstsq(A,dif)
        a = par[0][0]
        b = par[0][1]
        if (a>=0) & (a<1) &(b>=0) &(b<1) & (a+b <=1):
            print a,b
            break
    #print p
    lat,lon,h = itrf2latlon(p)
    return lat,lon,h
## Array Version

def computeViewLatLongArray(band,pixel_array,sat_position, sat_attitude, year,month,day,hour, mins,sec,microsec,utc_gps,dut1,dem_directory) :
    def load_dem_file(lat,lon,dem_directory):
        lat = int(lat)
        lon = int(lon)
        if (lat >=0) &( lon >= 0) :
            dem_file = dem_directory + "/n%02de%03d.bil"%(lat,lon)
            #dem_file01 = dem_directory + "n%02de%03d.bil"%(lat,lon)
        elif (lat>0) & (lon<0) :
            dem_file = dem_directory + "/n%02dw%03d.bil"%(lat,-lon)
        elif (lat<0) & (lon>=0):
            dem_file = dem_directory + "/s%02de%03d.bil"%(-lat,lon)
        else:
            dem_file = dem_directory + "/s%02dw%03d.bil"%(-lat,-lon)
        dem = gdal.Open(dem_file)
        return dem

    def load_dem_data(upleft,lowright,dem_dir) :
        lat_int_min = int(np.floor(upleft[0]))
        lon__int_min = int(np.floor(upleft[1]))
        lat_int_max = int(np.floor(lowright[0]))
        lon_int_max = int(np.floor(lowright[1]))
        latsec_min = upleft[0]*3600.
        lonsec_min = upleft[1]*3600.
        latsec_max = lowright[0]*3600.
        lonsec_max = lowright[1]*3600.
        #load DEM file
        dem = load_dem_file(lat_int_max,lon__int_min,dem_dir)
        dem_geo = dem.GetGeoTransform()
        xorg = dem_geo[0]
        yorg = dem_geo[3]
        xstep = dem_geo[1]
        ystep = dem_geo[5]
        latsec_min = int((upleft[0]*3600.-yorg)/ystep)*ystep +yorg
        lonsec_min = int((upleft[1]*3600.-xorg)/xstep)*xstep + xorg
        latsec_max = int((lowright[0]*3600.-yorg)/ystep)*ystep +yorg
        lonsec_max = int((lowright[1]*3600.-xorg)/xstep)*xstep +xorg

        x_size = int((lowright[1]-upleft[1])*3600./xstep)
        y_size = int((lowright[0]-upleft[0])*3600./ystep)
        lat_grid = np.zeros((y_size,x_size),'float64')
        lon_grid = np.zeros((y_size,x_size),'float64')
        h_grid   = np.zeros((y_size,x_size),'float64')
        for lat in range(lat_int_min,lat_int_max-1,-1):
            for lon in range(lon__int_min,lon_int_max+1) :
                dem = load_dem_file(lat,lon,dem_dir)
                dem_x_size = dem.RasterXSize
                dem_y_size = dem.RasterYSize
                dem_geo = dem.GetGeoTransform()
                x_min_dem = int((dem_geo[0]-lonsec_min)/xstep)
                y_min_dem = int((dem_geo[3]-latsec_min)/ystep)
                x_max_dem = x_min_dem +dem_x_size
                y_max_dem = y_min_dem+dem_y_size
                x_min = max(x_min_dem,0)
                y_min = max(y_min_dem,0)
                x_max = min(x_max_dem,x_size)
                y_max = min(y_max_dem,y_size)
                x_min_dem = x_min-x_min_dem
                y_min_dem = y_min -y_min_dem
                lon_a = dem_geo[0]+np.arange(x_min_dem,x_min_dem+x_max-x_min)*xstep
                lat_a = dem_geo[3]+np.arange(y_min_dem,y_min_dem+y_max-y_min)*ystep
                lon_temp,lat_temp = np.meshgrid(lon_a,lat_a)
                lat_grid[y_min:y_max,x_min:x_max] = lat_temp
                lon_grid[y_min:y_max,x_min:x_max] = lon_temp
                h_grid[y_min:y_max,x_min:x_max] = dem.ReadAsArray(x_min_dem,y_min_dem,x_max-x_min,y_max-y_min)
        lat_grid = lat_grid/3600.
        lon_grid = lon_grid/3600.
        h_grid = h_grid*(h_grid>-32767)
        return lat_grid,lon_grid,h_grid

    tt = dutil.datetime(year, month, day,hour, mins,sec,microsec)
    JD = tt.to_jd() + utc_gps/(24*60.*60.) #determine julian time from the utc time
     #left most
    uecef1 = computeUECEF(JD,dut1,pixel_array[0],sat_attitude,band) # look direction
    look_u = uecef1.flatten()
    earth_post = findEarthSurfacePosition(uecef1,sat_position) # look position without elevation
    latintl, lonintl, heightintl = itrf2latlon(earth_post) #initial latitude and longitude
    # right most
    uecef1 = computeUECEF(JD,dut1,pixel_array[-1],sat_attitude,band) # look direction
    look_u = uecef1.flatten()
    uecef_a = computeUECEF(JD,dut1,pixel_array,sat_attitude,band) # look direction
    earth_post = findEarthSurfacePosition(uecef1,sat_position) # look position without elevation
    latintr, lonintr, heightintr = itrf2latlon(earth_post) #initial latitude and longitude

    lat_min = min(latintl,latintr) - 20.*(3./3600.)
    lat_max = max(latintl,latintr) + 20.*(3./3600.)
    lon_min = min(lonintl,lonintr) - 20.*(3./3600.)
    lon_max = max(lonintl,lonintr) + 20.*(3./3600.)
    lat_grid,lon_grid,h_grid =  load_dem_data([lat_max,lon_min],[lat_min,lon_max],dem_directory)
    y_size,x_size = lat_grid.shape
    lat_grid = lat_grid.flatten()
    lon_grid = lon_grid.flatten()
    h_grid = h_grid.flatten()
    x,y,z = latlon2itrf(lat_grid,lon_grid,h_grid)
    ground_pos = np.vstack((x,y,z)).T
    # Make it an array of NxNx3
    postion_grid =ground_pos.reshape(y_size,x_size,3)
    rw,cl,bd  = postion_grid.shape
    rw_grids = np.arange(rw-1)
    cl_grids = np.arange(cl-1)
    rw_g,cl_g = np.meshgrid(rw_grids,cl_grids)
    rw_g = rw_g.flatten()
    cl_g = cl_g.flatten()
    # find the referenced points of the triangles
    p_ref1 = postion_grid[rw_g,cl_g,:] #upper left
    p_ref2 = postion_grid[rw_g+1,cl_g+1,:] #lower right
    # find the plane vectors
    vec11 = postion_grid[rw_g+1,cl_g,:]-p_ref1
    vec12 = postion_grid[rw_g,cl_g+1,:]-p_ref1
    num_points,dim = vec11.shape
    a11 = (1./np.sqrt((vec11**2).sum(1))).reshape(num_points,1)
    a111 = np.repeat(a11,3,1)
    u11 = a111*vec11
    a112 = ((vec12*u11).sum(1)).reshape(num_points,1)
    a112 = np.repeat(a112,3,1)
    r = vec12 - a112*u11
    a122 = (1./np.sqrt((r**2).sum(1))).reshape(num_points,1)
    a122 = np.repeat(a122,3,1)
    u12 = a122*r
    n1 = np.cross(vec11,vec12)
    term11 = ((p_ref1-sat_position)*n1).sum(1)
    vec21 = postion_grid[rw_g+1,cl_g,:]-p_ref2
    vec22 = postion_grid[rw_g,cl_g+1,:]-p_ref2
    a11 = (1./np.sqrt((vec21**2).sum(1))).reshape(num_points,1)
    a211 = np.repeat(a11,3,1)
    u21 = a211*vec21
    a212 = ((vec22*u21).sum(1)).reshape(num_points,1)
    a212 = np.repeat(a212,3,1)
    r = vec22 - a212*u21
    a222 = (1./np.sqrt((r**2).sum(1))).reshape(num_points,1)
    a222 = np.repeat(a222,3,1)
    u22 = a222*r
    n2 = np.cross(vec21,vec22)
    term21 = ((p_ref2-sat_position)*n2).sum(1)
    dim,num = uecef_a.shape
    lat_array = np.zeros((num,1))
    lon_array = np.zeros((num,1))
    h_array = np.zeros((num,1))
    for k in range(num):
        look_u = uecef_a[:,k]
        d1 = (term11/((look_u*n1).sum(1))).reshape(num_points,1)
        d2 = (term21/((look_u*n2).sum(1))).reshape(num_points,1)
        d1 = np.repeat(d1,3,1)
        d2 = np.repeat(d2,3,1)
        P1 = d1*look_u+sat_position
        P2 = d2*look_u+sat_position
        vc1 = P1 - p_ref1
        vc2 = P2 - p_ref2
        k1 = ((vc1*u11).sum(1)).reshape(num_points,1)
        k1 = np.repeat(k1,3,1)
        k2 = ((vc1*u12).sum(1)).reshape(num_points,1)
        k2 = np.repeat(k2,3,1)
        k11 = (k1*a111-k2*a112*a122*a111)[:,0]
        k12 = (k2*a122)[:,0]
        id1 = np.nonzero((k11>=0)*(k12>=0)*(k11+k12<=1))
        id1 = id1[0]
        #print id1

        k1 = ((vc2*u21).sum(1)).reshape(num_points,1)
        k1 = np.repeat(k1,3,1)
        k2 = ((vc2*u22).sum(1)).reshape(num_points,1)
        k2 = np.repeat(k2,3,1)
        k11 = (k1*a211-k2*a212*a222*a211)[:,0]
        k12 = (k2*a222)[:,0]
        id2 = np.nonzero((k11>=0)*(k12>=0)*(k11+k12<=1))
        id2 = id2[0]
        #print id2
        if (id1.shape[0] >= 1) & (id2.shape[0]== 0):
            p = P1[id1[0]]
            lat,lon,h = itrf2latlon(p)
            lat_array[k] = lat
            lon_array[k] = lon
            h_array[k] = h
        elif (id1.shape[0] == 0) & (id2.shape[0]>= 1):
            p = P2[id2[0]]
            lat,lon,h = itrf2latlon(p)
            lat_array[k] = lat
            lon_array[k] = lon
            h_array[k] = h
        elif(id1.shape[0] == 0) & (id2.shape[0]== 0):
            print "Cannot find the intersected points. Please check the dem file"
            exit()
        else: #multiple points pick id1
            print "find multiple locations..."
            p = P1[id1[0]]
            lat,lon,h = itrf2latlon(p)
            lat_array[k] = lat
            lon_array[k] = lon
            h_array[k] = h




    return lat_array,lon_array,h_array

def computeViewLatLongArrayGivenAltitude(band,pixel_array,sat_position, sat_attitude, altitude,year,month,day,hour, mins,sec,microsec,utc_gps,dut1) :


    tt = dutil.datetime(year, month, day,hour, mins,sec,microsec)
    JD = tt.to_jd() + utc_gps/(24*60.*60.) #determine julian time from the utc time
     #left most

    uecef_a = computeUECEF(JD,dut1,pixel_array,sat_attitude,band) # look direction
    lat_array,lon_array,h_array = findViewingLocationLatLong(uecef_a,sat_position,altitude)

    return lat_array,lon_array,h_array

def find_dist_and_dem_vectors(lat,lon,lat_grid,lon_grid,dem_grid,grid_size = 3./3600.,N=4):
    lat_max = lat_grid.max()
    lon_min = lon_grid.min()
    n_point = len(lat.flatten())
    diff_lat = lat_max - lat.flatten()
    diff_lon = lon.flatten() -lon_min
    step_lat = (diff_lat/grid_size).astype('float32')
    step_lon = (diff_lon/grid_size).astype('float32')
    step_lat_int = step_lat.astype('int32')
    step_lon_int = step_lon.astype('int32')
    small_step_lat = (step_lat-step_lat_int).astype('float32')
    small_step_lon = (step_lon-step_lon_int).astype('float32')
    if N%2 == 0 :
        str = -N/2+1
        stp = N/2
    else:
        str = -N/2
        stp = N/2
    Ns = N*N
    idx = np.arange(str,stp+1)
    row_diff = np.repeat(np.repeat(idx.reshape(N,1,1),N,1),n_point,2)
    col_diff = np.repeat(np.repeat(idx.reshape(1,N,1),N,0),n_point,2)
    ps = np.sqrt((row_diff.astype('float32')-small_step_lat)**2+(col_diff.astype('float32')-small_step_lon)**2)
    ps = ps.reshape((Ns,n_point))*grid_size
    rows = (row_diff+step_lat_int).reshape(Ns,n_point)
    cols = (col_diff+step_lon_int).reshape(Ns,n_point)
    dem_out = dem_grid[rows,cols]
    return ps,dem_out


def load_dem_file(lat,lon,dem_directory):
    try:
        open(dem_directory +"/h10g")
        dem_type = "GLOBE"
    except:
        dem_type = "SRTM"

    if dem_type == "SRTM":

        # if lon <0 :
        #     lon += 1
        if (lat >=0) &( lon >= 0) :
            dem_file = dem_directory + "/n%02de%03d.bil"%(lat,lon)
            #dem_file01 = dem_directory + "n%02de%03d.bil"%(lat,lon)
        elif (lat>0) & (lon<0) :
            dem_file = dem_directory + "/n%02dw%03d.bil"%(lat,-lon)
        elif (lat<0) & (lon>=0):
            dem_file = dem_directory + "/s%02de%03d.bil"%(-lat,lon)
        else:
            dem_file = dem_directory + "/s%02dw%03d.bil"%(-lat,-lon)
        dem = gdal.Open(dem_file)

        return dem
    elif dem_type == "GLOBE":
        if (lat >= 50.0):
            if (lon<-90.0):
                dem_file = dem_directory + "/a10g"
            elif ( lon < 0  ):
                dem_file = dem_directory + "/b10g"
            elif ( lon < 90  ):
                dem_file = dem_directory + "/c10g"
            else:
                dem_file = dem_directory + "/d10g"
        elif (lat >=0) & (lat <50):
            if (lon<-90.0):
                dem_file = dem_directory + "/e10g"
            elif ( lon < 0  ):
                dem_file = dem_directory + "/f10g"
            elif ( lon < 90  ):
                dem_file = dem_directory + "/g10g"
            else:
                dem_file = dem_directory + "/h10g"
        elif (lat >=-50) & (lat <0):
            if (lon<-90.0):
                dem_file = dem_directory + "/i10g"
            elif ( lon < 0  ):
                dem_file = dem_directory + "/j10g"
            elif ( lon < 90  ):
                dem_file = dem_directory + "/k10g"
            else:
                dem_file = dem_directory + "/l10g"
        else:
            if (lon<-90.0):
                dem_file = dem_directory + "/m10g"
            elif ( lon < 0  ):
                dem_file = dem_directory + "/n10g"
            elif ( lon < 90  ):
                dem_file = dem_directory + "/o10g"
            else:
                dem_file = dem_directory + "/p10g"

        dem = gdal.Open(dem_file)
        return dem







def load_dem_data(upleft,lowright,dem_dir) :
    #get the upper left lattitude and longitude hour
    latul = upleft[0]
    lonul = upleft[1]
    latlr = lowright[0]
    lonlr = lowright[1]
    latulsec = latul*3600.
    lonulsec = lonul*3600.
    latlrsec = latlr*3600.
    lonlrsec = lonlr*3600.
    lat_hour_ul = int(np.floor(latul))
    lon_hour_ul = int(np.floor(lonul))

    #load upper left DEM file
    dem = load_dem_file(lat_hour_ul,lon_hour_ul,dem_dir)
    dem_geo = dem.GetGeoTransform()
    xorg = dem_geo[0]
    yorg = dem_geo[3]
    xstep = dem_geo[1]
    ystep = dem_geo[5]
    # find row and col wrt to the upper left dem file
    col_ul = int((lonulsec-xorg)/xstep)
    row_ul = int((latulsec-yorg)/ystep)
    col_lr = int((lonlrsec-xorg)/xstep)
    row_lr = int((latlrsec-yorg)/ystep)
    x_size = col_lr - col_ul + 1
    y_size = row_lr - row_ul + 1
    lat_grid = np.zeros((y_size,x_size),'float64')
    lon_grid = np.zeros((y_size,x_size),'float64')
    h_grid   = np.zeros((y_size,x_size),'float64')
    if col_lr > dem.RasterXSize:
        num_file_col  = 2
    else:
        num_file_col = 1
    if row_lr > dem.RasterYSize:
        num_file_row = 2
    else:
        num_file_row = 1
    for file_r_id in range(num_file_row):
        for file_c_id in range(num_file_col):
            dem = load_dem_file(lat_hour_ul-file_r_id,lon_hour_ul+file_c_id,dem_dir) # open file
            dem_x_size = dem.RasterXSize # get file size
            dem_y_size = dem.RasterYSize # get file size
            dem_geo = dem.GetGeoTransform()
            dat = dem.ReadAsArray()
            sub_ul_x = dem_geo[0]
            sub_ul_y = dem_geo[3]
            sub_ul_col = int((sub_ul_x-xorg)/xstep)
            sub_ul_row = int((sub_ul_y-yorg)/ystep)
            max_row = min(row_lr - sub_ul_row +1,dem_y_size)
            max_col = min(col_lr - sub_ul_col +1,dem_x_size)
            min_row = max(0,row_ul - sub_ul_row)
            min_col = max(0,col_ul - sub_ul_col)
            overlapped_data = dat[min_row:max_row,min_col:max_col]
            min_row_out = min_row - row_ul + sub_ul_row
            min_col_out = min_col - col_ul + sub_ul_col
            max_row_out = max_row - row_ul + sub_ul_row
            max_col_out = max_col - col_ul + sub_ul_col

            lata = (np.arange(min_row,max_row))*dem_geo[5] + dem_geo[3]
            lona = (np.arange(min_col,max_col))*dem_geo[1] + dem_geo[0]
            lon2,lat2 = np.meshgrid(lona,lata)
            h_grid[min_row_out:max_row_out,min_col_out:max_col_out] = overlapped_data
            lat_grid[min_row_out:max_row_out,min_col_out:max_col_out] = lat2
            lon_grid[min_row_out:max_row_out,min_col_out:max_col_out] = lon2
    lat_grid = lat_grid/3600.
    lon_grid = lon_grid/3600.
    h_grid = h_grid*(h_grid != -32767)*(h_grid != -500)
    return lat_grid,lon_grid,h_grid
    #
    #
    # xlr = (dem_geo[0] - lonsec_min)/xstep - 0.5
    # ylr = (dem_geo[3] - latsec_min)/ystep - 0.5
    # for lat in range(lat_hour_ul,lat_hour_lr,-1):
    #     for lon in range(lon_hour_ul,lon_hour_lr) :
    #         dem = load_dem_file(lat,lon,dem_dir) # open file
    #         dem_x_size = dem.RasterXSize # get file size
    #         dem_y_size = dem.RasterYSize # get file size
    #         dem_geo = dem.GetGeoTransform()
    #         # Determine the coordinate of the ur wrt to dem file
    #         x_ul_dem = (dem_geo[0] - lonsec_min)/xstep
    #         x_min_dem = int((dem_geo[0]-lonsec_min)/xstep)
    #         y_min_dem = int((dem_geo[3]-latsec_min)/ystep)
    #         x_max_dem = x_min_dem + dem_x_size
    #         y_max_dem = y_min_dem + dem_y_size
    #         x_min = max(x_min_dem,0)
    #         y_min = max(y_min_dem,0)
    #         x_max = min(x_max_dem,x_size)
    #         y_max = min(y_max_dem,y_size)
    #         x_min_dem = x_min-x_min_dem
    #         y_min_dem = y_min -y_min_dem
    #         if (x_max-x_min>0) & (y_max-y_min>0):
    #             lon_a = dem_geo[0]+np.arange(x_min_dem,x_min_dem+x_max-x_min)*xstep
    #             lat_a = dem_geo[3]+np.arange(y_min_dem,y_min_dem+y_max-y_min)*ystep
    #             lon_temp,lat_temp = np.meshgrid(lon_a,lat_a)
    #             lat_grid[y_min:y_max,x_min:x_max] = lat_temp
    #             lon_grid[y_min:y_max,x_min:x_max] = lon_temp
    #             h_grid[y_min:y_max,x_min:x_max] = dem.ReadAsArray(x_min_dem,y_min_dem,x_max-x_min,y_max-y_min)
    # lat_grid = lat_grid/3600.
    # lon_grid = lon_grid/3600.
    # h_grid = h_grid*(h_grid>-32767)
    # return lat_grid,lon_grid,h_grid


def computeViewLatLongArrayUsingDEM(band,pixel_array,sat_position, sat_attitude, year,month,day,hour, mins,sec,
                                        microsec,utc_gps,dut1,dem, dem_interpolation_method) :


    tt = dutil.datetime(year, month, day,hour, mins,sec,microsec)
    JD = tt.to_jd() + utc_gps/(24*60.*60.) #determine julian time from the utc time
    uecef_array = computeUECEF(JD, dut1, pixel_array, sat_attitude, band)
    num = pixel_array.shape[0]
    points = np.zeros((num, 2))
    h_arr = np.zeros((num,))
    points_old = points + 1
    for it in range(20):
        lat_array, lon_array, h = findViewingLocationLatLong(uecef_array, sat_position, h_arr)
        if (lon_array.max() - lon_array.min()) > 340: # contain both west and east
            if lon_array.mean() >=0 :
                idx = np.nonzero(lon_array <0)
                lon_array[idx] = lon_array[idx] +360
            else :
                idx = np.nonzero(lon_array >= 0)
                lon_array[idx] = lon_array[idx] - 360
        points[:, 0] = lat_array
        points[:, 1] = lon_array
        if np.abs(points_old - points).max() < 1e-8:
            # print "The algorithm is terminated due to minimum error obtained at the %d-th iteration."%it
            break
        h_arr  = dem.interpolate(lat_array,lon_array,dem_interpolation_method)
        h_arr = h_arr.reshape((lat_array.shape))
        points_old = points.copy()
    return lat_array,lon_array,h_arr



def computeViewLatLongArrayUsingKriging(band,pixel_array,sat_position, sat_attitude, year,month,day,hour, mins,sec,
                                        microsec,utc_gps,dut1,dem_directory) :


    tt = dutil.datetime(year, month, day,hour, mins,sec,microsec)
    JD = tt.to_jd() + utc_gps/(24*60.*60.) #determine julian time from the utc time
     #left most
    uecef1 = computeUECEF(JD,dut1,pixel_array[0],sat_attitude,band)# look direction

    earth_post = findEarthSurfacePosition(uecef1,sat_position) # look position without elevation
    latintl, lonintl, heightintl = itrf2latlon(earth_post) #initial latitude and longitude
    # right most
    uecef1 = computeUECEF(JD,dut1,pixel_array[-1],sat_attitude,band) # look direction
    earth_post = findEarthSurfacePosition(uecef1,sat_position) # look position without elevation
    latintr, lonintr, heightintr = itrf2latlon(earth_post) #initial latitude and longitude
    dem_temp = load_dem_file(13,90,dem_directory)
    geot = dem_temp.GetGeoTransform()
    pixel_size = geot[1]/3600.0
    lat_min = min(latintl,latintr) - 32.* pixel_size
    lat_max = max(latintl,latintr) + 32.* pixel_size
    lon_min = min(lonintl,lonintr) - 32.* pixel_size
    lon_max = max(lonintl,lonintr) + 32.* pixel_size
    lat_grid,lon_grid,h_grid =  load_dem_data([lat_max,lon_min],[lat_min,lon_max],dem_directory)
    n_rw_dem, n_cl_dem = lat_grid.shape
    num_dem  = n_rw_dem*n_cl_dem
    #h_grid += 17.0
    P = np.zeros((num_dem,3))
    P[:,0] = lat_grid.flatten()
    P[:,1] = lon_grid.flatten()
    P[:,2] = h_grid.flatten()

    #semivar = computeSemivariogram(h_grid,3./3600.,16)
    semivar = demKriging.semivariogram(h_grid,pixel_size,16)
    c = np.var(h_grid.flatten())
    if c > 1e-4:
        covfct = demKriging.findOptModel(semivar,c,demKriging.spherical,pixel_size)

        #a = findOptParam(semivar,c)
        #xx = semivar[:,1]
        #yy = semivar[:,0]
        #x2 = np.linspace(0,xx.max(),1000)
        #y2 = spherical(x2,a,c)
        #plt.plot(xx,yy,'o',x2,y2,'-')
        #plt.show()
        N = 4
        Ns = 16
        K = np.zeros((Ns,Ns))
        for k in range(0,Ns):
            for m in range(0,Ns) :
                j = k%N
                i = k/N
                q = m%N
                p = m/N
                K[k,m] = np.sqrt(float(i-p)**2+float(j-q)**2)*pixel_size


        #semivar2 = variograms.semivariogram(P,lags,1e-10)
        K = covfct(K)
        K = K.reshape(Ns,Ns)
        K2 = np.ones((Ns+1,Ns+1))
        K2[:Ns,:Ns] = K
        K2[-1,-1] = 0
        #lags = np.array([1.,np.sqrt(2),2.,np.sqrt(5),np.sqrt(8.),3,np.sqrt(10),np.sqrt(9+4.),np.sqrt(18.)])*3./3600.
        #covfct = model.covariance(model.spherical,(a,c))
        uecef_array = computeUECEF(JD,dut1,pixel_array,sat_attitude,band)
        num = pixel_array.shape[0]
        points =np.zeros((num,2))
        h_arr = np.zeros((num,))
        points_old = points + 1
        k2 = np.ones((Ns+1,num))
        K2inv = np.linalg.inv(K2)
        for it in range(20):
            lat_array,lon_array,h = findViewingLocationLatLong(uecef_array,sat_position,h_arr)
            points[:,0] = lat_array
            points[:,1] = lon_array
            if np.abs(points_old-points).max() < 1e-8 :
                #print "The algorithm is terminated due to minimum error obtained at the %d-th iteration."%it
                break
            ks,z_temp = find_dist_and_dem_vectors(lat_array,lon_array,lat_grid,lon_grid,h_grid, grid_size=pixel_size)
            ks = covfct(ks)
            k2[:Ns,:] = ks
            w = np.dot(K2inv,k2)
            h_arr = (w[:-1]*z_temp).sum(0)
            #h_arr2,std_arr2 = kriging.krige(P,covfct,points,'ordinary',N=16)
            #h_arr2 = h_arr2[0]
            points_old = points.copy()
    else:
        uecef_array = computeUECEF(JD,dut1,pixel_array,sat_attitude,band)
        h_arr = h_grid.mean()
        lat_array,lon_array,h_arr = findViewingLocationLatLong(uecef_array,sat_position,h_arr)

    return lat_array,lon_array,h_arr


def computeViewLatLongArrayWithHeight(band,pixels,lines,height,line0,sat_position, sat_attitude, captured_time,year,month,day,
                                                  utc_gps,dut1,dem_directory=None) :
    import math
    def date_to_jd(year,month,day):
        """
        Convert a date to Julian Day.

        Algorithm from 'Practical Astronomy with your Calculator or Spreadsheet',
            4th ed., Duffet-Smith and Zwart, 2011.

        Parameters
        ----------
        year : int
            Year as integer. Years preceding 1 A.D. should be 0 or negative.
            The year before 1 A.D. is 0, 10 B.C. is year -9.

        month : int
            Month as integer, Jan = 1, Feb. = 2, etc.

        day : float
            Day, may contain fractional part.

        Returns
        -------
        jd : float
            Julian Day

        Examples
        --------
        Convert 6 a.m., February 17, 1985 to Julian Day

        >>> date_to_jd(1985,2,17.25)
        2446113.75

        """
        if month == 1 or month == 2:
            yearp = year - 1
            monthp = month + 12
        else:
            yearp = year
            monthp = month


        # this checks where we are in relation to October 15, 1582, the beginning
        # of the Gregorian calendar.
        if ((year < 1582) or
            (year == 1582 and month < 10) or
            (year == 1582 and month == 10 and day < 15)):
            # before start of Gregorian calendar
            B = 0
        else:
            # after start of Gregorian calendar
            A = math.trunc(yearp / 100.)
            B = 2 - A + math.trunc(A / 4.)

        if yearp < 0:
            C = math.trunc((365.25 * yearp) - 0.75)
        else:
            C = math.trunc(365.25 * yearp)

        D = math.trunc(30.6001 * (monthp + 1))

        jd = B + C + D + day + 1720994.5

        return jd
    line_max = captured_time.size
    linest = lines + line0-1
    line_low = linest.astype('int64')
    line_high  = line_low+1
    d_line = linest - line_low
    num = d_line.shape[0]
    dcap1 = captured_time[1]-captured_time[0]
    cap0 = captured_time[0]
    capm = captured_time[-1]
    dcaplast = captured_time[-1]- captured_time[-2]

    att0 = sat_attitude[0]
    datt1 = sat_attitude[1] - sat_attitude[0]
    attm = sat_attitude[-1]
    dattlast = sat_attitude[-1]- sat_attitude[-2]

    sat0 = sat_position[0]
    dsat1 = sat_position[1] - sat_position[0]
    satm  = sat_position[-1]
    dsatlast = sat_position[-1] - sat_position[-2]

    num_samples = len(line_low)

    #cprint "              Line min: %d, line max: %d"%(line_low.min(), line_low.max())

    cap_times_low = np.zeros((num_samples))
    cap_times_low[(line_low >= 0) * (line_low < line_max)] = captured_time[line_low[(line_low >= 0) * (line_low < line_max)]]
    #cap_times_low[line_low <0] = captured_time[0] + line_low[line_low<0]*dcap1
    #cap_times_low[line_low>= line_max] = captured_time[-1] + line_low[line_low>=line_max]*dcaplast

    cap_times_high = np.zeros((num_samples))
    cap_times_high[(line_high >= 0) * (line_high < line_max)] = captured_time[
        line_high[(line_high >= 0) * (line_high < line_max)]]
    #cap_times_high[line_high < 0] = captured_time[0] + line_high[line_high < 0] * dcap1
    #cap_times_high[line_high >= line_max] = captured_time[-1] + line_high[line_high >= line_max] * dcaplast

    cap_times = (1-d_line)*(cap_times_low*(line_low>=0)*(line_low<line_max)
                            + (line_low<0)*(cap0 + line_low*dcap1)
                            + (line_low>= line_max)*(capm + (line_low-line_max+1)*dcaplast))
    cap_times += d_line*(cap_times_high*(line_high>=0)*(line_high<line_max)
                         + (line_high<0)*(cap0 + line_high*dcap1)
                         + (line_high >= line_max) * (capm + (line_high-line_max+1) * dcaplast))
    #cap_times = cap_times**(line_low>=0) + (line_low<0)*((1-d_line)*(cap0+line_low*dcap1)+d_line*captured_time[line_high])
    d_line = d_line.reshape((num,1))
    #sat_att = sat_attitude[line_low]
    #sat_att = sat_attitude[line_low]
    #sat_h = sat_attitude[line_low]
    sat_att = np.zeros((num_samples, 4))
    sat_h = np.zeros((num_samples, 4))
    sat_att[(line_low >= 0)*(line_low < line_max)] = sat_attitude[line_low[(line_low >= 0)*(line_low < line_max)]]
    sat_h[(line_high >= 0) * (line_high < line_max)] = sat_attitude[line_high[(line_high >= 0) * (line_high < line_max)]]
    for k in range(4):
        sat_att[line_low < 0, k] = (att0[k] + line_low[line_low < 0]*datt1[k])
        sat_att[line_low >= line_max, k] = (attm[k] + (line_low[line_low >= line_max]-line_max+1)*dattlast[k])
        sat_h[line_high < 0, k] = att0[k] + line_high[line_high < 0]*datt1[k]
        sat_h[line_high >= line_max, k] = attm[k] + (line_high[line_high >= line_max]-line_max+1) * dattlast[k]
    sat_att = (1-d_line) * sat_att + d_line * sat_h

    sat_post = np.zeros((num_samples, 3))
    sat_h = np.zeros((num_samples, 3))
    #sat_post = sat_position[line_low]
    #sat_h = sat_position[line_low]
    sat_post[(line_low >=0) * (line_low < line_max)] = sat_position[line_low[(line_low>=0)*(line_low<line_max)]]
    sat_h[(line_high >= 0) * (line_high < line_max)] = sat_position[
        line_high[(line_high >= 0) * (line_high < line_max)]]
    for k in range(3):
        sat_post[line_low < 0, k] = sat0[k] + line_low[line_low<0]*dsat1[k]
        sat_post[line_low >= line_max, k] = (satm[k] + (line_low[line_low >= line_max] - line_max + 1) * dsatlast[k])
        sat_h[line_high < 0, k] = sat0[k] + line_high[line_high < 0] * dsat1[k]
        sat_h[line_high >= line_max, k] = satm[k] + (line_high[line_high >= line_max]-line_max+1) * dsatlast[k]
    sat_post = (1-d_line)*sat_post + d_line*sat_h



    hour = (cap_times/3600.).astype('int32')
    minute = ((cap_times-hour*3600.0)/60.0).astype('int32')
    seconds = cap_times%60.0
    sec = seconds.astype('int32')
    microsec = (1e6*(seconds -sec)).astype('int32')

    #tt = dutil.datetime(year, month, day,hour, minute,sec,microsec)
    days = sec + (microsec / 1.e6)
    days = minute+ (days / 60.)
    days = hour + (days / 60.)
    days /=  24.0
    days += day
    JD = date_to_jd(year,month,days) + utc_gps/(24*60.*60.) #determine julian time from the utc time

     #left most

    uecef1 = computeUECEF(JD,dut1,pixels+1,sat_att,band) # look direction
    sat_post = sat_post.T
    uecef1 = uecef1.T
    lat_array, lon_array,h_arr = findViewingLocationLatLong(uecef1,sat_post,height)

    return lat_array,lon_array,h_arr

def findMinMaxHeight(upr_lft,lwr_rght,dem_directory):
    lat_min = lwr_rght[0]
    lat_max = upr_lft[0]
    lon_min = upr_lft[1]
    lon_max = lwr_rght[1]
    lat_grid,lon_grid,h_grid =  load_dem_data([lat_max,lon_min],[lat_min,lon_max],dem_directory)
    h_min = h_grid.min()
    h_max = h_grid.max()
    return h_min,h_max


def determineHeight(lat,lon,dem_directory) :
    def load_dem_file(lat,lon,dem_directory):
        lat = int(lat)
        lon = int(lon)
        if (lat >=0) &( lon >= 0) :
            dem_file = dem_directory + "/n%02de%03d.bil"%(lat,lon)
            #dem_file01 = dem_directory + "n%02de%03d.bil"%(lat,lon)
        elif (lat>0) & (lon<0) :
            dem_file = dem_directory + "/n%02dw%03d.bil"%(lat,-lon)
        elif (lat<0) & (lon>=0):
            dem_file = dem_directory + "/s%02de%03d.bil"%(-lat,lon)
        else:
            dem_file = dem_directory + "/s%02dw%03d.bil"%(-lat,-lon)
        dem = gdal.Open(dem_file)
        return dem

    def load_dem_data(upleft,lowright,dem_dir) :
        lat_int_min = int(np.floor(upleft[0]))
        lon__int_min = int(np.floor(upleft[1]))
        lat_int_max = int(np.floor(lowright[0]))
        lon_int_max = int(np.floor(lowright[1]))
        latsec_min = upleft[0]*3600.
        lonsec_min = upleft[1]*3600.
        latsec_max = lowright[0]*3600.
        lonsec_max = lowright[1]*3600.
        #load DEM file
        dem = load_dem_file(lat_int_max,lon__int_min,dem_dir)
        dem_geo = dem.GetGeoTransform()
        xorg = dem_geo[0]
        yorg = dem_geo[3]
        xstep = dem_geo[1]
        ystep = dem_geo[5]
        latsec_min = int((upleft[0]*3600.-yorg)/ystep)*ystep +yorg
        lonsec_min = int((upleft[1]*3600.-xorg)/xstep)*xstep + xorg
        latsec_max = int((lowright[0]*3600.-yorg)/ystep)*ystep +yorg
        lonsec_max = int((lowright[1]*3600.-xorg)/xstep)*xstep +xorg

        x_size = int((lowright[1]-upleft[1])*3600./xstep)
        y_size = int((lowright[0]-upleft[0])*3600./ystep)
        lat_grid = np.zeros((y_size,x_size),'float64')
        lon_grid = np.zeros((y_size,x_size),'float64')
        h_grid   = np.zeros((y_size,x_size),'float64')
        for lat in range(lat_int_min,lat_int_max-1,-1):
            for lon in range(lon__int_min,lon_int_max+1) :
                dem = load_dem_file(lat,lon,dem_dir)
                dem_x_size = dem.RasterXSize
                dem_y_size = dem.RasterYSize
                dem_geo = dem.GetGeoTransform()
                x_min_dem = int((dem_geo[0]-lonsec_min)/xstep)
                y_min_dem = int((dem_geo[3]-latsec_min)/ystep)
                x_max_dem = x_min_dem +dem_x_size
                y_max_dem = y_min_dem+dem_y_size
                x_min = max(x_min_dem,0)
                y_min = max(y_min_dem,0)
                x_max = min(x_max_dem,x_size)
                y_max = min(y_max_dem,y_size)
                x_min_dem = x_min-x_min_dem
                y_min_dem = y_min -y_min_dem
                lon_a = dem_geo[0]+np.arange(x_min_dem,x_min_dem+x_max-x_min)*xstep
                lat_a = dem_geo[3]+np.arange(y_min_dem,y_min_dem+y_max-y_min)*ystep
                lon_temp,lat_temp = np.meshgrid(lon_a,lat_a)
                lat_grid[y_min:y_max,x_min:x_max] = lat_temp
                lon_grid[y_min:y_max,x_min:x_max] = lon_temp
                h_grid[y_min:y_max,x_min:x_max] = dem.ReadAsArray(x_min_dem,y_min_dem,x_max-x_min,y_max-y_min)
        lat_grid = lat_grid/3600.
        lon_grid = lon_grid/3600.
        h_grid = h_grid*(h_grid>-32767)
        return lat_grid,lon_grid,h_grid



    lat_min = lat.min() - 20.*(3./3600.)
    lat_max = lat.max() + 20.*(3./3600.)
    lon_min = lon.min() - 20.*(3./3600.)
    lon_max = lon.max() + 20.*(3./3600.)
    lat_grid,lon_grid,h_grid =  load_dem_data([lat_max,lon_min],[lat_min,lon_max],dem_directory)
    dem_step = 3./3600.
    lat_min = lat_grid.min()
    lat_max = lat_grid.max()
    lon_min = lon_grid.min()
    lon_max = lon_grid.max()

    rws = ((lat_max-lat)/dem_step).flatten()
    cls = ((lon - lon_min)/dem_step).flatten()
    rws_i = rws.astype('int32')
    cls_i = cls.astype('int32')
    a = rws-rws_i
    b = cls-cls_i
    h_dem = (a+b<=1)*(h_grid[rws_i,cls_i]+a*(h_grid[rws_i+1,cls_i]-h_grid[rws_i,cls_i])+b*(h_grid[rws_i,cls_i+1]-h_grid[rws_i,cls_i])) \
            + (a+b>1)*(h_grid[rws_i+1,cls_i+1]+(1-a)*(h_grid[rws_i+1,cls_i]-h_grid[rws_i+1,cls_i+1])+(1-b)*(h_grid[rws_i,cls_i+1]-h_grid[rws_i+1,cls_i+1]))
    n_rws,n_cls = lat.shape
    h_dem = h_dem.reshape((n_rws,n_cls))


    return h_dem

# def computeSemivariogram(dem_grid,delta_degree,N):
#     ssq = dict()
#     num_sample = dict()
#     #dem_grid = dem_grid -dem_grid.mean()
#
#     for k in range(N):
#         for m in range(N):
#             if (k>0) or (m>0):
#                 dist = k*k+m*m
#                 if (k==0) :
#                     err = dem_grid[:,:-m] - dem_grid[k:,m:]
#
#                 elif (m==0):
#                     err = dem_grid[:-k,:] - dem_grid[k:,m:]
#                 else:
#                     err1 = dem_grid[:-k,:-m] - dem_grid[k:,m:]
#                     err2 = dem_grid[k:,:-m] - dem_grid[:-k,m:]
#                     err = np.vstack((err1,err2))
#                 if ssq.has_key(dist) :
#                     ssq[dist] += (err**2).sum()
#                     num_sample[dist] += err.shape[0]*err.shape[1]
#                 else:
#                     ssq[dist] = (err**2).sum()
#                     num_sample[dist] = err.shape[0]*err.shape[1]
#
#     n = len(ssq)
#     semivar2 = np.zeros((n,2))
#     cnt = 0
#     for key in ssq.keys():
#         #print "%d:,%d,%d"%(key,num_sample[key],ssq[key])
#         semivar2[cnt,0] = ssq[key]/(2.0*num_sample[key])
#         semivar2[cnt,1] = np.sqrt(float(key))*delta_degree
#         cnt += 1
#     kk = np.argsort(semivar2[:,1])
#     semivar = np.zeros((n,2))
#     semivar[:,0] = semivar2[kk,0]
#     semivar[:,1] = semivar2[kk,1]
#     return semivar
#
# def spherical(h,a,c):
#     a = np.float32(a)
#     c = np.float32(c)
#     low = c*( 1.5*(h/a) - 0.5*(h/a)**3.0 )
#     high = c
#     y = low*(h<=a)
#     y += high*(h>a)
#     return y
#
# def spherical_prime(h,a,c):
#     a = np.float32(a)
#     c = np.float32(c)
#     low = c*( -1.5*(h/(a*a)) + 1.5*(h**3.0)/(a**4.0) )
#     high = 0
#     y = low*(h<=a)
#     y += high*(h>a)
#     return y
# def findOptParam(semivar,c):
#     def cost(a, data,dist,c):
#         modelv = spherical(dist,a,c)
#         err1 = (modelv-data)**2
#         err = err1.mean()
#         #print "err:", err
#         return err
#
#     def costp(a, data,dist,c):
#         modelv = spherical(dist,a,c)
#         modelvp = spherical_prime(dist,a,c)
#         errp1 = 2*(modelv-data)*modelvp
#         errp = errp1.mean()
#         #print "errp:",errp
#         return errp
#     data = semivar[:,0]
#     dist = semivar[:,1]
#     a = opt.fminbound(cost,dist.min(),dist.max()*10.0, args=(data,dist,c),disp=0)
#     print "optimum value is :%f."%a
#     return a
#

def interpolateDemGRidCubic(lat,lon,lat_grid,lon_grid,h_grid,pixel_size) :
    lon_ul = lon_grid.min()
    lat_ul = lat_grid.max()
    x = (lon-lon_ul)/pixel_size
    y = (lat_ul-lat)/pixel_size
    x = x.astype('float32')
    y = y.astype('float32')
    h_grid = h_grid.astype('float32')
    ha = cv2.remap(h_grid,x,y,cv2.INTER_CUBIC)
    return ha

def interpolateDemGRidNearest(lat,lon,lat_grid,lon_grid,h_grid,pixel_size) :
    lon_ul = lon_grid.min()
    lat_ul = lat_grid.max()
    x = (lon-lon_ul)/pixel_size
    y = (lat_ul-lat)/pixel_size
    x = x.astype('float32')
    y = y.astype('float32')
    h_grid = h_grid.astype('float32')
    ha = cv2.remap(h_grid,x,y,cv2.INTER_NEAREST)
    return ha

def interpolateDemGRidLinear(lat,lon,lat_grid,lon_grid,h_grid,pixel_size) :
    lon_ul = lon_grid.min()
    lat_ul = lat_grid.max()
    x = (lon-lon_ul)/pixel_size
    y = (lat_ul-lat)/pixel_size
    x = x.astype('float32')
    y = y.astype('float32')
    h_grid = h_grid.astype('float32')
    ha = cv2.remap(h_grid,x,y,cv2.INTER_LINEAR)
    return ha



def interpolateDemGrid(lat,lon,lat_grid,lon_grid,h_grid,pixel_size) :
    # temp = gdal.Open(dem_directory+"/n13e100.bil")
    # geot = temp.GetGeoTransform()
    # pixel_size = geot[1]/3600.0
    #
    # lat_min = lat.min() - 20.*pixel_size
    # lat_max = lat.max() + 20.*pixel_size
    # lon_min = lon.min() - 20.*pixel_size
    # lon_max = lon.max() + 20.*pixel_size
    #
    # lat_grid,lon_grid,h_grid =  load_dem_data([lat_max,lon_min],[lat_min,lon_max],dem_directory)
    #semivar = computeSemivariogram(h_grid,3./3600.,10)
    semivar = demKriging.semivariogram(h_grid,pixel_size,10)
    #print "seminar max:%f, min:%f"%(semivar[:,0].max(),semivar[:,0].min())
    #print semivar[:,0]
    sill = np.var(h_grid)
    nr,nc = lat.shape
    if sill > 1e-4:
        covfct = demKriging.findOptModel(semivar,sill,demKriging.spherical,pixel_size)
        #a = findOptParam(semivar,sill)
        # xx = semivar[:,1]
        # yy = semivar[:,0]
        # x2 = np.linspace(0,xx.max(),1000)
        # y2 = sill-covfct(x2)
        # plt.plot(xx,yy,'o',x2,y2,'-')
        # plt.show()




        n_points = nr*nc
        # estimate K
        N = 4
        Nsq = 16


        N = 4
        Ns = 16
        K = np.zeros((Ns,Ns))
        for k in range(0,Ns):
            for m in range(0,Ns) :
                j = k%N
                i = k/N
                q = m%N
                p = m/N
                K[k,m] = np.sqrt(float(i-p)**2+float(j-q)**2)*pixel_size


        #semivar2 = variograms.semivariogram(P,lags,1e-10)
        K = covfct(K)
        K = K.reshape(Ns,Ns)
        K2 = np.ones((Ns+1,Ns+1))
        K2[:Ns,:Ns] = K
        K2[-1,-1] = 0

        ks,z_term = find_dist_and_dem_vectors(lat,lon,lat_grid,lon_grid,h_grid,grid_size = pixel_size,N=4)
        #semivar2 = variograms.semivariogram(P,lags,1e-10)

        # cast as a matrix
        ks = covfct(ks)

        k2 = np.ones((Nsq+1,n_points))
        k2[:Nsq,:] = ks
        w = np.dot(np.linalg.inv(K2),k2)
        #w2 = np.dot(np.linalg.inv(K),ks)

        est = (w[:-1,:]*z_term).sum(0)
    else:
        est = h_grid.mean()*np.ones((nr,nc))

    #covfct = model.fitmodel(P,model.spherical,lags,1e-8)
    #est2 = (w2*(z_term-dem2.mean())).sum(0) +dem2.mean()
    #est2, kstd = kriging.krige( P, covfct, points , 'ordinary',N=4)
    #print np.linalg.norm(est-est2.flatten())
    return est.reshape(nr,nc)

def rbfgaussian(x,sigma):
    y = np.exp(-(x/sigma)**2)
    return y

def rbfinverseQuadratic(x,sigma):
    y = 1./(1.+(x/sigma)**2)
    return y

def rbfinverseMultiquadratic(x,sigma):
    y = 1. / np.sqrt(1. + (x / sigma) ** 2)
    return y
def rbfmultiquadratic(x,sigma):
    y = np.sqrt(1. + (x / sigma) ** 2)
    return y
def rbflinear(x,sigma):
    y = x/sigma
    return y
def rbfcubic(x,sigma):
    y  = (x/sigma)**3.
    return y
def rbfthinPlateSpline(x,sigma):
    x2 = x/sigma
    y = (x2**2)*np.log(x2)
    return y



def interpolateDemGridRBF(lat,lon,lat_grid,lon_grid,h_grid,pixel_size) :
    sigma = pixel_size
    num_data = lat_grid.size
    lat_grid2 = lat_grid.reshape(num_data,1)
    lon_grid2 = lon_grid.reshape(num_data,1)
    data_grid = np.hstack((lat_grid2,lon_grid2))
    distance_matrix = distance.cdist(data_grid,data_grid,"euclidean")
    A = rbfgaussian(distance_matrix, sigma)
    lamb_vec = np.linalg.solve(A, h_grid.flatten())
    num_out = lat.size
    rw,cl = lat.shape
    lat2 = lat.reshape(num_out, 1)
    lon2 = lon.reshape(num_out, 1)
    out_grids = np.hstack((lat2,lon2))
    print out_grids.shape, data_grid.shape
    distance_matrix = distance.cdist(out_grids,data_grid,"euclidean")

    A = rbfgaussian(distance_matrix,sigma)
    hout = np.dot(A,lamb_vec)
    hout = hout.reshape((rw,cl))
    return hout

def interpolateDem(lat,lon,dem_directory) :
    temp = gdal.Open(dem_directory+"/n13e100.bil")
    geot = temp.GetGeoTransform()
    pixel_size = geot[1]/3600.0

    lat_min = lat.min() - 20.*pixel_size
    lat_max = lat.max() + 20.*pixel_size
    lon_min = lon.min() - 20.*pixel_size
    lon_max = lon.max() + 20.*pixel_size

    lat_grid,lon_grid,h_grid =  load_dem_data([lat_max,lon_min],[lat_min,lon_max],dem_directory)
    #semivar = computeSemivariogram(h_grid,3./3600.,10)
    semivar = demKriging.semivariogram(h_grid,pixel_size,10)
    #print "seminar max:%f, min:%f"%(semivar[:,0].max(),semivar[:,0].min())
    #print semivar[:,0]
    sill = np.var(h_grid)
    nr,nc = lat.shape
    if sill > 1e-4:
        covfct = demKriging.findOptModel(semivar,sill,demKriging.spherical,pixel_size)
        #a = findOptParam(semivar,sill)
        # xx = semivar[:,1]
        # yy = semivar[:,0]
        # x2 = np.linspace(0,xx.max(),1000)
        # y2 = sill-covfct(x2)
        # plt.plot(xx,yy,'o',x2,y2,'-')
        # plt.show()




        n_points = nr*nc
        # estimate K
        N = 4
        Nsq = 16


        N = 4
        Ns = 16
        K = np.zeros((Ns,Ns))
        for k in range(0,Ns):
            for m in range(0,Ns) :
                j = k%N
                i = k/N
                q = m%N
                p = m/N
                K[k,m] = np.sqrt(float(i-p)**2+float(j-q)**2)*pixel_size


        #semivar2 = variograms.semivariogram(P,lags,1e-10)
        K = covfct(K)
        K = K.reshape(Ns,Ns)
        K2 = np.ones((Ns+1,Ns+1))
        K2[:Ns,:Ns] = K
        K2[-1,-1] = 0

        ks,z_term = find_dist_and_dem_vectors(lat,lon,lat_grid,lon_grid,h_grid,grid_size = pixel_size,N=4)
        #semivar2 = variograms.semivariogram(P,lags,1e-10)

        # cast as a matrix
        ks = covfct(ks)

        k2 = np.ones((Nsq+1,n_points))
        k2[:Nsq,:] = ks
        w = np.dot(np.linalg.inv(K2),k2)
        #w2 = np.dot(np.linalg.inv(K),ks)

        est = (w[:-1,:]*z_term).sum(0)
    else:
        est = h_grid.mean()*np.ones((nr,nc))

    #covfct = model.fitmodel(P,model.spherical,lags,1e-8)
    #est2 = (w2*(z_term-dem2.mean())).sum(0) +dem2.mean()
    #est2, kstd = kriging.krige( P, covfct, points , 'ordinary',N=4)
    #print np.linalg.norm(est-est2.flatten())
    return est.reshape(nr,nc)


def computeAlongTrackAndAccrossTrackDirection(p,v):
    """

    :param p: position of sattellite
    :param v: velocity
    :return: (ax,ay,az) along track, accross track and sat-to-earth unit vectors
    """
    az = -p/np.linalg.norm(p)
    alphv = np.inner(v,az)
    x = v-alphv*az
    ax = x/np.linalg.norm(x)
    y = np.cross(az,ax)
    ay = y/np.linalg.norm(y)
    if np.dot(np.cross(ax,ay),az) <0:
        ay = -ay

    return ax, ay, az

def computeViewingAngles(ax,ay,az,viewDirection):
    alpha1 = np.inner(viewDirection,az)
    remain = viewDirection-alpha1*az
    tanalpha = np.linalg.norm(remain)/alpha1
    alpha = np.arctan(tanalpha)*180.0/np.pi
    remain_along = np.inner(remain,ax)
    tanalpha_along = remain_along/alpha1
    alpha_along = np.arctan(tanalpha_along)*180.0/np.pi
    remain_accross = np.inner(remain,ay)
    tanalpha_accross = -remain_accross/alpha1
    alpha_accross = np.arctan(tanalpha_accross)*180.0/np.pi
    return alpha, alpha_along, alpha_accross

def computeSceneViewingAngles(pixel, band, sat_pos,sat_att,sat_vel,year,month,day,hour,minute,sec, microsec,utc_gps,dut1):
    tt = dutil.datetime(year, month, day,hour, minute,sec,microsec)
    JD = tt.to_jd() + utc_gps/(24*60.*60.) #determine julian time from the utc time
    uecef1 = computeUECEF(JD,dut1,pixel,sat_att,band) # look direction
    look_u = uecef1.flatten()
    ax, ay, az = computeAlongTrackAndAccrossTrackDirection(sat_pos,sat_vel)
    alpha, alpha_along, alpha_accross = computeViewingAngles(ax,ay,az,look_u)
    return alpha, alpha_along,alpha_accross


def computeSatAngles(sat_pos,alpha,mid_lat,mid_lon):
    RT = 6378137.0*((1-1./298.257223563)**(1./6.))
    RTh = np.linalg.norm(sat_pos)
    arg = RTh/RT*np.sin(alpha*np.pi/180.0)
    beta = np.arcsin(arg)*180./np.pi
    # print beta
    d2r = np.pi/180.0
    # find satellite nadir point
    u_nadir = -sat_pos/np.linalg.norm(sat_pos)
    earth_surface_position = findEarthSurfacePosition(u_nadir,sat_pos)
    nadir_lat,nadir_lon,h =  irf2latlonV2(earth_surface_position)
    #print lat,lon, h
    x = np.cos(mid_lat*d2r)*np.sin(nadir_lat*d2r) -np.sin(mid_lat*d2r)*np.cos(nadir_lat*d2r)*np.cos((nadir_lon-mid_lon)*d2r)
    y = np.sin((nadir_lon-mid_lon)*d2r)*np.cos(nadir_lat*d2r)
    sat_az = np.arctan2(y,x)/d2r
    sat_alt = RTh- RT
    return beta, sat_az%360, sat_alt


def computeSceneOrientation(mid_lat,mid_lon,mid_height):
    a = 6378137.
    f = 1./298.257223563
    b = a*(1-f)
    d2r = np.pi/180.0
    mid_lat = mid_lat*d2r
    mid_lon = mid_lon*d2r
    r = a*b/np.sqrt((b*np.cos(mid_lat))**2+(a*np.sin(mid_lat))**2)
    ax = -(r+mid_height)*np.sin(mid_lat)*np.cos(mid_lon)
    ay = -(r+mid_height)*np.sin(mid_lat)*np.sin(mid_lon)
    az = r*np.cos(mid_lat)
    north_vec = np.array([ax,ay,az])
    north_vec = north_vec/np.linalg.norm(north_vec)
    ax = -(r+mid_height)*np.cos(mid_lat)*np.sin(mid_lon)
    ay = (r+mid_height)*np.cos(mid_lat)*np.cos(mid_lon)
    az = 0
    east_vec = np.array([ax,ay,az])
    east_vec = east_vec/np.linalg.norm(east_vec)

    return north_vec, east_vec
    #print vec

def earthPositionToPixel(band,year,month,day,hour,mins,sec,microsec,utc_gps,dut1,earth_pos,sat_pos,sat_att):
    tt = dutil.datetime(year,month,day,hour,mins,sec,microsec)
    JD = tt.to_jd()
    JD = JD - utc_gps/(24.*60.*60.)
    uecef =earth_pos-sat_pos
    D = computePrecessionMatrix(JD)
    C = computeNutationMatrix(JD)
    d_phi, d_esp, esp_bar = comNutation2000BLongitude(JD)
    #print d_phi
    d_phi = d_phi*np.pi/180.
    cos_eps = cosd(esp_bar)
    #dut1 = -500.0/1000.0
    B = computeSideRealMatrixCPP(JD,dut1 ,d_phi,cos_eps)
    X = np.dot(B,C)
    X = np.dot(X,D)
    u_eci = np.dot(np.linalg.inv(X),uecef)
    quarternion = sat_att/np.linalg.norm(sat_att)
    q0 = quarternion[0]
    q1 = quarternion[1]
    q2 = quarternion[2]
    q3 = quarternion[3]

    Rq = np.array([[ 1.-2*(q2**2+q3**2)   , 2*(q2*q1-q0*q3)   , 2*(q1*q3+q0*q2) ],\
                  [ 2*(q2*q1+q0*q3)     , 1.-2*(q1**2+q3**2) , 2*(q2*q3-q0*q1) ],\
                  [ 2*(q1*q3-q0*q2)     ,2*(q2*q3+q0*q1)    , 1.-2*(q1**2+q2**2)]])
    ursat = np.dot(np.linalg.inv(Rq),u_eci)
    if band == "PAN":
        roll =  7.77619784614573e-04
        pitch = -3.96157545487306e-04
        yaw = 1.09478530648895e-04
    else:
        roll =  6.5991209596211403e-04
        pitch = -8.30730280198418e-04
        yaw = 2.60531951646004e-06
    # Band 1
    if band == "MS1":
        XLOS =np.array( [-5.64386773737977e+01,1.87603440114033e-02 ,2.51482470613764e-08  ,\
                         -2.81072936768217e-12 ],'float64')/1000.0
        YLOS = np.array( [2.08358226050628e+00, 2.74118683409263e-07 ,1.94869621248422e-10,\
                          -3.14863243948727e-14],'float64')/1000.0
    elif band == "MS2" :
        # Band 2
        XLOS =np.array( [-5.64399703561670e+01 ,1.87596208982883e-02 ,2.55950408827066e-08 ,\
                         -2.85793462006183e-12 ],'float64')/1000.0
        YLOS = np.array( [1.04002614769951e+00,1.59963514942009e-06 ,-3.56440483618224e-10,\
                           2.85698030634138e-14],'float64')/1000.0
    elif band == "MS3":
        # Band 3
        XLOS =np.array( [-5.64396406090353e+01,1.87584774628217e-02, 2.59609656739278e-08 ,\
                         -2.88457756116942e-12],'float64')/1000.0
        YLOS = np.array( [-2.25648281796593e-03, 8.18103975700301e-07 , -6.02722977568500e-11,\
                          -2.10578363971240e-15],'float64')/1000.0

    elif band == "MS4":
        #Band 4
        XLOS =np.array( [-5.64386179785625e+01,1.87524124587818e-02, 2.78767164745339e-08  ,\
                         -3.03848934201707e-12],'float64')/1000.0
        YLOS = np.array( [-1.04660771241013e+00, 3.05951163818994e-07 , 5.60667858453505e-10,\
                          -9.70686921049864e-14],'float64')/1000.0
    elif band == "PAN":
        XLOS =np.array( [-1.34103048970642e+01,2.22032090570242e-03, 3.58240556977001e-09 ,\
                         -1.97809568473004e-13],'float64')/1000.0
        YLOS = np.array( [-2.75975559329229e-03 , 1.71820520179567e-06 , -2.02116761813481e-10,\
                          5.05505016712029e-15],'float64')/1000.0
    Rroll = np.array([[1,0,0],\
             [0, np.cos(roll),-np.sin(roll)],\
             [0,np.sin(roll),np.cos(roll)]])

    Rpitch = np.array([[np.cos(pitch),0,np.sin(pitch)],\
                       [0,1,0],\
                       [-np.sin(pitch),0,np.cos(pitch)]])
    Ryaw = np.array([[np.cos(yaw),-np.sin(yaw),0],\
                     [np.sin(yaw),np.cos(yaw),0],\
                     [0,0,1]])
    Rb = np.dot(np.dot(Ryaw,Rpitch),Rroll)
    u  = np.dot(np.linalg.inv(Rb),ursat)







if __name__ == "__main__" :
    #lata = np.array([])
    #lona = np.linspace(100.5,100.51,100)
    #lat,lon = np.meshgrid(lata,lona)
    #dem = r""
    #lon = np.load(r"D:\Data2APanSharpen\2016-05-27\bridge error\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\lon.npy")
    #lat = np.load(r"D:\Data2APanSharpen\2016-05-27\bridge error\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\lat.npy")
    #rw,cl = lon.shape
    #dem_directory = r"D:\dem\gls"
    dem_dir = r"D:\globedem"
    temp = load_dem_file(13,99,dem_dir)
    temp2 = temp.GetGeoTransform()
    pixel_size = temp2[1]/3600.
    lat = 8.673471
    lon = 99.775102
    lata,lona,ha = load_dem_data([lat+3*pixel_size,lon-3*pixel_size],[lat-3*pixel_size,lon+3*pixel_size],dem_dir)
    print lata,lona, ha

    # sat_post = np.loadtxt(r"D:\Data2APanSharpen\2016-05-27\bridge error\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\GERALD\info\TS1_2016131_39848_022_B1.pos")
    # sat_att = np.loadtxt(r"D:\Data2APanSharpen\2016-05-27\bridge error\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\GERALD\info\TS1_2016131_39848_022_B1.att")
    # sat_time = np.loadtxt(r"D:\Data2APanSharpen\2016-05-27\bridge error\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\GERALD\info\TS1_2016131_39848_022_B1.tim")
    # lat,lon,h = computeViewLatLongArrayWithHeight(1,np.array([4071.522]),np.array([3830.51]),np.array([200]),2392,sat_post, sat_att, sat_time,2016,5,10, -17.0,-0.1)
    # print lat,lon
    # import utm
    # x,y,t1,t2 = utm.from_latlon(lat,lon)
    # f = r"D:\Data2APanSharpen\2016-05-27\bridge error\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\GERALD\output\IMAGERYARTM30.tif"
    # im = gdal.Open(f)
    # geot = im.GetGeoTransform()
    # rw = (y-geot[3])/geot[5]
    # cl = (x-geot[0])/geot[1]
    # print cl,rw
    # exit()
    #
    # dem_directory = r"D:\gdem\gls"
    # lat = 8.998316
    # lon = 99.550047
    # latgrid,longrid,hgrid = load_dem_data([lat+100/3600.,lon-100/3600.],[lat-100/3600.,lon+100/3600.],dem_directory)
    # lat0 = latgrid[0,0]
    # lon0 = longrid[0,0]
    # #print hgrid[6:15,6:15]
    #
    # x,y,t1,t2 = utm.from_latlon(lat,lon)
    #
    # # xg2,yg2 = np.meshgrid(xg,yg)
    # #
    # #
    # # #long2,latg2 = np.meshgrid(lone,late)
    # # xg2 = ((long2-lon0)*3600.).astype('float32')
    # # yg2 = ((lat0-latg2)*3600.).astype('float32')
    # # xg2,yg2
    #
    # cl = 4960
    # rw = 4282
    # #utm.to_latlon()
    # f = r"D:\Data2APanSharpen\2016-05-27\Tested Images\revolution_39848_new\old_product\TH_CAT_160511081330552_1\IMAGERY.tif"
    # im = gdal.Open(f)
    # geot = im.GetGeoTransform()
    # x_old = (cl*15+geot[0])
    # y_old =(rw*(-15)+geot[3])
    #
    # cl = 4960
    # rw = 4276
    # #utm.to_latlon()
    # f = r"D:\Data2APanSharpen\2016-05-27\bridge error\THEOS_1_LEVEL0_1_111039848_39848_MS_PB_TOP_2_22_2016-05-10_03-31-51\GERALD\output\IMAGERY.tif"
    # im = gdal.Open(f)
    # geot = im.GetGeoTransform()
    # x_new = (cl*15+geot[0])
    # y_new =(rw*(-15)+geot[3])
    #
    # print x_old-x_new,y_old-y_new
    # exit()
    #
    # xg = (cl*15+geot[0] + (np.arange(20)-5.)*15).astype('float32')
    # yg = (rw*(-15)+geot[3] - (np.arange(20)-5.)*15).astype('float32')
    # xg2,yg2 = np.meshgrid(xg,yg)
    # xg2 = xg2.astype('float32')
    # yg2 = yg2.astype('float32')
    #
    # import utmLatlon
    # latg2,long2 = utmLatlon.to_latlon(xg2,yg2,t1,t2)
    # hest = interpolateDemGRid(latg2,long2,latgrid,longrid,hgrid,1/3600.)
    # print hest
    # import cv2
    # xg2 = ((long2-lon0)*3600.).astype('float32')
    # yg2 = ((lat0-latg2)*3600.).astype('float32')
    # hest2 = cv2.remap(hgrid,xg2,yg2,cv2.INTER_CUBIC)
    # err =  hest2-hest
    # print err.max(),err.min()
    # yy,xx =np.mgrid[int(yg2.min()):int(yg2.max()+1),int(xg2.min()):int(xg2.max()+1)]
    # print hgrid[yy,xx]
    # #est = interpolateDem(lat,lon,dem_directory)
    # #print est.reshape((rw,cl))

    # tt = dutil.datetime(2015,1,1,3,45,32-16,973323)
    # JD = tt.to_jd()r"
    # #JD = 57023.157048302346+ 2400000.5
    # print JD
    # D = computePrecessionMatrix(JD)
    # #C,d_phi, cos_eps = computeNutationMatrixCPP(JD)
    # C = computeNutationMatrix(JD)
    # d_phi, d_esp, esp_bar = comNutation2000BLongitude(JD)
    # print d_phi
    # d_phi = d_phi*np.pi/180.
    # cos_eps = cosd(esp_bar)
    # dut1 = -459.9090/1000.0  #-0.5
    # B = computeSideRealMatrixCPP(JD,dut1 ,d_phi,cos_eps)
    # X = np.dot(B,C)
    # #X = C
    # X = np.dot(X,D)
    # print D
    # print C
    # print B
    # print np.dot(C,D)
    # print X
    # #X=B
    # # X = np.array([[ -9.18289156e-01,   3.95908019e-01,   1.36622335e-03],\
    # #               [ -3.95907661e-01,  -9.18290171e-01,   5.34458080e-04],\
    # #               [  1.46618571e-03,  -5.01112321e-05,   9.99998924e-01]])
    # # X = np.array([[ -9.18302438e-01,   3.95877211e-01,   1.36609317e-03],\
    # #               [ -3.95876851e-01,  -9.18303453e-01,   5.35773680e-04],\
    # #               [  1.46658866e-03,  -4.88023858e-05,   9.99998923e-01]])
    # X = np.array([[ -9.17826611e-01,   3.96979153e-01,   1.36559719e-03],\
    #               [ -3.96978795e-01,  -9.17827625e-01,   5.36051565e-04],\
    #               [  1.46618412e-03,  -5.01107347e-05,   9.99998924e-01]])
    # #P = np.array([-825874.124326,6724064.035388,2447109.182713])
    # #quar = np.array([0.513241,-0.351701, 0.721899,0.302906])
    # P = np.array([-1285228.146861,6851288.558620,1817656.877501])
    # quar = np.array([0.538054,-0.391109, 0.539261,0.516459])
    # Pm = np.array([-1276786.503229, 6864994.032056,1771544.037509])
    # P = Pm
    # #P1 = np.array([-8.2617937500000000e+05,6.7234620000000000e+06, 2.4486505000000000e+06])
    # #P2 = np.array([-8.2583750000000000e+05, 6.7241360000000000e+06,2.4469250000000000e+06])
    # #q1 = np.array([5.1316964626312256e-01,-3.5175848007202148e-01, 7.2194528579711914e-01, 3.0285006761550903e-01])
    # #q2 = np.array([5.1324927806854248e-01,-3.5169464349746704e-01, 7.2189331054687500e-01, 3.0291223526000977e-01])
    # #t1 = 32.75
    # #t2 = 33.00
    # #t =  32.973323
    # #print P
    # #P = (P2-P1)*(t-t1)/(t2-t1)+P1
    # #print P
    # #print quar
    # #quar = (q2-q1)*(t-t1)/(t2-t1)+q1
    # #print quar
    # tlist = np.arange(-160,-159).astype('float32')/10.0
    # #t = 32.973323
    # t = 37.689724
    # for tu in  tlist :
    #     tin = t+tu
    #     ts = int(np.floor(tin))
    #     tm = int((tin-ts)*1e6)
    #     #tt = dutil.datetime(2015,1,1,3,45,ts,tm)
    #     tt = dutil.datetime(2015,1,2,3,27,ts,tm)
    #     JD = tt.to_jd()
    #     #print tu, ts, tm, JD
    #     uecef = computeUECEF(JD,3000,quar,3)
    #     uecef2 = computeUECEF(JD,np.arange(6000),quar,3)
    #     earth_post = findEarthSurfacePosition(uecef,P)
    #     earth_post2 = findEarthSurfacePosition(uecef2,P)
    #     rx = 1.3078100585937500e+03
    #     ry = 2.0906474609375000e+03
    #     rz = -7.1220117187500000e+03
    #     r = np.array([rx,ry,rz])
    #     ax, ay, az = computeAlongTrackAndAccrossTrackDirection(P,r)
    #     print "ax = ",ax
    #     print "ay = ",ay
    #     print "az = ",az
    #     lat, lon, height = itrf2latlon(earth_post)
    #     lat2, lon2, height2 = itrf2latlon(earth_post2)
    #     sat2scene = earth_post-P
    #     alpha,alpha_along,alpha_accross = computeViewingAngles(ax,ay,az,sat2scene)
    #     print "angles: ",alpha, alpha_along, alpha_accross
    #     print "%f: lon err:%f, lat err: %f"%(tu , lon-99.248840,lat-17.710803)
    #     XA,YA,ZA = latlon2itrf(lat,lon,height)
    #     print "earth position:", earth_post
    #     print "XA:%f, YA:%f, ZA: %f"%(XA,YA,ZA)
    # #print "UECEF:", uecef
    # #earth_post = findEarthSurfacePosition(uecef,P)
    # #lat, lon, height = itrf2latlon(earth_post)
    # #print lon, lat, height
    #
    # #tt = dutil.datetime(2014,1,10,3,45,16,75)
    # #JD = tt.to_jd()
    # #JD = 2457023.656701389
    # exit()
    # #dPsi = computeNutitionLogitude(JD)
    # #dEsp = computeCNutationObliquity(JD)
    # #dPsi2000, dEsp2000,EspMean = comNutation2000BLongitude(JD)
    # #print dPsi, dPsi2000
    # #print dEsp, dEsp2000, EspMean
    # #print JD2GAST(JD)
    # #print JD2GMST(JD)
    # #dlong = computeNutitionLogitude(JD)
    # #dLat = computeCNutationObliquity(JD)
    # #print dlong, dLat
    # #D = computePrecessionMatrix(JD)
    # #print D
    # #C = computeNutationMatrix(JD)
    #
    # #C2 = computeNutationMatrixCPP(JD)
    # #print "C:", C
    # #print "C2:", C2[2]*180./np.pi
    # #B = computeSiderealMatrix(JD)
    # #B2 = computeSideRealMatrixCPP(JD,-0.459949,03.,45.,38.999989628791809, -3.37053589593e-05,0.921110392071)
    # #print B
    # #print B2
    # P =np.array([-817248.375, 6740815., 2403721.0])
    # quar = [0.515303, -0.350044,0.720557, 0.304516]
    # uecef = computeUECEF(JD,3000,quar)
    # print "UECEF:", uecef
    # earth_post = findEarthSurfacePosition(uecef,P)
    # lat, lon, height = itrf2latlon(earth_post)
    # print lon, lat, height
    # P1 = np.array([-1.6868005000000000e+06, 6.6144790000000000e+06,2.2995780000000000e+06])
    # t1 = 31.250000
    # P2 = np.array([-1.6865340000000000e+06, 6.6151540000000000e+06,2.2978385000000000e+06])
    # t2= 31.500000
    # P3 = np.array([-1.6862712500000000e+06, 6.6158290000000000e+06,2.2960990000000000e+06])
    # t3 = 31.750000
    # P4 = np.array([-1.6860082500000000e+06, 6.6165030000000000e+06,2.2943590000000000e+06])
    # t4 = 32.000000
    # P5 = np.array([-1.6857442500000000e+06,  6.6171740000000000e+06,2.2926190000000000e+06])
    # t5 = 32.250000
    # P6 = np.array([-1.6854775000000000e+06,  6.6178480000000000e+06,2.2908785000000000e+06])
    # t6 = 32.500000
    # P7 = np.array([-1.6852140000000000e+06,  6.6185220000000000e+06,2.2891380000000000e+06])
    # t7 = 32.750000
    # P8 = np.array([-1.6849507500000000e+06,  6.6191930000000000e+06,2.2873980000000000e+06])
    # t8 = 33.000000
    # P = [P1, P2, P3, P4, P5,P6,P7, P8]
    # T = [t1, t2, t3, t4, t5, t6, t7, t8]
    # tk = 32.114704
    # Post = estimageLensePostion(P, T,tk)
    # print Post
    # #JD = 2456671.63709 +(0.6367+1.6000000000000000e+01+1.0000000149011612e-01)/(24.*60.*60.)
    # #Post = [-1.6264092500000000e+06, 6.5988430000000000e+06, 2.3395440000000000e+06]
    # #print Post
    # JD =2456671.63718 + (0.114704-1.6000000000000000e+01-1.0000000149011612e-01)/(24.*60.*60.)
    # #quar = [-3.8320046663284302e-01, 5.1414871215820312e-01, -6.2684822082519531e-01, -4.4257199764251709e-01]
    # quar = [-3.8311737775802612e-01,5.1420402526855469e-01,-6.2690043449401855e-01,-4.4250589609146118e-01]
    # #quar = [-3.8099020719528198e-01,5.1562416553497314e-01,-6.2822294235229492e-01, -4.4081103801727295e-01]
    # uecef = computeUECEF(JD,3000,quar)
    # print "UECEF:", uecef
    # earth_post = findEarthSurfacePosition(uecef,Post)
    # lat, lon, height = itrf2latlon(earth_post)
    # print  lat, lon,  height






